/**
 * ctc_loss_layer.h
 * Author: baijinfeng (baijinfeng@conew.com)
 * Created on: 2016-08-01
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include <new>
#include <algorithm>
#include "activation.h"
#include "ctc_loss_layer.h"
#include "util.h"

namespace houyi {
namespace train {

CtcLossLayer* CtcLossLayer::clone() {
    CtcLossLayer* ly = new CtcLossLayer(_cfg);
    return ly;
}

void CtcLossLayer::insert_blank(std::vector<int>& labels) {
    std::vector<int> tmp_labels(labels); //copy of none blank list
    labels.clear();
    int n = tmp_labels.size();
    labels.resize(2 * n + 1);

    for (int i = 0; i < n; i++) {
        labels[2 * i] = _blank_index;
        labels[2 * i + 1] = tmp_labels[i];
    }

    labels[2 * n] = _blank_index;
}

void CtcLossLayer::remove_blank(std::vector<int>& labels) {
    std::vector<int> tmpLabels(labels); //copy of none blank list
    labels.clear();

    for (size_t i = 0; i < tmpLabels.size(); i++) {
        if (tmpLabels[i] != _blank_index) {
            labels.push_back(tmpLabels[i]);
        }
    }
}

void CtcLossLayer::cal_target(std::vector<IOPackage*>& output,
                              std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {

    CHECK2(output[0] && label[0] && target[0]);
    size_t h = output[0]->get_height();
    size_t w = output[0]->get_width();
    target[0]->resize(Dim(h, w), output[0]->get_mask(), gpu_device());
    _log_in_gpu.resize(output[0]->get_ten()->get_size());

    _loss->clear();
    target[0]->copy_from(*output[0]);
    _log_in_gpu.copy_from(*output[0]->get_ten());

    _real_sample_count = get_real_sample_num(*label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_ignore_label());
}

void CtcLossLayer::cal_loss(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);

    if (_prior) {
        _log_in_gpu.log_sub_prior(*_prior);
    }

    get_ctc_error_parallel(*label[0]->get_mask(),
                           *label[0]->get_ten(), *output[0]->get_ten(),
                           _log_in_gpu, *loss[0]->get_ten());
#ifdef __GRADIENT_NORM__
    loss[0]->get_ten()->mul(_cfg.get_loss_weight() / _sample_num);
#else
    loss[0]->get_ten()->mul(_cfg.get_loss_weight());
#endif
    //*** CTC PREDICT ****////////////////////////////////////////////////////////////////////////////////////////////
    //write_ctc_score(*label[0]->get_ten(), *output[0]->get_ten(), _log_in_gpu, *loss[0]->get_ten());
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}

Loss& CtcLossLayer::get_cost_value(TGT_COST_TYPE type) {
    switch (type) {
    case TGT_ACU:
    case TGT_ERR:
        cal_result();
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    return *_loss;
}

void CtcLossLayer::cal_result() {
    CtcLoss* loss = dynamic_cast<CtcLoss*>(_loss);

    size_t tt_frames = output(_output_keys[0]).get_ten()->get_height();
    Tensor<int> cu_max_ids(Dim(tt_frames), gpu_device());
    output(_output_keys[0]).get_ten()->find_row_max_id(cu_max_ids);
    Tensor<int> max_ids(Dim(tt_frames), cpu_device());
    max_ids.copy_from(cu_max_ids);

    for (int s = 0; s < _sample_num; s++) {
        std::vector<int> hyp(_frame_num_utt[s]);

        for (int f = 0; f < _frame_num_utt[s]; f++) {
            hyp[f] = max_ids.get_element(Dim(f * _sample_num + s));
        }

        hyp.erase(std::unique(hyp.begin(), hyp.end()), hyp.end());
        hyp.erase(std::remove(hyp.begin(), hyp.end(), _blank_index), hyp.end());

        std::vector<ItemPair> res = lcs_valueing(_formatted_labels[s], hyp);
        stat_wer(res, _formatted_labels[s], *loss);
    }

    //
    DType total_pzx = 0.0;

    for (size_t i = 0; i < _host_pzx.get_size(0); i++)  {
        total_pzx += _host_pzx.get_element(Dim(i));
    }

    loss->set_log_pzx(total_pzx);
    loss->set_log_lh(-total_pzx);
    loss->set_frame_counter(_real_sample_count);
    loss->set_sample_counter(_sample_num);
}

void CtcLossLayer::debug_error(const Tensor<int>& mask, const Tensor<DType>& label,
                               Tensor<DType>& in, Tensor<DType>& in_prior, Tensor<DType>& out) {
    Tensor<DType> out1;
    DType log_like1 = get_ctc_error(mask, label, in, in_prior, out1);

    Tensor<DType> out2;
    DType log_like2 = get_ctc_error_v2(mask, label, in, in_prior, out2);

    std::cout << "logLike1: " << log_like1 << std::endl;
    std::cout << "logLike2: " << log_like2 << std::endl;

    for (int ii = 0; ii < (int)out1.get_height(); ii++) {
        for (int jj = 0; jj < (int)out1.get_width(); jj++) {
            float o_data1 = out1.get_element(Dim(ii, jj));
            float o_data2 = out2.get_element(Dim(ii, jj));

            if (fabs(o_data1 - o_data2) < FLT_EPSILON) {
                std::cout << "The element (" << ii << ", " << jj
                          << ") in mat(" << out1.get_height() << ", " << out1.get_width();
                std::cout << ") is: " << o_data1 << "\t" << o_data2 << std::endl;
            }
        }
    }

    std::cout << "done." << std::endl;
}

DType CtcLossLayer::get_vtb_error(const Tensor<int>& mask, 
        const Tensor<DType>& label, Tensor<DType>& in,
        Tensor<DType>& in_prior, Tensor<DType>& out) {

    out.resize(Dim(in.get_height(), in.get_width()));
    out.zero();
    out.elem_add(out, in, 1.0f, -1.0f);
    
    _cpu_mask.resize(mask.get_size());
    _cpu_mask.copy_from(mask);
    for (int ii = 0; ii < (int)in.get_height(); ii++) {
        if (_cpu_mask.get_data()[ii] == 0) {
        //if ((int)label.get_element(Dim(ii, 0)) == -1) {
            //no error backprop
            out.range_row(ii, ii + 1).zero();
        }
    }

    DType log_like = 0.0;
    std::vector<int> label_vec;
    CHECK2(in.get_height() == label.get_size(0));
    int len = (int)in.get_height() / _sample_num;

    for (int ii = 0; ii < _sample_num; ii++) {
        label_vec.clear();

        for (int jj = 0; jj < len; jj++) {
            if (mask.get_element(Dim(jj * _sample_num + ii))) {
                label_vec.push_back((int)label.get_element(Dim(jj * _sample_num + ii, 0)));
            }
        }

        if (label_vec.size() == 0) {
            continue;
        } else {
            //1. convert to sentence uniq phone sequence, (eg. a a a b b b a a --> a b a)
            int num_frame = (int)label_vec.size();
            std::vector<int>::iterator it = std::unique(label_vec.begin(), label_vec.end());
            label_vec.erase(it, label_vec.end());

            //2. insert blank label
            //remove_blank(label_vec);
            //insert_blank(label_vec);
            int num_state = (int)label_vec.size();

            _alpha.resize(Dim(num_frame, num_state));
            _alpha.set_element(_log_zero);
            _prev.resize(Dim(num_frame, num_state));
            _prev.set_element(-1);
            std::vector<int> bestPath(num_frame);

            //3. forward
            _alpha.set_element(Dim(0, 0), in_prior.get_element(Dim(ii, label_vec[0])));

            //_alpha.set_element(in_prior.get_element(ii, label_vec[1]), 0, 1);
            for (int tt = 1; tt < num_frame; tt++) {
                int st = 0;
                int ed = num_state;

                for (int ss = st; ss < ed; ss++) {
                    DType max = _alpha.get_element(Dim(tt - 1, ss));
                    int max_idx = ss;

                    if (ss >= 1) {
                        if (_alpha.get_element(Dim(tt - 1, ss - 1)) > max) {
                            max = _alpha.get_element(Dim(tt - 1, ss - 1));
                            max_idx = ss - 1;
                        }
                    }

                    float v = max + in_prior.get_element(Dim(tt * _sample_num + ii, label_vec[ss]));
                    _alpha.set_element(Dim(tt, ss), v);
                    _prev.set_element(Dim(tt, ss), max_idx);
                }
            }

            //4. backward
            double best_score = _alpha.get_element(Dim(num_frame - 1, num_state - 1));
            bestPath[num_frame - 1] = num_state - 1;

            for (int tt = num_frame -  2; tt >= 0; tt--) {
                bestPath[tt] = _prev.get_element(Dim(tt + 1, bestPath[tt + 1]));
            }

            //6. calc outDiff
            for (int tt = 0; tt < num_frame; tt++) {
                int state_id = label_vec[bestPath[tt]];

                DType o_data = out.get_element(Dim(tt * _sample_num + ii, state_id));
                out.set_element(Dim(tt * _sample_num + ii, state_id), 1.0 + o_data);
            }

            log_like += best_score;
        }
    }

    return log_like;
}

DType CtcLossLayer::get_ctc_error(const Tensor<int>& mask, const Tensor<DType>& label,
                                  Tensor<DType>& in, Tensor<DType>& in_prior, Tensor<DType>& out) {
    size_t tt_frames = in.get_height();
    size_t tt_class = in.get_width();
    CHECK2(tt_frames == in_prior.get_height());
    CHECK2(tt_frames == label.get_size(0));

    _cpu_label_vec.resize(label.get_size());
    _cpu_label_vec.copy_from(label);
    out.resize(Dim(tt_frames, tt_class));
    out.elem_add(out, in, 0.0f, -1.0f);
    
    _cpu_mask.resize(mask.get_size());
    _cpu_mask.copy_from(mask);
    for (int ii = 0; ii < (int)in.get_height(); ii++) {
        if (_cpu_mask.get_data()[ii] == 0) {
        //if (_cpu_label_vec.get_element(Dim(ii, 0)) == -1) {
            out.range_row(ii, ii + 1).zero();
        }
    }

    // All computation in CPU
    //_log_in.resize(Dim(tt_frames, tt_class));
    _host_out.resize(Dim(tt_frames, tt_class));
    //_log_in.copy_from(in_prior);
    _host_out.copy_from(out);

    DType log_like = 0.0;
    int len = tt_frames / _sample_num;

    for (int ii = 0; ii < _sample_num; ii++) {
        std::vector<int> label_vec;

        for (int jj = 0; jj < len; jj++) {
            if (_cpu_mask.get_data()[jj * _sample_num + ii] == 0) {
            // if (_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)) == -1) {
                break;
            }

            label_vec.push_back(_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)));
        }

        if (label_vec.size() == 0) {
            continue;
        }

        //1. Deal with (a a a 0 a a b b b 0 0 0 a a --> a 0 a b 0 a)
        int num_frame = (int)label_vec.size();
        std::vector<int>::iterator it = unique(label_vec.begin(), label_vec.end());
        label_vec.erase(it, label_vec.end());

        //2. Deal with (0 a 0 0 0 a 0 b 0 0 0 a 0 --> 0 a 0 a 0 b 0 a 0)
        insert_blank(label_vec);
        it = unique(label_vec.begin(), label_vec.end());
        label_vec.erase(it, label_vec.end());

        int num_state = (int)label_vec.size();
        _alpha.resize(Dim(num_frame, num_state));
        _beta.resize(Dim(num_frame, num_state));
        _alpha.set_element(_log_zero);
        _beta.set_element(_log_zero);

        //3. forward
        _alpha.set_element(Dim(0, 0), in_prior.get_element(Dim(ii, label_vec[0])));
        _alpha.set_element(Dim(0, 1), in_prior.get_element(Dim(ii, label_vec[1])));

        for (int tt = 1; tt < num_frame; tt++) {
            int st = std::max(0, num_state - 2 * (num_frame - tt));
            int ed = std::min(2 * (tt + 1), num_state);

            for (int ss = st; ss < ed; ss++) {
                DType sum = _alpha.get_element(Dim(tt - 1, ss));

                if (ss >= 1) {
                    sum = log_sum_exp(sum, _alpha.get_element(Dim(tt - 1, ss - 1)), false);
                }

                if (ss >= 2 && ss % 2 == 1 && label_vec[ss] != label_vec[ss - 2]) {
                    sum = log_sum_exp(sum, _alpha.get_element(Dim(tt - 1, ss - 2)), false);
                }

                float t = in_prior.get_element(Dim(tt * _sample_num + ii, label_vec[ss]));
                _alpha.set_element(Dim(tt, ss), sum + t);
            }
        }

        //4. backward
        _beta.set_element(Dim(num_frame - 1, num_state - 1), 0.0);
        _beta.set_element(Dim(num_frame - 1, num_state - 2), 0.0);

        for (int tt = num_frame - 2; tt >= 0; tt--) {
            int st = std::max(0, num_state - 2 * (num_frame - tt));
            int ed = std::min(2 * (tt + 1), num_state) - 1;

            for (int ss = ed; ss >= st; ss--) {
                DType sum = _beta.get_element(Dim(tt + 1, ss)) +
                            in_prior.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss]));

                if (ss < num_state - 1) {
                    float y = _beta.get_element(Dim(tt + 1, ss + 1)) +
                              in_prior.get_element(Dim((tt + 1) * _sample_num + ii,  label_vec[ss + 1]));
                    sum = log_sum_exp(sum, y, false);
                }

                if (ss < num_state - 2 && ss % 2 == 1 && label_vec[ss] != label_vec[ss + 2]) {
                    float y = _beta.get_element(Dim(tt + 1, ss + 2)) +
                              in_prior.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss + 2]));
                    sum = log_sum_exp(sum, y, false);
                }

                _beta.set_element(Dim(tt, ss), sum);
            }
        }

        //5. Get kOutput (0 a 0 a 0 b 0 a 0 --> 0 a b)
        std::vector<int> kOutput(label_vec);
        sort(kOutput.begin(), kOutput.end());
        it = unique(kOutput.begin(), kOutput.end());
        kOutput.erase(it, kOutput.end());

        int num_k = kOutput.size();
        std::vector< std::vector<int> > k_label_pos;
        k_label_pos.resize(num_k);

        for (int k = 0; k < num_k; k++) {
            for (int s = 0; s < num_state; s++) {
                if (kOutput[k] == label_vec[s]) {
                    k_label_pos[k].push_back(s);
                }
            }
        }

        //6. calc outDiff
        std::vector<float> zt_vec(num_frame, 0);

        for (int tt = 0; tt < num_frame; tt++) {
            zt_vec[tt] = _log_zero;

            for (int ss = 0; ss < num_state; ss++) {
                zt_vec[tt] = log_sum_exp(zt_vec[tt],
                                         _alpha.get_element(Dim(tt, ss)) + _beta.get_element(Dim(tt, ss)), false);
            }

            for (int kk = 0; kk < num_k; kk++) {
                DType alpha_beta = _log_zero;

                for (int pp = 0; pp < (int)k_label_pos[kk].size(); pp++) {
                    float y = _alpha.get_element(Dim(tt, k_label_pos[kk][pp]))
                              + _beta.get_element(Dim(tt, k_label_pos[kk][pp]));
                    alpha_beta = log_sum_exp(alpha_beta, y, false);
                }

                DType t_data = exp(alpha_beta - zt_vec[tt]);
                DType o_data = _host_out.get_element(Dim(tt * _sample_num + ii, kOutput[kk]));
                _host_out.set_element(Dim(tt * _sample_num + ii, kOutput[kk]), t_data + o_data);
            }
        }

        log_like += zt_vec[0];
    }

    out.copy_from(_host_out);

    return -log_like;
}

DType CtcLossLayer::get_ctc_error_v2(const Tensor<int>& mask, const Tensor<DType>& label,
                                     Tensor<DType>& in, Tensor<DType>& in_prior, Tensor<DType>& out) {
    CtcLoss* loss = dynamic_cast<CtcLoss*>(_loss);

    size_t tt_class = in.get_width();
    size_t tt_frames = in.get_height();
    CHECK2(tt_frames == in_prior.get_height());
    CHECK2(tt_frames == label.get_size(0));

    // All computation in CPU
    _cpu_label_vec.resize(label.get_size());
    _cpu_label_vec.copy_from(label);
    out.resize(Dim(tt_frames, tt_class));
    out.elem_add(out, in, 0.0f, -1.0f);

    _cpu_mask.resize(mask.get_size());
    _cpu_mask.copy_from(mask);
    for (int ii = 0; ii < (int)in.get_height(); ii++) {
        if (_cpu_mask.get_data()[ii] == 0) {
        // if (_cpu_label_vec.get_element(Dim(ii, 0)) == -1) {
            out.range_row(ii, ii + 1).zero();
        }
    }

    //_log_in.resize(Dim(tt_frames, tt_class));
    //_log_in.copy_from(in_prior);
    _host_out.resize(Dim(tt_frames, tt_class));
    _host_out.copy_from(out);

    loss->set_local_rate(_sample_num);

    DType log_like = 0.0;
    int utt_len = tt_frames / _sample_num;

    for (int ii = 0; ii < _sample_num; ii++) {
        std::vector<int> fix_label_vec;

        for (int jj = 0; jj < utt_len; jj++) {
            if (_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)) == -1) {
                break;
            }

            fix_label_vec.push_back(_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)));
        }

        int num_frame = (int)fix_label_vec.size();

        if (num_frame == 0) {
            continue;
        }

        std::vector<int> ctc_label_vec;
        get_syllable_ctc_label(fix_label_vec, ctc_label_vec);

        std::vector<int> ref;
        get_ref(ctc_label_vec, ref);

        std::vector<int> hyp_org, hyp;
        best_decode(in_prior, ii, num_frame, hyp_org);
        get_hyp(hyp_org, hyp);

        std::vector<ItemPair> res = lcs_valueing(ref, hyp);
        //DType wer = stat_wer(res, ref);
        DType wer = 0.0f;

        /* For log more information */
        //write_result(fix_label_vec, ref, hyp_org, hyp);

        if (_local_ctc == true) {
            int flag_1 = 0;
            int flag_2 = 0;
            std::vector< std::vector<int> > local_path;

            if (wer <= 0.3) {
                std::vector< std::pair<int, int> > pos_pair;
                get_label_map(hyp_org, pos_pair);
                get_local_path(res, pos_pair, local_path);
                flag_1 = calc_alpha(in_prior, ii, num_frame, ctc_label_vec, local_path);
                flag_2 = calc_beta(in_prior, ii, num_frame, ctc_label_vec, local_path);
            }

            if (flag_1 != 0 || flag_2 != 0 || wer > 0.3) {
                calc_alpha(in_prior, ii, num_frame, ctc_label_vec);
                calc_beta(in_prior, ii, num_frame, ctc_label_vec);
                loss->set_local_rate(loss->get_local_rate() - 1);
            }

            log_like += calc_diff(_host_out, ii, num_frame, ctc_label_vec, local_path);
        } else {
            loss->set_local_rate(loss->get_local_rate() - 1);
            calc_alpha(in_prior, ii, num_frame, ctc_label_vec);
            calc_beta(in_prior, ii, num_frame, ctc_label_vec);
            log_like += calc_diff(_host_out, ii, num_frame, ctc_label_vec);
        }
    }

    out.copy_from(_host_out);
    loss->set_log_lh(-log_like);

    return -log_like;
}

void CtcLossLayer::get_ctc_error_parallel(const Tensor<int>& mask,
        const Tensor<DType>& label,
        Tensor<DType>& in, Tensor<DType>& in_prior, Tensor<DType>& out) {
    size_t tt_frames = in.get_height();
    size_t tt_class = in.get_width();
    CHECK2(tt_frames == in_prior.get_height());
    CHECK2(tt_frames == label.get_size(0));

    _cpu_label_vec.resize(label.get_size());
    _cpu_label_vec.copy_from(label);

    int num_frames_per_sequence = tt_frames / _sample_num;

    // frame number of each sequence
    _frame_num_utt.clear();
    _frame_num_utt.resize(_sample_num);
    // reformatted labels
    _formatted_labels.resize(_sample_num);

    for (int i = 0; i < _sample_num; i++) {
        _formatted_labels[i].clear();
    }
    
    _cpu_mask.resize(mask.get_size());
    _cpu_mask.copy_from(mask);
    for (int i = 0; i < num_frames_per_sequence; i++) {
        for (int j = 0; j < _sample_num; j++) {
            if (_cpu_mask.get_data()[i * _sample_num + j]) {
                _formatted_labels[j].push_back(_cpu_label_vec.get_element(Dim(i * _sample_num + j, 0)));
                _frame_num_utt[j]++;
            }
        }
    }

    // remove blank
    for (int i = 0; i < _sample_num; i++) {
        _formatted_labels[i].erase(std::unique(_formatted_labels[i].begin(),
                                               _formatted_labels[i].end()), _formatted_labels[i].end());
        _formatted_labels[i].erase(std::remove(_formatted_labels[i].begin(),
                                               _formatted_labels[i].end(), _blank_index), _formatted_labels[i].end());
    }

    int max_label_len = 0;

    for (int s = 0; s < _sample_num; s++) {
        if (_formatted_labels[s].size() > (size_t)max_label_len) {
            max_label_len = _formatted_labels[s].size();
        }
    }

    // insert blank
    std::vector<int> label_lengths_utt(_sample_num);
    int exp_len_labels = 2 * max_label_len + 1;
    std::vector<int> label_expand(_sample_num * exp_len_labels, -1);

    for (int s = 0; s < _sample_num; s++) {
        std::vector<int> label_s = _formatted_labels[s];
        label_lengths_utt[s] = 2 * label_s.size() + 1;

        for (size_t l = 0; l < label_s.size(); l++) {
            label_expand[s * exp_len_labels + 2 * l] = _blank_index;
            label_expand[s * exp_len_labels + 2 * l + 1] = label_s[l];
        }

        label_expand[s * exp_len_labels + 2 * label_s.size()] = _blank_index;
    }

    _device_alpha.resize(Dim(tt_frames, exp_len_labels));
    _device_beta.resize(Dim(tt_frames, exp_len_labels));
    _device_alpha.set_element(_log_zero);
    _device_beta.set_element(_log_zero);

    // copy host to device
    Tensor<int> cu_labels(Dim(label_expand.size()), gpu_device());
    Tensor<int> cu_frm_num_utt(Dim(_frame_num_utt.size()), gpu_device());
    Tensor<int> cu_label_lens_utt(Dim(label_lengths_utt.size()), gpu_device());

    cu_labels.copy_from(&label_expand[0], 0, label_expand.size());
    cu_frm_num_utt.copy_from(&_frame_num_utt[0], 0, _frame_num_utt.size());
    cu_label_lens_utt.copy_from(&label_lengths_utt[0], 0, label_lengths_utt.size());

    // computing alpha
    for (int t = 0; t < num_frames_per_sequence; t++) {
        _device_alpha.compute_ctc_alpha(in_prior, t, cu_labels, cu_frm_num_utt, cu_label_lens_utt);
    }

    // computing beta
    for (int t = (num_frames_per_sequence - 1); t >= 0; t--) {
        _device_beta.compute_ctc_beta(in_prior, t, cu_labels, cu_frm_num_utt, cu_label_lens_utt);
    }


    // computing pzx
    _device_pzx.resize(Dim(_sample_num));
    //CpuVector<DType> host_pzx(_device_pzx._size);
    _host_pzx.resize(Dim(_device_pzx._size));

    for (int s = 0; s < _sample_num; s++) {
        int label_len = label_lengths_utt[s];
        int frame_num = _frame_num_utt[s];

        if (frame_num > 0 && label_len > 1) {
            DType tmp1 = _device_alpha.get_element(Dim((frame_num - 1) * _sample_num + s, label_len - 1)),
                  tmp2 = _device_alpha.get_element(Dim((frame_num - 1) * _sample_num + s, label_len - 2));
            _host_pzx.set_element(Dim(s), log_sum_exp(tmp1, tmp2, false));
        }
    }

    _device_pzx.copy_from(_host_pzx);

    // computing ctc errs
    out.resize(Dim(tt_frames, tt_class));
    out.compute_ctc_err(_device_alpha, _device_beta, cu_labels, cu_frm_num_utt, _device_pzx);
    out.elem_add(out, in, 1.0, -1.0);
    out.vec_mask(out, mask);
}

void CtcLossLayer::write_ctc_score(const Tensor<int>& mask, const Tensor<DType>& label,
                                   Tensor<DType>& in, Tensor<DType>& in_prior, Tensor<DType>& out) {
    size_t tt_class = in.get_width();
    size_t tt_frames = in.get_height();
    int utt_len = tt_frames / _sample_num;

    _log_in.resize(Dim(tt_frames, tt_class));
    _log_in.copy_from(in_prior);
    _cpu_label_vec.resize(Dim(tt_frames, 1));
    _cpu_label_vec.copy_from(label);

    _cpu_mask.resize(mask.get_size());
    _cpu_mask.copy_from(mask);

    for (int ii = 0; ii < _sample_num; ii++) {
        std::vector<int> fix_label_vec;

        for (int jj = 0; jj < utt_len; jj++) {
            if (_cpu_mask.get_data()[jj * _sample_num + ii] == 0) {
            //if (_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)) == -1) {
                break;
            }

            fix_label_vec.push_back(_cpu_label_vec.get_element(Dim(jj * _sample_num + ii, 0)));
        }

        Tensor<DType> tmp_out {cpu_device()};
        tmp_out.resize(Dim(fix_label_vec.size(), tt_class));

        char score_name[1024];

        for (size_t jj = 0; jj < fix_label_vec.size(); jj++) {
            memcpy(tmp_out.get_row(jj), _log_in.get_row(jj * _sample_num + ii), sizeof(float) * tt_class);
        }

        sprintf(score_name, "./score_files/%04d.score", _sent_id);
        FILE* fptr = fopen(score_name, "w+");
        //ofstream out_score;
        //out_score.open(score_name);
        tmp_out.write(fptr, 0);
        //out_score.close();
        fclose(fptr);
        std::cout << "write score to file: " << score_name << std::endl;
        _sent_id++;
    }

    out.resize(Dim(tt_frames, tt_class));
    out.zero();

}
void CtcLossLayer::stat_wer(std::vector<ItemPair>& res, std::vector<int>& ref, CtcLoss& loss) {
    int ins = 0;
    int sub = 0;
    int del = 0;

    for (size_t i = 0; i < res.size(); i++) {
        if (res[i].first._value == -1) {
            ins++;
            continue;
        }

        if (res[i].second._value == -1) {
            del++;
            continue;
        }

        if (res[i].first._value != res[i].second._value) {
            sub++;
            continue;
        }
    }

    loss.set_ins_len(ins);
    loss.set_del_len(del);
    loss.set_sub_len(sub);
    loss.set_wer_len(ins + del + sub);
    loss.set_ref_len((int)ref.size());
}

void CtcLossLayer::write_result(const std::vector<int>& fix_label_vec,
                                const std::vector<int>& ref, const std::vector<int>& hyp_org, const std::vector<int>& hyp) {
    _num_utt++;
    pid_t tid = syscall(SYS_gettid);

    printf("Pid%u_Fix_label_vec_%6d:", tid, _num_utt);

    for (size_t jj = 0; jj < fix_label_vec.size(); jj++) {
        printf("\t%d", fix_label_vec[jj]);
    }

    printf("\n");

    printf("Pid%u_Ref_label_vec_%6d:", tid,  _num_utt);

    for (size_t jj = 0; jj < ref.size(); jj++) {
        printf("\t%d", ref[jj]);
    }

    printf("\n");

    printf("Pid%u_Hyp_org_label_vec_%6d:", tid, _num_utt);

    for (size_t jj = 0; jj < hyp_org.size(); jj++) {
        printf("\t%d", hyp_org[jj]);
    }

    printf("\n");

    printf("Pid%u_Hyp_label_vec_%6d:", tid, _num_utt);

    for (size_t jj = 0; jj < hyp.size(); jj++) {
        printf("\t%d", hyp[jj]);
    }

    printf("\n");
}

void CtcLossLayer::get_syllable_ctc_label(const std::vector<int>& fix_label_vec,
        std::vector<int>& ctc_label_vec) {
    //Deal with (a a a 0 a a b b b 0 0 0 a a --> a 0 a b 0 a)
    ctc_label_vec = fix_label_vec;
    std::vector<int>::iterator it = unique(ctc_label_vec.begin(), ctc_label_vec.end());
    ctc_label_vec.erase(it, ctc_label_vec.end());

    //Deal with (0 a 0 0 0 a 0 b 0 0 0 a 0 --> 0 a 0 a 0 b 0 a 0)
    insert_blank(ctc_label_vec);
    it = unique(ctc_label_vec.begin(), ctc_label_vec.end());
    ctc_label_vec.erase(it, ctc_label_vec.end());
}

void CtcLossLayer::get_local_path(std::vector<ItemPair>& res,
                                  std::vector< std::pair<int, int> >& pos_pair, std::vector< std::vector<int> >& local_path) {
    std::vector<int> triple_item;

    for (size_t i = 0; i < res.size(); i++) {
        if (res[i].first._value == res[i].second._value && res[i].first._value != -1) {
            triple_item.clear();
            int ss = 2 * (res[i].first._idx) + 1;
            CHECK2(res[i].second._idx < (int)pos_pair.size());
            int tt_start = pos_pair[res[i].second._idx].first;
            int tt_end = pos_pair[res[i].second._idx].second;
            triple_item.push_back(ss);
            triple_item.push_back(tt_start);
            triple_item.push_back(tt_end);
            local_path.push_back(triple_item);
        }
    }
}

void CtcLossLayer::get_label_map(const std::vector<int>& hyp_org,
                                 std::vector< std::pair<int, int> >& pos_pair) {
    int cur_id = 0;

    for (int i = 1; i < (int)hyp_org.size(); i++) {
        if (hyp_org[i - 1] == hyp_org[i]) {
            continue;
        }

        if (hyp_org[i - 1] != _blank_index) {
            std::pair<int, int> rr = std::pair<int, int>(cur_id, i - 1);
            pos_pair.push_back(rr);
        }

        cur_id = i;
    }

    if (hyp_org.back() != _blank_index) {
        std::pair<int, int> rr = std::pair<int, int>(cur_id, hyp_org.size() - 1);
        pos_pair.push_back(rr);
    }
}

void CtcLossLayer::best_decode(Tensor<DType>& log_in, int ii, int num_frame,
                               std::vector<int>& hyp) {
    int num_class = log_in.get_width();

    for (int tt = 0; tt < num_frame; tt++) {
        int tt_id = -1;
        DType tt_max = _log_zero;

        for (int kk = 0; kk < num_class; kk++) {
            DType o_data = log_in.get_element(Dim(tt * _sample_num + ii, kk));

            if (o_data > tt_max) {
                tt_max = o_data;
                tt_id = kk;
            }
        }

        hyp.push_back(tt_id);
    }
}

int CtcLossLayer::calc_alpha(Tensor<DType>& log_in, int ii, int num_frame,
                             std::vector<int>& label_vec) {
    int num_state = label_vec.size();
    _alpha.resize(Dim(num_frame, num_state));
    _alpha.set_element(_log_zero);

    _alpha.set_element(Dim(0, 0), log_in.get_element(Dim(ii, label_vec[0])));
    _alpha.set_element(Dim(0, 1), log_in.get_element(Dim(ii, label_vec[1])));
    calc_std_alpha(log_in, ii, label_vec, 0, num_frame, 0, num_state);

    return 0;
}

int CtcLossLayer::calc_alpha(Tensor<DType>& log_in, int ii, int num_frame,
                             std::vector<int>& label_vec, std::vector< std::vector<int> >& local_path) {
    if (local_path.empty()) {
        INTER_LOG("Warning: empty label in local_path.\n");
        return -1;
    }

    int num_state = label_vec.size();
    _alpha.resize(Dim(num_frame, num_state));
    _alpha.set_element(_log_zero);

    if (calc_local_alpha_st(log_in, ii, label_vec, local_path.front())) {
        return -1;
    }

    for (int i = 0; i < (int)local_path.size() - 1; i++) {
        if (calc_local_alpha(log_in, ii, label_vec, local_path[i], local_path[i + 1])) {
            return -1;
        }
    }

    if (calc_local_alpha_ed(log_in, ii, label_vec, num_frame, local_path.back())) {
        return -1;
    }

    return 0;
}

int CtcLossLayer::calc_local_alpha_st(Tensor<DType>& log_in, int ii,
                                      std::vector<int>& label_vec, std::vector<int> triple_st) {
    // Deal with exception case
    if (triple_st[0] > 2 * triple_st[1] + 1) {
        INTER_LOG("Warning [losing label at head]: (ss:%d, tt:%d)", triple_st[0], triple_st[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (triple_st[0] == 1 && triple_st[1] == 0) {
        _alpha.set_element(Dim(0, 1), log_in.get_element(Dim(ii, label_vec[triple_st[0]])));
        calc_std_alpha(log_in, ii, label_vec, triple_st[1], triple_st[2] + 1, 1, 2);
        return 0;
    }

    // case 2
    if (triple_st[0] == 1 && triple_st[1] > 0) {
        _alpha.set_element(Dim(0, 0), log_in.get_element(Dim(ii, label_vec[0])));
        calc_std_alpha(log_in, ii, label_vec, 0, triple_st[1], 0, 1);

        sum = _alpha.get_element(Dim(triple_st[1] - 1, 0))
              + log_in.get_element(Dim(triple_st[1] * _sample_num + ii, label_vec[1]));
        _alpha.set_element(Dim(triple_st[1], 1), sum);
        calc_std_alpha(log_in, ii, label_vec, triple_st[1], triple_st[2] + 1, 1, 2);
        return 0;
    }

    // case 3
    if (triple_st[0] > 1 && triple_st[1] > 0 && triple_st[0] < 2 * triple_st[1] + 1) {
        _alpha.set_element(Dim(0, 0), log_in.get_element(Dim(ii, label_vec[0])));
        _alpha.set_element(Dim(0, 1), log_in.get_element(Dim(ii, label_vec[1])));
        calc_std_alpha(log_in, ii, label_vec, 0, triple_st[1], 0, triple_st[0]);

        sum = log_sum_exp(_alpha.get_element(Dim(triple_st[1] - 1, triple_st[0] - 1)),
                          _alpha.get_element(Dim(triple_st[1] - 1, triple_st[0] - 2)));
        sum += log_in.get_element(Dim(triple_st[1] * _sample_num + ii, label_vec[triple_st[0]]));
        _alpha.set_element(Dim(triple_st[1], triple_st[0]), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_st[1], triple_st[2] + 1, triple_st[0], triple_st[0] + 1);
        return 0;
    }

    // case 4
    if (triple_st[0] > 1 && triple_st[1] > 0 && triple_st[0] == 2 * triple_st[1] + 1) {
        _alpha.set_element(Dim(0, 1), log_in.get_element(Dim(ii, label_vec[triple_st[0]])));

        for (int tt = 1; tt <= triple_st[1]; tt++) {
            sum = _alpha.get_element(Dim(tt - 1, 2 * tt - 1))
                  + log_in.get_element(Dim(tt * _sample_num + ii, label_vec[2 * tt + 1]));
            _alpha.set_element(Dim(tt, 2 * tt + 1), sum);
        }

        calc_std_alpha(log_in, ii, label_vec,
                       triple_st[1], triple_st[2] + 1, triple_st[0], triple_st[0] + 1);
    }

    return 0;
}

int CtcLossLayer::calc_local_alpha_ed(Tensor<DType>& log_in, int ii,
                                      std::vector<int>& label_vec, int num_frame, std::vector<int> triple_ed) {
    // Deal with exception case
    int num_state = label_vec.size();

    if (num_state - triple_ed[0] > 2 * (num_frame - triple_ed[2])) {
        INTER_LOG("Warning [losing label at tail]: (ss:%d, tt:%d)", triple_ed[0], triple_ed[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (triple_ed[0] == num_state - 2 && triple_ed[2] == num_frame - 1) {
        return 0;
    }

    // case 2
    if (triple_ed[0] == num_state - 2 && triple_ed[2] < num_frame - 1) {
        sum = _alpha.get_element(Dim(triple_ed[2], triple_ed[0]))
              + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[triple_ed[0] + 1]));
        _alpha.set_element(Dim(triple_ed[2] + 1, triple_ed[0] + 1), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[2] + 1, num_frame, triple_ed[0] + 1, num_state);
        return 0;
    }

    // case 3
    if (triple_ed[0] < num_state - 2 && triple_ed[2] < num_frame - 1
            && num_state - triple_ed[0] < 2 * (num_frame - triple_ed[2])) {
        sum = _alpha.get_element(Dim(triple_ed[2], triple_ed[0]))
              + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[triple_ed[0] + 1]));
        _alpha.set_element(Dim(triple_ed[2] + 1, triple_ed[0] + 1), sum);
        sum = _alpha.get_element(Dim(triple_ed[2], triple_ed[0]))
              + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[triple_ed[0] + 2]));
        _alpha.set_element(Dim(triple_ed[2] + 1, triple_ed[0] + 2), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[2] + 1, num_frame, triple_ed[0] + 1, num_state);
        return 0;
    }

    // case 4
    if (triple_ed[0] < num_state - 2 && triple_ed[2] < num_frame - 1
            && num_state - triple_ed[0] == 2 * (num_frame - triple_ed[2])) {
        for (int tt = triple_ed[2] + 1; tt < num_frame; tt++) {
            int ss = triple_ed[0] + 2 * (tt - triple_ed[2]);
            sum = _alpha.get_element(Dim(tt - 1, ss - 2))
                  + log_in.get_element(Dim(tt * _sample_num + ii, label_vec[ss]));
            _alpha.set_element(Dim(tt, ss), sum);
        }
    }

    return 0;
}

int CtcLossLayer::calc_local_alpha(Tensor<DType>& log_in, int ii,
                                   std::vector<int>& label_vec, std::vector<int> triple_st, std::vector<int> triple_ed) {
    // Deal with exception case
    int tt_st = triple_st[2];
    int tt_ed = triple_ed[1];
    int ss_st = triple_st[0];
    int ss_ed = triple_ed[0];

    if (ss_ed - ss_st > 2 * (tt_ed - tt_st)) {
        INTER_LOG("Warning [losing label in middle]: (ss_st:%d, tt_st:%d)--(ss_st:%d, tt_st:%d)",
                  triple_st[0], triple_st[2], triple_ed[0], triple_ed[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (ss_ed - ss_st == 2 && tt_ed - tt_st == 1) {
        sum = _alpha.get_element(Dim(triple_st[2], triple_st[0]))
              + log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _alpha.set_element(Dim(triple_ed[1], triple_ed[0]), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[1], triple_ed[2] + 1, triple_ed[0], triple_ed[0] + 1);
        return 0;
    }

    // case 2
    if (ss_ed - ss_st == 2 && tt_ed - tt_st > 1) {
        sum = _alpha.get_element(Dim(triple_st[2], triple_st[0]))
              + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 1]));
        _alpha.set_element(Dim(triple_st[2] + 1, triple_st[0] + 1), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_st[2] + 1, triple_ed[1], triple_st[0] + 1, triple_ed[0]);
        sum = _alpha.get_element(Dim(triple_ed[1] - 1, triple_ed[0] - 1))
              + log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _alpha.set_element(Dim(triple_ed[1], triple_ed[0]), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[1], triple_ed[2] + 1, triple_ed[0], triple_ed[0] + 1);
        return 0;
    }

    // case 3
    if (ss_ed - ss_st > 2 && ss_ed - ss_st < 2 * (tt_ed - tt_st)) {
        sum = _alpha.get_element(Dim(triple_st[2], triple_st[0]))
              + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 1]));
        _alpha.set_element(Dim(triple_st[2] + 1, triple_st[0] + 1), sum);
        sum = _alpha.get_element(Dim(triple_st[2], triple_st[0]))
              + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 2]));
        _alpha.set_element(Dim(triple_st[2] + 1, triple_st[0] + 2), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_st[2] + 1, triple_ed[1], triple_st[0] + 1, triple_ed[0]);

        sum = log_sum_exp(_alpha.get_element(Dim(triple_ed[1] - 1, triple_ed[0] - 1)),
                          _alpha.get_element(Dim(triple_ed[1] - 1, triple_ed[0] - 2)));
        sum += log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _alpha.set_element(Dim(triple_ed[1], triple_ed[0]), sum);
        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[1], triple_ed[2] + 1, triple_ed[0], triple_ed[0] + 1);
        return 0;
    }

    // case 4
    if (ss_ed - ss_st > 2 && ss_ed - ss_st == 2 * (tt_ed - tt_st)) {
        for (int tt = triple_st[2] + 1; tt < triple_ed[1] + 1; tt++) {
            int ss = triple_st[0] + 2 * (tt - triple_st[2]);
            sum = _alpha.get_element(Dim(tt - 1, ss - 2))
                  + log_in.get_element(Dim(tt * _sample_num + ii, label_vec[ss]));
            _alpha.set_element(Dim(tt, ss), sum);
        }

        calc_std_alpha(log_in, ii, label_vec,
                       triple_ed[1], triple_ed[2] + 1, triple_ed[0], triple_ed[0] + 1);
    }

    return 0;
}

int CtcLossLayer::calc_std_alpha(Tensor<DType>& log_in, int ii, std::vector<int>& label_vec,
                                 int tt_st, int tt_ed, int ss_st, int ss_ed) {
    for (int tt = tt_st + 1; tt < tt_ed; tt++) {
        int st = std::max(ss_st, ss_ed - 2 * (tt_ed - tt));
        int ed = std::min(ss_st + 2 * (tt - tt_st + 1), ss_ed);

        for (int ss = st; ss < ed; ss++) {
            DType sum = _alpha.get_element(Dim(tt - 1, ss));

            if (ss >= ss_st + 1) {
                sum = log_sum_exp(sum, _alpha.get_element(Dim(tt - 1, ss - 1)));
            }

            if (ss >= ss_st + 2 && ss % 2 == 1 && label_vec[ss] != label_vec[ss - 2]) {
                sum = log_sum_exp(sum, _alpha.get_element(Dim(tt - 1, ss - 2)));
            }

            _alpha.set_element(Dim(tt, ss), sum + log_in.get_element(Dim(tt * _sample_num + ii,
                               label_vec[ss])));
        }
    }

    return 0;
}

int CtcLossLayer::calc_beta(Tensor<DType>& log_in, int ii, int num_frame,
                            std::vector<int>& label_vec) {
    int num_state = label_vec.size();
    _beta.resize(Dim(num_frame, num_state));
    _beta.set_element(_log_zero);

    _beta.set_element(Dim(num_frame - 1, num_state - 1), 0.0);
    _beta.set_element(Dim(num_frame - 1, num_state - 2), 0.0);
    calc_std_beta(log_in, ii, label_vec, 0, num_frame - 1, 0, num_state - 1);

    return 0;
}

int CtcLossLayer::calc_beta(Tensor<DType>& log_in, int ii, int num_frame,
                            std::vector<int>& label_vec, std::vector< std::vector<int> >& local_path) {
    if (local_path.empty()) {
        INTER_LOG("Warning: empty label in local_path.\n");
        return -1;
    }

    int num_state = label_vec.size();
    _beta.resize(Dim(num_frame, num_state));
    _beta.set_element(_log_zero);

    if (calc_local_beta_ed(log_in, ii, label_vec, num_frame, local_path.back())) {
        return -1;
    }

    for (int i = local_path.size() - 1; i > 0; i--) {
        if (calc_local_beta(log_in, ii, label_vec, local_path[i - 1], local_path[i])) {
            return -1;
        }
    }

    if (calc_local_beta_st(log_in, ii, label_vec, local_path.front())) {
        return -1;
    }

    return 0;
}

int CtcLossLayer::calc_local_beta_ed(Tensor<DType>& log_in, int ii,
                                     std::vector<int>& label_vec, int num_frame, std::vector<int> triple_ed) {
    // Deal with exception case
    int num_state = label_vec.size();

    if (num_state - triple_ed[0] > 2 * (num_frame - triple_ed[2])) {
        INTER_LOG("Warning [losing label at head]: (ss:%d, tt:%d)", triple_ed[0], triple_ed[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (triple_ed[0] == num_state - 2 && triple_ed[2] == num_frame - 1) {
        _beta.set_element(Dim(num_frame - 1, num_state - 2), 0.0);
        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[1], triple_ed[2], triple_ed[0], triple_ed[0]);
        return 0;
    }

    // case 2
    if (triple_ed[0] == num_state - 2 && triple_ed[2] < num_frame - 1) {
        _beta.set_element(Dim(num_frame - 1, num_state - 1), 0.0);
        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[2] + 1, num_frame - 1, num_state - 1, num_state - 1);

        sum = _beta.get_element(Dim(triple_ed[2] + 1, num_state - 1))
              + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[num_state - 1]));
        _beta.set_element(Dim(triple_ed[2], triple_ed[0]), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[1], triple_ed[2], triple_ed[0], triple_ed[0]);
        return 0;
    }

    // case 3
    if (triple_ed[0] < num_state - 2
            && num_state - triple_ed[0] < 2 * (num_frame - triple_ed[2])) {
        _beta.set_element(Dim(num_frame - 1, num_state - 1), 0.0);
        _beta.set_element(Dim(num_frame - 1, num_state - 2), 0.0);
        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[2] + 1, num_frame - 1, triple_ed[0] + 1, num_state - 1);

        DType sum1 = _beta.get_element(Dim(triple_ed[2] + 1, triple_ed[0] + 1))
                     + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[triple_ed[0] + 1]));
        DType sum2 = _beta.get_element(Dim(triple_ed[2] + 1, triple_ed[0] + 2))
                     + log_in.get_element(Dim((triple_ed[2] + 1) * _sample_num + ii, label_vec[triple_ed[0] + 2]));

        sum = log_sum_exp(sum1, sum2);
        _beta.set_element(Dim(triple_ed[2], triple_ed[0]), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[1], triple_ed[2], triple_ed[0], triple_ed[0]);
        return 0;
    }

    // case 4
    if (triple_ed[0] == num_state - 2
            && num_state - triple_ed[0] == 2 * (num_frame - triple_ed[2])) {
        _beta.set_element(Dim(num_frame - 1, num_state - 2), 0.0);

        for (int tt = num_frame - 2; tt >= triple_ed[2]; tt--) {
            int ss = num_state - 2 * (num_frame - tt);
            sum = _beta.get_element(Dim(tt + 1, ss + 2))
                  + log_in.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss + 2]));
            _beta.set_element(Dim(tt, ss), sum);
        }

        calc_std_beta(log_in, ii, label_vec,
                      triple_ed[1], triple_ed[2], triple_ed[0], triple_ed[0]);
    }

    return 0;
}

int CtcLossLayer::calc_local_beta_st(Tensor<DType>& log_in, int ii,
                                     std::vector<int>& label_vec, std::vector<int> triple_st) {
    // Deal with exception case
    if (triple_st[0] > 2 * triple_st[1] + 1) {
        INTER_LOG("Warning [losing label at head]: (ss:%d, tt:%d)", triple_st[0], triple_st[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (triple_st[0] == 1 && triple_st[1] == 0) {
        return 0;
    }

    // case 2
    if (triple_st[0] == 1 && triple_st[1] > 0) {
        sum = _beta.get_element(Dim(triple_st[1], triple_st[0]))
              + log_in.get_element(Dim(triple_st[1] * _sample_num + ii, label_vec[triple_st[0]]));
        _beta.set_element(Dim(triple_st[1] - 1, triple_st[0] - 1), sum);
        calc_std_beta(log_in, ii, label_vec, 0, triple_st[1] - 1, 0, 0);
        return 0;
    }

    // case 3
    if (triple_st[0] > 1 && triple_st[1] > 0 && triple_st[0] < 2 * triple_st[1] + 1) {
        sum = _beta.get_element(Dim(triple_st[1], triple_st[0]))
              + log_in.get_element(Dim(triple_st[1] * _sample_num + ii, label_vec[triple_st[0]]));
        _beta.set_element(Dim(triple_st[1] - 1, triple_st[0] - 1), sum);
        _beta.set_element(Dim(triple_st[1] - 1, triple_st[0] - 2), sum);
        calc_std_beta(log_in, ii, label_vec, 0, triple_st[1] - 1, 0, triple_st[0] - 1);
        return 0;
    }

    // case 4
    if (triple_st[0] > 1 && triple_st[1] > 0 && triple_st[0] == 2 * triple_st[1] + 1) {
        for (int tt = triple_st[1] - 1; tt >= 0; tt--) {
            int ss = triple_st[0] - 2 * (triple_st[1] - tt);
            sum = _beta.get_element(Dim(tt + 1, ss + 2))
                  + log_in.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss + 2]));
            _beta.set_element(Dim(tt, ss), sum);
        }
    }

    return 0;
}

int CtcLossLayer::calc_local_beta(Tensor<DType>& log_in, int ii,
                                  std::vector<int>& label_vec, std::vector<int> triple_st, std::vector<int> triple_ed) {
    // Deal with exception case
    int tt_st = triple_st[2];
    int tt_ed = triple_ed[1];
    int ss_st = triple_st[0];
    int ss_ed = triple_ed[0];

    if (ss_ed - ss_st > 2 * (tt_ed - tt_st)) {
        INTER_LOG("Warning [losing label in middle]: (ss_st:%d, tt_st:%d)--(ss_st:%d, tt_st:%d)",
                  triple_st[0], triple_st[2], triple_ed[0], triple_ed[1]);
        return -1;
    }

    DType sum = 0.0f;

    // case 1
    if (ss_ed - ss_st == 2 && tt_ed - tt_st == 1) {
        sum = _beta.get_element(Dim(triple_ed[1], triple_ed[0]))
              + log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _beta.set_element(Dim(triple_st[2], triple_st[0]), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_st[1], triple_st[2], triple_st[0], triple_st[0]);
        return 0;
    }

    // case 2
    if (ss_ed - ss_st == 2 && tt_ed - tt_st > 1) {
        sum = _beta.get_element(Dim(triple_ed[1], triple_ed[0]))
              + log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _beta.set_element(Dim(triple_ed[1] - 1, triple_ed[0] - 1), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_st[2] + 1, triple_ed[1] - 1, triple_st[0] + 1, triple_ed[0] - 1);

        sum = _beta.get_element(Dim(triple_st[2] + 1, triple_st[0] + 1))
              + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 1]));
        _beta.set_element(Dim(triple_st[2], triple_st[0]), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_st[1], triple_st[2], triple_st[0], triple_st[0]);
        return 0;
    }

    // case 3
    if (ss_ed - ss_st > 2 && ss_ed - ss_st < 2 * (tt_ed - tt_st)) {
        sum = _beta.get_element(Dim(triple_ed[1], triple_ed[0]))
              + log_in.get_element(Dim(triple_ed[1] * _sample_num + ii, label_vec[triple_ed[0]]));
        _beta.set_element(Dim(triple_ed[1] - 1, triple_ed[0] - 1), sum);
        _beta.set_element(Dim(triple_ed[1] - 1, triple_ed[0] - 2), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_st[2] + 1, triple_ed[1] - 1, triple_st[0] + 1, triple_ed[0] - 1);

        DType sum1 = _beta.get_element(Dim(triple_st[2] + 1, triple_st[0] + 1))
                     + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 1]));
        DType sum2 = _beta.get_element(Dim(triple_st[2] + 1, triple_st[0] + 2))
                     + log_in.get_element(Dim((triple_st[2] + 1) * _sample_num + ii, label_vec[triple_st[0] + 2]));
        sum = log_sum_exp(sum1, sum2);
        _beta.set_element(Dim(triple_st[2], triple_st[0]), sum);
        calc_std_beta(log_in, ii, label_vec,
                      triple_st[1], triple_st[2], triple_st[0], triple_st[0]);
        return 0;
    }

    // case 4
    if (ss_ed - ss_st > 2 && ss_ed - ss_st == 2 * (tt_ed - tt_st)) {
        for (int tt = triple_ed[1] - 1; tt >= triple_st[2]; tt--) {
            int ss = triple_ed[0] - 2 * (triple_ed[1] - tt);
            sum = _beta.get_element(Dim(tt + 1, ss + 2))
                  + log_in.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss + 2]));
            _beta.set_element(Dim(tt, ss), sum);
        }

        calc_std_beta(log_in, ii, label_vec,
                      triple_st[1], triple_st[2], triple_st[0], triple_st[0]);
    }

    return 0;
}

int CtcLossLayer::calc_std_beta(Tensor<DType>& log_in, int ii, std::vector<int>& label_vec,
                                int tt_st, int tt_ed, int ss_st, int ss_ed) {
    for (int tt = tt_ed - 1; tt >= tt_st; tt--) {
        int st = std::max(ss_st, ss_ed + 1 - 2 * (tt_ed + 1 - tt));
        int ed = std::min(ss_st + 2 * (tt - tt_st + 1) - 1, ss_ed);

        for (int ss = ed; ss >= st; ss--) {
            DType sum = _beta.get_element(Dim(tt + 1, ss))
                        + log_in.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss]));

            if (ss < ss_ed) {
                float y = _beta.get_element(Dim(tt + 1, ss + 1))
                          + log_in.get_element(Dim((tt + 1) * _sample_num + ii,  label_vec[ss + 1]));
                sum = log_sum_exp(sum, y, false);
            }

            if (ss < ss_ed - 1 && ss % 2 == 1 && label_vec[ss] != label_vec[ss + 2]) {
                float y = _beta.get_element(Dim(tt + 1, ss + 2))
                          + log_in.get_element(Dim((tt + 1) * _sample_num + ii, label_vec[ss + 2]));
                sum = log_sum_exp(sum, y, false);
            }

            _beta.set_element(Dim(tt, ss), sum);
        }
    }

    return 0;
}

DType CtcLossLayer::calc_diff(Tensor<DType>& host_out, int ii, int num_frame,
                              std::vector<int>& label_vec) {
    std::vector< std::vector<int> > local_path;
    return calc_diff(host_out, ii, num_frame, label_vec, local_path);
}

DType CtcLossLayer::calc_diff(Tensor<DType>& host_out, int ii, int num_frame,
                              std::vector<int>& label_vec, std::vector< std::vector<int> >& local_path) {
    //Get kOutput (0 a 0 a 0 b 0 a 0 --> 0 a b)
    std::vector<int> kOutput(label_vec);
    sort(kOutput.begin(), kOutput.end());
    std::vector<int>::iterator it = unique(kOutput.begin(), kOutput.end());
    kOutput.erase(it, kOutput.end());

    int num_k = kOutput.size();
    int num_state = label_vec.size();
    std::vector< std::vector<int> > k_label_pos;
    k_label_pos.resize(num_k);

    for (int k = 0; k < num_k; k++) {
        for (int s = 0; s < num_state; s++) {
            if (kOutput[k] == label_vec[s]) {
                k_label_pos[k].push_back(s);
            }
        }
    }

    //Calc outDiff
    std::vector<float> zt_vec(num_frame, 0);

    for (int tt = 0; tt < num_frame; tt++) {
        zt_vec[tt] = _log_zero;

        for (int ss = 0; ss < num_state; ss++) {
            zt_vec[tt] = log_sum_exp(zt_vec[tt],
                                     _alpha.get_element(Dim(tt, ss)) + _beta.get_element(Dim(tt, ss)));
        }

        if (zt_vec[tt] == _log_zero) {
            exit(0);
        }

        for (int kk = 0; kk < num_k; kk++) {
            DType alpha_beta = _log_zero;

            for (int pp = 0; pp < (int)k_label_pos[kk].size(); pp++) {
                alpha_beta = log_sum_exp(alpha_beta,
                                         _alpha.get_element(Dim(tt, k_label_pos[kk][pp]))
                                         + _beta.get_element(Dim(tt, k_label_pos[kk][pp])));
            }

            DType t_data = exp(alpha_beta - zt_vec[tt]);
            DType o_data = host_out.get_element(Dim(tt * _sample_num + ii, kOutput[kk]));
            host_out.set_element(Dim(tt * _sample_num + ii, kOutput[kk]), t_data + o_data);
        }
    }

    return zt_vec[0];
}

} //namespace houyi
} //namespace train

