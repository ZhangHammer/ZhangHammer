//by zzxfl 2017.06.02
#include <string>
#include "box_annotator_ohem_layer.h"

namespace houyi {
namespace train {

BoxAnnotatorOHEMLayer::BoxAnnotatorOHEMLayer(BoxAnnotatorOHEMConfig& config) : Layer(config) {
    set_device();
    _config = config;
    _roi_per_img = _config.get_roi_per_img();
    _ignore_label = _config.get_ignore_label();
    /*
    _num = _config.get_in_dim()[0][0];
    _channel = _config.get_in_dim()[0][1];
    _height = _config.get_in_dim()[0][2];
    _width = _config.get_in_dim()[0][3];
    _spatial_dim = _height * _width;

    for(int i = 0; i < _config.get_in_dim().size(); i++){
        CHECK2(_config.get_in_dim()[i][0] == _num);
        CHECK2(_config.get_in_dim()[i][1] == _channel);
        CHECK2(_config.get_in_dim()[i][2] == _height);
        CHECK2(_config.get_in_dim()[i][3] == _width);
    }
    */
}

void BoxAnnotatorOHEMLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void BoxAnnotatorOHEMLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);

    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}


BoxAnnotatorOHEMLayer::BoxAnnotatorOHEMLayer(BoxAnnotatorOHEMLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    //bool is_update = need_update();
    //from->config().set_update(is_update);
    new(this) BoxAnnotatorOHEMLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

BoxAnnotatorOHEMLayer::~BoxAnnotatorOHEMLayer() {

}

void BoxAnnotatorOHEMLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* rois = pack[0]->get_ten();
    Tensor<DType>* loss = pack[1]->get_ten();
    Tensor<DType>* labels = pack[2]->get_ten();
    Tensor<DType>* bbox_loss_weights = pack[3]->get_ten();
    Tensor<DType>* out_labels = Layer::output(_output_keys[0]).get_ten();
    out_labels->resize(labels->get_size());
    Tensor<DType>* out_bbox_loss_weights = Layer::output(_output_keys[1]).get_ten();
    out_bbox_loss_weights->resize(bbox_loss_weights->get_size());
    _num =  rois->get_size()[0];
    _channel = pack[3]->get_ten()->get_c();

    //TODO
    if (pack[0]->get_ten()->get_dim() >= 4) {
        _height = pack[0]->get_ten()->get_h();
        _width = pack[0]->get_ten()->get_w();
    } else {
        _height = 1;
        _width = 1;
    }

    _spatial_dim = _height * _width;
    /*
    _height = rois->get_size()[2];
    _width = rois->get_size()[3];
    _spatial_dim = _height * _width;
    */
    _in_rois.resize(rois->get_size());
    _in_rois.copy_from(*rois);
    _in_loss.resize(loss->get_size());
    _in_loss.copy_from(*loss);
    /*
     *
     */
    //_in_loss.log();
    //_in_loss.mul(-1.0f);
    _in_labels.resize(labels->get_size());
    _in_labels.copy_from(*labels);
    _in_bbox_loss_weights.resize(bbox_loss_weights->get_size());
    _in_bbox_loss_weights.copy_from(*bbox_loss_weights);
    _out_labels.resize(out_labels->get_size());
    _out_bbox_loss_weights.resize(out_bbox_loss_weights->get_size());

    _out_labels.set_element(_ignore_label);
    _out_bbox_loss_weights.set_element(0);

    int _num_rois = loss->get_element_count();
    int num_imgs = -1;
    DType* _in_rois_ptr = _in_rois.get_data();

    for (int n = 0; n < _num_rois; n++) {
        for (int s = 0; s < (int)_spatial_dim; s++) {
            num_imgs = _in_rois_ptr[0] > num_imgs ? _in_rois_ptr[0] : num_imgs;
            _in_rois_ptr++;
        }

        _in_rois_ptr += (5 - 1) * _spatial_dim;
    }

    num_imgs++;
    CHECK2(num_imgs > 0);
    // find rois with max loss
    std::vector<int>sorted_idx(_num_rois);

    for (int i = 0; i < _num_rois; i++) {
        sorted_idx[i] = i;
    }

    DType* loss_ptr = _in_loss.get_data();
    std::sort(sorted_idx.begin(), sorted_idx.end(),
    [loss_ptr](int i1, int i2) {
        return loss_ptr[i1] > loss_ptr[i2];
    });

    //generate output labels ofr scoing and loss_eeights for bbox regression
    std::vector<int> number_left(num_imgs, _roi_per_img);

    for (int i = 0; i < _num_rois; i++) {
        int index = sorted_idx[i];
        int s = index % (_width * _height);
        int n = index / (_width * _height);
        int batch_ind = _in_rois.get_data()[n * 5 * _spatial_dim + s];

        if (number_left[batch_ind] > 0) {
            number_left[batch_ind]--;
            _out_labels.get_data()[index] = _in_labels.get_data()[index];

            for (int j = 0; j < (int)_channel; j++) {
                int bbox_index = (n * _channel + j) * _spatial_dim + s;
                _out_bbox_loss_weights.get_data()[bbox_index]
                    = _in_bbox_loss_weights.get_data()[bbox_index];
            }
        }
    }

    out_labels->copy_from(_out_labels);
    out_bbox_loss_weights->copy_from(_out_bbox_loss_weights);
}

void BoxAnnotatorOHEMLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
        std::vector<IOPackage*>& out_pack) {
    /*
    for(size_t i  = 0; i < out_pack.size(); i++){
        Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
        Tensor<DType>* pre_diff = out_pack[i]->get_ten();
        pre_diff->resize(local_diff->get_size());
    }
    */
    return;
}

void BoxAnnotatorOHEMLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
}

Layer* BoxAnnotatorOHEMLayer::clone() {
    return new BoxAnnotatorOHEMLayer(this);
}

}
}

