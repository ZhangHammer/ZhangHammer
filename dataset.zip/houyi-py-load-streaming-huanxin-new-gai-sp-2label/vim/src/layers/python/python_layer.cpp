/**
 * file: python_layer.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年12月29日 16时02分09秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#include "python_layer.h"
#include "layer_config.h"
#include "image_utils.h"

namespace houyi {
namespace train {

PythonLayer* get_python_layer(PythonConfig& cfg) {
    try {
        PythonConfig* layer_cfg = dynamic_cast<PythonConfig*>(&cfg);
        bp::object module = PythonRuntime::instance().import(layer_cfg->get_python_model());
        bp::object layer = PythonRuntime::instance().module_attr(module, 
                layer_cfg->get_python_layer_type_str(),
                cfg); 
        return PythonRuntime::instance().extract<PythonLayer*>(layer);
    } catch (bp::error_already_set) {
        PyErr_Print();
        throw;
    }
}

void PythonLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    PythonRuntime::instance().attr(_self, "layer_set", inputs, sample_num);
    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void PythonLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    PythonRuntime::instance().attr(_self, "resize_out", inputs, sample_num);
}

void PythonLayer::forward(Argument& args) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif

    /*data_layer resize out */
    /* todo remove */
    if (_config.get_python_layer_type() == DATA_LAYER) {
        _output[0].resize(_config.get_out_dim()[0], gpu_device());
        _output[1].resize(_config.get_out_dim()[1], gpu_device());
    }

    std::vector<IOPackage*> in_pack;
    for (size_t i = 0; i < _input_keys.size(); i++) {
        IOPackage* io = args.get_pack(_input_keys[i]);
        CHECK(io != NULL, "layer %s input key error", _name.c_str());
        in_pack.push_back(io);
#ifdef __TRAIN_OUTPUT_RESULT__

        //判断文件夹是否存在，不存在则创建
        if (access("layer_result_out", 0) == -1) {
            mkdir("layer_result_out", S_IRWXU);
        }

        char name[1024];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_input_%d",
                device, batch_cnt, _name.c_str(), (int)i);

        if (io->get_ten()) {
            write_tensor(*(io->get_ten()), name, _layer_result_output_num);
        }
#endif
    }

    for (size_t i = 0; i < _label_key.size(); i++) {
        IOPackage* io = args.get_pack(_label_key[i]);
        CHECK(io != NULL, "layer %s label key error", _name.c_str());
        in_pack.push_back(io);
#ifdef __TRAIN_OUTPUT_RESULT__

        //判断文件夹是否存在，不存在则创建
        if (access("layer_result_out", 0) == -1) {
            mkdir("layer_result_out", S_IRWXU);
        }

        char name[1024];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_label_%d",
                device, batch_cnt, _name.c_str(), (int)i);
        write_tensor(*(io->get_ten()), name, _layer_result_output_num);
#endif
    }

    IOPackage desc;
    if (_feat_desc_keys.size() > 0) {
        CHECK(_feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
        int desc_num = args.get_feat_desc()->get_origin_height(_feat_desc_keys[0]).size();
        desc.resize(Dim(desc_num, 3), GPU);

        for (auto j = 0; j < desc_num; j++) {
            desc.get_ten()->set_element(Dim(j, 0),
                        args.get_feat_desc()->get_origin_height(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 1),
                        args.get_feat_desc()->get_origin_width(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 2),
                        args.get_feat_desc()->get_scale(_feat_desc_keys[0])[j]);
        }

        in_pack.push_back(&desc);
    }

    inter_forward(in_pack);

    _act->forward(*output(_output_keys[0]).get_ten(), *output(_output_keys[0]).get_ten());

#ifdef __TRAIN_OUTPUT_RESULT__
    if (access("layer_result_out", 0) == -1) {
        mkdir("layer_result_out", S_IRWXU);
    }

    for (size_t i = 0; i < _output_keys.size(); i++) {
        char name_output[1024];
        sprintf(name_output, "./layer_result_out/device_%d_batch_%d_%s_output%d",
                device, batch_cnt, _name.c_str(), (int)i);
        write_tensor(*(output(_output_keys[i]).get_ten()), name_output, _layer_result_output_num);
    }

    std::map<std::string, BaseWeight*>::iterator it;
    int count = 0;

    for (it = _w_map.begin(); it != _w_map.end(); it++) {
        char name[1024];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_%s_%d", device,
                batch_cnt, _name.c_str(), it->first.c_str(), count);
        write_tensor(*(it->second)->w(), name, _layer_result_output_num);
        count++;
    }
#endif
}

bool PythonLayer::backward(Argument& args, Argument& diff) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif

    //_act->backward(*Layer::diff(_output_keys[0]).get_ten(),
    //            *output(_output_keys[0]).get_ten(), *Layer::diff(_output_keys[0]).get_ten());

    zero_buf(D_WEIGHT);
    IOPackage* pre_diff = NULL;
    IOPackage* in = NULL;
    std::vector<IOPackage*> in_pack;
    std::vector<IOPackage*> pre_diff_pack;

    for (size_t i = 0; i < _input_keys.size(); i++) {
        in = args.get_pack(_input_keys[i]);
        in_pack.push_back(in);

        if (args.is_feat_key(_input_keys[i]) == false) {
            pre_diff = diff.get_pack(_input_keys[i]);
            pre_diff_pack.push_back(pre_diff);
        }
    }

    for (size_t i = 0; i < _label_key.size(); i++) {
        IOPackage* io = args.get_pack(_label_key[i]);
        if (io == NULL && _feature_share_input) {
            continue;
        }
        CHECK(io != NULL, "layer %s label key error", _name.c_str());
        in_pack.push_back(io);
    }

    IOPackage desc;
    if (_feat_desc_keys.size() > 0) {
        CHECK(_feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
        int desc_num = args.get_feat_desc()->get_origin_height(_feat_desc_keys[0]).size();
        desc.resize(Dim(desc_num, 3), GPU);

        for (auto j = 0; j < desc_num; j++) {
            desc.get_ten()->set_element(Dim(j, 0),
                        args.get_feat_desc()->get_origin_height(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 1),
                        args.get_feat_desc()->get_origin_width(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 2),
                        args.get_feat_desc()->get_scale(_feat_desc_keys[0])[j]);
        }

        in_pack.push_back(&desc);
    }

    for (auto it : _input_keys) {                 
        IOPackage* in = args.get_pack(it);           

        if (args.is_feat_key(it) == false) {         
            IOPackage* pre_diff = diff.get_pack(it);
            pre_diff->resize(in->get_size(), in->get_device());
        }                                                      
    }                                                          

    inter_bprop_diff(in_pack, pre_diff_pack);

#ifdef __TRAIN_OUTPUT_RESULT__
    /*
    char name_cur_diff[1024];
    char name_pre_diff[1024];
    for(size_t i = 0; i < _output_keys.size(); i++){
        sprintf(name_cur_diff, "./layer_result_out/device_%d_batch_%d_%s_cur_diff_%d", device,
                batch_cnt, _name.c_str(), (int)i);
        Layer::diff(_output_keys[i]).get_ten()->write(name_cur_diff, _layer_result_output_num);
    }
    for(size_t i = 0; i < _input_keys.size(); i++){
        pre_diff = pre_diff_pack[i];
        if (pre_diff != NULL) {
            sprintf(name_pre_diff, "./layer_result_out/device_%d_batch_%d_%s_pre_diff_%d",
                    device, batch_cnt, _name.c_str(), (int)i);
            pre_diff_pack[0]->get_ten()->write(name_pre_diff, _layer_result_output_num);
        }
    }*/

#endif

    inter_bprop_grad(in_pack, pre_diff_pack);
#ifdef __TRAIN_OUTPUT_RESULT__
    std::map<std::string, BaseWeight*>::iterator it;
    int count = 0;

    for (it = _dw_map.begin(); it != _dw_map.end(); it++) {
        char name[1024];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_d%s_%d",
                device, batch_cnt, _name.c_str(), it->first.c_str(), count);
        dynamic_cast<DenseWeight* >(it->second)->w()->write(name, _layer_result_output_num);
        count++;
    }

#endif
}

}   /* namespace of houyi */
}   /* namespace of train */

