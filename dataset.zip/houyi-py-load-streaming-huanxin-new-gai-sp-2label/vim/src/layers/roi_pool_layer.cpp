/**
 * roi_pool_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-27
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "roi_pool_layer.h"

namespace houyi {
namespace train {
ROIPoolLayer::ROIPoolLayer(ROIPoolConfig& cfg) : Layer(cfg) {
    init();
    set_device();
    _cfg = cfg;

    _pooling_type = cfg.get_pooling_type();
    _pooled_height = cfg.get_pooled_height();
    _pooled_width = cfg.get_pooled_width();
    _roi_num = cfg.get_roi_num();
    _spatial_scale = cfg.get_spatial_scale();

    _roi_pool_dec.pooled_height = _pooled_height;
    _roi_pool_dec.pooled_width = _pooled_width;
    _roi_pool_dec.spatial_scale = _spatial_scale;

    build_map();
}

void ROIPoolLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ROIPoolLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size0 = inputs[0]->get_size();
    const Dim& input_size1 = inputs[1]->get_size();
    CHECK(4 == input_size0.get_size(), "ROIPoolLayer input0 must be 4D");
    CHECK(2 == input_size1.get_size(), "ROIPoolLayer input1 must be 2D");
    output(_output_keys[0]).resize(Dim(input_size1[0] * _roi_num,
                                       input_size0[1], _pooled_height, _pooled_width), inputs[0]->get_mask(), 
                                   gpu_device());
}

void ROIPoolLayer::init() {
    _pooling_type = POOL_TYPE_UNKNOWN;
    _pooled_height = 0;
    _pooled_width = 0;
    _roi_num = 0;
    _width = 0;
    _height = 0;
    _input_maps = 0;
    _spatial_scale = 1.0f;
}

void ROIPoolLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input0 = in_pack[0]->get_ten();
    Tensor<DType>* input1 = in_pack[1]->get_ten();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();

    _max_idx.resize(Dim(input1->get_size(0) * _roi_num, input0->get_size(1), _pooled_height,
                        _pooled_width));
    output->roi_pool_fwd(_roi_pool_dec, *input0, *input1, _max_idx, 1.0f, 1.0f);

}

void ROIPoolLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                                    std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* label = in_pack[1]->get_ten();

    out_diff->roi_pool_bp(_roi_pool_dec, *in_diff, *label, _max_idx, 1.0f, 1.0f);
}

void ROIPoolLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                                    std::vector<IOPackage*>& out_pack) {
    // nothing to do
}

}
}
