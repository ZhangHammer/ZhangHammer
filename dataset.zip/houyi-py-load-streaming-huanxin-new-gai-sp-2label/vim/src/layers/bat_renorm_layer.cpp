/**
 * Bat_renormal_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-06-06
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "bat_renorm_layer.h"
#include "tools.h"

namespace houyi {
namespace train {

BatRenormalLayer::BatRenormalLayer(BatRenormConfig& config) : Layer(config) {
    set_device();
    _config = config;
    _epsilon = config.epsilon();

    _r_max = config.get_r_max();
    _d_max = config.get_d_max();

    _deta = config.get_deta();

    _real_frame_num = 0;
    _store_item = 0;
    _frame_dim = 0;

    if (config.mean_var_file().size() != 0) {
        _global_mean_var = config.mean_var_file();
    }

    build_map();
}

BatRenormalLayer::BatRenormalLayer(BatRenormalLayer* from) : Layer(from) {
    CHECK(from != NULL, "from is NULL");
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this)BatRenormalLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    _gamma.resize_like(from->gamma());
    _gamma.copy_from(from->gamma());
    _beta.resize_like(from->beta());
    _beta.copy_from(from->beta());

    if (!from->mean_vec().is_init()) {
        _mean_vec.resize_like(from->mean_vec());
        _mean_vec.copy_from(from->mean_vec());
    }

    if (from->var_vec().is_init()) {
        _var_vec.resize_like(from->var_vec());
        _var_vec.copy_from(from->var_vec());
    }
}

void BatRenormalLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "gamma", &_gamma));
    _w_map.insert(WeightsMap::value_type(pre + "beta", &_beta));

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "gamma", &_d_gamma));
        _dw_map.insert(WeightsMap::value_type(pre + "beta", &_d_beta));
    }
}

BatRenormalLayer::~BatRenormalLayer() {
}

void BatRenormalLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    Dim dim = inputs[0]->get_size();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    int frame_dim = dim[1];
    _frame_dim = frame_dim;
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _gamma.resize(Dim(1, frame_dim), GPU);
    _beta.resize(Dim(1, frame_dim), GPU);

    if (need_update()) {
        _d_gamma.resize(Dim(1, frame_dim), GPU);
        _d_beta.resize(Dim(1, frame_dim), GPU);
    }

    _statis_mean_vec.resize(Dim(1, frame_dim));
    _statis_var_vec.resize(Dim(1, frame_dim));
    _statis_mean_vec.set_element(0.0f);
    _statis_var_vec.set_element(1.0f);

    _d_mean_vec.resize(Dim(1, frame_dim));
    _d_var_vec.resize(Dim(1, frame_dim));

    _r.resize(Dim(1, frame_dim));
    _d.resize(Dim(1, frame_dim));

    _mean_vec.resize(Dim(1, frame_dim));
    _var_vec.resize(Dim(1, frame_dim));
    _var_reciprocal_vec.resize(Dim(1, frame_dim));

    if (!_global_mean_var.empty()) {
        read_initial_mean_var();
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void BatRenormalLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    _sample_num = sample_num;

    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}


void BatRenormalLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    _real_frame_num = get_real_frame_num(in_pack[0]);

    if (is_predict_job(job_type())) {
        inter_forward_inf(in_pack);
    } else {
        inter_forward_train(in_pack);
    }
}

void BatRenormalLayer::inter_forward_inf(std::vector<IOPackage*>& in_pack) {
    size_t batch_size = in_pack[0]->get_height();
    size_t width = in_pack[0]->get_width();

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    _label_mask.resize(in_pack[1]->get_mask()->get_size());
    _label_mask.copy_from(*in_pack[1]->get_mask());

    _x_sharp_o.resize(Dim(batch_size, width));
    _x_bias.resize(Dim(batch_size, _frame_dim));
    _x_bias.vec_mask(*in, _label_mask);

    // calculate input-var-value
    _x_bias.row_add_vec(_x_bias, _mean_vec, 1.0f, -1.0f);
    _x_bias.vec_mask(_x_bias, _label_mask);
    _x_sharp_o.row_mul_vec(_x_bias, _var_vec, 1.0f, 0.0f);
    out->row_mul_vec(_x_sharp_o, *_gamma.w(), 1.0f, 0.0f);
    out->row_add_vec(*out, *_beta.w());
}

void BatRenormalLayer::inter_forward_train(std::vector<IOPackage*>& in_pack) {
    size_t batch_size = in_pack[0]->get_height();
    size_t width = in_pack[0]->get_width();
    CHECK2((int)width == _frame_dim);

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    _x_sharp_o.resize(Dim(batch_size, width));
    _x_bias.resize(Dim(batch_size, _frame_dim));
    _acc_x_bias.resize(Dim(batch_size, _frame_dim));
    _real_in.resize(Dim(batch_size, _frame_dim));

    /* mask phony frame */
    _label_mask.resize(in_pack[1]->get_mask()->get_size());
    _label_mask.copy_from(*in_pack[1]->get_mask());
    _real_in.vec_mask(*in, _label_mask);

    /* calculate ub */
    _mean_vec.col_sum(_real_in, 1.0f / (float)_real_frame_num);
    _x_bias.row_add_vec(_real_in, _mean_vec, 1.0f, -1.0f);
    _x_bias.vec_mask(_x_bias, _label_mask);

    /* calculate vb */
    out->square(_x_bias);
    _var_vec.col_sum(*out, 1.0f / (float)_real_frame_num, 0.0f);

    if (_epsilon > 0.0f) {
        _var_vec.add(_epsilon);
    }

    /* NOTICE: the Variance  has been sqrted already! */
    _var_vec.sqrt();
    _var_reciprocal_vec.reciprocal(_var_vec);

    /* calculate r and d */
    _r.elem_div(_var_vec, _statis_var_vec, 1.0f, 0.0f);
    _r.limit(1.0 / _r_max, _r_max);
    _d.elem_add(_mean_vec, _statis_mean_vec, 1.0f, -1.0f);
    _d.elem_div(_d, _statis_var_vec, 1.0f, 0.0f);
    _d.limit(-1.0 * _d_max, _d_max);

    /* calculate x, _x_sharp_o = (x - ub) / vb */
    _acc_x_bias.row_add_vec(_real_in, _mean_vec, 1.0f, -1.0f);
    _acc_x_bias.vec_mask(_acc_x_bias, _label_mask);
    _x_sharp_o.row_mul_vec(_acc_x_bias, _var_reciprocal_vec, 1.0f, 0.0f);
    _x_sharp_o.row_mul_vec(_x_sharp_o, _r, 1.0f, 0.0f);
    _x_sharp_o.row_add_vec(_x_sharp_o, _d, 1.0f, 1.0f);

    /* calculate the output of this layer y */
    out->row_mul_vec(_x_sharp_o, *_gamma.w(), 1.0f, 0.0f);
    out->row_add_vec(*out, *_beta.w());

    /* update u, v */
    _d_mean_vec.elem_add(_mean_vec, _statis_mean_vec, 1.0f, -1.0f);
    _d_var_vec.elem_add(_var_vec, _statis_var_vec, 1.0f, -1.0f);
    _statis_mean_vec.elem_add(_statis_mean_vec, _d_mean_vec, 1.0f, _deta);
    _statis_var_vec.elem_add(_statis_var_vec, _d_var_vec, 1.0f, _deta);
}

void BatRenormalLayer::inter_bprop_diff(
    std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    INTER_CHECK(need_update(), "the need_update is false");
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten(); // NOTICE: not _diff

    size_t batch_size = in->get_height();
    _d_mean_vec.resize(Dim(1, _frame_dim));
    _d_var_vec.resize(Dim(1, _frame_dim));

    _buf_e.resize(Dim(batch_size, local_diff->get_width()));

    /* calculate the w-gradient dGamma */
    _buf_e.elem_mul(_x_sharp_o, *local_diff, 1.0f, 0.0f);
    _d_gamma.w()->col_sum(_buf_e, 1.0f, 0.0f);

    /* calculate the bias-gradient (dBeta) */
    _d_beta.w()->col_sum(*local_diff, 1.0f, 0.0f);

    /************************ calculate the pre diff ***************************/
    /* 1. delta-xSharp : _x_sharp_o = _x_sharp_o*gamma(_w) */
    _x_sharp_o.row_mul_vec(*local_diff, *_gamma.w(), 1.0f, 0.0f);

    /* 2. delta-var */
    _d_var_vec.pow(_var_vec, -3); // dvar = var^(-3/2), but var = var^(1/2)
    _d_var_vec.mul(-0.5f); // dvar = -1/2 * dvar
    _buf_e.elem_mul(_x_bias, _x_sharp_o, 1.0f, 0.0f);
    _buf_e.row_mul_vec(_buf_e, _d_var_vec, 1.0f, 0.0f);
    _buf_e.row_mul_vec(_buf_e, _r, 1.0f, 0.0f);
    _d_var_vec.col_sum(_buf_e, 1.0f, 0.0f);

    /* 3.delta-mean */
    _d_mean_vec.elem_div(_r, _var_vec, 1.0f, 0.0f);
    _buf_e.row_mul_vec(_x_sharp_o, _d_mean_vec, 1.0f, 0.0f);
    _d_mean_vec.col_sum(_buf_e, -1.0f, 0.0f);

    /* 4.finally calculate pre diff */
    out_diff->row_mul_vec(_x_bias, _d_var_vec, 2.0f / _real_frame_num, 0.0f);
    out_diff->elem_add(*out_diff, _buf_e);
    out_diff->row_add_vec(*out_diff, _d_mean_vec, 1.0f, 1.0f / _real_frame_num);
    out_diff->vec_mask(*out_diff, _label_mask);
    /******************** end of calculate the pre diff ************************/
}

void BatRenormalLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {
    /* nothing todo */
}

void BatRenormalLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->write(output);
        _beta.w()->write(output);
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }

    store_bn();
}

void BatRenormalLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->read(input);
        _beta.w()->read(input);
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the BatRenormalLayer has no this parameter: %d", t);
    }
}

void BatRenormalLayer::store_bn() {
    uint64_t frame_counter = 1;
    char name[256] = {0};

    pid_t tid;
    pid_t pid;
    pid = getpid();
    // 时间, 格式如下(年月日时分秒): 20161124112460
    char datetime[20];
    get_datetime(datetime);
    tid = syscall(SYS_gettid);

    if (access("statis_bn", 0) == -1) {
        mkdir("statis_bn", S_IRWXU);
    }

    snprintf(name, 256, "statis_bn/Statis_Layer_%s_pid_%u_tid_%u_part_%lu_time_%s.sta",
             _name.c_str(), pid, tid, _store_item, datetime);
    Tensor<DType> mean {Dim(1, _frame_dim), CPU};
    Tensor<DType> var {Dim(1, _frame_dim), CPU};
    mean.copy_from(_mean_vec);
    var.copy_from(_var_vec);

    std::ofstream in_out(name, std::ios::binary);
    // current mean & var
    in_out.write((char*)&_frame_dim, sizeof(size_t));
    in_out.write((char*)&frame_counter, sizeof(uint64_t));
    in_out.write((char*)mean.get_data(), 1 * _frame_dim * sizeof(DType));
    in_out.write((char*)var.get_data(), 1 * _frame_dim * sizeof(DType));

    _store_item ++;
}

void BatRenormalLayer::init_weight(const ModelInitConfig& global_cfg) {
    _gamma.w()->set_element(1.0f);
    _beta.w()->set_element(0.0f);
}
void BatRenormalLayer::init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers) {
    CHECK(global_cfg.weight_init_type() == MODEL_INIT, "model init type must be model init");

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _gamma.w()->set_element(1.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的weight */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.weight_name().size() != 0) ? _model_init_cfg.weight_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) == std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "weight not found in model");
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _beta.w()->set_element(0.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的bias */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.bias_name().size() != 0) ? _model_init_cfg.bias_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) != std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "bias not found in model");
        break;
    }

    default:
        CHECK(false, "model init type error");
    }
}

void BatRenormalLayer::gauss_init(DType mean, DType stdv) {
    _gamma.w()->set_element(1.0f);
    _beta.w()->set_element(0.0f);
}


void BatRenormalLayer::read_initial_mean_var() {
    if (_global_mean_var.empty()) {
        return;
    }

    if (is_predict_job(job_type())) {
        read_initial_mean_var_inf(_global_mean_var.c_str());
    } else {
        read_initial_mean_var_train(_global_mean_var.c_str());
    }
}

void BatRenormalLayer::read_initial_mean_var(std::string bn_file_prefix) {
    if (0 == bn_file_prefix.size()) {
        return;
    }

    if (is_predict_job(job_type())) {
        read_initial_mean_var_inf((bn_file_prefix + "/bn_" + _name).c_str());
    } else {
        CHECK(false, "Can not call read_initial_mean_var(std::string bn_file_prefix) in train mode.");
    }
}

int BatRenormalLayer::get_real_frame_num(IOPackage* label_pack) {
    int cnt = 0;
    Tensor<DType>* label = label_pack->get_ten();

    _label_host.resize(Dim(label->get_size()));
    _label_host.copy_from(*label);

    DType* ptr = _label_host.get_data();

    for (int i = 0; i < _label_host.get_size().product(); i++) {
        if ((int)ptr[i] != -1) {
            cnt++;
        }
    }

    return cnt;
}


void BatRenormalLayer::read_initial_mean_var_inf(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");

    // 做预测时, 如果 bn 文件暂时未生成, 则设置均值为0, 方差为1
    if (NULL == fin) {
        INTER_LOG("Open file error %s", file_name);
        _var_vec.resize(Dim(1, _frame_dim));
        _mean_vec.resize(Dim(1, _frame_dim));
        _var_vec.set_element(1.0f);
        _mean_vec.set_element(0.0f);
    } else {
        //CHECK(fin != NULL, "Open file error %s", file_name);

        std::vector<float> mean, var;
        float m = 0.0f;
        float v = 0.0f;

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &v);
            var.push_back(v);
        }

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &m);
            mean.push_back(m);
        }

        fclose(fin);

        _var_vec.resize(Dim(1, _frame_dim));
        _mean_vec.resize(Dim(1, _frame_dim));

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            _mean_vec.set_element(Dim(0, i), mean[i]);
            _var_vec.set_element(Dim(0, i), std::sqrt(var[i] + _epsilon));
        }

        _var_vec.reciprocal();
    }
}


void BatRenormalLayer::read_initial_mean_var_train(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");
    CHECK(fin != NULL, "Open file error %s", file_name);

    std::vector<float> mean, var;
    float mv = 0.0f;

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        var.push_back(mv);
        _var_vec.set_element(Dim(0, i), mv);
    }

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        mean.push_back(mv);
        _mean_vec.set_element(Dim(0, i), mv);
    }

    fclose(fin);
}

}
}

