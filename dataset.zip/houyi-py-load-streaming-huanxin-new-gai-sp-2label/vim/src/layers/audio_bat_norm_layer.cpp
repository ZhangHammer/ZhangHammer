/**
 * audio_bat_norm_layer.cpp
 * Author: chencheng19 (chencheng19@baidu.com)
 * Created on: 2017-11-9
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 */
#include "audio_bat_norm_layer.h"
#include "tools.h"

namespace houyi {
namespace train {

AudioBatNormalLayer::AudioBatNormalLayer(BatNormConfig& config)
    : Layer(config) {
    set_device();
    _config = config;
    _epsilon = 1e-6;
    //_epsilon = config.epsilon();

    _real_frame_num = 0;

    if (config.mean_var_file().size() != 0) {
        _global_mean_var = (char*)(config.mean_var_file().c_str());
    } else {
        _global_mean_var = NULL;
    }

    build_map();

    _eta = config.get_eta();

    _mask = NULL;
    _counter = 0;
    _store_item = 0;
    _frame_dim = 0;
    _pid = 0;
    _tid = 0;
    _moving_average_fraction = config.get_moving_average_fraction();
}

AudioBatNormalLayer::AudioBatNormalLayer(AudioBatNormalLayer* from) : Layer(from){
    CHECK(from != NULL, "from is NULL");
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) AudioBatNormalLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
    _gamma.resize_like(from->gamma());
    _gamma.copy_from(from->gamma());
    _beta.resize_like(from->beta());
    _beta.copy_from(from->beta());

    if (_inq) {
        _gamma_t.resize_like(from->gamma_t());
        _gamma_t.copy_from(from->gamma_t());
        _beta_t.resize_like(from->beta_t());
        _beta_t.copy_from(from->beta_t());
    }

    /*
        if (from->mean_vec() != NULL) {
            _mean_vec.resize(1, _frame_dim);
            _mean_vec.copy_from(*from->mean_vec());
        }

        if (from->var_vec() != NULL) {
            _var_vec.resize(1, _frame_dim);
            _var_vec.copy_from(*from->var_vec());
        }
    */
}

void AudioBatNormalLayer::build_map(const char* prefix) {
    std::string pre;
    if (prefix) {
        pre.append(prefix);
    }

    // 此处的 weight 和 bias 可能会影响到权重初始化
    _w_map.insert(WeightsMap::value_type(pre + "weight", &_gamma));
    _w_map.insert(WeightsMap::value_type(pre + "bias", &_beta));

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_d_gamma));
        _dw_map.insert(WeightsMap::value_type(pre + "bias", &_d_beta));
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_gamma_t));
        _w_map.insert(WeightsMap::value_type(pre + "bias_binary", &_beta_t));
    }
}

void AudioBatNormalLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    Dim dim = inputs[0]->get_size();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size %zu not equal width dim size %zu", _input_keys.size(), inputs.size());
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    int frame_dim = dim[1];

    _frame_dim = frame_dim;
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _gamma.resize(Dim(1, frame_dim), GPU);
    _beta.resize(Dim(1, frame_dim), GPU);

    if (need_update()) {
        _d_gamma.resize(Dim(1, frame_dim), GPU);
        _d_beta.resize(Dim(1, frame_dim), GPU);
    }

	if (_inq) {
		_gamma_t.resize(Dim(1, frame_dim), GPU);
		_gamma_t.w()->set_element(1);

        _beta_t.resize(Dim(1, frame_dim), GPU);
        _beta_t.w()->set_element(1);
	}

    _mean_vec.resize(Dim(1, frame_dim));
    _var_vec.resize(Dim(1, frame_dim));

    _run_mean.resize(Dim(1, frame_dim));
    _run_var.resize(Dim(1, frame_dim));

    _statis_mean_vec.resize(Dim(1, frame_dim));
    _statis_var_vec.resize(Dim(1, frame_dim));

    if (_global_mean_var != NULL) {
        read_initial_mean_var();
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void AudioBatNormalLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    _pid = getpid();
    _tid = syscall(SYS_gettid);
    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}

AudioBatNormalLayer::~AudioBatNormalLayer() {
}

void AudioBatNormalLayer::init_weight(const ModelInitConfig& global_cfg) {
    _gamma.w()->set_element(1.0f);
    _beta.w()->set_element(0.0f);
}
void AudioBatNormalLayer::init_weight(
        const ModelInitConfig& global_cfg, std::vector<Layer*>& layers) {
#ifdef __CLOSE_RANDOM__
    wind_set_seed(1024);
#else
    time_t seed = time(NULL);
    wind_set_seed(seed);
#endif
    CHECK(global_cfg.weight_init_type() == MODEL_INIT, "model init type must be model init");

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _gamma.w()->set_element(1.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的weight */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.weight_name().size() != 0) ?
                _model_init_cfg.weight_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) == std::string::npos &&
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) == std::string::npos &&
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);
                        if (itr != i->w_map().end()) {
                            BaseWeight *src = itr->second;
                            dst->copy_from(src);
                            _inq_weight_max = i->get_inq_weight_max();
                        }
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "weight not found in model");
        /*  for inq train */
        if (_inq) {
            inq_init_weight();
        }
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _beta.w()->set_element(0.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的bias */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.bias_name().size() != 0) ?
                _model_init_cfg.bias_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) != std::string::npos &&
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) != std::string::npos &&
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);
                        if (itr != i->w_map().end()) {
                            BaseWeight *src = itr->second;
                            dst->copy_from(src);
                            _inq_bias_max = i->get_inq_bias_max();
                        }
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "bias not found in model");
        /* for inq train */
        if (_inq) {
            inq_init_bias();
        }
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

}

void AudioBatNormalLayer::gauss_init(DType mean, DType stdv) {
    _gamma.w()->set_element(1.0f);
    _beta.w()->set_element(0.0f);
}


void AudioBatNormalLayer::read_initial_mean_var() {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    if (NULL == _global_mean_var) {
        return;
    }

    if (is_predict_job(type)) {
        read_initial_mean_var_em1(_global_mean_var);
    } else {
        read_initial_mean_var_em0(_global_mean_var);
    }
}

void AudioBatNormalLayer::read_initial_mean_var(std::string bn_file_prefix) {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    if (0 == bn_file_prefix.size()) {
        return;
    }

    if (is_predict_job(type)) {
        read_initial_mean_var_em1((bn_file_prefix + "/bn_" + _name).c_str());
    } else {
        CHECK(false, "Can not call read_initial_mean_var(bn_file_prefix) in train mode.");
    }
}

void AudioBatNormalLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (is_predict_job(type)) {
        inter_forward_em1(in_pack);
    } else {
        inter_forward_em0(in_pack);
    }
}

void AudioBatNormalLayer::read_initial_mean_var_em1(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");

    // 做预测时, 如果 bn 文件暂时未生成, 则设置均值为0, 方差为1
    if (NULL == fin) {
        INTER_LOG("Open file error %s", file_name);
        _run_mean.set_element(1.0f);
        _run_var.set_element(0.0f);
    } else {
        //CHECK(fin != NULL, "Open file error %s", file_name);

        std::vector<float> mean, var;
        float m = 0.0f;
        float v = 0.0f;

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &v);
            var.push_back(v);
        }

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &m);
            mean.push_back(m);
        }

        fclose(fin);

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            _run_mean.set_element(Dim(0, i), mean[i]);
            _run_var.set_element(Dim(0, i), 1.0f / std::sqrt(var[i] + _epsilon));
            //_var_vec.set_element(Dim(0, i), var[i]);
        }
    }
}

void AudioBatNormalLayer::inter_forward_em1(std::vector<IOPackage*>& in_pack) {

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    _mask = in_pack[0]->get_mask();

    out->audio_batch_norm_inf(
            *in,
            *_gamma.w(),
            *_beta.w(),
            _run_mean,
            _run_var,
            *_mask,
            _epsilon);
}

void AudioBatNormalLayer::read_initial_mean_var_em0(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");
    CHECK(fin != NULL, "Open file error %s", file_name);

    std::vector<float> mean, var;
    float mv = 0.0f;

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        var.push_back(mv);
        _run_var.set_element(Dim(0, i), mv);
    }

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        mean.push_back(mv);
        _run_mean.set_element(Dim(0, i), mv);
    }

    fclose(fin);

#if 0
    _w.resize(Dim(1, _frame_dim), GPU);
    _bias.resize(Dim(1, _frame_dim), GPU);

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        _w.w()->set_element(Dim(0, i), mean[i]);
        _bias.w()->set_element(Dim(0, i), var[i]);
    }

#endif
}

void AudioBatNormalLayer::inter_forward_em0(std::vector<IOPackage*>& in_pack) {
    size_t width = in_pack[0]->get_width();
    CHECK2((int)width == _frame_dim);

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    _mask = in_pack[0]->get_mask();

    _real_frame_num = _mask->sum();
    out->audio_batch_norm_train(
            *in,
            *_gamma.w(),
            *_beta.w(),
            *_mask,
            _run_mean,
            _run_var,
            _statis_mean_vec,
            _statis_var_vec,
            _mean_vec,
            _var_vec,
            _real_frame_num,
            _eta,
            _moving_average_fraction,
            _epsilon);

    _counter = _counter * _moving_average_fraction + 1;
}

void AudioBatNormalLayer::inter_bprop_diff(
    std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    INTER_CHECK(need_update(), "the need_update is false");
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten(); // NOTICE: not _diff

    out_diff->audio_batch_norm_bp(
            *in,
            *local_diff,
            *_gamma.w(),
            _mean_vec,
            _var_vec,
            *_mask,
            *_d_gamma.w(),
            *_d_beta.w(),
            _real_frame_num,
            _eta,
            _epsilon);
}

void AudioBatNormalLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
            std::vector<IOPackage*>& out_pack) {
    /* nothing todo */
}

void AudioBatNormalLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->write(output);
		if (_inq) {
			_gamma_t.w()->write(output);
			Tensor<DType> max(Dim(1), CPU);
			max.set_element(Dim(0), _inq_weight_max.front());
			max.write(output);
		}

        _beta.w()->write(output);
		if (_inq) {
			_beta_t.w()->write(output);
			Tensor<DType> max(Dim(1), CPU);
			max.set_element(Dim(0), _inq_bias_max.front());
			max.write(output);
		}

        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the AudioBatNormLayer has no this parameter: %d", t);
    }

}

void AudioBatNormalLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->read(input);
        _beta.w()->read(input);
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the AudioBatNormalLayer has no this parameter: %d", t);
    }
}

void AudioBatNormalLayer::read_inq_model(std::ifstream &input, SPEECH_NN_W_TYPE t)
{
    switch (t) {
        case WEIGHT:
            _gamma.w()->read(input);
            if (_inq) {
                _gamma_t.w()->read(input);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_weight_max.push_back(max.get_element(Dim(0)));
            }

            _beta.w()->read(input);
            if (_inq) {
                _beta_t.w()->read(input);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_bias_max.push_back(max.get_element(Dim(0)));
            }
            break;

        case MD_WEIGHT:
        default:
            INTER_CHECK(false, "the AudioBatNormLayer has no this parameter: %d", t);
    }
}

void AudioBatNormalLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->read_hfnn(input);
        _beta.w()->read_hfnn(input);
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the AudioBatNormLayer has no this parameter: %d", t);
    }
}

void AudioBatNormalLayer::read_heter_model(std::ifstream& input) {
    INTER_CHECK(false, "Not implemented");
}
void AudioBatNormalLayer::store_mean_var() {
    Tensor<DType> mean {CPU};
    Tensor<DType> var {CPU};
    char name[256] = {0};
    // 时间, 格式如下(年月日时分秒): 20161124112460
    char datetime[20];
    get_datetime(datetime);

    if (access("statis_bn", 0) == -1) {
        mkdir("statis_bn", S_IRWXU);
    }

    snprintf(name, 256, "statis_bn/Statis_Layer_%s_pid_%u_tid_%u_part_%lu_time_%s.sta",
             _name.c_str(), _pid, _tid, _store_item, datetime);
    mean.resize(Dim(1, _frame_dim));
    var.resize(Dim(1, _frame_dim));

    //计算真正的mean，var
    _statis_mean_vec.mul(1.0f / _counter);
    _statis_var_vec.mul(1.0f / _counter);

    mean.copy_from(_statis_mean_vec);
    var.copy_from(_statis_var_vec);

    std::ofstream in_out(name, std::ios::binary);
    size_t mean_var_dim = _statis_mean_vec.get_w();
    in_out.write((char*)&mean_var_dim, sizeof(size_t));

    // current mean & var
    size_t frame_counter = 1;
    in_out.write((char*)&frame_counter, sizeof(size_t));
    in_out.write((char*)mean.get_data(), _frame_dim * sizeof(DType));
    in_out.write((char*)var.get_data(), _frame_dim * sizeof(DType));

    _store_item++;
}

}
}

