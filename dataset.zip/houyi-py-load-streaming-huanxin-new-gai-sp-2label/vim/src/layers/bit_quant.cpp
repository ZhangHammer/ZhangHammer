// by wangguibin 2018.06.08
#include <string>
#include "bit_quant.h"
#include "user_ops.h"

namespace houyi {
namespace train {

BitQuant::BitQuant(BitQuantConfig& config) : Layer(config) {
    set_device();
    _config = config;
    _nbits = config.get_nbits();
    _algo = config.get_algo();
    _input_alpha = config.get_alpha();

    build_map();
}

void BitQuant::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
        "%s layer only have one input", _name.c_str());
    CHECK(inputs[0]->get_size().get_axis() == 2, 
        "%s layer only support 2-d input", _name.c_str());
    CHECK2(_nbits > 0);

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _alpha.resize(Dim(1, _nbits), gpu_device());
    if (_input_alpha.size()) {
        CHECK2(_nbits >= _input_alpha.size());
        for (size_t i = 0; i < _input_alpha.size(); i++) {
            _alpha.set_element(Dim(0, i), _input_alpha[i]);
        } 
    }
    _batch_alpha.set_device(gpu_device());
    _batch_beta.set_device(gpu_device());

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void BitQuant::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int height = inputs[0]->get_size()[0];
    int width = inputs[0]->get_size()[1];

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(height, width),  inputs[i]->get_mask(), 
                          gpu_device());
    }
}

void BitQuant::build_map(const char* prefix) {
}

BitQuant::BitQuant(BitQuant* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) BitQuant(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

BitQuant::~BitQuant() {
}

void BitQuant::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    float tmp1 = 0;
    float tmp2 = 0;
    bool log = (rand() % 100 == 0) ? true : false;
    if (log) {
        tmp1 = pre_in->norm2();
    }

    if (_algo == QUANT_BIT) {
        bit_quantize(*out, *pre_in);
        
    } else if (_algo == QUANT_GREEDY) {
        greedy_quantize(*out, *pre_in);

    } else if (_algo == QUANT_FIXED) {
        wind_fixed(*out, *pre_in, _nbits);
    }

    if (log) {
        tmp2 = out->norm2();
        INTER_LOG("Layer %s quantion error = %f (%f / %f)", _name.c_str(), tmp2 / tmp1, tmp2, tmp1);
    }
}

void BitQuant::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    if (!out_pack[0]) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    pre_diff->copy_from(*in_diff);
}

void BitQuant::inter_bprop_grad(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
}

bool BitQuant::bit_quantize(Tensor<DType>& out, const Tensor<DType>& in) {
    bool ret = false;

    out.copy_from(in);

    _batch_alpha.resize(Dim(out.get_height(), _nbits));
    _batch_beta.resize(Dim(out.get_height(), _nbits, out.get_width()));
        
    out.add(-0.5f);
    wind_fixed_alpha(_batch_alpha, out);
    wind_quantize(out, _batch_alpha);
    out.add(0.5f);

    return ret;
}

bool BitQuant::greedy_quantize(Tensor<DType>& out, const Tensor<DType>& in) {
    bool ret = true;
    out.copy_from(in);
    wind_greedy_quantize(out, _nbits, _alpha);
    return ret;
}

void BitQuant::store_quant_alpha(int device_id) {
    Tensor<DType> quant {CPU};
    char name[256] = {0};
    // 时间, 格式如下(年月日时分秒): 20161124112460
    char datetime[20];
    get_datetime(datetime);

    if (access("statis_quant", 0) == -1) {
        mkdir("statis_quant", S_IRWXU);
    }

    snprintf(name, 256, "statis_quant/Statis_Layer_%s_dev_%d_seq_%lu_time_%s.sta",
             _name.c_str(), device_id, _quant_cnt, datetime);
    quant.resize(_alpha.get_size());
    quant.copy_from(_alpha);

    std::ofstream in_out(name, std::ios::binary);
    in_out.write((char*)&_nbits, sizeof(size_t));

    in_out.write((char*)quant.get_data(), _nbits * sizeof(DType));

    _quant_cnt++;
}

Layer* BitQuant::clone() {
    return new BitQuant(this);
}

void BitQuant::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
}

void BitQuant::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
}

void BitQuant::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
}

} // namespace houyi
} // namespace train

