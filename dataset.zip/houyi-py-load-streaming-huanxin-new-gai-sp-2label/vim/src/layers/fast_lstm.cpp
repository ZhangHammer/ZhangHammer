/**
 * fast_lstm.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-25
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include "user_ops.h"
#include "fast_lstm.h"

namespace houyi {
namespace train {

static const int GATE_NUMBER = 4;
static const int W_CEC_NUMBER = 3;

FastLstmLayer::FastLstmLayer(LstmConfig& conf) : Layer(conf) {
    set_device();
    _config = conf;

#if 0
    int tbptt = conf.tbptt();
#endif
    size_t cell_dim = conf.cell_dim();
    size_t out_dim = conf.get_output_dim();
    size_t rec_dim = conf.rec_dim();
    _skip_num = conf.skip_num();
#if 1
    _t_bptt    = 1;
#endif
    //_t_bptt    = tbptt;
    _cell_dim  = cell_dim;
    _rec_dim   = rec_dim;
    _out_dim   = out_dim;
    _nxt_start = 0;

    _gcec_x_w = _cell_dim * GATE_NUMBER; // 4: inputGate + forgetGate + outGate + cell

    _gcec_c_w = _cell_dim; // 3: inputGate + forgetGate + outGate

    if (!_rec_dim) {
        _rec_dim = _out_dim;
    }

    _gcec_r_h =  _rec_dim;
    _gcec_r_w = _cell_dim * GATE_NUMBER;// 4: inputGate + forgetGate + outGate + cell

    _rec_act = Activation::create(conf.rec_act());

    //act for max-out
    if (conf.pooling_size() != 0) {
        _mid_act = Activation::create(conf.mid_act(), conf.pooling_size());
    } else {
        _mid_act = NULL;
    }

    build_map();

    _dr_threshold = conf.dr_threshold();
    _dc_threshold = conf.dc_threshold();
    _statis_dc = 0.0f;
    _statis_dr = 0.0f;
    _statis_counter = 0;
    _statis_sentence_counter = 0;

    _max_min_counter = 0;
    _max_min_sentence_counter = 0;
    _statis_max = conf.error_statistic_num();
    _cec_min = conf.cec_out_limit_lo();
    _cec_max = conf.cec_out_limit_hi();
    _max_min_sentence_number = conf.cec_o_statistic_num();

    _final_mean_norm_dw_r = -1.0;
    _final_mean_norm_dw_x_gcec = -1.0;
    _final_mean_norm_dw_r_gcec = -1.0;
    _final_mean_norm_dw_c_gcec = -1.0;
    _final_mean_norm_d_bias_gcec = -1.0;

    _final_stdv_norm_dw_r = -1.0;
    _final_stdv_norm_dw_x_gcec = -1.0;
    _final_stdv_norm_dw_r_gcec = -1.0;
    _final_stdv_norm_dw_c_gcec = -1.0;
    _final_stdv_norm_d_bias_gcec = -1.0;

    _mean_norm_dw_r = 0.0;
    _mean_norm_dw_x_gcec = 0.0;
    _mean_norm_dw_r_gcec = 0.0;
    _mean_norm_dw_c_gcec = 0.0;
    _mean_norm_d_bias_gcec = 0.0;

    _stdv_norm_dw_r = 0.0;
    _stdv_norm_dw_x_gcec = 0.0;
    _stdv_norm_dw_r_gcec = 0.0;
    _stdv_norm_dw_c_gcec = 0.0;
    _stdv_norm_d_bias_gcec = 0.0;

    _mean_counter = 0;
    _mean_batch_number = conf.mean_statistic_num();

    _sub_seq_size = 0;
}

FastLstmLayer::FastLstmLayer(FastLstmLayer* from) : Layer(from) {
    set_device();
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) FastLstmLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    _w_x_gcec.resize_like(*from->w_x_gcec());
    _w_x_gcec.copy_from(*from->w_x_gcec());
    _bias_gcec.resize_like(*from->bias_gcec());
    _bias_gcec.copy_from(*from->bias_gcec());
    _w_c_gcec.resize_like(*from->w_c_gcec());
    _w_c_gcec.copy_from(*from->w_c_gcec());
    _w_r_gcec.resize_like(*from->w_r_gcec());
    _w_r_gcec.copy_from(*from->w_r_gcec());

    if (!_mid_act) {
        _w_r.resize_like(*from->w_r());
        _w_r.copy_from(*from->w_r());
    }

    if (_inq) {
        _w_x_gcec_t.resize_like(*from->w_x_gcec_t());
        _w_x_gcec_t.copy_from(*from->w_x_gcec_t());
        _bias_gcec_t.resize_like(*from->bias_gcec_t());
        _bias_gcec_t.copy_from(*from->bias_gcec_t());
        _w_c_gcec_t.resize_like(*from->w_c_gcec_t());
        _w_c_gcec_t.copy_from(*from->w_c_gcec_t());
        _w_r_gcec_t.resize_like(*from->w_r_gcec_t());
        _w_r_gcec_t.copy_from(*from->w_r_gcec_t());

        if (!_mid_act) {
            _w_r_t.resize_like(*from->w_r_t());
            _w_r_t.copy_from(*from->w_r_t());
        }
    }
}

void FastLstmLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    bool need_update = _config.need_update();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num * _skip_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _feat_dim  = inputs[0]->get_width();
    _gcec_x_h =  _feat_dim;

    _w_x_gcec.resize(Dim(_gcec_x_h, _gcec_x_w), gpu_device());
    _bias_gcec.resize(Dim(1, _gcec_x_w), gpu_device());

    if (need_update) {
        _dw_x_gcec.resize(Dim(_gcec_x_h, _gcec_x_w), gpu_device());
        _d_bias_gcec.resize(Dim(1, _gcec_x_w), gpu_device());
    }

    _w_c_gcec.resize(Dim(W_CEC_NUMBER, _gcec_c_w), gpu_device());

    if (need_update) {
        _dw_c_gcec.resize(Dim(W_CEC_NUMBER, _gcec_c_w), gpu_device());
    }

    if (_rec_dim) {
        _bias.resize(Dim(1, _out_dim), gpu_device());

        if (need_update) {
            _d_bias.resize(Dim(1, _out_dim), gpu_device());
        }
    }

    _w_r_gcec.resize(Dim(_gcec_r_h, _gcec_r_w), gpu_device());

    if (need_update) {
        _dw_r_gcec.resize(Dim(_gcec_r_h, _gcec_r_w), gpu_device());
    }

    // matrix
    if (!_mid_act) {
        _w_r.resize(Dim(_cell_dim, _rec_dim), gpu_device());

        if (need_update) {
            _dw_r.resize(Dim(_cell_dim, _rec_dim), gpu_device());
        }
    }

    // matrix
    if (!_mid_act) {
        _w_r.resize(Dim(_cell_dim, _rec_dim), gpu_device());

        if (need_update) {
            _dw_r.resize(Dim(_cell_dim, _rec_dim), gpu_device());
        }
    }

    if (_inq) {
        _w_x_gcec_t.resize(Dim(_gcec_x_h, _gcec_x_w), gpu_device());
		_w_x_gcec_t.w()->set_element(1);
        _bias_gcec_t.resize(Dim(1, _gcec_x_w), gpu_device());
		_bias_gcec_t.w()->set_element(1);
        _w_c_gcec_t.resize(Dim(W_CEC_NUMBER, _gcec_c_w), gpu_device());
		_w_c_gcec_t.w()->set_element(1);
        if (_rec_dim) {
            _bias_t.resize(Dim(1, _out_dim), gpu_device());
            _bias_t.w()->set_element(1);
        }
        _w_r_gcec_t.resize(Dim(_gcec_r_h, _gcec_r_w), gpu_device());
		_w_r_gcec_t.w()->set_element(1);
        if (!_mid_act) {
            _w_r_t.resize(Dim(_cell_dim, _rec_dim), gpu_device());
            _w_r_t.w()->set_element(1);
        }
    }

    int frame_num = inputs[0]->get_size()[0];
    CHECK(frame_num % _skip_num == 0, "frame num must be divisible by skip num");
    _sub_seq_size = frame_num / _sample_num;

    _state_oe_c.resize(frame_num, _t_bptt * _sample_num, _cell_dim);
    _state_oe_r.resize(frame_num, _t_bptt * _sample_num, _rec_dim);

    resize_tensor(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void FastLstmLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int frame_num = inputs[0]->get_size()[0];
    CHECK(frame_num % _skip_num == 0, "frame num must be divisible by skip num");
    /* todo:支持batch size变化 */
    //CHECK(_sample_num == sample_num * _skip_num, "sample num error");
    _sample_num = sample_num * _skip_num;
    _sub_seq_size = frame_num / _sample_num;

    Tensor<DType> pre_c0 {gpu_device()};
    Tensor<DType> pre_r0 {gpu_device()};
    pre_c0.resize(Dim(_sample_num, _cell_dim));
    pre_r0.resize(Dim(_sample_num, _rec_dim));

    int start = 1;
    pre_c0.copy_from(_state_oe_c._all_o.range_row(start - 1, start, _sample_num));
    pre_r0.copy_from(_state_oe_r._all_o.range_row(start - 1, start, _sample_num));

    _state_oe_c.resize(frame_num, _t_bptt * _sample_num, _cell_dim);
    _state_oe_r.resize(frame_num, _t_bptt * _sample_num, _rec_dim);
    _state_oe_c._all_o.range_row(_t_bptt - 1, _t_bptt, _sample_num).copy_from(pre_c0);
    _state_oe_r._all_o.range_row(_t_bptt - 1, _t_bptt, _sample_num).copy_from(pre_r0);

    resize_tensor(inputs, sample_num);
}

void FastLstmLayer::resize_tensor(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int frame_num = inputs[0]->get_size()[0];

    _gcec_o.resize(Dim(frame_num, _cell_dim * GATE_NUMBER));
    _m_o.resize(Dim(frame_num, _cell_dim));
    _hc_o.resize(Dim(frame_num, _cell_dim));

    _in_gate_o.resize(Dim(frame_num, _cell_dim));
    _out_gate_o.resize(Dim(frame_num, _cell_dim));
    _fgt_gate_o.resize(Dim(frame_num, _cell_dim));
    _gc_o.resize(Dim(frame_num, _cell_dim));

    _error_gcec.resize(Dim(frame_num, _cell_dim * GATE_NUMBER));
    _error_m.resize(Dim(frame_num, _cell_dim));
    _cur_error_c.resize(Dim(_sample_num, _cell_dim));

    _back_error_c.resize(Dim(_sample_num, _cell_dim));
    _back_error_r.resize(Dim(_sample_num, _rec_dim));

    output(_output_keys[0]).resize(Dim(frame_num, _out_dim), inputs[0]->get_mask(), 
                                   gpu_device());
}

void FastLstmLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "w_x_gcec", &_w_x_gcec));
    _w_map.insert(WeightsMap::value_type(pre + "bias_gcec", &_bias_gcec));
    _w_map.insert(WeightsMap::value_type(pre + "w_c_gcec", &_w_c_gcec));
    _w_map.insert(WeightsMap::value_type(pre + "w_r_gcec", &_w_r_gcec));

    if (!_mid_act) {
        _w_map.insert(WeightsMap::value_type(pre + "w_r", &_w_r));
    }

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "w_x_gcec", &_dw_x_gcec));
        _dw_map.insert(WeightsMap::value_type(pre + "bias_gcec", &_d_bias_gcec));
        _dw_map.insert(WeightsMap::value_type(pre + "w_c_gcec", &_dw_c_gcec));
        _dw_map.insert(WeightsMap::value_type(pre + "w_r_gcec", &_dw_r_gcec));

        if (!_mid_act) {
            _dw_map.insert(WeightsMap::value_type(pre + "w_r", &_dw_r));
        }
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "w_x_gcec_binary", &_w_x_gcec_t));
        _w_map.insert(WeightsMap::value_type(pre + "bias_gcec_binary", &_bias_gcec_t));
        _w_map.insert(WeightsMap::value_type(pre + "w_c_gcec_binary", &_w_c_gcec_t));
        _w_map.insert(WeightsMap::value_type(pre + "w_r_gcec_binary", &_w_r_gcec_t));

        if (!_mid_act) {
            _w_map.insert(WeightsMap::value_type(pre + "w_r_binary", &_w_r_t));
        }
    }
}

void FastLstmLayer::set_next_start() {
    //_w_x_gcec
    _nxt_start++;
    //_bias_gcec
    _nxt_start++;
    //_w_c_gcec
    _nxt_start++;
    //_w_r_gcec
    _nxt_start++;

    if (!_mid_act) {
        //_w_r
        _nxt_start++;
    }
}

void FastLstmLayer::heuristic_clear_history(std::vector<int>& his_vec) {
    // clear history
    CHECK2(_sample_num <= (int)his_vec.size());

    for (int ii = 0; ii < _sample_num; ii++) {
        if (his_vec[ii]) {
            _state_oe_c.reset(ii, _sample_num);
            _state_oe_r.reset(ii, _sample_num);
        }
    }
}

void FastLstmLayer::squash_out(int t) {
    if (_max_min_sentence_number > 0) {
        if (!_o_max.is_init()) {
            _o_max.resize(Dim(1, _sample_num));
            _o_min.resize(Dim(1, _sample_num));
            _o_max_sum.resize(Dim(1, _sample_num));
            _o_min_sum.resize(Dim(1, _sample_num));
        }

        _o_max.row_max(_state_oe_c._cur_o->range_row(t, t + 1, _sample_num));
        _o_max_sum.elem_add(_o_max_sum, _o_max);
        _o_min.row_min(_state_oe_c._cur_o->range_row(t, t + 1, _sample_num));
        _o_min_sum.elem_add(_o_min_sum, _o_min);
        _max_min_counter += _sample_num;
    }

    if ((_cec_max - _cec_min) > 0.0f) {
        _state_oe_c._cur_o->range_row(t, t + 1, _sample_num).limit(_cec_min, _cec_max);
    }

}

void FastLstmLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();
#if 0
    Tensor<int>tmp_mask{gpu_device()};
    tmp_mask.resize(mask->get_size());
    tmp_mask.copy_from(*mask);
    mask->set_element(1);
#endif

    Dim dim = in->get_size();

    if (_is_reversal) {
        int real_sample_num = _sample_num / _skip_num;
        int real_sub_seq_size = _sub_seq_size * _skip_num;

        _reverse.resize(dim);
        _reverse_out.resize(out->get_size());
        _seq_len.resize(Dim(real_sample_num));
        _seq_len.count_valid_label(*mask, real_sample_num, real_sub_seq_size);
        _reverse.mask_reverse(*in, _seq_len, real_sample_num, real_sub_seq_size);
        in = &_reverse;
        out = &_reverse_out;
    }

    in->reshape(Dim(in->get_size(0), in->get_element_count() / in->get_size(0)));
    //out->resize(in->get_height(), _out_dim);
    //todo:remove, use resize_out_pack()
    //set_sample_num(in->get_height());
    CHECK2(in->get_height() % _sample_num == 0);
    size_t sample_num = in->get_height() / _sample_num;

    _state_oe_c.set_sent_length(mask, _sample_num);
    _state_oe_r.set_sent_length(mask, _sample_num);
    
    // X * Wx
    _gcec_o.mul(*in, *_w_x_gcec.w());
    _gcec_o.row_add_vec(_gcec_o, *_bias_gcec.w(), 1.0f, 1.0f);

    wind_set_sync_flag(false);

    for (size_t t = 0; t < sample_num; t++) {
        size_t start_r = _t_bptt + t - 1;
        size_t end_r   = _t_bptt + t;
        if (_intl_quant_bits) {
            Tensor<DType> tmp = _state_oe_r._all_o.range_row(start_r, end_r, _sample_num);
            intl_quantize(tmp, 0);
        }

        // R(t-1) * Wr
        _gcec_o.range_row(t, t + 1, _sample_num).mul(
            _state_oe_r._all_o.range_row(start_r, end_r, _sample_num),
            *_w_r_gcec.w(), 1.0f, 1.0f);

        Tensor<DType> c_cur = _state_oe_c._cur_o->range_row(t, t + 1, _sample_num);
        Tensor<DType> c_pre = _state_oe_c._all_o.range_row(start_r, end_r, _sample_num);
        Tensor<DType> i_out = _in_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> f_out = _fgt_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> c_out = _gc_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> o_out = _out_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> hc_out = _hc_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> m_out = _m_o.range_row(t, t + 1, _sample_num);
        m_out.lstm_op(_gcec_o.range_row(t, t + 1, _sample_num),
                      get_w_c(INPUT_C),
                      get_w_c(FORGET_C),
                      get_w_c(OUTPUT_C),
                      c_pre,
                      c_cur,
                      i_out,
                      f_out,
                      c_out,
                      o_out,
                      hc_out,
                      _cec_max,
                      _cec_min);

        if (_max_min_sentence_number > 0) {
            if (!_o_max.is_init()) {
                _o_max.resize(Dim(1, _sample_num));
                _o_min.resize(Dim(1, _sample_num));
                _o_max_sum.resize(Dim(1, _sample_num));
                _o_min_sum.resize(Dim(1, _sample_num));
            }

            _o_max.row_max(c_cur);
            _o_max_sum.elem_add(_o_max_sum, _o_max);
            _o_min.row_min(c_cur);
            _o_min_sum.elem_add(_o_min_sum, _o_min);
            _max_min_counter += _sample_num;
        }
        if (_intl_quant_bits) {
            Tensor<DType> tmp = _m_o.range_row(t, t + 1, _sample_num);
            intl_quantize(tmp, 1);
        }

        // r(t) = m(t) * Wr
        _state_oe_r._cur_o->range_row(t, t + 1, _sample_num).mul(
            _m_o.range_row(t, t + 1, _sample_num),
            *_w_r.w(), 1.0f, 0.0f);

        Tensor<DType> current_o = _state_oe_r._cur_o->range_row(t, t + 1, _sample_num);
        _rec_act->forward(current_o, current_o);
        // _state_oe_r._cur_o->range_row(t, t + 1, _sample_num),
        // _state_oe_r._cur_o->range_row(t, t + 1, _sample_num));
    }

    wind_set_sync_flag(true);
    wind_stream_synchronize(WIND_STREAM_DEFAULT);

    out->copy_from(*_state_oe_r._cur_o);

    if (_is_reversal) {
        int real_sample_num = _sample_num / _skip_num;
        int real_sub_seq_size = _sub_seq_size * _skip_num;
        out = output(_output_keys[0]).get_ten();
        in = in_pack[0]->get_ten();
        out->mask_reverse(_reverse_out, _seq_len, real_sample_num, real_sub_seq_size);
    }

    in->reshape(dim);
    in = out = NULL;
#if 0
    mask->copy_from(tmp_mask);
#endif 
}

void FastLstmLayer::cells_gate_backward(
    int t, Tensor<DType>& error_m,
    Tensor<DType>& out_gate_o,
    Tensor<DType>& in_gate_o,
    Tensor<DType>& hc_o) {

    _cur_error_c.ld_cell_cur_error(
        error_m.range_row(t, t + 1, _sample_num),
        out_gate_o.range_row(t, t + 1, _sample_num),
        hc_o.range_row(t, t + 1, _sample_num),
        get_oe(OUTPUT_ERROR).range_row(t, t + 1, _sample_num),
        get_w_c(OUTPUT_C),
        _back_error_c);

    get_oe(CELL_ERROR).range_row(t, t + 1, _sample_num).ld_tanh_backprop(
        _cur_error_c,
        in_gate_o.range_row(t, t + 1, _sample_num),
        _gc_o.range_row(t, t + 1, _sample_num));
}

void FastLstmLayer::calcu_rec_back_error(int t) {
    _back_error_r.mul(_error_gcec.range_row(t, t + 1, _sample_num), false, *_w_r_gcec.w(), true);
}

void FastLstmLayer::cal_time_gradient() {
    int st_row = _state_oe_r._all_o.get_height() / _sample_num - _sub_seq_size - 1;
    int ed_row = _state_oe_r._all_o.get_height() / _sample_num - 1;

    if (need_update()) {
        Tensor<DType> tmp_in {gpu_device()};
        _dw_r.w()->mul(_m_o, true, _state_oe_r._error, false, 1.0f, 0.0f);

        _dw_r_gcec.w()->mul(_state_oe_r._all_o.range_row(st_row, ed_row, _sample_num),
                            true, _error_gcec, false);
        //tmp_in.clear();

        // input_gate-Wc
        get_dw_c(INPUT_C).diag_mat_diff(
            _state_oe_c._all_o.range_row(st_row, ed_row, _sample_num),
            get_oe(INPUT_ERROR));

        // forget_gate-Wc
        get_dw_c(FORGET_C).diag_mat_diff(
            _state_oe_c._all_o.range_row(st_row, ed_row, _sample_num),
            get_oe(FORGET_ERROR));

        // output_gate-Wc
        get_dw_c(OUTPUT_C).diag_mat_diff(
            _state_oe_c._all_o.range_row(st_row + 1, ed_row + 1, _sample_num),
            get_oe(OUTPUT_ERROR));
    }
}

void FastLstmLayer::calcu_cec_back_error(int t) {
    _back_error_c.elem_mul(
        _cur_error_c, _fgt_gate_o.range_row(t, t + 1, _sample_num));
    _back_error_c.row_mul_vec(
        get_oe(FORGET_ERROR).range_row(t, t + 1, _sample_num),
        get_w_c(FORGET_C), 1.0f, 1.0f);
    _back_error_c.row_mul_vec(
        get_oe(INPUT_ERROR).range_row(t, t + 1, _sample_num),
        get_w_c(INPUT_C), 1.0f, 1.0f);
}

//void FastLstmLayer::store_current_out()
void FastLstmLayer::store_history() {
    if (_is_reversal) {
        return;
    }

    //_state_oe_c.store_cur_out();
    //_state_oe_r.store_cur_out();
    _state_oe_c.store_cur_out(_sample_num);
    _state_oe_r.store_cur_out(_sample_num);
}

void FastLstmLayer::input_error_backprop(Tensor<DType>& outError) {
    Tensor<DType> tmp_w {gpu_device()};
    //outError.resize(Dim(_sub_seq_size * _sample_num, _feat_dim));
    outError.mul(_error_gcec, false, *_w_x_gcec.w(), true, 1.0f, 1.0f);
    //tmp_w.clear();
}

void FastLstmLayer::linear_gradient(const Tensor<DType>& x) {
    if (need_update()) {
        Tensor<DType> tmp_in {gpu_device()};

        // gcec_w_x
        //tmp_in.transpose(x);
        _dw_x_gcec.w()->mul(x, true, _error_gcec, false, 1.0f, 0.0f);

        // gcec_bias
        _d_bias_gcec.w()->collect_bias(_error_gcec, 1.0f, 0.0f);
        //tmp_in.clear();
    }
}

void FastLstmLayer::inter_bprop_diff(
    std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    
    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Dim dim = out_diff->get_size();

    if (_is_reversal) {
        int real_sample_num = _sample_num / _skip_num;
        int real_sub_seq_size = _sub_seq_size * _skip_num;
        _reverse_in_diff.resize(in_diff->get_size());
        _reverse_pre_diff.resize(out_diff->get_size());
        _reverse_in_diff.mask_reverse(*in_diff, _seq_len, real_sample_num, real_sub_seq_size);
        in_diff = &_reverse_in_diff;
        out_diff = &_reverse_pre_diff;
    }

    out_diff->reshape(Dim(out_diff->get_size(0),
                          out_diff->get_element_count() / out_diff->get_size(0)));

    //CHECK(_t_bptt == _sub_seq_size,
    //      "the bptt must be equal with the size of subsequence.");

    _back_error_c.resize(Dim(_sample_num, _cell_dim));
    _back_error_r.resize(Dim(_sample_num, _rec_dim));
    _back_error_c.zero();
    _back_error_r.zero();

    //_error_gcec.zero();
    //_error_m.zero();
    //_cur_error_c.zero();
    Tensor<DType> tmp_w {gpu_device()};
    size_t st_row = 0;
    size_t ed_row = 0;
    _state_oe_r._error.copy_from(*(const_cast<Tensor<DType>*>(in_diff)));
    wind_set_sync_flag(false);

    for (int t = _sub_seq_size - 1; t >= 0; t--) {
        st_row = _state_oe_r._all_o.get_height() / _sample_num - (_sub_seq_size - t);
        ed_row = st_row + 1;

        // add back-error from last frame
        _state_oe_r._error.range_row(t, t + 1, _sample_num).elem_add(
                _state_oe_r._error.range_row(t, t + 1, _sample_num), _back_error_r);

        Tensor<DType> error_t = _state_oe_r._error.range_row(t, t + 1, _sample_num);
        Tensor<DType> all_t = _state_oe_r._all_o.range_row(st_row, ed_row, _sample_num);
        _rec_act->backward(error_t, all_t, error_t);
        //_rec_act->backward(
        //        _state_oe_r._error.range_row(t, t + 1, _sample_num),
        //        _state_oe_r._all_o.range_row(st_row, ed_row, _sample_num),
        //        _state_oe_r._error.range_row(t, t + 1, _sample_num));

        if (!_mid_act) {
            //tmp_w.transpose(*_w_r.w());
            _error_m.range_row(t, t + 1, _sample_num).mul(
                _state_oe_r._error.range_row(t, t + 1, _sample_num), false,
                *_w_r.w(), true);
        } else {
            Tensor<DType> all_o = _state_oe_r._all_o.range_row(t, t + 1, _sample_num);
            Tensor<DType> error_m = _error_m.range_row(t, t + 1, _sample_num);
            _mid_act->backward(error_t, all_o, error_m, t, _t_bptt, 1.0f, 1.0f);
            //_mid_act->backward(
            //        _state_oe_r._error.range_row(t, t + 1, _sample_num),
            //        _state_oe_r._all_o.range_row(t, t + 1, _sample_num),
            //        _error_m.range_row(t, t + 1, _sample_num),
            //        t, _t_bptt, 1.0f, 1.0f);
        }

        Tensor<DType> c_cur = _state_oe_c._cur_o->range_row(t, t + 1, _sample_num);
        Tensor<DType> i_out = _in_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> f_out = _fgt_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> c_out = _gc_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> o_out = _out_gate_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> hc_out = _hc_o.range_row(t, t + 1, _sample_num);
        Tensor<DType> wx_err = _error_gcec.range_row(t, t + 1, _sample_num);
        Tensor<DType> c_pre = _state_oe_c._all_o.range_row(st_row - 1, ed_row - 1, _sample_num);
        wx_err.lstm_bp_op(i_out,
                          f_out,
                          c_out,
                          o_out,
                          get_w_c(OUTPUT_C),
                          _error_m.range_row(t, t + 1, _sample_num),
                          hc_out,
                          c_pre,
                          _back_error_c,
                          _cur_error_c);

        // recurrent - back error
        calcu_rec_back_error(t);
        clip_error_update(_back_error_r, _dr_threshold);

        // cells - back error
        //calcu_cec_back_error(t);
        _back_error_c.ld_cell_back_error(
            _cur_error_c, _fgt_gate_o.range_row(t, t + 1, _sample_num),
            get_oe(FORGET_ERROR).range_row(t, t + 1, _sample_num),
            get_w_c(FORGET_C),
            get_oe(INPUT_ERROR).range_row(t, t + 1, _sample_num),
            get_w_c(INPUT_C));

        clip_error_update(_back_error_c, _dc_threshold);
    }

    wind_set_sync_flag(true);
    tmp_w.clear();

    // error-backprop
    input_error_backprop(*out_diff);

    if (_is_reversal) {
        int real_sample_num = _sample_num / _skip_num;
        int real_sub_seq_size = _sub_seq_size * _skip_num;
        out_diff = out_pack[0]->get_ten();
        out_diff->mask_reverse(_reverse_pre_diff, _seq_len, real_sample_num, real_sub_seq_size);
    }

    out_diff->reshape(dim);
}

void FastLstmLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
            std::vector<IOPackage*>& out_pack) {
    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }
    Tensor<DType>* in_feat = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();

    Dim dim = in_feat->get_size();

    if (_is_reversal) {
        in_feat = &_reverse;
        out_diff = &_reverse_pre_diff;
    }

    in_feat->reshape(Dim(in_feat->get_size(0), in_feat->get_element_count() / in_feat->get_size(0)));

    //
    cal_time_gradient();
    // dwx
    linear_gradient(*in_feat);

    // store the cell & recurrent state
    store_history();

    if (!clip_gradient()) {
        clear_gradient();

        if (_is_reversal) {
            _reverse_pre_diff.zero();
            out_diff = out_pack[0]->get_ten();
        }

        out_diff->zero();
        weight_flag(false);
    }

    in_feat->reshape(dim);
}

void FastLstmLayer::linear_backprop(const Tensor<DType>& inError) {
    //_error_m.zero();
    DType beta = 0.0f;
    _state_oe_r._error.elem_add(_state_oe_r._error,
            *(const_cast<Tensor<DType>*>(&inError)), beta, 1.0f);
}

void FastLstmLayer::clear_gradient() {
    if (need_update()) {
        if (!_mid_act) {
            _dw_r.w()->zero();
        }

        _dw_c_gcec.w()->zero();
        _dw_r_gcec.w()->zero();
        _dw_x_gcec.w()->zero();
        _d_bias_gcec.w()->zero();
    }
}

bool FastLstmLayer::clip_gradient() {
    DType threshold = _updater->threshold();
    DType threshold_ratio = _updater->threshold_ratio();
    //DType norm = 0.0f;

    DType gate_threshold = threshold * GATE_NUMBER;
    DType cec_threshold = threshold * W_CEC_NUMBER;

    DType norm_dw_r = 0.0;
    DType norm_dw_c_gcec = 0.0;
    DType norm_dw_r_gcec = 0.0;
    DType norm_dw_x_gcec = 0.0;
    DType norm_d_bias_gcec = 0.0;

    bool ret_flag = true;

    if (need_update()) {
        if (!_mid_act) {
            norm_dw_r = _dw_r.w()->norm2();

            if (threshold > 0.0f && norm_dw_r > threshold && 
                        _config.get_drop_gradient() == false) {
                _dw_r.w()->mul(threshold / norm_dw_r);
                INTER_LOG("norm_dw_r = %f, threshold = %f",
                          norm_dw_r, threshold);
            }
            else if (threshold > 0.0f && norm_dw_r > threshold && 
                        _config.get_drop_gradient() == true) {
                _dw_r.w()->zero();
                INTER_LOG("norm_dw_r = %f, threshold = %f, drop",
                          norm_dw_r, threshold);
            }

            if (_final_mean_norm_dw_r > 0.0 && threshold_ratio > 0.0 &&
                    norm_dw_r > _final_mean_norm_dw_r + threshold_ratio * _final_stdv_norm_dw_r) {
                INTER_LOG("dw_r : norm = %f, mean = %f, stdv = %f",
                          norm_dw_r, _final_mean_norm_dw_r,
                          _final_stdv_norm_dw_r);
                ret_flag = false;
            }
        }

        // dw_c_gcec
        norm_dw_c_gcec = _dw_c_gcec.w()->norm2();

        if (threshold > 0.0f && norm_dw_c_gcec > cec_threshold && 
                    _config .get_drop_gradient() == false) {
            _dw_c_gcec.w()->mul(cec_threshold / norm_dw_c_gcec);
            INTER_LOG("norm_dw_c_gcec = %f, cec_threshold = %f",
                      norm_dw_c_gcec, cec_threshold);
        }
        else if (threshold > 0.0f && norm_dw_c_gcec > cec_threshold && 
                    _config .get_drop_gradient() == true) {
            _dw_c_gcec.w()->zero();
            INTER_LOG("norm_dw_c_gcec = %f, cec_threshold = %f, drop",
                      norm_dw_c_gcec, cec_threshold);
        }

        if (_final_mean_norm_dw_c_gcec > 0.0 && threshold_ratio > 0.0 &&
                norm_dw_c_gcec > _final_mean_norm_dw_c_gcec +
                threshold_ratio * _final_stdv_norm_dw_c_gcec) {
            INTER_LOG("dw_c_gcec : norm = %f, mean = %f, stdv = %f",
                      norm_dw_c_gcec, _final_mean_norm_dw_c_gcec,
                      _final_stdv_norm_dw_c_gcec);
            ret_flag = false;
        }

        // dw_r_gcec
        norm_dw_r_gcec = _dw_r_gcec.w()->norm2();

        if (threshold > 0.0f && norm_dw_r_gcec > gate_threshold && 
                    _config.get_drop_gradient() == false) {
            _dw_r_gcec.w()->mul(gate_threshold / norm_dw_r_gcec);
            INTER_LOG("norm_dw_r_gcec = %f, gate_threshold = %f",
                      norm_dw_r_gcec, gate_threshold);
        }
        else if (threshold > 0.0f && norm_dw_r_gcec > gate_threshold && 
                    _config.get_drop_gradient() == true) {
            _dw_r_gcec.w()->zero();
            INTER_LOG("norm_dw_r_gcec = %f, gate_threshold = %f, drop",
                      norm_dw_r_gcec, gate_threshold);
        }

        if (_final_mean_norm_dw_r_gcec > 0.0 && threshold_ratio > 0.0 &&
                norm_dw_r_gcec > _final_mean_norm_dw_r_gcec +
                threshold_ratio * _final_stdv_norm_dw_r_gcec) {
            INTER_LOG("dw_r_gcec : norm = %f, mean = %f, stdv = %f",
                      norm_dw_r_gcec, _final_mean_norm_dw_r_gcec,
                      _final_stdv_norm_dw_r_gcec);
            ret_flag = false;
        }

        // dw_x_gcec
        norm_dw_x_gcec = _dw_x_gcec.w()->norm2();

        if (threshold > 0.0f && norm_dw_x_gcec > gate_threshold && 
                    _config.get_drop_gradient() == false) {
            _dw_x_gcec.w()->mul(gate_threshold / norm_dw_x_gcec);
            INTER_LOG("norm_dw_x_gcec = %f, gate_threshold = %f",
                      norm_dw_x_gcec, gate_threshold);
        }
        else if (threshold > 0.0f && norm_dw_x_gcec > gate_threshold && 
                    _config.get_drop_gradient() == false) {
            _dw_x_gcec.w()->zero();
            INTER_LOG("norm_dw_x_gcec = %f, gate_threshold = %f, drop",
                      norm_dw_x_gcec, gate_threshold);
        }

        if (_final_mean_norm_dw_x_gcec > 0.0 && threshold_ratio > 0.0 &&
                norm_dw_x_gcec > _final_mean_norm_dw_x_gcec +
                threshold_ratio * _final_stdv_norm_dw_x_gcec) {
            INTER_LOG("dw_x_gcec : norm = %f, mean = %f, stdv = %f",
                      norm_dw_x_gcec, _final_mean_norm_dw_x_gcec,
                      _final_stdv_norm_dw_x_gcec);
            ret_flag = false;
        }

        // dw_d_bias_gcec
        norm_d_bias_gcec = _d_bias_gcec.w()->norm2();

        if (threshold > 0.0f && norm_d_bias_gcec > gate_threshold && 
                    _config.get_drop_gradient() == false) {
            _d_bias_gcec.w()->mul(gate_threshold / norm_d_bias_gcec);
            INTER_LOG("norm_d_bias_gcec = %f, gate_threshold = %f",
                      norm_d_bias_gcec, gate_threshold);
        }
        else if (threshold > 0.0f && norm_d_bias_gcec > gate_threshold && 
                    _config.get_drop_gradient() == true) {
            _d_bias_gcec.w()->zero();
            INTER_LOG("norm_d_bias_gcec = %f, gate_threshold = %f, drop",
                      norm_d_bias_gcec, gate_threshold);
        }

        if (_final_mean_norm_d_bias_gcec > 0.0 && threshold_ratio > 0.0 &&
                norm_d_bias_gcec > _final_mean_norm_d_bias_gcec +
                threshold_ratio * _final_stdv_norm_d_bias_gcec) {
            INTER_LOG("d_bias_gcec : norm = %f, mean = %f, stdv = %f",
                      norm_d_bias_gcec, _final_mean_norm_d_bias_gcec,
                      _final_stdv_norm_d_bias_gcec);
            ret_flag = false;
        }

        if (ret_flag && threshold_ratio > 0.0) {
            if (!_mid_act) {
                _mean_norm_dw_r += norm_dw_r;
                _stdv_norm_dw_r += norm_dw_r * norm_dw_r;
            }

            _mean_norm_dw_c_gcec += norm_dw_c_gcec;
            _stdv_norm_dw_c_gcec += norm_dw_c_gcec * norm_dw_c_gcec;

            _mean_norm_dw_r_gcec += norm_dw_r_gcec;
            _stdv_norm_dw_r_gcec += norm_dw_r_gcec * norm_dw_r_gcec;

            _mean_norm_dw_x_gcec += norm_dw_x_gcec;
            _stdv_norm_dw_x_gcec += norm_dw_x_gcec * norm_dw_x_gcec;

            _mean_norm_d_bias_gcec += norm_d_bias_gcec;
            _stdv_norm_d_bias_gcec += norm_d_bias_gcec * norm_d_bias_gcec;

            _mean_counter++;

            if (_mean_batch_number > 0 && _mean_counter >= _mean_batch_number) {

                _final_mean_norm_dw_r = _mean_norm_dw_r / _mean_counter;
                _final_stdv_norm_dw_r = sqrt(_stdv_norm_dw_r / _mean_counter -
                                             _final_mean_norm_dw_r * _final_mean_norm_dw_r);
                _mean_norm_dw_r = 0.0;
                _stdv_norm_dw_r = 0.0;
                //INTER_LOG("dw_r : mean = %f, stdv = %f",
                //        _final_mean_norm_dw_r, _final_stdv_norm_dw_r);

                _final_mean_norm_dw_x_gcec = _mean_norm_dw_x_gcec / _mean_counter;
                _final_stdv_norm_dw_x_gcec = sqrt(_stdv_norm_dw_x_gcec / _mean_counter -
                                                  _final_mean_norm_dw_x_gcec * _final_mean_norm_dw_x_gcec);
                _mean_norm_dw_x_gcec = 0.0;
                _stdv_norm_dw_x_gcec = 0.0;
                //INTER_LOG("dw_x_gcec : mean = %f, stdv = %f",
                //        _final_mean_norm_dw_x_gcec, _final_stdv_norm_dw_x_gcec);

                _final_mean_norm_dw_r_gcec = _mean_norm_dw_r_gcec / _mean_counter;
                _final_stdv_norm_dw_r_gcec = sqrt(_stdv_norm_dw_r_gcec / _mean_counter -
                                                  _final_mean_norm_dw_r_gcec * _final_mean_norm_dw_r_gcec);
                _mean_norm_dw_r_gcec = 0.0;
                _stdv_norm_dw_r_gcec = 0.0;
                //INTER_LOG("dw_r_gcec : mean = %f, stdv = %f",
                //        _final_mean_norm_dw_r_gcec, _final_stdv_norm_dw_r_gcec);

                _final_mean_norm_dw_c_gcec = _mean_norm_dw_c_gcec / _mean_counter;
                _final_stdv_norm_dw_c_gcec = sqrt(_stdv_norm_dw_c_gcec / _mean_counter -
                                                  _final_mean_norm_dw_c_gcec * _final_mean_norm_dw_c_gcec);
                _mean_norm_dw_c_gcec = 0.0;
                _stdv_norm_dw_c_gcec = 0.0;
                //INTER_LOG("dw_c_gcec : mean = %f, stdv = %f",
                //        _final_mean_norm_dw_c_gcec, _final_stdv_norm_dw_c_gcec);

                _final_mean_norm_d_bias_gcec = _mean_norm_d_bias_gcec / _mean_counter;
                _final_stdv_norm_d_bias_gcec = sqrt(_stdv_norm_d_bias_gcec / _mean_counter -
                                                    _final_mean_norm_d_bias_gcec * _final_mean_norm_d_bias_gcec);
                _mean_norm_d_bias_gcec = 0.0;
                _stdv_norm_d_bias_gcec = 0.0;
                //INTER_LOG("d_bias_gcec : mean = %f, stdv = %f",
                //        _final_mean_norm_d_bias_gcec, _final_stdv_norm_d_bias_gcec);

                _mean_counter = 0;
            }
        }
    }

    return ret_flag;
}

Layer* FastLstmLayer::clone() {
    return new FastLstmLayer(this);
}

void FastLstmLayer::clear_history() {
    _state_oe_c._pre_o->zero();
    _state_oe_r._pre_o->zero();

    for (int i = 0; i < _sample_num; i++) {
        _statis_sentence_counter++;

        if (_statis_sentence_counter == _statis_max) {
            _dr_threshold = _statis_dr / _statis_counter;
            _dc_threshold = _statis_dc / _statis_counter;
            //INTER_LOG("_dc_threshold := %f", _dc_threshold);
            //INTER_LOG("_dr_threshold := %f", _dr_threshold);

            _statis_counter = 0;
            _statis_dc = 0.0f ;
            _statis_dr = 0.0f;
            // If the statistics only once, this operation does not need
            _statis_sentence_counter = 0;
        }

        // cec
        _max_min_sentence_counter++;

        if (_max_min_sentence_number > 0
                && _max_min_sentence_counter >= _max_min_sentence_number) {

            _cec_max = _o_max_sum.sum() / _max_min_counter;
            _cec_min = _o_min_sum.sum() / _max_min_counter;
            //INTER_LOG("Cells::reset- max:= %f min:= %f", _cec_max, _cec_min);
            _max_min_counter = 0;
            _max_min_sentence_counter = 0;
            _o_max_sum.zero();
            _o_min_sum.zero();
        }
    }
}

void FastLstmLayer::clear_history(int sent_idx) {
    // dr & dc threshold
    _state_oe_c.reset(sent_idx, _sample_num);
    _state_oe_r.reset(sent_idx, _sample_num);
    _statis_sentence_counter++;

    if (_statis_sentence_counter == _statis_max) {
        _dr_threshold = _statis_dr / _statis_counter;
        _dc_threshold = _statis_dc / _statis_counter;
        //INTER_LOG("_dc_threshold := %f", _dc_threshold);
        //INTER_LOG("_dr_threshold := %f", _dr_threshold);

        _statis_counter = 0;
        _statis_dc = 0.0f ;
        _statis_dr = 0.0f;
        _statis_sentence_counter = 0; // If the statistics only once, this operation does not need
    }

    // cec
    _max_min_sentence_counter++;

    if (_max_min_sentence_number > 0
            && _max_min_sentence_counter >= _max_min_sentence_number) {

        _cec_max = _o_max_sum.sum() / _max_min_counter;
        _cec_min = _o_min_sum.sum() / _max_min_counter;
        //INTER_LOG("Cells::reset- max:= %f min:= %f", _cec_max, _cec_min);
        _max_min_counter = 0;
        _max_min_sentence_counter = 0;
        _o_max_sum.zero();
        _o_min_sum.zero();
    }
}

void FastLstmLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    Tensor<DType> iwx {cpu_device()};
    Tensor<DType> iwc {cpu_device()};
    Tensor<DType> iwr {cpu_device()};
    Tensor<DType> ibias {cpu_device()};
    iwx.resize(Dim(_feat_dim, _cell_dim));
    iwc.resize(Dim(1, _cell_dim));
    iwr.resize(Dim(_rec_dim, _cell_dim));
    ibias.resize(Dim(1, _cell_dim));

    Tensor<DType> owx {cpu_device()};
    Tensor<DType> owc {cpu_device()};
    Tensor<DType> owr {cpu_device()};
    Tensor<DType> obias {cpu_device()};
    owx.resize(Dim(_feat_dim, _cell_dim));
    owc.resize(Dim(1, _cell_dim));
    owr.resize(Dim(_rec_dim, _cell_dim));
    obias.resize(Dim(1, _cell_dim));

    Tensor<DType> fwx {cpu_device()};
    Tensor<DType> fwc {cpu_device()};
    Tensor<DType> fwr {cpu_device()};
    Tensor<DType> fbias {cpu_device()};
    fwx.resize(Dim(_feat_dim, _cell_dim));
    fwc.resize(Dim(1, _cell_dim));
    fwr.resize(Dim(_rec_dim, _cell_dim));
    fbias.resize(Dim(1, _cell_dim));

    Tensor<DType> cwx {cpu_device()};
    Tensor<DType> cwr {cpu_device()};
    Tensor<DType> cbias {cpu_device()};
    cwx.resize(Dim(_feat_dim, _cell_dim));
    cwr.resize(Dim(_rec_dim, _cell_dim));
    cbias.resize(Dim(1, _cell_dim));

    // 把 _w_x_gcec.w() 拷贝到 [iwx,fwx, owx,cwx]
    // (_feat_dim, 4 * _cell_dim)
    iwx.copy_from(_w_x_gcec.w()->range_col(0, 1, _cell_dim));
    fwx.copy_from(_w_x_gcec.w()->range_col(1, 2, _cell_dim));
    owx.copy_from(_w_x_gcec.w()->range_col(2, 3, _cell_dim));
    cwx.copy_from(_w_x_gcec.w()->range_col(3, 4, _cell_dim));

    // 把 _bias_gcec.w() 拷贝到 [ibias, fbias, obias, cbias]
    // (1, 4 * _cell_dim)
    ibias.copy_from(_bias_gcec.w()->range_col(0, 1, _cell_dim));
    fbias.copy_from(_bias_gcec.w()->range_col(1, 2, _cell_dim));
    obias.copy_from(_bias_gcec.w()->range_col(2, 3, _cell_dim));
    cbias.copy_from(_bias_gcec.w()->range_col(3, 4, _cell_dim));

    //                         [iwc]
    // 把 _w_c_gcec.w() 拷贝到 [fwc]
    //                         [owc]
    // (3, _cell_dim)
    iwc.copy_from(_w_c_gcec.w()->range_row(0, 1));
    fwc.copy_from(_w_c_gcec.w()->range_row(1, 2));
    owc.copy_from(_w_c_gcec.w()->range_row(2, 3));

    // 把 _w_r_gcec.w() 拷贝到 [iwr,fwr, owr, cwr]
    // (_rec_dim, 4 * _cell_dim)
    iwr.copy_from(_w_r_gcec.w()->range_col(0, 1, _cell_dim));
    fwr.copy_from(_w_r_gcec.w()->range_col(1, 2, _cell_dim));
    owr.copy_from(_w_r_gcec.w()->range_col(2, 3, _cell_dim));
    cwr.copy_from(_w_r_gcec.w()->range_col(3, 4, _cell_dim));

    iwx.write(output);
    iwc.write(output);
    iwr.write(output);
    ibias.write(output);

    owx.write(output);
    owc.write(output);
    owr.write(output);
    obias.write(output);

    fwx.write(output);
    fwc.write(output);
    fwr.write(output);
    fbias.write(output);

    cwx.write(output);
    cwr.write(output);
    cbias.write(output);

    float tmin = _cec_min;
    float tmax = _cec_max;
    output.write((char*) & (tmin), sizeof(DType));
    output.write((char*) & (tmax), sizeof(DType));

    if (!_mid_act) {
        _w_r.w()->write(output);
    }

    if (_inq) {
        Tensor<DType> max(Dim(1), CPU);
        int max_idx = 0;
        _w_x_gcec_t.w()->write(output);
        max.set_element(Dim(0), _inq_weight_max[max_idx++]);
        max.write(output);

        _bias_gcec_t.w()->write(output);
        max.set_element(Dim(0), _inq_bias_max[0]);
        max.write(output);

        _w_c_gcec_t.w()->write(output);
        max.set_element(Dim(0), _inq_weight_max[max_idx++]);
        max.write(output);
        _w_r_gcec_t.w()->write(output);
        max.set_element(Dim(0), _inq_weight_max[max_idx++]);
        max.write(output);

        if (!_mid_act) {
            _w_r_t.w()->write(output);
            max.set_element(Dim(0), _inq_weight_max[max_idx++]);
            max.write(output);
        }
    }
}

void FastLstmLayer::read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> iwx {cpu_device()};
    Tensor<DType> iwc {cpu_device()};
    Tensor<DType> iwr {cpu_device()};
    Tensor<DType> ibias {cpu_device()};
    iwx.resize(Dim(_feat_dim, _cell_dim));
    iwc.resize(Dim(1, _cell_dim));
    iwr.resize(Dim(_rec_dim, _cell_dim));
    ibias.resize(Dim(1, _cell_dim));
    iwx.read(input);
    iwc.read(input);
    iwr.read(input);
    ibias.read(input);

    Tensor<DType> owx {cpu_device()};
    Tensor<DType> owc {cpu_device()};
    Tensor<DType> owr {cpu_device()};
    Tensor<DType> obias {cpu_device()};
    owx.resize(Dim(_feat_dim, _cell_dim));
    owc.resize(Dim(1, _cell_dim));
    owr.resize(Dim(_rec_dim, _cell_dim));
    obias.resize(Dim(1, _cell_dim));
    owx.read(input);
    owc.read(input);
    owr.read(input);
    obias.read(input);

    Tensor<DType> fwx {cpu_device()};
    Tensor<DType> fwc {cpu_device()};
    Tensor<DType> fwr {cpu_device()};
    Tensor<DType> fbias {cpu_device()};
    fwx.resize(Dim(_feat_dim, _cell_dim));
    fwc.resize(Dim(1, _cell_dim));
    fwr.resize(Dim(_rec_dim, _cell_dim));
    fbias.resize(Dim(1, _cell_dim));
    fwx.read(input);
    fwc.read(input);
    fwr.read(input);
    fbias.read(input);

    Tensor<DType> cwx {cpu_device()};
    Tensor<DType> cwr {cpu_device()};
    Tensor<DType> cbias {cpu_device()};
    cwx.resize(Dim(_feat_dim, _cell_dim));
    cwr.resize(Dim(_rec_dim, _cell_dim));
    cbias.resize(Dim(1, _cell_dim));
    cwx.read(input);
    cwr.read(input);
    cbias.read(input);

    // 将iwx, fwx, owx, cwx 拼接成 [iwx, fwx, owx, cwx] 格式的大矩阵
    // [_feat_dim, 4 * _cell_dim]
    _w_x_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwx);
    _w_x_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwx);
    _w_x_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owx);
    _w_x_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwx);

    // [1, 4 * _cell_dim]
    _bias_gcec.w()->range_col(0, 1, _cell_dim).copy_from(ibias);
    _bias_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fbias);
    _bias_gcec.w()->range_col(2, 3, _cell_dim).copy_from(obias);
    _bias_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cbias);

    // [3, _cell_dim]
    _w_c_gcec.w()->range_row(0, 1).copy_from(iwc);
    _w_c_gcec.w()->range_row(1, 2).copy_from(fwc);
    _w_c_gcec.w()->range_row(2, 3).copy_from(owc);

    // 把 [iwr, fwr, owr, cwr] 拼接到 _w_r_gcec
    // [_rec_dim, 4 * _cell_dim]
    _w_r_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwr);
    _w_r_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwr);
    _w_r_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owr);
    _w_r_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwr);

    float tmin = 0.0f;
    float tmax = 0.0f;
    input.read((char*) & (tmin), sizeof(DType));
    input.read((char*) & (tmax), sizeof(DType));
    INTER_LOG("read from file: min:= %f max:= %f", tmin, tmax);

    if ((_cec_max - _cec_min) <= 0.0f) {
        _cec_max = -1.0f;
        _cec_min = -1.0f;
        INTER_LOG("min:= %f max:= %f", _cec_min, _cec_max);
        //_cec_max = tmax;
        //_cec_min = tmin;
    }

    if (!_mid_act) {
        _w_r.w()->read(input);
    }

    if (_inq) {
        Tensor<DType> max(Dim(1), CPU);
        _w_x_gcec_t.w()->read(input);
        max.read(input);
        _inq_weight_max.push_back(max.get_element(Dim(0)));

        _bias_gcec_t.w()->read(input);
        max.read(input);
        _inq_bias_max.push_back(max.get_element(Dim(0)));

        _w_c_gcec_t.w()->read(input);
        max.read(input);
        _inq_weight_max.push_back(max.get_element(Dim(0)));

        _w_r_gcec_t.w()->read(input);
        max.read(input);
        _inq_weight_max.push_back(max.get_element(Dim(0)));

        if (!_mid_act) {
            _w_r_t.w()->read(input);
            max.read(input);
            _inq_weight_max.push_back(max.get_element(Dim(0)));
        }
    }
}

void FastLstmLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> iwx {cpu_device()};
    Tensor<DType> iwc {cpu_device()};
    Tensor<DType> iwr {cpu_device()};
    Tensor<DType> ibias {cpu_device()};
    iwx.resize(Dim(_feat_dim, _cell_dim));
    iwc.resize(Dim(1, _cell_dim));
    iwr.resize(Dim(_rec_dim, _cell_dim));
    ibias.resize(Dim(1, _cell_dim));
    iwx.read(input);
    iwc.read(input);
    iwr.read(input);
    ibias.read(input);

    Tensor<DType> owx {cpu_device()};
    Tensor<DType> owc {cpu_device()};
    Tensor<DType> owr {cpu_device()};
    Tensor<DType> obias {cpu_device()};
    owx.resize(Dim(_feat_dim, _cell_dim));
    owc.resize(Dim(1, _cell_dim));
    owr.resize(Dim(_rec_dim, _cell_dim));
    obias.resize(Dim(1, _cell_dim));
    owx.read(input);
    owc.read(input);
    owr.read(input);
    obias.read(input);

    Tensor<DType> fwx {cpu_device()};
    Tensor<DType> fwc {cpu_device()};
    Tensor<DType> fwr {cpu_device()};
    Tensor<DType> fbias {cpu_device()};
    fwx.resize(Dim(_feat_dim, _cell_dim));
    fwc.resize(Dim(1, _cell_dim));
    fwr.resize(Dim(_rec_dim, _cell_dim));
    fbias.resize(Dim(1, _cell_dim));
    fwx.read(input);
    fwc.read(input);
    fwr.read(input);
    fbias.read(input);

    Tensor<DType> cwx {cpu_device()};
    Tensor<DType> cwr {cpu_device()};
    Tensor<DType> cbias {cpu_device()};
    cwx.resize(Dim(_feat_dim, _cell_dim));
    cwr.resize(Dim(_rec_dim, _cell_dim));
    cbias.resize(Dim(1, _cell_dim));
    cwx.read(input);
    cwr.read(input);
    cbias.read(input);

    // 将iwx, fwx, owx, cwx 拼接成 [iwx, fwx, owx, cwx] 格式的大矩阵
    // [_feat_dim, 4 * _cell_dim]
    _w_x_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwx);
    _w_x_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwx);
    _w_x_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owx);
    _w_x_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwx);

    // [1, 4 * _cell_dim]
    _bias_gcec.w()->range_col(0, 1, _cell_dim).copy_from(ibias);
    _bias_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fbias);
    _bias_gcec.w()->range_col(2, 3, _cell_dim).copy_from(obias);
    _bias_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cbias);

    // [3, _cell_dim]
    _w_c_gcec.w()->range_row(0, 1).copy_from(iwc);
    _w_c_gcec.w()->range_row(1, 2).copy_from(fwc);
    _w_c_gcec.w()->range_row(2, 3).copy_from(owc);

    // 把 [iwr, fwr, owr, cwr] 拼接到 _w_r_gcec
    // [_rec_dim, 4 * _cell_dim]
    _w_r_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwr);
    _w_r_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwr);
    _w_r_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owr);
    _w_r_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwr);

    float tmin = 0.0f;
    float tmax = 0.0f;
    input.read((char*) & (tmin), sizeof(DType));
    input.read((char*) & (tmax), sizeof(DType));
    INTER_LOG("read from file: min:= %f max:= %f", tmin, tmax);

    if ((_cec_max - _cec_min) <= 0.0f) {
        _cec_max = -1.0f;
        _cec_min = -1.0f;
        INTER_LOG("min:= %f max:= %f", _cec_min, _cec_max);
        //_cec_max = tmax;
        //_cec_min = tmin;
    }

    if (!_mid_act) {
        _w_r.w()->read(input);
    }
}

void FastLstmLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> iwx {cpu_device()};
    Tensor<DType> iwc {cpu_device()};
    Tensor<DType> iwr {cpu_device()};
    Tensor<DType> ibias {cpu_device()};
    iwx.resize(Dim(_feat_dim, _cell_dim));
    iwc.resize(Dim(1, _cell_dim));
    iwr.resize(Dim(_rec_dim, _cell_dim));
    ibias.resize(Dim(1, _cell_dim));
    iwx.read_hfnn(input);
    iwc.read_hfnn(input);
    iwr.read_hfnn(input);
    ibias.read_hfnn(input);

    Tensor<DType> owx {cpu_device()};
    Tensor<DType> owc {cpu_device()};
    Tensor<DType> owr {cpu_device()};
    Tensor<DType> obias {cpu_device()};
    owx.resize(Dim(_feat_dim, _cell_dim));
    owc.resize(Dim(1, _cell_dim));
    owr.resize(Dim(_rec_dim, _cell_dim));
    obias.resize(Dim(1, _cell_dim));
    owx.read_hfnn(input);
    owc.read_hfnn(input);
    owr.read_hfnn(input);
    obias.read_hfnn(input);

    Tensor<DType> fwx {cpu_device()};
    Tensor<DType> fwc {cpu_device()};
    Tensor<DType> fwr {cpu_device()};
    Tensor<DType> fbias {cpu_device()};
    fwx.resize(Dim(_feat_dim, _cell_dim));
    fwc.resize(Dim(1, _cell_dim));
    fwr.resize(Dim(_rec_dim, _cell_dim));
    fbias.resize(Dim(1, _cell_dim));
    fwx.read_hfnn(input);
    fwc.read_hfnn(input);
    fwr.read_hfnn(input);
    fbias.read_hfnn(input);

    Tensor<DType> cwx {cpu_device()};
    Tensor<DType> cwr {cpu_device()};
    Tensor<DType> cbias {cpu_device()};
    cwx.resize(Dim(_feat_dim, _cell_dim));
    cwr.resize(Dim(_rec_dim, _cell_dim));
    cbias.resize(Dim(1, _cell_dim));
    cwx.read_hfnn(input);
    cwr.read_hfnn(input);
    cbias.read_hfnn(input);

    // 将iwx, fwx, owx, cwx 拼接成 [iwx, fwx, owx, cwx] 格式的大矩阵
    // [_feat_dim, 4 * _cell_dim]
    _w_x_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwx);
    _w_x_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwx);
    _w_x_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owx);
    _w_x_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwx);

    // [1, 4 * _cell_dim]
    _bias_gcec.w()->range_col(0, 1, _cell_dim).copy_from(ibias);
    _bias_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fbias);
    _bias_gcec.w()->range_col(2, 3, _cell_dim).copy_from(obias);
    _bias_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cbias);

    // [3, _cell_dim]
    _w_c_gcec.w()->range_row(0, 1).copy_from(iwc);
    _w_c_gcec.w()->range_row(1, 2).copy_from(fwc);
    _w_c_gcec.w()->range_row(2, 3).copy_from(owc);

    // 把 [iwr, fwr, owr, cwr] 拼接到 _w_r_gcec
    // [_rec_dim, 4 * _cell_dim]
    _w_r_gcec.w()->range_col(0, 1, _cell_dim).copy_from(iwr);
    _w_r_gcec.w()->range_col(1, 2, _cell_dim).copy_from(fwr);
    _w_r_gcec.w()->range_col(2, 3, _cell_dim).copy_from(owr);
    _w_r_gcec.w()->range_col(3, 4, _cell_dim).copy_from(cwr);

    float tmin = 0.0f;
    float tmax = 0.0f;
    input.read((char*) & (tmin), sizeof(DType));
    input.read((char*) & (tmax), sizeof(DType));
    INTER_LOG("read_hfnn from file: min:= %f max:= %f", tmin, tmax);

    if ((_cec_max - _cec_min) <= 0.0f) {
        _cec_max = -1.0f;
        _cec_min = -1.0f;
        INTER_LOG("min:= %f max:= %f", _cec_min, _cec_max);
        //_cec_max = tmax;
        //_cec_min = tmin;
    }

    if (!_mid_act) {
        _w_r.w()->read_hfnn(input);
    }
}

void FastLstmLayer::clip_error_update(Tensor<DType>& E, DType threshold) {
    if (threshold > 0.0f) {
        DType norm = E.norm2();

        if (norm > threshold) {
            E.mul(threshold / norm);    ////
        }
    }
}

void FastLstmLayer::intl_quantize(Tensor<DType>& tensor, int idx)
{
    if (_intl_quant_bits) {
        switch (_intl_quant_algo) {
            case QUANT_BIT:
                bit_quantize(tensor, idx);
                break;
            case QUANT_FIXED:
                wind_fixed(tensor, _intl_quant_bits);
                break;
            case QUANT_GREEDY:
                greedy_quantize(tensor, _intl_quant_bits);
            default:
                CHECK2(false);
        }
    }
}

}
}
