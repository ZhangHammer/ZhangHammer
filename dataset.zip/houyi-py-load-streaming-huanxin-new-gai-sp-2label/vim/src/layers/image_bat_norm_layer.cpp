/**
 * image_bat_norm_layer.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-01
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include "image_bat_norm_layer.h"
#include "tools.h"

namespace houyi {
namespace train {

ImageBatNormalLayer::ImageBatNormalLayer(ImageBatNormConfig& config)
    : Layer(config) {
    set_device();
    _counter = 0;
    _store_item = 0;
    _epsilon = config.epsilon();
    _norm_type = config.norm_type();
    _statis_threshold = config.statis_threshold();
    _config = config;
    _moving_average_fraction = config.get_moving_averate_fraction();

    _global_mean_var = config.mean_var_file();

    build_map();

}

ImageBatNormalLayer::ImageBatNormalLayer(ImageBatNormalLayer* from)
    : Layer(from) {
    CHECK2(from != NULL);

    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) ImageBatNormalLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    _gamma.resize_like(*from->gamma());
    _gamma.copy_from(*from->gamma());
    _beta.resize_like(*from->beta());
    _beta.copy_from(*from->beta());

    if (_inq) {
        _gamma_t.resize_like(*from->gamma_t());
        _gamma_t.copy_from(*from->gamma_t());
        _beta_t.resize_like(*from->beta_t());
        _beta_t.copy_from(*from->beta_t());
    }
}


void ImageBatNormalLayer::layer_set(std::vector<IOPackage*>& inputs,
                                    int sample_num) {
    Dim dim = inputs[0]->get_size();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    int size = dim.get_size();
    CHECK(size == 2 || size == 4, "input dim must be 2 or 4");

    if (size == 2) {
        CHECK(_norm_type == NORM_1CHW, "dim is 2, norm type must be norm_1chw");
        _mean_var_dim = dim[1];
    } else {
        if (_norm_type == NORM_1CHW) {
            _mean_var_dim = dim[1] * dim[2] * dim[3];
        } else if (_norm_type == NORM_1C11) {
            _mean_var_dim = dim[1];
        } else {
            CHECK(false, "batch norm type error");
        }
    }

    _gamma.resize(Dim(_mean_var_dim), gpu_device());
    _beta.resize(Dim(_mean_var_dim), gpu_device());

    if (need_update()) {
        _d_gamma.resize(Dim(_mean_var_dim), gpu_device());
        _d_beta.resize(Dim(_mean_var_dim), gpu_device());
    }

    if (_inq) {
        _gamma_t.resize(Dim(_mean_var_dim), gpu_device());
        _gamma_t.w()->set_element(1);
        _beta_t.resize(Dim(_mean_var_dim), gpu_device());
        _beta_t.w()->set_element(1);
    }

    _static_mean_vec.resize(Dim(_mean_var_dim));
    _static_var_vec.resize(Dim(_mean_var_dim));
    _run_var_vec.resize(Dim(_mean_var_dim));
    _run_mean_vec.resize(Dim(_mean_var_dim));
    _run_var_vec.set_element(1.0f);
    _run_mean_vec.set_element(0.0f);

    if (_global_mean_var.size()) {
        read_initial_mean_var();
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ImageBatNormalLayer::resize_out(std::vector<IOPackage*>& inputs,
                                     int sample_num) {
    CHECK2(inputs.size() == 1);
    const Dim& input_size = inputs[0]->get_size();
    _sample_num = sample_num;

    output(_output_keys[0]).resize(input_size, inputs[0]->get_mask(), gpu_device());
}

Layer* ImageBatNormalLayer::clone() {
    return new ImageBatNormalLayer(this);
}

void ImageBatNormalLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "gamma", &_gamma));
    _w_map.insert(WeightsMap::value_type(pre + "beta", &_beta));

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "gamma", &_d_gamma));
        _dw_map.insert(WeightsMap::value_type(pre + "beta", &_d_beta));
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(
                    pre + "gamma_binary", &_gamma_t));
        _w_map.insert(WeightsMap::value_type(
                    pre + "beta_binary", &_beta_t));
    }
}

ImageBatNormalLayer::~ImageBatNormalLayer() {
}

void ImageBatNormalLayer::init_weight(const ModelInitConfig& global_cfg) {
#ifdef __CLOSE_RANDOM__
    wind_set_seed(1024);
#else
    time_t seed = time(NULL);
    wind_set_seed(seed);
#endif

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
    case UNIFORM_INIT:
    case MSRA_INIT:
    case XAVIER_INIT:
        _gamma.w()->set_element(1.0f);
        break;
    case CONSTANT_INIT:
        _gamma.w()->set_element(_model_init_cfg.weight_value());
        break;

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN:
        switch (global_cfg.weight_init_type()) {
        case GAUSS_INIT:
        case UNIFORM_INIT:
        case MSRA_INIT:
        case XAVIER_INIT:
            _gamma.w()->set_element(1.0f);
            break;
        case CONSTANT_INIT:
            _gamma.w()->set_element(global_cfg.weight_value());
            break;
        default:
            CHECK(false, "model init type error");
        }

        break;
    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
    case UNIFORM_INIT:
    case MSRA_INIT:
    case XAVIER_INIT:
        _beta.w()->set_element(1.0f);
        break;
    case CONSTANT_INIT:
        _beta.w()->set_element(_model_init_cfg.bias_value());
        break;

    /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN:
        switch (global_cfg.bias_init_type()) {
        case GAUSS_INIT:
        case UNIFORM_INIT:
        case MSRA_INIT:
        case XAVIER_INIT:
            _beta.w()->set_element(1.0f);
            break;
        case CONSTANT_INIT:
            _beta.w()->set_element(global_cfg.bias_value());
            break;

        default:
            CHECK(false, "model init type error");
        }

        break;
    default:
        CHECK(false, "model init type error");
    }
}

void ImageBatNormalLayer::init_weight(
    const ModelInitConfig& global_cfg,
    std::vector<Layer*>& layers) {
    CHECK(global_cfg.weight_init_type() == MODEL_INIT, "model init type must be model init");

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
    case UNIFORM_INIT:
        _gamma.w()->set_element(1.0f);
        break;
    case CONSTANT_INIT:
        _gamma.w()->set_element(_model_init_cfg.weight_value());
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的weight */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.weight_name().size() != 0) ? _model_init_cfg.weight_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("beta", 0) == std::string::npos &&            
                                name.find("binary", 0) == std::string::npos) { 
                        BaseWeight *src = i->w_map().find(name)->second;       
                        dst->copy_from(src);                                   
                    }                                                          
                    else if (name.find("beta", 0) == std::string::npos &&       
                                name.find("binary", 0) != std::string::npos) { 
                        WeightsMap::iterator itr = i->w_map().find(name);      
                        if (itr != i->w_map().end()) {                         
                            BaseWeight *src = itr->second;                     
                            dst->copy_from(src);                               
                            _inq_weight_max = i->get_inq_weight_max();         
                        }                                                      
                    }                                                          
                }
                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "weight not found in model");
        /*  for inq train */    
        if (_inq) {            
            inq_init_weight(); 
        }                      
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
    case UNIFORM_INIT:
        _beta.w()->set_element(0.0f);
        break;
    case CONSTANT_INIT:
        _beta.w()->set_element(_model_init_cfg.bias_value());
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的bias */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.bias_name().size() != 0) ? _model_init_cfg.bias_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("beta", 0) != std::string::npos &&           
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight *src = i->w_map().find(name)->second;      
                        dst->copy_from(src);                                  
                    }                                                         
                    else if (name.find("beta", 0) != std::string::npos &&      
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);     
                        if (itr != i->w_map().end()) {                        
                            BaseWeight *src = itr->second;                    
                            dst->copy_from(src);                              
                            _inq_bias_max = i->get_inq_bias_max();            
                        }                                                     
                    }                                                         

                }
                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "bias not found in model");
        /* for inq train */  
        if (_inq) {          
            inq_init_bias(); 
        }                    
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

}
void ImageBatNormalLayer::inq_init_weight() {
    CHECK(_inq_ratio.size() != 0, "inq ratio error");
    WeightsMap::iterator itr1 = _w_map.begin();
    Tensor<DType> w_t_cpu{CPU};
    Tensor<DType> w_cpu{CPU};
    std::vector<DType> max_vec;
    int max_idx = 0;
    if (_inq_weight_max.size() > 0) {
        max_vec = _inq_weight_max;
    }

    for (; itr1 != _w_map.end(); ++itr1 ) {
        BaseWeight *dst = itr1->second;
        Tensor<DType> &w_t = *dst->w();
        std::string name = itr1->first;

        if (name.find("binary", 0) != std::string::npos && name.find("beta", 0) == std::string::npos ) {
            w_t_cpu.resize(w_t.get_size());
            w_t_cpu.copy_from(w_t);

            std::string w_name = name.substr(0, name.find("_binary"));
            Tensor<DType> &w = *_w_map.find(w_name)->second->w();
            CHECK(w.get_size() == w_t.get_size(), "dim error");
            w_cpu.resize(w.get_size());
            w_cpu.copy_from(w);

            DType max = FLT_MAX;
            if (max_vec.size() > 0) {
                max = max_vec[max_idx];
            }
            inq_quantization(w_cpu, w_t_cpu, max);
            if (_inq_weight_max.size() == 0) {
                max_vec.push_back(max);
            }

            w_t.copy_from(w_t_cpu);
            w.copy_from(w_cpu);

            max_idx++;
        }
    }
    _inq_weight_max = max_vec;
}
void ImageBatNormalLayer::inq_init_bias() {
    CHECK(_inq_ratio.size() != 0, "inq ratio error");
    WeightsMap::iterator itr1 = _w_map.begin();
    Tensor<DType> w_t_cpu{CPU};
    Tensor<DType> w_cpu{CPU};
    std::vector<DType> max_vec;
    int max_idx = 0;
    if (_inq_bias_max.size() > 0) {
        max_vec = _inq_bias_max;
    }

    for (; itr1 != _w_map.end(); ++itr1 ) {
        BaseWeight *dst = itr1->second;
        Tensor<DType> &w_t = *dst->w();
        std::string name = itr1->first;

        if (name.find("binary", 0) != std::string::npos && name.find("beta", 0) != std::string::npos ) {
            w_t_cpu.resize(w_t.get_size());
            w_t_cpu.copy_from(w_t);

            std::string w_name = name.substr(0, name.find("_binary"));
            Tensor<DType> &w = *_w_map.find(w_name)->second->w();
            CHECK(w.get_size() == w_t.get_size(), "dim error");
            w_cpu.resize(w.get_size());
            w_cpu.copy_from(w);

            DType max = FLT_MAX;
            if (max_vec.size() > 0) {
                max = max_vec[max_idx];
            }
            inq_quantization(w_cpu, w_t_cpu, max);
            if (_inq_bias_max.size() == 0) {
                max_vec.push_back(max);
            }

            w_t.copy_from(w_t_cpu);
            w.copy_from(w_cpu);

            max_idx++;
        }
    }
    _inq_bias_max = max_vec;
}

void ImageBatNormalLayer::gauss_init(DType mean, DType stdv) {
    _gamma.w()->set_element(1.0f);
    _beta.w()->set_element(0.0f);
}

void ImageBatNormalLayer::read_initial_mean_var() {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (is_predict_job(type)) {
        read_initial_mean_var_eval(_global_mean_var.c_str());
    } else {
        read_initial_mean_var_train(_global_mean_var.c_str());
    }
}

void ImageBatNormalLayer::read_initial_mean_var(std::string bn_file_prefix) {
    if (0 == bn_file_prefix.size()) {
        return;
    }

    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (is_predict_job(type)) {
        read_initial_mean_var_eval((bn_file_prefix + "/bn_" + _name).c_str());
    } else {
        CHECK(false, "Can not call read_initial_mean_var(std::string bn_file_prefix) in train mode.");
    }
}

void ImageBatNormalLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (is_predict_job(type)) {
        inter_forward_eval(in_pack);
    } else {
        inter_forward_train(in_pack);
    }
}

void ImageBatNormalLayer::read_initial_mean_var_eval(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");

    // 做预测时, 如果 bn 文件暂时未生成, 则设置均值为0, 方差为1
    if (NULL == fin) {
        INTER_LOG("Open file error %s", file_name);
        _run_var_vec.resize(Dim(_mean_var_dim));
        _run_mean_vec.resize(Dim(_mean_var_dim));
        _run_var_vec.set_element(1.0f);
        _run_mean_vec.set_element(0.0f);
    } else {

        // CHECK(fin != NULL, "Open file error %s", file_name);
        std::vector<float> mean, var;
        float m = 0.0f;
        float v = 0.0f;

        for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
            fscanf(fin, "%f ", &v);
            var.push_back(v);
        }

        for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
            fscanf(fin, "%f ", &m);
            mean.push_back(m);
        }

        fclose(fin);

        _run_var_vec.resize(Dim(_mean_var_dim));
        _run_mean_vec.resize(Dim(_mean_var_dim));

        for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
            _run_var_vec.set_element(Dim(i), var[i]);
            _run_mean_vec.set_element(Dim(i), mean[i]);
        }

        _static_var_vec.resize(Dim(_mean_var_dim));
        _static_mean_vec.resize(Dim(_mean_var_dim));
        _static_var_vec.copy_from(_run_var_vec);
        _static_mean_vec.copy_from(_run_mean_vec);
    }

    _counter = 1;
}

void ImageBatNormalLayer::inter_forward_eval(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    //size_t channel = in->get_size(1);
    //CHECK2(channel == _channel);
    size_t in_dim = in->get_dim();
    CHECK2(in_dim >= 2);

    Dim dim_2(in->get_size(0), in->get_size(1));
    Dim dim_4(in->get_size(0), in->get_size(1), 1, 1);

    if (in_dim == 2) {
        CHECK(_norm_type == NORM_1CHW, "dim is 2, norm type must be norm_1chw");
        in->reshape(dim_4);
    }

    //out->resize(in->get_size());

    out->image_bat_norm_forward_inf(_norm_type, 1.0f, 1.0f, *in, *_gamma.w(), *_beta.w(),
                                    _run_mean_vec, _run_var_vec, _epsilon);

    if (in_dim == 2) {
        in->reshape(dim_2);
        out->reshape(dim_2);
    }
}

void ImageBatNormalLayer::read_initial_mean_var_train(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");
    CHECK(fin != NULL, "Open file error %s", file_name);

    std::vector<float> mean, var;
    float mv = 0.0f;

    for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
        fscanf(fin, "%f ", &mv);
        var.push_back(mv);
    }

    for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
        fscanf(fin, "%f ", &mv);
        mean.push_back(mv);
    }

    fclose(fin);

    _gamma.resize(Dim(_mean_var_dim), gpu_device());
    _beta.resize(Dim(_mean_var_dim), gpu_device());

    for (size_t i = 0; i < (size_t)_mean_var_dim; i++) {
        _gamma.w()->set_element(Dim(i), mean[i]);
        _beta.w()->set_element(Dim(i), var[i]);
    }
}

void ImageBatNormalLayer::inter_forward_train(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    //size_t channel = in->get_size(1);
    //CHECK2(channel == _channel);
    size_t in_dim = in->get_dim();
    CHECK2(in_dim >= 2);

    Dim dim_2(in->get_size(0), in->get_size(1));
    Dim dim_4(in->get_size(0), in->get_size(1), 1, 1);

    if (in_dim == 2) {
        CHECK(_norm_type == NORM_1CHW, "dim is 2, norm type must be norm_1chw");
        in->reshape(dim_4);
    }

    //out->resize(in->get_size());
    _mean_vec.resize(Dim(_mean_var_dim));
    _var_vec.resize(Dim(_mean_var_dim));

    _run_mean_vec.resize(Dim(_mean_var_dim));
    _run_var_vec.resize(Dim(_mean_var_dim));

    out->image_bat_norm_forward_train(_norm_type, 1.0f, 1.0f, *in, *_gamma.w(), *_beta.w(),
                                      1.0f, _run_mean_vec, _run_var_vec, _epsilon, _mean_vec, _var_vec);

    if (in_dim == 2) {
        in->reshape(dim_2);
        out->reshape(dim_2);
    }

    _static_mean_vec.elem_add(_static_mean_vec, _run_mean_vec, _moving_average_fraction, 1.0f);
    _static_var_vec.elem_add(_static_var_vec, _run_var_vec, _moving_average_fraction, 1.0f);
    _counter = _counter * _moving_average_fraction + 1;
}

void ImageBatNormalLayer::store_mean_var() {
    Tensor<DType> mean {cpu_device()};
    Tensor<DType> var {cpu_device()};
    char name[256] = {0};
    pid_t tid;
    pid_t pid;
    pid = getpid();
    char datetime[20];
    get_datetime(datetime);
    tid = syscall(SYS_gettid);

    if (access("statis_bn", 0) == -1) {
        mkdir("statis_bn", S_IRWXU);
    }

    snprintf(name, 256, "statis_bn/Statis_Layer_%s_pid_%u_tid_%u_part_%lu_time_%s.sta",
             _name.c_str(), pid, tid, _store_item, datetime);
    mean.resize(Dim(_mean_var_dim));
    var.resize(Dim(_mean_var_dim));

    //计算真正的mean，var
    //_static_mean_vec.mul(1.0f / _counter);
    //_static_var_vec.mul(1.0f / _counter);

    mean.copy_from(_static_mean_vec);
    var.copy_from(_static_var_vec);

    mean.mul(1.0f / _counter);
    var.mul(1.0f / _counter);

    std::ofstream in_out(name, std::ios::trunc);
    //ofstream in_out(name, std::ios::binary);
    in_out.write((char*)&_mean_var_dim, sizeof(size_t));
    // 和语音兼容
    size_t frame_counter = 1;
    in_out.write((char*)&frame_counter, sizeof(size_t));
    in_out.write((char*)mean.get_data(), _mean_var_dim * sizeof(DType));
    in_out.write((char*)var.get_data(), _mean_var_dim * sizeof(DType));

    _store_item++;
    //_counter = 0;
    //_static_mean_vec.zero();
    //_static_var_vec.zero();
}

void ImageBatNormalLayer::inter_bprop_diff(
            std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    size_t in_dim = in->get_dim();
    CHECK(in_dim >= 2, "in dim must >=2");
    CHECK2(in->get_size() == out_diff->get_size());
    CHECK2(local_diff->get_size() == out_diff->get_size());

    Dim dim_2(in->get_size(0), in->get_size(1));
    Dim dim_4(in->get_size(0), in->get_size(1), 1, 1);

    if (in_dim == 2) {
        CHECK(_norm_type == NORM_1CHW, "dim is 2, norm type must be norm_1chw");
        in->reshape(dim_4);
        out_diff->reshape(dim_4);
        local_diff->reshape(dim_4);
    }

    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (is_predict_job(type)) {
        // out_diff = local_diff / sqrt(var + eps) * scale
        out_diff->image_bat_norm_back_inf(_norm_type, *local_diff,
                                          _run_var_vec, *_gamma.w(),
                                          _epsilon);
    } else {
        out_diff->image_bat_norm_back(_norm_type, 1.0f, 1.0f, 1.0f, 1.0f, *in, *local_diff, *_gamma.w(),
                                      *_d_gamma.w(), *_d_beta.w(), _epsilon, _mean_vec, _var_vec);
    }

    if (in_dim == 2) {
        in->reshape(dim_2);
        out_diff->reshape(dim_2);
        local_diff->reshape(dim_2);
    }
}

void ImageBatNormalLayer::inter_bprop_grad(
            std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    // nothing to do
}

void ImageBatNormalLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->write(output);
        if (_inq) {                                          
            _gamma_t.w()->write(output);                         
            Tensor<DType> max(Dim(1), CPU);                  
            max.set_element(Dim(0), _inq_weight_max.front());
            max.write(output);                               
        }                                                    
        _beta.w()->write(output);
        if (_inq) {                                          
            _beta_t.w()->write(output);                         
            Tensor<DType> max(Dim(1), CPU);                  
            max.set_element(Dim(0), _inq_bias_max.front());
            max.write(output);                               
        }                                                    
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }

    //store_mean_var();
}

void ImageBatNormalLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->read(input);
        _beta.w()->read(input);
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the ImageBatNormalLayer has no this parameter: %d", t);
    }
}

void ImageBatNormalLayer::read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _gamma.w()->read(input);
        if (_inq) {                                            
            _gamma_t.w()->read(input);                          
            Tensor<DType> max(Dim(1), CPU);                    
            max.read(input);                                   
            _inq_weight_max.push_back(max.get_element(Dim(0)));
        }                                                      
        _beta.w()->read(input);
        if (_inq) {                                            
            _beta_t.w()->read(input);                          
            Tensor<DType> max(Dim(1), CPU);                    
            max.read(input);                                   
            _inq_bias_max.push_back(max.get_element(Dim(0)));
        }                                                      
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the ImageBatNormalLayer has no this parameter: %d", t);
    }
}

}
}

