/**
 * split_layer.cpp
 *
 * Author: chencheng19(chencheng19@baidu.com)
 * Created on: 2017-09-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "split_layer.h"

namespace houyi {
namespace train {

SplitLayer::SplitLayer(SplitConfig& config) : Layer(config) {
    set_device();
    _config = config;

}

SplitLayer::SplitLayer(SplitLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    new(this) SplitLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void SplitLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void SplitLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);

    // 设置输出的尺寸，为了防止空间浪费
    // 这里调用 set_dtype_ten 让输入输出使用同一个 tensor, 而不是 resize
    for (int i = 0; i < output_num(); ++i) {
        output(_output_keys[i]).share(inputs[0]->get_ten(), inputs[0]->get_mask());
    }
}

void SplitLayer::inter_forward(std::vector<IOPackage*>& pack) {
    // nothing to do
}

void SplitLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
            std::vector<IOPackage*>& out_pack) {
    if (out_pack[0] == NULL) {
        return;
    }
    Tensor<DType>* local_diff1 = diff(_output_keys[0]).get_ten();
    Tensor<DType>* local_diff2 = diff(_output_keys[1]).get_ten();
    Tensor<DType>* pre_diff = out_pack[0]->get_ten();

    if (_diff_ready[0] && _diff_ready[1]) {
        pre_diff->elem_add(*local_diff1, *local_diff2);
        for (int i = 2; i < output_num(); ++i) {
            pre_diff->elem_add(*pre_diff, *diff(_output_keys[i]).get_ten());
        }
    }
    else {
        //在中英文多头混合训练时，部分分支可能不做后向
        for (int i = 0; i < output_num(); ++i) {
            Tensor<DType>* tmp_diff = diff(_output_keys[i]).get_ten();
            if (_diff_ready[i]) {
                pre_diff->elem_add(*pre_diff, *tmp_diff);
            }
        }
    }
}

Layer* SplitLayer::clone() {
    return new SplitLayer(this);
}

}   // namespace train
}   // namespace houyi
