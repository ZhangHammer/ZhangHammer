/**
 * weight.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-19
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "weight.h"

namespace houyi {
namespace train {

int unique_insert(std::vector<int>& vec, int ele) {
    std::vector<int>::iterator iter = find(vec.begin(), vec.end(), ele);

    if (iter != vec.end()) {
        return iter - vec.begin();
    } else {
        vec.push_back(ele);
        return vec.size() - 1;
    }
}

void unique_combine(std::vector<int>& dst, std::vector<int>& src) {
    for (std::vector<int>::iterator iter = src.begin(); iter != src.end(); iter++) {
        unique_insert(dst, *iter);
    }
}
//
//void BaseWeight::alloc_serial_buf(int height, int width) {
//    // _serial_buf should only malloc once
//    CHECK2(_serial_buf == NULL);
//
//    _serial_buf_bytes = MAX_SERIAL_SIZE(height, width);
//    int ret = wind_malloc_host((void**)&_serial_buf, _serial_buf_bytes);
//    CHECK2(ret == HPPL_RET_OK);
//    memset(_serial_buf, 0, _serial_buf_bytes);
//}
DenseWeight::DenseWeight(const Dim& size, const Device& device) {
    _w = NULL;
    _serial_buf = NULL;
    _serial_buf_bytes = 0;
    _serial_bytes = 0;
    _type = WEIGHT_DENSE;
    resize(size, device);
}

//DenseWeight::DenseWeight(const Dim &size, const Device &device, WeightUpdataType update_type) :
//        BaseWeight(update_type){
//    _w = NULL;
//    _serial_buf = NULL;
//    _serial_buf_bytes = 0;
//    _serial_bytes = 0;
//    _type = WEIGHT_DENSE;
//    resize(size, device);
//}
BaseWeight* DenseWeight::clone() {
    return clone(_w->get_device());
}

BaseWeight* DenseWeight::clone(const Device& device) {
    DenseWeight* d = NULL;
    d = new DenseWeight(_w->get_size(), device);
    //d = new DenseWeight(_w->get_size(), device, _update_type);
    /*
        if (on_gpu) {
            d->_serial_buf = (char*)d->_gpu_w->get_data();
            d->_serial_buf_bytes = d->_gpu_w->getHeight() * d->_gpu_w->getWidth() * sizeof(DType);
            d->_serial_bytes = d->_serial_buf_bytes;
        } else {
            d->_serial_buf = (char*)d->_cpu_w->get_data();
            d->_serial_buf_bytes = d->_cpu_w->getHeight() * d->_cpu_w->getWidth() * sizeof(DType);
            d->_serial_bytes = d->_serial_buf_bytes;
        }
    */
    return d;
}

void DenseWeight::fixed_loss() {
    _w->fixed_loss();
}

void DenseWeight::resize(const Dim& size, const Device& device) {
    if (_w == NULL) {
        _w = new Tensor<DType>(size, device);
    } else {
        CHECK(device == _w->get_device(), "device error");
        _w->resize(size);
    }
}

void DenseWeight::zero() {
    _w->zero();
}

void DenseWeight::add(BaseWeight* w, float alpha, float beta) {
    CHECK2(w);

    switch (w->type()) {
    case WEIGHT_DENSE: {
        DenseWeight* dense =
            dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
        add(*dense, alpha, beta);
    }
    break;

    //case WEIGHT_DISC: {
    //    DiscWeight* disc =
    //        dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(w));
    //    add(*disc, alpha, beta);
    //}
    //break;

    default:
        CHECK(false, "not support!");
    }
}

void DenseWeight::mul_scalar(float scalar) {
    CHECK2(_w);
    _w->mul(scalar);
}

DType DenseWeight::norm() {
    DType p = 0.0f;
    CHECK2(_w);
    p = _w->norm2();
    return p;
}

void DenseWeight::random(DType lo, DType hi) {
    CHECK2(_w);
    _w->random(lo, hi);
}

void DenseWeight::set_const(DType v) {
    CHECK2(_w);
    _w->set_element(v);
}
void DenseWeight::gauss_random(DType mean, DType stdv) {
    CHECK2(_w);
    _w->gauss_random(mean, stdv);
}
void DenseWeight::copy_from(const BaseWeight* w) {
    switch (w->type()) {
    case WEIGHT_DENSE: {
        DenseWeight* dense =
            dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
        CHECK2(dense);
        copy_from(*dense);
    }
    break;

    //case WEIGHT_DISC: {
    //    DiscWeight* disc =
    //        dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(w));
    //    CHECK2(disc);
    //    copy_from(*disc);
    //}
    break;

    case WEIGHT_EXTDENSE: {
        DenseWeight* dense =
            dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
        CHECK2(dense);
        copy_from(*dense);
    }
    break;

    default:
        CHECK(false, "not support!");
    }
}

size_t DenseWeight::serialize() {
    /* Nothing to do */
    return _serial_bytes;
}

size_t DenseWeight::deserialize() {
    /* Nothing to do */
    return _serial_bytes;
}

void DenseWeight::copy_from(const BaseWeight* w, WindStream stream) {
    switch (w->type()) {
    case WEIGHT_DENSE: {
        DenseWeight* dense =
            dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
        CHECK2(dense);
        CHECK2(dense->w()->is_contiguous());
        CHECK2(this->w()->is_contiguous());
        CHECK2(dense->w()->get_size() == this->w()->get_size());
        wind_memcpy_async(this->w()->get_data(), dense->w()->get_data(),
                dense->w()->get_element_count() * sizeof(DType), stream);
    }
    break;

    //case WEIGHT_DISC: {
    //    DiscWeight* disc =
    //        dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(w));
    //    CHECK2(disc);
    //    copy_from(*disc);
    //}
    //break;

    default:
        CHECK2("Internal error");
    }
}

void DenseWeight::copy_from(const DenseWeight& w) {
    _w->copy_from(*w.w());
}

void DenseWeight::copy_from(const DiscWeight& in_w) {
    int map_id = 0;
    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
    std::vector<int>::iterator iter = w->get_update().begin();

    while (iter != w->get_update().end()) {
        int wrd_id = *iter;
        _w->range_row(wrd_id, wrd_id + 1).copy_from(
            w->w()->range_row(map_id, map_id + 1));
        ++map_id;
        ++iter;
    }
}

void DenseWeight::add(DenseWeight& w, float alpha, float beta) {
    CHECK2(w.get_device() == get_device());

    _w->elem_add(*_w, *w.w(), alpha, beta);
}

void DenseWeight::add(DiscWeight& in_w, float alpha, float beta) {
    int map_id = 0;
    CHECK2(in_w.get_device() == get_device());
    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
    std::vector<int>::iterator iter = w->get_update().begin();

    while (iter != w->get_update().end()) {
        int wrd_id = *iter;
        _w->range_row(wrd_id, wrd_id + 1).elem_add(
            _w->range_row(wrd_id, wrd_id + 1),
            w->w()->range_row(map_id, map_id + 1), alpha, beta);
        ++map_id;
        ++iter;
    }
}

void DenseWeight::store_model(std::ofstream& output) {
    _w->write(output);
}

void DenseWeight::read_model(std::ifstream& input) {
    _w->read(input);
}

void DenseWeight::init_weight(DType lo, DType hi) {
    _w->random(lo, hi);
}

void DenseWeight::init_weight(DType const_value) {
    _w->set_element(const_value);
}

void DenseWeight::gauss_init_weight(DType mean, DType stdv) {
    _w->gauss_random(mean, stdv);
}


//ExtDenseWeight::ExtDenseWeight(size_t w_height, size_t w_width, bool on_gpu) {
//    _cpu_w = NULL;
//    _gpu_w = NULL;
//    _type = WEIGHT_EXTDENSE;
//    resize(w_height, w_width, on_gpu);
//}
//
//BaseWeight* ExtDenseWeight::clone(bool on_gpu) {
//    ExtDenseWeight* d = new ExtDenseWeight(_height, _width, on_gpu);
//    d->set_update(this->get_update());
//    return d;
//}
//
//void ExtDenseWeight::zero() {
//    DenseWeight::zero();
//    _update_set.clear();
//}
//
//void ExtDenseWeight::add(const BaseWeight* w, float alpha, float beta) {
//    CHECK2(w);
//
//    switch (w->type()) {
//        case WEIGHT_DENSE: {
//            DenseWeight* dense =
//                dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
//            add(*dense, alpha, beta);
//        }
//        break;
//
//        case WEIGHT_EXTDENSE: {
//            ExtDenseWeight* ext =
//                dynamic_cast<ExtDenseWeight*>(const_cast<BaseWeight*>(w));
//            add(*ext, alpha, beta);
//        }
//        break;
//
//        case WEIGHT_DISC: {
//            DiscWeight* disc =
//                dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(w));
//            add(*disc, alpha, beta);
//        }
//        break;
//
//        default:
//            CHECK(false, "not support!");
//    }
//}
//
//void ExtDenseWeight::add(const DenseWeight &w, float alpha, float beta) {
//    CHECK2("Not supported");
//}
//
//void ExtDenseWeight::add(const ExtDenseWeight &in_w, float alpha, float beta) {
//    CHECK2(in_w.is_on_gpu() == is_on_gpu());
//    ExtDenseWeight* w = const_cast<ExtDenseWeight*>(&in_w);
//    if (_cpu_w) {
//        std::vector<int>::iterator iter = w->get_update().begin();
//        while (iter != w->get_update().end()) {
//            int wrd_id = *iter;
//            unique_insert(_update_set, wrd_id);
//            _cpu_w->range_row(wrd_id, wrd_id + 1).add(
//                    w->cpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++iter;
//        }
//
//    } else if (_gpu_w) {
//        std::vector<int>::iterator iter = w->get_update().begin();
//        while (iter != w->get_update().end()) {
//            int wrd_id = *iter;
//            unique_insert(_update_set, wrd_id);
//            _gpu_w->range_row(wrd_id, wrd_id + 1).add(
//                    w->gpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++iter;
//        }
//
//    } else {
//        CHECK2("not initialized");
//    }
//
//}
//
//void ExtDenseWeight::add(const DiscWeight &in_w, float alpha, float beta) {
//    int map_id = 0;
//    CHECK2(in_w.is_on_gpu() == is_on_gpu());
//    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
//    if (_cpu_w) {
//        std::vector<int>::iterator iter = w->get_update().begin();
//        while (iter != w->get_update().end()) {
//            int wrd_id = *iter;
//            unique_insert(_update_set, wrd_id);
//            _cpu_w->range_row(wrd_id, wrd_id + 1).add(
//                    w->cpu_w()->range_row(map_id, map_id + 1), alpha, beta);
//            ++map_id;
//            ++iter;
//        }
//
//    } else if (_gpu_w) {
//        std::vector<int>::iterator iter = w->get_update().begin();
//        while (iter != w->get_update().end()) {
//            int wrd_id = *iter;
//            unique_insert(_update_set, wrd_id);
//            _gpu_w->range_row(wrd_id, wrd_id + 1).add(
//                    w->gpu_w()->range_row(map_id, map_id + 1), alpha, beta);
//            ++map_id;
//            ++iter;
//        }
//
//    } else {
//        CHECK2("not initialized");
//    }
//}
//
//void ExtDenseWeight::copy_from(const BaseWeight* in_w) {
//    switch (in_w->type()) {
//        case WEIGHT_DENSE: {
//            DenseWeight* dense =
//                dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(dense);
//            copy_from(*dense);
//        }
//        break;
//
//        case WEIGHT_EXTDENSE: {
//            ExtDenseWeight* ext =
//                dynamic_cast<ExtDenseWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(ext);
//            copy_from(*ext);
//        }
//        break;
//
//        case WEIGHT_DISC: {
//            DiscWeight* disc =
//                dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(disc);
//            copy_from(*disc);
//        }
//        break;
//
//        default:
//            CHECK2("not supported");
//    }
//}
//
///*
// * Add modified rows from DiscWeight to ExtDenseWeight
// * */
//void ExtDenseWeight::copy_from(const DiscWeight& in_w) {
//    int src_id = 0;
//    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
//    std::vector<int>::iterator iter = w->get_update().begin();
//    while (iter != w->get_update().end()) {
//        int dst_id = *iter;
//        unique_insert(_update_set, dst_id);
//        if (_cpu_w) {
//            if (w->is_on_gpu()) {
//                _cpu_w->range_row(dst_id, dst_id + 1).copy_from(
//                    w->gpu_w()->range_row(src_id, src_id + 1));
//            } else {
//                _cpu_w->range_row(dst_id, dst_id + 1).copy_from(
//                    w->cpu_w()->range_row(src_id, src_id + 1));
//            }
//
//        } else if (_gpu_w) {
//            if (w->is_on_gpu()) {
//                _gpu_w->range_row(dst_id, dst_id + 1).copy_from(
//                    w->gpu_w()->range_row(src_id, src_id + 1));
//            } else {
//                _gpu_w->range_row(dst_id, dst_id + 1).copy_from(
//                    w->cpu_w()->range_row(src_id, src_id + 1));
//            }
//
//        } else {
//            CHECK2("not initialized");
//        }
//
//        src_id++;
//        ++iter;
//    }
//}
//
///*
// * Add modified rows from DiscWeight to ExtDenseWeight
// * */
//void ExtDenseWeight::copy_add(const DiscWeight& in_w) {
//    int src_id = 0;
//    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
//
//    /* First zero the referred rows */
//    std::vector<int>::iterator iter = w->get_update().begin();
//    while (iter != w->get_update().end()) {
//        int dst_id = *iter;
//        if (_cpu_w) {
//            _cpu_w->range_row(dst_id, dst_id + 1).zero();
//        } else if (_gpu_w) {
//            _gpu_w->range_row(dst_id, dst_id + 1).zero();
//        } else {
//            CHECK2("not initialized");
//        }
//        iter++;
//    }
//
//    iter = w->get_update().begin();
//    while (iter != w->get_update().end()) {
//        int dst_id = *iter;
//        unique_insert(_update_set, dst_id);
//        if (_cpu_w) {
//            if (w->is_on_gpu()) {
//                _cpu_w->range_row(dst_id, dst_id + 1).add(
//                    w->gpu_w()->range_row(src_id, src_id + 1), 1.0f, 1.0f);
//            } else {
//                _cpu_w->range_row(dst_id, dst_id + 1).add(
//                    w->cpu_w()->range_row(src_id, src_id + 1), 1.0f, 1.0f);
//            }
//
//        } else if (_gpu_w) {
//            if (w->is_on_gpu()) {
//                _gpu_w->range_row(dst_id, dst_id + 1).add(
//                    w->gpu_w()->range_row(src_id, src_id + 1), 1.0f, 1.0f);
//            } else {
//                _gpu_w->range_row(dst_id, dst_id + 1).add(
//                    w->cpu_w()->range_row(src_id, src_id + 1), 1.0f, 1.0f);
//            }
//
//        }
//
//        src_id++;
//        ++iter;
//    }
//}
//
//void ExtDenseWeight::copy_from(const DenseWeight& w) {
//    DenseWeight::copy_from(w);
//}
//
//void ExtDenseWeight::copy_from(const ExtDenseWeight& in_w) {
//    ExtDenseWeight* w = const_cast<ExtDenseWeight*>(&in_w);
//    DenseWeight::copy_from(w);
//    _update_set = w->get_update();
//}
//
//void ExtDenseWeight::copy_from(const BaseWeight* in_w, WindStream stream) {
//    //TODO
//    copy_from(in_w);
//}
//
//size_t ExtDenseWeight::serialize() {
//    if (_update_set.size() == 0) {
//        _serial_bytes = 0;
//        return 0;
//    }
//
//    size_t tgt_seri_bytes = MAX_SERIAL_SIZE(_update_set.size(), width());
//    CHECK2(tgt_seri_bytes <= _serial_buf_bytes);
//
//    int offset = 0;
//    uint64_t len = tgt_seri_bytes;
//    memcpy(_serial_buf + offset, &len, sizeof(uint64_t));
//    offset += sizeof(uint64_t);
//
//    int update_size = (int)_update_set.size();
//    memcpy(_serial_buf + offset, &update_size, sizeof(int));
//    offset += sizeof(int);
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int tmp = *iter;
//        memcpy(_serial_buf + offset, &tmp, sizeof(int));
//        offset += sizeof(int);
//    }
//
//    int h = (int)height();
//    memcpy(_serial_buf + offset, &h, sizeof(int));
//    offset += sizeof(int);
//    int w = (int)width();
//    memcpy(_serial_buf + offset, &w, sizeof(int));
//    offset += sizeof(int);
//
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int wrd_id = *iter;
//        if (cpu_w()) {
//            memcpy(_serial_buf + offset,
//                    cpu_w()->range_row(wrd_id, wrd_id + 1).get_data(),
//                    sizeof(float) * width());
//        } else {
//            gpu_w()->range_row(wrd_id, wrd_id + 1).copy_to(
//                    (float*)(_serial_buf + offset), 0, 1);
//        }
//        offset += sizeof(float) * width();
//    }
//    CHECK2((int)tgt_seri_bytes == offset);
//    _serial_bytes = tgt_seri_bytes;
//
//    return _serial_bytes;
//}
//
//size_t ExtDenseWeight::deserialize()  {
//    size_t offset = 0;
//    uint64_t len = 0;
//    int update_size = 0;
//
//    len = *((uint64_t*)(_serial_buf + offset));
//    offset += sizeof(uint64_t);
//
//    update_size = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//    /* reset update_set */
//    _update_set.clear();
//    for (int i = 0; i < update_size; i++) {
//        _update_set.push_back(*((int*)(_serial_buf + offset)));
//        offset += sizeof(int);
//    }
//
//    int height = 0;
//    int width  = 0;
//    height = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//    width  = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//
//    CHECK2(height != 0 && width != 0);
//    resize(height, width, _on_gpu);
//
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int wrd_id = *iter;
//        if (_on_gpu) {
//            gpu_w()->range_row(wrd_id, wrd_id + 1).copy_from(
//                    (float*)(_serial_buf + offset), 0, width);
//        } else {
//            memcpy(cpu_w()->range_row(wrd_id, wrd_id + 1).get_data(),
//                    _serial_buf + offset, sizeof(float) * width);
//        }
//        offset += sizeof(float) * width;
//    }
//
//    CHECK2((size_t)len == offset);
//    return offset;
//}
//
//DiscWeight::DiscWeight(size_t height, size_t width, bool on_gpu) {
//    _type = WEIGHT_DISC;
//    resize(height, width, on_gpu);
//}
//
//BaseWeight* DiscWeight::clone(bool on_gpu) {
//    DiscWeight* d = new DiscWeight(_height, _width, on_gpu);
//    d->set_update(this->get_update());
//    if (_serial_buf) {
//        d->_serial_buf_bytes = this->_serial_buf_bytes;
//        int ret = wind_malloc_host((void**)&d->_serial_buf, d->_serial_buf_bytes);
//        CHECK2(ret == HPPL_RET_OK);
//        memset(d->_serial_buf, 0, d->_serial_buf_bytes);
//    }
//    return d;
//}
//
//void DiscWeight::resize(size_t height, size_t width, bool on_gpu) {
//    _on_gpu = on_gpu;
//    _height = height;
//    _width  = width;
//
//    DenseWeight::resize(height, width, on_gpu);
//}
//
//void DiscWeight::zero() {
//    DenseWeight::zero();
//    _update_set.clear();
//}
//
//void DiscWeight::copy_from(const BaseWeight* in_w) {
//    switch (in_w->type()) {
//        case WEIGHT_DENSE: {
//            DenseWeight* dense =
//                dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(dense);
//            copy_from(*dense);
//        }
//        break;
//
//        case WEIGHT_EXTDENSE: {
//            ExtDenseWeight* ext =
//                dynamic_cast<ExtDenseWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(ext);
//            copy_from(*ext);
//        }
//        break;
//
//        case WEIGHT_DISC: {
//            DiscWeight* disc =
//                dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(in_w));
//            CHECK2(disc);
//            copy_from(*disc);
//        }
//        break;
//
//        default:
//            CHECK2("not supported");
//    }
//}
//
//void DiscWeight::copy_from(const DiscWeight& w) {
//
//    CHECK2(((_update_set.size() == 0) && (w._update_set.size() > 0)) ||
//        ((w._update_set.size() == 0) && (_update_set.size() > 0)) ||
//        (_update_set == w._update_set));
//    if (_cpu_w) {
//        if (w.is_on_gpu()) {
//            cpu_w()->copy_from(*w.gpu_w());
//        } else {
//            cpu_w()->copy_from(*w.cpu_w());
//        }
//    } else if (_gpu_w) {
//        if (w.is_on_gpu()) {
//            gpu_w()->copy_from(*w.gpu_w());
//        } else {
//            gpu_w()->copy_from(*w.cpu_w());
//        }
//    } else {
//        CHECK2("not initialized");
//    }
//}
//
///* Do we really need this ? */
//void DiscWeight::copy_from(const DenseWeight& w) {
//    int map_id = 0;
//    std::vector<int>::iterator iter = _update_set.begin();
//    while (iter != _update_set.end()) {
//        int wrd_id = *iter;
//        if (_cpu_w) {
//            if (w.is_on_gpu()) {
//                cpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w.gpu_w()->range_row(wrd_id, wrd_id + 1));
//            } else {
//                cpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w.cpu_w()->range_row(wrd_id, wrd_id + 1));
//            }
//        } else if (_gpu_w) {
//            if (w.is_on_gpu()) {
//                gpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w.gpu_w()->range_row(wrd_id, wrd_id + 1));
//            } else {
//                gpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w.cpu_w()->range_row(wrd_id, wrd_id + 1));
//            }
//        } else {
//            CHECK2("not initialized");
//        }
//        ++map_id;
//        ++iter;
//    }
//}
//
///*
// * copy based on local update set
// * */
//void DiscWeight::copy_from(const ExtDenseWeight& in_w) {
//    int map_id = 0;
//
//    ExtDenseWeight* w = const_cast<ExtDenseWeight*>(&in_w);
//
//    std::vector<int>::iterator iter = _update_set.begin();
//    while (iter != _update_set.end()) {
//        int wrd_id = *iter;
//        if (_cpu_w) {
//            if (w->is_on_gpu()) {
//                cpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w->gpu_w()->range_row(wrd_id, wrd_id + 1));
//            } else {
//                cpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w->cpu_w()->range_row(wrd_id, wrd_id + 1));
//            }
//        } else if (_gpu_w) {
//            if (w->is_on_gpu()) {
//                gpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w->gpu_w()->range_row(wrd_id, wrd_id + 1));
//            } else {
//                gpu_w()->range_row(map_id, map_id + 1).copy_from(
//                    w->cpu_w()->range_row(wrd_id, wrd_id + 1));
//            }
//        } else {
//            CHECK2("not initialized");
//        }
//        ++map_id;
//        ++iter;
//    }
//
//}
//
//void DiscWeight::copy_from(const BaseWeight* in_w, WindStream stream) {
//    copy_from(in_w);
//}
//
///* increment manner */
//void DiscWeight::add(const BaseWeight* w, float alpha, float beta) {
//    CHECK2(w);
//
//    switch (w->type()) {
//        case WEIGHT_DENSE: {
//            DenseWeight* dense =
//                dynamic_cast<DenseWeight*>(const_cast<BaseWeight*>(w));
//            add(*dense, alpha, beta);
//        }
//        break;
//
//        case WEIGHT_DISC: {
//            DiscWeight* disc =
//                dynamic_cast<DiscWeight*>(const_cast<BaseWeight*>(w));
//            add(*disc, alpha, beta);
//        }
//        break;
//
//        case WEIGHT_EXTDENSE: {
//            ExtDenseWeight* ext =
//                dynamic_cast<ExtDenseWeight*>(const_cast<BaseWeight*>(w));
//            add(*ext, alpha, beta);
//        }
//        break;
//
//        default:
//            CHECK(false, "not support!");
//    }
//}
//
//size_t DiscWeight::serialize() {
//    CHECK2(_update_set.size() > 0);
//    size_t tgt_seri_bytes = MAX_SERIAL_SIZE(_update_set.size(), width());
//    CHECK2(tgt_seri_bytes <= _serial_buf_bytes);
//
//    int offset = 0;
//    uint64_t len = tgt_seri_bytes;
//    memcpy(_serial_buf + offset, &len, sizeof(uint64_t));
//    offset += sizeof(uint64_t);
//
//    int update_size = (int)_update_set.size();
//    memcpy(_serial_buf + offset, &update_size, sizeof(int));
//    offset += sizeof(int);
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int tmp = *iter;
//        memcpy(_serial_buf + offset, &tmp, sizeof(int));
//        offset += sizeof(int);
//    }
//
//    int h = (int)height();
//    memcpy(_serial_buf + offset, &h, sizeof(int));
//    offset += sizeof(int);
//    int w = (int)width();
//    memcpy(_serial_buf + offset, &w, sizeof(int));
//    offset += sizeof(int);
//
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int wrd_id = *iter;
//        if (cpu_w()) {
//            memcpy(_serial_buf + offset,
//                    cpu_w()->range_row(wrd_id, wrd_id + 1).get_data(),
//                    sizeof(float) * width());
//        } else {
//            gpu_w()->range_row(wrd_id, wrd_id + 1).copy_to(
//                    (float*)(_serial_buf + offset), 0, 1);
//        }
//        offset += sizeof(float) * width();
//    }
//    CHECK2((int)tgt_seri_bytes == offset);
//    _serial_bytes = tgt_seri_bytes;
//
//    return _serial_bytes;
//}
//
//size_t DiscWeight::deserialize()  {
//    size_t offset = 0;
//    uint64_t len = 0;
//    int update_size = 0;
//
//    len = *((uint64_t*)(_serial_buf + offset));
//    offset += sizeof(uint64_t);
//
//    update_size = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//    for (int i = 0; i < update_size; i++) {
//        _update_set.push_back(*((int*)(_serial_buf + offset)));
//        offset += sizeof(int);
//    }
//
//    int height = 0;
//    int width  = 0;
//    height = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//    width  = *((int*)(_serial_buf + offset));
//    offset += sizeof(int);
//
//    CHECK2(height != 0 && width != 0);
//    resize(height, width, _on_gpu);
//
//    for (std::vector<int>::iterator iter = _update_set.begin(); iter != _update_set.end(); iter++) {
//        int wrd_id = *iter;
//        if (_on_gpu) {
//            gpu_w()->range_row(wrd_id, wrd_id + 1).copy_from(
//                    (float*)(_serial_buf + offset), 0, width);
//        } else {
//            memcpy(cpu_w()->range_row(wrd_id, wrd_id + 1).get_data(),
//                    _serial_buf + offset, sizeof(float) * width);
//        }
//        offset += sizeof(float) * width;
//    }
//
//    CHECK2((size_t)len == offset);
//    return offset;
//}
//
//void DiscWeight::add(const DenseWeight& w, float alpha, float beta) {
//    int map_id = 0;
//    CHECK2(w.is_on_gpu() == is_on_gpu());
//    if (_cpu_w) {
//        std::vector<int>::iterator iter = _update_set.begin();
//        while (iter != _update_set.end()) {
//            int wrd_id = *iter;
//            _cpu_w->range_row(map_id, map_id + 1).add(
//                    w.cpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++map_id;
//            ++iter;
//        }
//
//    } else if (_gpu_w) {
//        std::vector<int>::iterator iter = _update_set.begin();
//        while (iter != _update_set.end()) {
//            int wrd_id = *iter;
//            _gpu_w->range_row(map_id, map_id + 1).add(
//                    w.gpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++map_id;
//            ++iter;
//        }
//
//    } else {
//        CHECK2("not initialized");
//    }
//}
//
///*
// * add based on local update set
// */
//void DiscWeight::add(const ExtDenseWeight& in_w, float alpha, float beta) {
//    int map_id = 0;
//    int wrd_id = 0;
//    ExtDenseWeight* w = const_cast<ExtDenseWeight*>(&in_w);
//    CHECK2(w->is_on_gpu() == is_on_gpu());
//
//    if (_cpu_w) {
//        std::vector<int>::iterator iter = _update_set.begin();
//        while (iter != _update_set.end()) {
//            wrd_id = *iter;
//            _cpu_w->range_row(map_id, map_id + 1).add(
//                    w->cpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++iter;
//        }
//
//    } else if (_gpu_w) {
//        std::vector<int>::iterator iter = _update_set.begin();
//        while (iter != _update_set.end()) {
//            wrd_id = *iter;
//            _gpu_w->range_row(map_id, map_id + 1).add(
//                    w->gpu_w()->range_row(wrd_id, wrd_id + 1), alpha, beta);
//            ++iter;
//        }
//
//    } else {
//        CHECK2("not initialized");
//    }
//}
//
//void DiscWeight::add(const DiscWeight& in_w, float alpha, float beta) {
//    CHECK2(in_w.is_on_gpu() == is_on_gpu());
//
//    DiscWeight* w = const_cast<DiscWeight*>(&in_w);
//
//    CHECK2(_update_set == w->get_update());
//
//    if (_cpu_w) {
//        _cpu_w->add(*w->cpu_w(), alpha, beta);
//
//    } else if (_gpu_w) {
//        _gpu_w->add(*w->gpu_w(), alpha, beta);
//
//    } else {
//        CHECK(false, "not initialized");
//    }
//}

}
}

