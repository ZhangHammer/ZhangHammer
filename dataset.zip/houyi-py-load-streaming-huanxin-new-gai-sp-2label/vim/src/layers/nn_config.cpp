/**
 * nn_config.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-19
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "nn_config.h"
#include "tools.h"
#include "model_init_config.h"
#include <unordered_map>
#include "train_type.h"

namespace houyi {
namespace train {

void PeriodConfig::read(std::string& cfg_lines) {
    // PeriodConfig
    parse_from_string("epoch", &cfg_lines, &_epoch);
    INTER_LOG("epoch = %d", _epoch);
    /* todo remove */
    parse_from_string("globalStorePeriod", &cfg_lines, &_global_store_period);
    parse_from_string("logPeriod", &cfg_lines, &_log_period);
    INTER_LOG("logPeriod = %d", _log_period);
    parse_from_string("modelPeriod", &cfg_lines, &_model_period);
    INTER_LOG("modelPeriod = %d", _model_period);
    /* todo remove */
    parse_from_string("fixedPeriod", &cfg_lines, &_fixed_period);

    parse_from_string("localSyncPeriod", &cfg_lines, &_local_sync_period);
    INTER_LOG("localSyncPeriod = %d", _local_sync_period);
    std::string train_str;

    if (parse_from_string("trainType", &cfg_lines, &train_str)) {
        string_to_enum(train_str, trainTypeName, &_train_type);
        INTER_LOG("trainType = %s", train_str.c_str());
    }

    CHECK(_train_type != TRAIN_UNKNOWN,
          "train type must be set trainType = sync or trainType = async");

    parse_from_string("globalSyncPeriod", &cfg_lines, &_global_sync_period);
    INTER_LOG("globalSyncPeriod = %d", _global_sync_period);
    /* todo: remove */ 
    parse_from_string("shrinkLRPeriod", &cfg_lines, &_shrink_lr_period);
    parse_from_string("checkPoint", &cfg_lines, &_check_point); // TODO:remove
}

void DiscTrainConfig::read(std::string& cfg_lines) {
    parse_from_string("priorFile", &cfg_lines, &_prior_name);// TODO: move to outputlayer
    INTER_LOG("priorFile = %s", _prior_name.c_str());
    parse_from_string("discTrainThreadNum", &cfg_lines, &_disc_train_thread_num);
    INTER_LOG("discTrainThreadNum = %d", _disc_train_thread_num);
    parse_from_string("discScoreThreadNum", &cfg_lines, &_disc_score_thread_num);
    INTER_LOG("discScoreThreadNum = %d", _disc_score_thread_num);
    parse_from_string("rescore_thread_num", &cfg_lines, &_rescore_thread_num);
    INTER_LOG("rescore_thread_num = %d", _rescore_thread_num);
    parse_from_string("DiscConfigFile", &cfg_lines, &_disc_config_file);
    INTER_LOG("DiscConfigFile = %s", _disc_config_file.c_str());
    parse_from_string("kaldiMdlFn", &cfg_lines, &_kaldi_mdl_fn);
    INTER_LOG("kaldiMdlFn = %s", _kaldi_mdl_fn.c_str());
    parse_from_string("kaldiFstFn", &cfg_lines, &_kaldi_fst_fn);
    INTER_LOG("kaldiFstFn= %s", _kaldi_fst_fn.c_str());
}

NNConfig::NNConfig() {
    _device_ids.clear();
    _thread_num = 0;

    _batch_size = 1;
    _job_type = TRAIN;
    _keep_history = true;
    _load_by_python = false;
    _cfg_vec.clear();
    _skip_num = 0;

    _inq = false;      
    _inq_ratio.clear();
    _inq_bit = 5;      

    _quant_bits = 0;
    _sample_statis_norm = 1.0;
}

NNConfig::~NNConfig() {
    for (size_t i = 0; i < _cfg_vec.size(); i++) {
        delete _cfg_vec[i];
        _cfg_vec[i] = NULL;
    }
}

void NNConfig::read_config(const char* file) {
    std::ifstream input(file);
    CHECK(input, "configure file open error: %s", file);

    std::string line;
    std::string conf_line;

    INTER_LOG("\n===========================================\
==layer config=========================================");
    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }

        remove_white_space_comment(line);

        if (line.size() == 0) {
            continue;
        }

        if (line == "[Layer]") {
            LayerConfig* new_cfg = LayerConfig::read(input);

            if (new_cfg == NULL) {
                continue;
            }

            CHECK(new_cfg != NULL, "new layer configure error");

            _cfg_vec.push_back(new_cfg);
        } else {
            conf_line.append("\t");
            conf_line.append(line);
        }
    }
    INTER_LOG("\n=========================================end of layer config\
======================================");
    // 插入 split 层, 重新更新 id
    insert_splits();
    /* layer id, start: 0 end: size - 1*/
    for (size_t i = 0; i < _cfg_vec.size(); ++i) {
        _cfg_vec[i]->set_layer_id(static_cast<int>(i));
    }

    INTER_LOG("\n=============================================global config\
========================================");
    parse_from_string("deviceId", &conf_line, &_device_ids);
    for (auto id : _device_ids) {
        INTER_LOG("deviceId = %d", id);
    }
    parse_from_string("keepHistory", &conf_line, &_keep_history);
    INTER_LOG("keepHistory = %d", _keep_history);
    parse_from_string("dataCfgFile", &conf_line, &_data_cfg_file);
    INTER_LOG("dataCfgFile = %s", _data_cfg_file.c_str());

    parse_from_string("pythonPath", &conf_line, &_python_path);
    INTER_LOG("pythonPath = %s", _python_path.c_str());
    parse_from_string("pythonGlobalCfgFile", &conf_line, &_python_global_cfg_file);
    INTER_LOG("pythonGlobalCfgFile = %s", _python_global_cfg_file.c_str());

    parse_from_string("loadByPython", &conf_line, &_load_by_python);
    INTER_LOG("loadByPython = %d", _load_by_python);

    for (auto i : _cfg_vec) {
        i->set_global_cfg_file(_python_global_cfg_file);
    }

	parse_from_string("inq", &conf_line, &_inq);
    INTER_LOG("inq = %d", _inq);
	parse_from_string("inqRatio", &conf_line, &_inq_ratio);
    for (auto i : _inq_ratio) {
        INTER_LOG("inqRatio = %f", i);
    }
	parse_from_string("inqBit", &conf_line, &_inq_bit);
    INTER_LOG("inqBit = %d", _inq_bit);
	CHECK((_inq == true && _inq_ratio.size() != 0) || _inq == false, "inq ratio error"); 
	for (size_t i = 0; i < _cfg_vec.size(); i++) {
		_cfg_vec[i]->set_inq(_inq);
		_cfg_vec[i]->set_inq_ratio(_inq_ratio);
		_cfg_vec[i]->set_inq_bit(_inq_bit);
	}

    parse_from_string("quantBits", &conf_line, &_quant_bits);
    INTER_LOG("quantBits = %lu", _quant_bits);
    parse_from_string("threadNum", &conf_line, &_thread_num); // TODO:remove

    parse_from_string("sampleStatisNorm", &conf_line, &_sample_statis_norm); 
    INTER_LOG("sampleStatisNorm = %f", _sample_statis_norm);

    parse_from_string("name", &conf_line, &_name);
    if (_name.empty()) {
        char time_str[15] = {0};
        get_datetime(time_str);
        _name = time_str;
    }
    INTER_LOG("name = %s", _name.c_str());

    std::string job_str;
    if (parse_from_string("jobType", &conf_line, &job_str)) {
        string_to_enum(job_str, jobTypeName, &_job_type);
        INTER_LOG("jobType = %s", job_str.c_str());
    }

    for (size_t i = 0; i < _cfg_vec.size(); i++) {
        _cfg_vec[i]->set_global_job_type(_job_type);
    }

    _model_init_cfg.read(conf_line);// initialize

    for (auto i : _cfg_vec) {
        i->set_global_model_init_cfg(_model_init_cfg);
    }

    _period_cfg.read(conf_line);    // period
    _disc_cfg.read(conf_line);      // DiscTrainConfig

    _global_updater_cfg.read(conf_line);
    _global_updater_cfg.set_iter_size(_period_cfg.local_sync_period()); 
    _global_updater_cfg.set_device_num(_device_ids.size());             
    for (auto i : _cfg_vec) {
        i->set_global_up_cfg(_global_updater_cfg);
    }
    INTER_LOG("\n=========================================end of global config\
======================================");

    INTER_LOG("\n==============================================data config\
==========================================");
    _data_cfg.read(_data_cfg_file.c_str());
    gen_feat_label_key(_data_cfg);

    _batch_size_adjust_cfg.read(conf_line);
    /* if no set, the set some default values */
    _batch_size = _data_cfg.get_batch_size();
    CHECK2(_batch_size != 0);

    if (_thread_num == 0) {
        _thread_num = (int)_device_ids.size();
    }

    _data_cfg.set_device_num(_thread_num);
    _data_cfg.set_train_type(ASYNC_TRAIN);
    //_data_cfg.set_train_type(_period_cfg.train_type());
    INTER_LOG("\n==========================================end of data config\
=======================================");

    input.close();
}

void NNConfig::gen_feat_label_key(BaseReposConfig& cfg) {
    std::vector<std::pair<std::string, std::vector<std::string>>>& feat_list = cfg.get_reader_cfg()->get_feat_list();

    if (feat_list.size())
        for (auto i : feat_list) {
            _feature_keys.push_back(i.first);
        }
    else {
        _feature_keys.push_back("train-data");
    }

    std::vector<std::pair<std::string, std::vector<std::string>>>& label_list =
                cfg.get_reader_cfg()->get_label_list();

    if (label_list.size()) {
        for (auto i : label_list) {
            _label_keys.push_back(i.first);
        }
    } else {
        _label_keys.push_back("label-data");
    }
}


void NNConfig::insert_splits() {
    // 保存某个数据块的输入输出层
    // (1) 如果数据块输入层为空，则为数据加载的数据
    // (2) 如果数据块输出层为空，则为最后的loss层
    // (3) 如果数据块有多个输入, 则配置表错误
    // (4) 如果数据块有多个输出，则需要插入 split 层
    using NodeInfo = std::pair<std::string, std::vector<std::string>>;
    std::unordered_map<std::string, NodeInfo> node_map;
    // 使用nodes 保持节点的顺序, 最后按顺序遍历, 方便检查
    std::vector<std::string> nodes;
    for (LayerConfig* config : _cfg_vec) {
        std::string name = config->layer_name();
        // 对于每层的输入节点, 该层为节点的输出层
        // map 中没有找到节点, 则插入对应的nodeinfo, 并将name 放到输出层中
        // 如果找到, 并将name 追加到节点的输出层中
        //CHECK2(config->input_num() > 0);
        for (const auto& input : config->input_keys()) {
            if (node_map.find(input) == node_map.end()) {
                NodeInfo nodeinfo;
                nodeinfo.second.push_back(name);
                node_map[input] = std::move(nodeinfo);
            } else {
                node_map[input].second.push_back(name);
            }
            if (std::find(nodes.begin(), nodes.end(), input) == nodes.end()) {
                nodes.push_back(input);
            }
        }

        // 对于每层的输出节点, 该层为节点的输入层
        // 没有找到, 则插入对应的nodeinfo, 并将name 放到输入层中
        CHECK2(config->output_num() > 0);
        for (const auto& output : config->output_keys()) {
            if (node_map.find(output) == node_map.end()) {
                NodeInfo nodeinfo;
                nodeinfo.first = name;
                node_map[output] = std::move(nodeinfo);
            } else {
                if (!node_map[output].first.empty()) {
                    // 一个节点不可能有多个输入层, 配置写错
                    CHECK2(false);
                }
                node_map[output].first = name;
            }
            if (std::find(nodes.begin(), nodes.end(), output) == nodes.end()) {
                nodes.push_back(output);
            }
        }
    }

    // 遍历结束后检查哪些数据块有多个输出
    // 插入 split 层, 插入到数据块的输入层之后
    //                   /---> [Out1]
    // 插入前: [In]-->node
    //                   \---> [Out2]
    //
    //                            /---> node1 ----> [Out1]
    // 插入后: [In]-->node-->[Split]
    //                            \---> node2 ----> [Out2]
    for (auto& node : nodes) {
        NodeInfo& nodeinfo = node_map[node];
        if (nodeinfo.second.size() > 1) {
            // 找到split 层插入的位置
            // 检查输入层的类型, 如果输入层是 split 层则不处理
            // 这种情况只有在用户在配置里面写了 split 层才会出现
            size_t pos = 0;
            bool is_input_split = false;
            // 输入数据节点的 first 为空
            // 需要在最开始插入 split 层
            bool is_no_input = nodeinfo.first.empty();
            if (!is_no_input) {
                for (pos = 0; pos < _cfg_vec.size(); ++pos) {
                    if (_cfg_vec[pos]->layer_name() == nodeinfo.first) {
                        if (_cfg_vec[pos]->type() == SPLIT) {
                            is_input_split = true;
                        }
                        break;
                    }
                }
                if (is_input_split) {
                    continue;
                }
            }
            SplitConfig* split_config = new SplitConfig();
            // 由于layer_config 中有很多默认设置
            // 此处通过构造一个配置字符串来创建一个 split 层
            std::stringstream ss;
            // eg: name = __split_0
            std::string name = "__split_" + node;
            ss << "name=" << name << " ";
            ss << "inputs=" << node << " ";
            ss << "outputs=";
            INTER_LOG("insert split layer %s : node %s", name.c_str(), node.c_str());
            // 设置 split 层的输出, 并更新node 输出层的输入
            for (size_t i = 0; i < nodeinfo.second.size(); ++i) {
                // eg: outputs = __split_0_node_1
                std::string split_out_node =
                    "__" + node + "_node_" + std::to_string(i);
                if (i == nodeinfo.second.size() - 1) {
                    ss << split_out_node;
                } else {
                    ss << split_out_node << ":";
                }
                std::string orig_out_name = nodeinfo.second[i];
                for (LayerConfig* config : _cfg_vec) {
                    // 找到原本的输出层，修改该层的输入key
                    if (config->layer_name() == orig_out_name) {
                        for (int j = 0; j < config->input_num(); ++j) {
                            if (config->input_key(j) == node) {
                                config->input_key(j) = split_out_node;
                                break;
                            }
                        }
                        break;
                    }
                }
            }
            std::string config_str = ss.str();
            INTER_LOG("Split config %s", config_str.c_str());
            split_config->read_config(config_str);
            // 将SplitConfig 插入到 node 的输入层之后
            if (is_no_input) {
                // 如果特征数据需要 split 则插在最前面
                _cfg_vec.insert(_cfg_vec.begin(), split_config);
            } else {
                _cfg_vec.insert(_cfg_vec.begin() + pos + 1, split_config);
            }
        }
    }
}

}
} //namespace houyi

