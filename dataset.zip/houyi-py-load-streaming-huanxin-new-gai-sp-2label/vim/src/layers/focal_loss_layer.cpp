/**
 * focal_loss_layer.h
 * Author: fuxuanyu (fuxuanyu@baidu.com)
 * Created on: 2018-05-15
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "focal_loss_layer.h"
#include "focal_loss_ops.h"

namespace houyi {
namespace train {

void FocalLossLayer::cal_target(
        std::vector<IOPackage*>& output,
        std::vector<IOPackage*>& label,
        std::vector<IOPackage*>& target)
{
    CHECK2(output[0] && label[0] && target[0]);
    _real_sample_count = get_real_sample_num(*label[0]->get_ten(), *label[0]->get_mask(),
            _cfg.get_ignore_label());
    target[0]->get_ten()->cross_entropy(*output[0]->get_ten(), *label[0]->get_ten(),
            *label[0]->get_mask());
}

void FocalLossLayer::cal_loss(
        std::vector<IOPackage*>& output,
        std::vector<IOPackage*>& label,
        std::vector<IOPackage*>& loss)
{
    CHECK2(output[0] && label[0] && loss[0]);
     
    if (_bp_down[0]) {
        float cur_ratio = 1.0f * rand() / RAND_MAX;
        // focal loss 
        if (cur_ratio <= _ratio) {
            int label_size = label[0]->get_ten()->get_size(0);
            label[0]->get_mask()->reshape(Dim(label_size, 1)); 
            wind_focal_loss_cal_error(*loss[0]->get_ten(), *output[0]->get_ten(),
                    *label[0]->get_ten(), *label[0]->get_mask(), _gamma);
            label[0]->get_mask()->reshape(Dim(label_size));
        }
        // ce loss
        else {
            loss[0]->get_ten()->cross_entropy_bp(*output[0]->get_ten(), *label[0]->get_ten(),
                    *label[0]->get_mask(), 1.0f);
        }
    }
}

Loss& FocalLossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;

    switch (type) {
    case TGT_ACU:
    case TGT_ERR:
        cost = output(_output_keys[0]).get_ten()->sum();
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    _loss->set_frame_counter(_real_sample_count);
    _loss->set_sample_counter(_sample_num);
    return *_loss;
}

} //namespace houyi
} //namespace train
