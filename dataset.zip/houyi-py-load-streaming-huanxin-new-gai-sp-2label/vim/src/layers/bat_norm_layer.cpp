/**
 * BatNormLayer.cpp
 * Author: madongpeng (madongpeng@baidu.com)
 * Created on: 2014-09-14
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 */
#include "bat_norm_layer.h"
#include "tools.h"

namespace houyi {
namespace train {

BatNormalLayer::BatNormalLayer(BatNormConfig& config)
    : Layer(config) {
    set_device();
    _config = config;
    _epsilon = 1e-6;
    //_epsilon = config.epsilon();

    _real_frame_num = 0;
    _label_host.set_device(CPU);

    if (config.mean_var_file().size() != 0) {
        _global_mean_var = (char*)(config.mean_var_file().c_str());
    } else {
        _global_mean_var = NULL;
    }

    build_map();

    _eta = config.get_eta();

    _counter = 0;
    _store_item = 0;
    _frame_dim = 0;
    _pid = 0;
    _tid = 0;
    _moving_average_fraction = config.get_moving_average_fraction();
}

BatNormalLayer::BatNormalLayer(BatNormalLayer* from):
    Layer(from) {
    CHECK(from != NULL, "from is NULL");
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) BatNormalLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    _w.resize_like(*from->w());
    _w.copy_from(*from->w());
    _bias.resize_like(*from->bias());
    _bias.copy_from(*from->bias());

    if (_inq) {
        _w_t.resize_like(*from->w_t());
        _w_t.copy_from(*from->w_t());
        _bias_t.resize_like(*from->bias_t());
        _bias_t.copy_from(*from->bias_t());
    }
}

void BatNormalLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    Dim dim = inputs[0]->get_size();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    int frame_dim = dim[1];

    _frame_dim = frame_dim;
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _w.resize(Dim(1, frame_dim), GPU);
    _bias.resize(Dim(1, frame_dim), GPU);

    if (need_update()) {
        _dw.resize(Dim(1, frame_dim), GPU);
        _d_bias.resize(Dim(1, frame_dim), GPU);
    }

	if (_inq) {
		_w_t.resize(Dim(1, frame_dim), GPU);
		_w_t.w()->set_element(1);

        _bias_t.resize(Dim(1, frame_dim), GPU);  
        _bias_t.w()->set_element(1);
	}

    _acc_mean_vec.resize(Dim(1, frame_dim));
    _acc_var_vec.resize(Dim(1, frame_dim));

    _statis_mean_vec.resize(Dim(1, frame_dim));
    _statis_var_vec.resize(Dim(1, frame_dim));

    if (_global_mean_var != NULL) {
        read_initial_mean_var();
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void BatNormalLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "weight", &_w));
    _w_map.insert(WeightsMap::value_type(pre + "bias", &_bias));

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_dw));
        _dw_map.insert(WeightsMap::value_type(pre + "bias", &_d_bias));
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_w_t));      
        _w_map.insert(WeightsMap::value_type(pre + "bias_binary", &_bias_t)); 
    }
}

void BatNormalLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    _pid = getpid();
    _tid = syscall(SYS_gettid);
    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}

BatNormalLayer::~BatNormalLayer() {
}

void BatNormalLayer::init_weight(const ModelInitConfig& global_cfg) {
    _w.w()->set_element(1.0f);
    _bias.w()->set_element(0.0f);
}

void BatNormalLayer::init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers) {
    CHECK(global_cfg.weight_init_type() == MODEL_INIT, "model init type must be model init");

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _w.w()->set_element(1.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的weight */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.weight_name().size() != 0) ? _model_init_cfg.weight_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) == std::string::npos && 
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) == std::string::npos &&       
                                name.find("binary", 0) != std::string::npos) { 
                        WeightsMap::iterator itr = i->w_map().find(name);      
                        if (itr != i->w_map().end()) {                         
                            BaseWeight *src = itr->second;                     
                            dst->copy_from(src);                               
                            _inq_weight_max = i->get_inq_weight_max();         
                        }                                                      
                    }                                                          
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "weight not found in model");
        /*  for inq train */    
        if (_inq) {            
            inq_init_weight(); 
        }                      
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
    case CONSTANT_INIT:
    case UNIFORM_INIT:
        _bias.w()->set_element(0.0f);
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的bias */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.bias_name().size() != 0) ? _model_init_cfg.bias_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) != std::string::npos && 
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight* src = i->w_map()[name];
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) != std::string::npos &&      
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);     
                        if (itr != i->w_map().end()) {                        
                            BaseWeight *src = itr->second;                    
                            dst->copy_from(src);                              
                            _inq_bias_max = i->get_inq_bias_max();            
                        }                                                     
                    }                                                         
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "bias not found in model");
        /* for inq train */  
        if (_inq) {          
            inq_init_bias(); 
        }                    
        break;
    }

    default:
        CHECK(false, "model init type error");
    }

}

void BatNormalLayer::gauss_init(DType mean, DType stdv) {
    _w.w()->set_element(1.0f);
    _bias.w()->set_element(0.0f);
}


void BatNormalLayer::read_initial_mean_var() {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    if (NULL == _global_mean_var) {
        return;
    }

    if (is_predict_job(type)) {
        read_initial_mean_var_em1(_global_mean_var);
    } else {
        read_initial_mean_var_em0(_global_mean_var);
    }
}

void BatNormalLayer::read_initial_mean_var(std::string bn_file_prefix) {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    if (0 == bn_file_prefix.size()) {
        return;
    }

    if (is_predict_job(type)) {
        read_initial_mean_var_em1((bn_file_prefix + "/bn_" + _name).c_str());
    } else {
        CHECK(false, "Can not call read_initial_mean_var(std::string bn_file_prefix) in train mode.");
    }
}

int BatNormalLayer::get_real_frame_num(IOPackage* label_pack) {
    int cnt = 0;
    Tensor<DType>* label = label_pack->get_ten();

    _label_host.resize(Dim(label->get_size()));
    _label_host.copy_from(*label);

    DType* ptr = _label_host.get_data();

    for (int i = 0; i < _label_host.get_size().product(); i++) {
        if ((int)ptr[i] != -1) {
            cnt++;
        }
    }

    return cnt;
}

void BatNormalLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    _real_frame_num = in_pack[0]->get_mask()->sum();

    if (is_predict_job(type)) {
        inter_forward_em1(in_pack);
    } else {
        inter_forward_em0(in_pack);
    }
}

void BatNormalLayer::read_initial_mean_var_em1(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");

    // 做预测时, 如果 bn 文件暂时未生成, 则设置均值为0, 方差为1
    if (NULL == fin) {
        INTER_LOG("Open file error %s", file_name);
        _var_vec.resize_like(_acc_mean_vec);
        _mean_vec.resize_like(_acc_mean_vec);
        _var_vec.set_element(1.0f);
        _mean_vec.set_element(0.0f);
    } else {
        //CHECK(fin != NULL, "Open file error %s", file_name);

        std::vector<float> mean, var;
        float m = 0.0f;
        float v = 0.0f;

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &v);
            var.push_back(v);
        }

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            fscanf(fin, "%f ", &m);
            mean.push_back(m);
        }

        fclose(fin);

        _var_vec.resize(Dim(1, _frame_dim));
        _mean_vec.resize(Dim(1, _frame_dim));

        for (size_t i = 0; i < (size_t)_frame_dim; i++) {
            _mean_vec.set_element(Dim(0, i), mean[i]);
            _var_vec.set_element(Dim(0, i), std::sqrt(var[i] + _epsilon));
            //_var_vec.set_element(Dim(0, i), var[i]);
        }

        _var_vec.reciprocal();
    }
}

void BatNormalLayer::inter_forward_em1(std::vector<IOPackage*>& in_pack) {
    size_t batch_size = in_pack[0]->get_height();

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    _x_sharp_o.resize(Dim(batch_size, out->get_width()));
    _x_bias.resize(Dim(batch_size, _frame_dim));

    _label_mask.resize(in_pack[0]->get_mask()->get_size());
    _label_mask.copy_from(*in_pack[0]->get_mask());

    _x_bias.vec_mask(*in, _label_mask);

    // calculate input-var-value
    //_x_bias.add_bias(_x_bias, _mean_vec, 1.0f, -1.0f);
    _x_bias.row_add_vec(_x_bias, _mean_vec, 1.0f, -1.0f);
    _x_bias.vec_mask(_x_bias, _label_mask);
    _x_sharp_o.row_mul_vec(_x_bias, _var_vec, 1.0f, 0.0f);
    out->row_mul_vec(_x_sharp_o, *_w.w(), 1.0f, 0.0f);
    out->row_add_vec(*out, *_bias.w());
}

void BatNormalLayer::read_initial_mean_var_em0(const char* file_name) {
    FILE* fin = fopen(file_name, "rt");
    CHECK(fin != NULL, "Open file error %s", file_name);

    std::vector<float> mean, var;
    float mv = 0.0f;

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        var.push_back(mv);
        _acc_var_vec.set_element(Dim(0, i), mv);
    }

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        fscanf(fin, "%f ", &mv);
        mean.push_back(mv);
        _acc_mean_vec.set_element(Dim(0, i), mv);
    }

    fclose(fin);

#if 0
    _w.resize(Dim(1, _frame_dim), GPU);
    _bias.resize(Dim(1, _frame_dim), GPU);

    for (size_t i = 0; i < (size_t)_frame_dim; i++) {
        _w.w()->set_element(Dim(0, i), mean[i]);
        _bias.w()->set_element(Dim(0, i), var[i]);
    }

#endif
}

void BatNormalLayer::inter_forward_em0(std::vector<IOPackage*>& in_pack) {
    size_t batch_size = in_pack[0]->get_height();
    size_t width = in_pack[0]->get_width();
    CHECK2((int)width == _frame_dim);

    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    _x_sharp_o.resize(Dim(batch_size, width));
    _x_bias.resize(Dim(batch_size, _frame_dim));
    _acc_x_bias.resize(Dim(batch_size, _frame_dim));
    _real_in.resize(Dim(batch_size, _frame_dim));

    _label_mask.resize(in_pack[0]->get_mask()->get_size());
    _label_mask.copy_from(*in_pack[0]->get_mask());
    _real_in.vec_mask(*in, _label_mask);

    _mean_vec.resize(Dim(1, width));
    _var_vec.resize(Dim(1, width));

    // calculate input-mean-value
    _mean_vec.col_sum(_real_in, 1.0f / (float)_real_frame_num);
    _acc_mean_vec.elem_add(_mean_vec, _acc_mean_vec, _eta, 1 - _eta);
    _x_bias.row_add_vec(_real_in, _mean_vec, 1.0f, -1.0f);
    _x_bias.vec_mask(_x_bias, _label_mask);

    // calculate input-var-value
    out->square(_x_bias);
    _var_vec.col_sum(*out, 1.0f / (float)_real_frame_num, 0.0f);
    _acc_var_vec.elem_add(_var_vec, _acc_var_vec, _eta, 1 - _eta);

    _statis_mean_vec.elem_add(_statis_mean_vec, _mean_vec, _moving_average_fraction, 1.0f);
    _statis_var_vec.elem_add(_statis_var_vec, _var_vec, _moving_average_fraction, 1.0f);
    _counter = _counter * _moving_average_fraction + 1;

    if (_epsilon > 0.0f) {
        _acc_var_vec.add(_epsilon);
    }

    _acc_var_vec.sqrt(); // NOTICE: the Variance  has been sqrted already!
    _acc_var_vec.reciprocal();

    // calculate the output of this layer
    _acc_x_bias.row_add_vec(_real_in, _acc_mean_vec, 1.0f, -1.0f);
    _acc_x_bias.vec_mask(_acc_x_bias, _label_mask);
    _x_sharp_o.row_mul_vec(_acc_x_bias, _acc_var_vec, 1.0f, 0.0f);

    out->row_mul_vec(_x_sharp_o, *_w.w(), 1.0f, 0.0f);
    out->row_add_vec(*out, *_bias.w());
}

void BatNormalLayer::inter_bprop_diff(
    std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    INTER_CHECK(need_update(), "the need_update is false");
    
    if (in_pack[0] == NULL || out_pack[0] == NULL) {
        return;
    }
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten(); // NOTICE: not _diff

    size_t batch_size = in->get_height();
    _d_mean_vec.resize(Dim(1, _frame_dim));
    _d_var_vec.resize(Dim(1, _frame_dim));

    _buf_e.resize(Dim(batch_size, local_diff->get_width()));

    // calculate the w-gradient (dGamma)
    _buf_e.elem_mul(_x_sharp_o, *local_diff, 1.0f, 0.0f);
    _dw.w()->col_sum(_buf_e, 1.0f, 0.0f);

    // calculate the bias-gradient (dBeta)
    _d_bias.w()->col_sum(*local_diff, 1.0f, 0.0f);

    // calculate the backprop-error
    // 1. delta-xSharp : _x_sharp_o = _x_sharp_o*gamma(_w)
    _x_sharp_o.row_mul_vec(*local_diff, *_w.w(), 1.0f, 0.0f);

    // 2. delta-var
    _d_var_vec.pow(_acc_var_vec, 3); // dvar = var^(-3/2), but var = var^(-1/2)
    _d_var_vec.mul(-0.5f * _eta); // dvar = -1/2 * dvar
    _buf_e.elem_mul(_x_bias, _x_sharp_o, 1.0f, 0.0f);
    _buf_e.row_mul_vec(_buf_e, _d_var_vec, 1.0f, 0.0f);
    _d_var_vec.col_sum(_buf_e, 1.0f, 0.0f);

    // 3.delta-mean
    _buf_e.row_mul_vec(_x_sharp_o, _acc_var_vec, -1.0f * _eta, 0.0f);
    _d_mean_vec.col_sum(_buf_e, 1.0f, 0.0f);
    _buf_e.row_add_vec(*in, _mean_vec, 2.0f / _real_frame_num, -2.0f / _real_frame_num);
    _buf_e.row_mul_vec(_buf_e, _d_var_vec, 1.0f, 0.0f);
    _buf_e.vec_mask(_buf_e, _label_mask);
    _d_mean_vec.col_sum(_buf_e, -1.0f, 1.0f);

    // 4.finally calculate backprop-error
    out_diff->row_mul_vec(_x_sharp_o, _acc_var_vec, 1.0f, 0.0f);
    out_diff->elem_add(*out_diff, _buf_e);
    out_diff->row_add_vec(*out_diff, _d_mean_vec, 1.0f, 1.0f / _real_frame_num);
    out_diff->vec_mask(*out_diff, _label_mask);
}

void BatNormalLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    /* nothing todo */
}

void BatNormalLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->write(output);
        if (_inq) {
            _w_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_weight_max.front());
            max.write(output);
        }

        _bias.w()->write(output);
        if (_inq) {
            _bias_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_bias_max.front());
            max.write(output);
        }
        break;
    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the BatNorm has no this parameter: %d", t);
    }
}

void BatNormalLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
        case WEIGHT:{
        _w.w()->read(input);
        _bias.w()->read(input);
        break;
    }
    case MD_WEIGHT:
    default:{
        INTER_CHECK(false, "the BatNorm has no this parameter: %d", t);
    }
    }
}

void BatNormalLayer::read_inq_model(std::ifstream &input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> tmp;
    tmp.set_device(CPU);
    Tensor<DType> t_bias;
    t_bias.set_device(CPU);
    size_t trans_dim_m = 0;
    
    switch (t) {
        case WEIGHT:
            tmp.read(input);
            trans_dim_m = tmp.get_height();
            CHECK2(trans_dim_m == _w.height());
            _w.w()->copy_from(tmp);
            if (_inq) {
                tmp.read(input);
                _w_t.w()->copy_from(tmp);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_weight_max.push_back(max.get_element(Dim(0)));
            }
            t_bias.read(input);
            _bias.w()->copy_from(t_bias);
            if (_inq) {
                t_bias.read(input);
                _bias_t.w()->copy_from(t_bias);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_bias_max.push_back(max.get_element(Dim(0)));
            }
            break;
        case MD_WEIGHT:
        default:
            INTER_CHECK(false, "the BatNorm has no this parameter: %d", t);
    }            
}

void BatNormalLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> tmp;
    tmp.set_device(cpu_device());
    Tensor<DType> t_bias;
    t_bias.set_device(cpu_device());
    int repeace = 1;
    size_t trans_dim_n = 0;
    size_t trans_dim_m = 0;
    size_t cpy_dim = 0;
    switch (t) {
        case WEIGHT:
            tmp.read_hfnn(input, sizeof(size_t));
            trans_dim_n = tmp.get_width();
            trans_dim_m = tmp.get_height();
            CHECK2(trans_dim_m == _w.height());
            cpy_dim = trans_dim_n;
            repeace = _w.width() / cpy_dim;
            INTER_LOG("repeace: %d", repeace);
            for (size_t i = 0; i < _w.height(); i++) {
                for (size_t j = 0; j < (size_t)repeace; j++) {
                    _w.w()->range_row(i, i + 1).copy_from(
                            tmp.get_row(i), cpy_dim * j, cpy_dim);
                }
            }
            t_bias.read_hfnn(input, sizeof(size_t));
            for (size_t j = 0; j < (size_t)repeace; j++) {
                _bias.w()->copy_from(
                        t_bias.get_data(), cpy_dim * j, cpy_dim);
            }
            break;
        case MD_WEIGHT:
        default:
            INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }
}

void BatNormalLayer::read_heter_model(std::ifstream& input) {
    Tensor<DType> tmp;
    tmp.set_device(cpu_device());
    bool has_bias = true;
    tmp.read_hfnn(input, sizeof(int));
    size_t trans_dim_m = tmp.get_height();
    size_t trans_dim_n = tmp.get_width();
    INTER_LOG("read a BatNorm: height:= %lu, width:= %lu",
            trans_dim_m, trans_dim_n);
    int repeace = 1;
    if (trans_dim_m != _w.height()) {
        CHECK2((trans_dim_m - 1 == _w.height()
                    && (trans_dim_n - 1 == _w.width()
                        || trans_dim_n == _w.width()))
                || _w.width() % trans_dim_n == 0);
    } else {
        has_bias = false;
    }
    size_t cpy_dim = (_w.width() % trans_dim_n == 0) ? \
                     trans_dim_n : trans_dim_n - 1;
    repeace = _w.width() / cpy_dim;
    INTER_LOG("repeace: %d", repeace);
    for (size_t i = 0; i < _w.height(); i++) {
        for (size_t j = 0; j < (size_t)repeace; j++) {
            _w.w()->range_row(i, i + 1).copy_from(
                    tmp.get_row(i), cpy_dim * j, cpy_dim);
        }
    }
    if (has_bias) {
        for (size_t j = 0; j < (size_t)repeace; j++) {
            _bias.w()->copy_from(
                    tmp.get_row(trans_dim_m - 1), cpy_dim * j, cpy_dim);
        }
    }
}

void BatNormalLayer::store_mean_var() {
    Tensor<DType> mean {CPU};
    Tensor<DType> var {CPU};
    char name[256] = {0};
    // 时间, 格式如下(年月日时分秒): 20161124112460
    char datetime[20];
    get_datetime(datetime);

    if (access("statis_bn", 0) == -1) {
        mkdir("statis_bn", S_IRWXU);
    }

    snprintf(name, 256, "statis_bn/Statis_Layer_%s_pid_%u_tid_%u_part_%lu_time_%s.sta",
            _name.c_str(), _pid, _tid, _store_item, datetime);
    mean.resize(Dim(1, _frame_dim));
    var.resize(Dim(1, _frame_dim));

    //计算真正的mean，var

    mean.copy_from(_statis_mean_vec);
    var.copy_from(_statis_var_vec);
    mean.mul(1.0f / _counter);
    var.mul(1.0f / _counter);

    std::ofstream in_out(name, std::ios::binary);
    size_t mean_var_dim = _statis_mean_vec.get_w();
    in_out.write((char*)&mean_var_dim, sizeof(size_t));

    // current mean & var
    size_t frame_counter = 1;
    in_out.write((char*)&frame_counter, sizeof(size_t));
    in_out.write((char*)mean.get_data(), _frame_dim * sizeof(DType));
    in_out.write((char*)var.get_data(), _frame_dim * sizeof(DType));

    _store_item++;
}

}
}

