/**
 * updater.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-27
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <new>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <iostream>
#include "weight.h"
#include "updater.h"

namespace houyi {
namespace train {
BaseUpdater* BaseUpdater::create(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) {
    std::string type = (cfg.type() == "unknown") ? global_cfg.get_gd_type() : cfg.type();

    if (type == "sgd") {
        return new SgdUpdater(cfg, global_cfg);
    } else if (type == "adam") {
        return new AdamUpdater(cfg, global_cfg);
    } else if (type == "norm-sgd") {
        return new NormUpdater(cfg, global_cfg);
    } else if (type == "avg") {
        return new AvgUpdater(cfg, global_cfg);
    } else if (type == "rms") {
        return new RmsUpdater(cfg, global_cfg);
    } else if (type == "nesterov-sgd") {
        return new NesterovSgdUpdater(cfg, global_cfg);
    } else {
        INTER_CHECK(false, "unknown updater type: %s", cfg.type().c_str());
    }

    return NULL;
}

void BaseUpdater::adjust_lr(size_t iter_cnt) {
    if (_global_cfg.get_warmup() && iter_cnt < (size_t)_global_cfg.get_warmup_iter()) {
        DType alpha = iter_cnt * 1.0f / _global_cfg.get_warmup_iter();
        DType learn_rate = _global_cfg.get_warmup_lr() + 
                    (_base_learn_rate - _global_cfg.get_warmup_lr()) * alpha;
        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: warmup");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    }
    else if (_global_cfg.get_lr_adjust_type() == FIXED_LR) {
        if (_learn_rate != _base_learn_rate) {
            INTER_LOG("type: fixed_lr");
            INTER_LOG("cur learn rate %.10f", _base_learn_rate);
        }

        _learn_rate = _base_learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == STEP_LR) {
        int cur_step = iter_cnt / _global_cfg.get_step();
        DType learn_rate = _base_learn_rate * pow(_global_cfg.get_gamma(), cur_step);

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: step_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == LINEAR_STEP_LR) {
        int cur_step = iter_cnt / _global_cfg.get_step();
        DType learn_rate = _base_learn_rate + _global_cfg.get_gamma() * cur_step;

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: linear_step_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == EXP_LR) {
        DType learn_rate = _base_learn_rate * pow(_global_cfg.get_gamma(), iter_cnt);

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: exp_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == INV_LR) {
        DType learn_rate = _base_learn_rate *
                           pow((1 + _global_cfg.get_gamma() * iter_cnt), -_global_cfg.get_power());

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: inv_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == MULTI_STEP_LR) {
        if (_cur_step < (int)_global_cfg.get_step_value().size() &&
                (int)iter_cnt >= _global_cfg.get_step_value()[_cur_step]) {
            _cur_step++;
        }

        DType learn_rate = _base_learn_rate * pow(_global_cfg.get_gamma(), _cur_step);

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: multi_step_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == POLY_LR) {
        DType learn_rate = _base_learn_rate *
                           pow((1 - (DType)(iter_cnt) / _global_cfg.get_max_iter()),
                               _global_cfg.get_power());

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: poly_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == SIGMOID_LR) {
        DType learn_rate = _base_learn_rate *
                           (1 / (1 +  exp(-_global_cfg.get_gamma() *
                                          (iter_cnt - _global_cfg.get_step()))));

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: sigmoid_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else if (_global_cfg.get_lr_adjust_type() == LINEAR_MULTI_STEP_LR) {
        if (_cur_step < (int)_global_cfg.get_step_value().size() &&
                (int)iter_cnt >= _global_cfg.get_step_value()[_cur_step]) {
            _cur_step++;
        }

        DType learn_rate = _base_learn_rate + _global_cfg.get_gamma() * _cur_step;

        if (learn_rate != _learn_rate && 
                    iter_cnt >= _iter_cnt_tmp + _global_cfg.get_lr_print_period()) {
            INTER_LOG("type: linear_multi_step_lr");
            INTER_LOG("cur learn rate %.10f", learn_rate);
            _iter_cnt_tmp = iter_cnt;
        }

        _learn_rate = learn_rate;
    } else {
        CHECK(false, "learn rate adjust type error");
    }
}

void SgdUpdater::init_md_weight(const WeightsMap& grads) {
    if (_md_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _md_weights.insert(WeightsMap::value_type(key, bw));
        }
    }

    if (_dw_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _dw_weights.insert(WeightsMap::value_type(key, bw));
        }
    }
}

void SgdUpdater::scale_momentum() {
    MAP_LOOP(_md_weights) {
        BaseWeight* dst = itr1->second;
        dst->mul_scalar(_momentum);
    }
}

void SgdUpdater::collect(const WeightsMap& grads, WeightsMap& weights, int sample_num) {
    init_md_weight(grads); //
    inc_sample_num(sample_num); //

    CHECK2(_dw_weights.size() == grads.size());

    MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
        BaseWeight* src = itr1->second;
        WeightsMap::iterator itr2 = _dw_weights.find(itr1->first);
        BaseWeight* dst = itr2->second;
        /* (-dw) = (-dw) + (-grad) */
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            dst->add(src, 1.0f, 1.0f);
        } else {
            dst->add(src, 1.0f, 1.0f);
        }
    }
}

void SgdUpdater::update_w(BaseWeight* w, BaseWeight* grad, 
        BaseWeight* mdw, 
        DType learning_rate, DType momentum) {
    /* w = w + (-mdw) */
    w->add(mdw, 1.0f, 1.0f); 
}

void SgdUpdater::update(WeightsMap& weights) {
#if 0
    CHECK2(_md_weights.size() == weights.size());
#endif
    MAP_LOOP(weights) {
        BaseWeight* dst = itr1->second;
        std::string name = itr1->first;
        if (name.find("binary", 0) == std::string::npos) { 
            WeightsMap::iterator itr2 = _dw_weights.find(itr1->first);
            BaseWeight* src = itr2->second;

#ifdef __GRADIENT_NORM__
            /*  (-dw) = (-dw) / (device_num * iter_size) */
            src->mul_scalar(1.0 / (_global_cfg.get_iter_size() * _global_cfg.get_device_num()));
#endif

            /* (-dw) = w * (-l2_penalty) + (-dw) */
            WeightsMap::iterator itr3 = weights.find(itr1->first);
            BaseWeight* w = itr3->second;
            if (_l2_penalty > 0.0f) {
                src->add(w, 1.0f, -1.0f * _l2_penalty);
            }

            /* Layer-wise Adaptive Rate Scaling */
            DType learn_rate = _learn_rate;
            if (_global_cfg.get_lars()) {
                DType w_norm2 = w->w()->norm2();
                DType dw_norm2 = src->w()->norm2();
                w_norm2 = (w_norm2 < 1e-6)? 1e-6 : w_norm2;
                learn_rate = _learn_rate * _global_cfg.get_lars_ratio() * w_norm2 / dw_norm2;
            }

            /*  (-mdw) = mom * (-mdw) + lr * (-dw)*/                    
            WeightsMap::iterator iter4 = _md_weights.find(itr1->first);
            BaseWeight *mdw = iter4->second;                           
            mdw->add(src, _momentum, learn_rate);                     

            std::string name_bianry = name.append("_binary");
            WeightsMap::iterator itr1_w_t = weights.find(name_bianry);
            if (itr1_w_t != weights.end()) {
                Tensor<DType> &w_t = *itr1_w_t->second->w();
                mdw->w()->elem_mul(*mdw->w(), w_t);
            }

            update_w(dst, src, mdw, _learn_rate, _momentum);
        }
    }
    zero_weight_map(_dw_weights);
}

void SgdUpdater::accum_to(WeightsMap& accum, DType alpha, DType beta) {
    CHECK2(accum.size() == _md_weights.size());

    WeightsMap::iterator itr1 = accum.begin();

    for (; itr1 != accum.end(); ++itr1) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* src = itr2->second;
        dst->add(src, beta, alpha);
    }
}

void SgdUpdater::copy_from(WeightsMap& accum) {
    init_md_weight(accum);
    CHECK2(accum.size() == _md_weights.size());

    WeightsMap::iterator itr1 = accum.begin();

    for (; itr1 != accum.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* dst = itr2->second;
        dst->copy_from(src);
    }
}

void SgdUpdater::copy_to(WeightsMap& accum) {
    CHECK2(accum.size() == _md_weights.size());
    WeightsMap::iterator itr1 = accum.begin();

    for (; itr1 != accum.end(); ++itr1) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* src = itr2->second;
        dst->copy_from(src);
    }
}

void SgdUpdater::clone_to(WeightsMap& accum) {
    clone_weight_map(accum, _md_weights); 
} 

void SgdUpdater::zero() {
    BaseUpdater::zero();
    WeightsMap::iterator itr1 = _md_weights.begin();

    for (; itr1 != _md_weights.end(); ++itr1) {
        BaseWeight* dst = itr1->second;
        dst->zero();
    }
}

void NesterovSgdUpdater::update_w(BaseWeight* w, 
        BaseWeight* grad,
        BaseWeight* mdw,
        DType learning_rate, 
        DType momentum) {
    /* w = w + lr * (-dw) */
    w->add(grad, 1.0f, _learn_rate);
    /* w = w + (-mdw) * _momentum */
    w->add(mdw, 1.0f, _momentum);
}

//////////////////////////////////////////////////////////////////////////////////
void AdamUpdater::init_md_weight(const WeightsMap& grads) {
    /* 初始化adam用到的各个统计量 */

    SgdUpdater::init_md_weight(grads);

    if (_mt_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _mt_weights.insert(WeightsMap::value_type(key, bw));
        }
    }

    if (_vt_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _vt_weights.insert(WeightsMap::value_type(key, bw));
        }
    }

    if (_tmp_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _tmp_weights.insert(WeightsMap::value_type(key, bw));
        }
    }
}

void AdamUpdater::collect(const WeightsMap& grads, WeightsMap& weights, int sample_num) {
    init_md_weight(grads); //
    inc_sample_num(sample_num); //

    CHECK2(_md_weights.size() == grads.size());

    if (_collect_counter == 0) {
        MAP_LOOP(_md_weights) {
            BaseWeight* mdw = itr1->second;
            mdw->zero();
        }
    }

    /* collect过程只做梯度累加 */
    MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
        BaseWeight* dw = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* mdw = itr2->second;
        mdw->add(dw, 1.0f, 1.0f);  //mdw += dw
    }

    _collect_counter ++;
}

void AdamUpdater::update(WeightsMap& weights) {
    CHECK2(_md_weights.size() == weights.size());

    _t++;

    MAP_LOOP(weights) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* mdw = itr2->second;

        BaseWeight* mt = _mt_weights.find(itr1->first)->second;
        BaseWeight* vt = _vt_weights.find(itr1->first)->second;
        BaseWeight* tmp = _tmp_weights.find(itr1->first)->second;

        /* mdw = w * l2_penalty + mdw */
        if (_l2_penalty > 0.0f) {
            WeightsMap::iterator itr3 = weights.find(itr1->first);
            BaseWeight* l2 = itr3->second;
            mdw->add(l2, 1.0f, -1.0f * _l2_penalty);
        }

        /* beta1,t = beta1 * lamdba^(t - 1) */
        _beta1t = _beta1 * pow(_lambda, _t);
        /* mt = beta1,t * mt-1 + (1 - beta1,t) * gt */
        mt->add(mdw, _beta1t, (1.0 - _beta1t));
        /* gt = gt^2*/
        mdw->w()->square(*mdw->w());
        /* vt = beta2 * vt-1 + (1 - beta2) * gt */
        vt->add(mdw, _beta2, (1.0 - _beta2));

        /* tmp = mt / (sqrt(vt) + epsilon) */
        tmp->w()->sqrt(*vt->w());
        tmp->w()->add(_epsilon);
        tmp->w()->elem_div(*mt->w(), *tmp->w(), 1.0f, 0.0f);

        DType scale = 0;
        /*scale = sqrt(1 - beta2^t) / (1 - beta1^t)*/
        scale = sqrt(1.0 - pow(_beta2, _t)) / (1 - pow(_beta1, _t));

        /* thetat = thetat-1 - alpha * scale * tmp */
        dst->add(tmp, 1.0f, _learn_rate * scale);

    }
    _collect_counter = 0;
}

//////////////////////////////////////////////////////////////////////////////////
void RmsUpdater::init_md_weight(const WeightsMap& grads) {
    /* 初始化rms用到的各个统计量 */
    SgdUpdater::init_md_weight(grads);

    if (_et_weights.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _et_weights.insert(WeightsMap::value_type(key, bw));
        }
    }

    if (_tmp.size() == 0) {
        MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
            const std::string& key = itr1->first;
            BaseWeight* bw = itr1->second->clone();
            _tmp.insert(WeightsMap::value_type(key, bw));
        }
    }
}
void RmsUpdater::collect(const WeightsMap& grads, WeightsMap& weights, int sample_num) {
    init_md_weight(grads); //
    inc_sample_num(sample_num); //

    CHECK2(_md_weights.size() == grads.size());

    if (_collect_counter == 0) {
        MAP_LOOP(_md_weights) {
            BaseWeight* mdw = itr1->second;
            mdw->zero();
        }
    }

    /* collect过程只做梯度累加 */
    MAP_LOOP((*(const_cast<WeightsMap*>(&grads)))) {
        BaseWeight* dw = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* mdw = itr2->second;
        mdw->add(dw, 1.0f, 1.0f);  //mdw += dw
    }

    _collect_counter ++;
}

void RmsUpdater::update(WeightsMap& weights) {
    CHECK2(_md_weights.size() == weights.size());

    MAP_LOOP(weights) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* mdw = itr2->second;

        BaseWeight* et = _et_weights.find(itr1->first)->second;
        BaseWeight* tmp = _tmp.find(itr1->first)->second;

        /* mdw = w * l2_penalty + mdw */
        if (_l2_penalty > 0.0f) {
            WeightsMap::iterator itr3 = weights.find(itr1->first);
            BaseWeight* l2 = itr3->second;
            mdw->add(l2, 1.0f, -1.0f * _l2_penalty);
        }

        /* et = gamma * et-1 + (1 - gamma) * gt^2 */
        tmp->w()->square(*mdw->w());
        et->add(tmp, _gamma, (1.0 - _gamma));
        /* tmp = sqrt(et + epsilon) */
        tmp->w()->copy_from(*et->w());
        tmp->w()->add(_epsilon);
        tmp->w()->sqrt();

        /* thetat = thetat-1 - eta * (gt / tmp) */
        tmp->w()->elem_div(*mdw->w(), *tmp->w(), 1.0f, 0.0f);
        dst->add(tmp, 1.0f, _learn_rate);
    }
    _collect_counter = 0;
}

/////////////////////////////////////////////////////////////////////////////////////
void NormUpdater::collect(
    const WeightsMap& grads, WeightsMap& weights, int sample_num) {

    init_md_weight(grads); //
    inc_sample_num(sample_num); //

    if (_collect_counter == 0) {
        scale_momentum();
    }

    MAP_LOOP(_md_weights) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = const_cast<WeightsMap*>(&grads)->find(itr1->first);
        BaseWeight* src = itr2->second;
        DType norm = src->norm();

        if (_threshold > 0.0f && norm > _threshold) {
            if (_threshold_ratio < 1.0f || norm < _threshold_ratio * _threshold) {
                dst->add(src, 1.0f, _learn_rate * (_threshold / norm));
            } else {
                INTER_LOG("norm_grad = %f, threshold = %f", norm, _threshold);
            }
        }
    }
    _collect_counter ++;
}

void AvgUpdater::collect(const WeightsMap& grads, WeightsMap& weights, int sample_num) {
    init_md_weight(grads); //
    inc_sample_num(sample_num); //
    MAP_LOOP(_md_weights) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = const_cast<WeightsMap*>(&grads)->find(itr1->first);
        BaseWeight* src = itr2->second;
        //DType norm = src->norm2();
        dst->add(src, 1.0f, 1.0f);
    }
    _collect_counter ++;
}

void AvgUpdater::update(WeightsMap& weights) {
    CHECK2(_md_weights.size() == weights.size());
    MAP_LOOP(weights) {
        BaseWeight* dst = itr1->second;
        WeightsMap::iterator itr2 = _md_weights.find(itr1->first);
        BaseWeight* src = itr2->second;
        dst->add(src, 1.0f, 1.0f / (float)_collect_counter);
    }
    zero_weight_map(_md_weights);
    _collect_counter = 0;
}

void zero_weight_map(WeightsMap& map) {
    WeightsMap::iterator itr1 = map.begin();

    for (; itr1 != map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        src->zero();
    }
}

void copy_weight_map(WeightsMap& dst_map,
                     WeightsMap& src_map, WindStream cp_in_stream) {

    CHECK2(src_map.size() == dst_map.size() || src_map.size() == dst_map.size() / 2);
    WeightsMap::iterator itr1 = src_map.begin();

    for (; itr1 != src_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        WeightsMap::iterator itr2 = dst_map.find(itr1->first);
        BaseWeight* dst = itr2->second;
        dst->copy_from(src, cp_in_stream);
    }
}

void copy_weight_map(WeightsMap& dst_map, WeightsMap& src_map) {

    CHECK2(src_map.size() == dst_map.size());
    WeightsMap::iterator itr1 = src_map.begin();

    for (; itr1 != src_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        WeightsMap::iterator itr2 = dst_map.find(itr1->first);
        BaseWeight* dst = itr2->second;
        dst->copy_from(src);
    }
}

void init_weight_map(WeightsMap& dst_map,
                     WeightsMap& src_map, const Device& device) {
    if (dst_map.size() == src_map.size()) {
        return;
    }

    WeightsMap::iterator itr1 = src_map.begin();

    for (; itr1 != src_map.end(); ++itr1) {
        std::string key = itr1->first;
        BaseWeight* bw = itr1->second->clone(device);
        dst_map.insert(WeightsMap::value_type(key, bw));
    }

    CHECK2(src_map.size() == dst_map.size());
}

void clone_weight_map(WeightsMap& dst_map, WeightsMap& src_map) {
    MAP_LOOP(src_map) {
        std::string key = itr1->first;
        BaseWeight* bw = itr1->second;
        dst_map.insert(WeightsMap::value_type(key, bw));
    }
    CHECK2(src_map.size() == dst_map.size());
}

void release_weight_map(WeightsMap& dst_map) {
    MAP_LOOP(dst_map) {
        std::string key = itr1->first;
        BaseWeight* bw = itr1->second;

        if (bw) {
            delete bw;
            bw = NULL;
        }

        itr1->second = NULL;
    }
    dst_map.clear();
}

}
}
