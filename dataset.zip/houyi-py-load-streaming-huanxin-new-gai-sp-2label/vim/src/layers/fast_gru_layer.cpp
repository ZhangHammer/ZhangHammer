//by zhxfl 2017.11.30
#include <vector>
#include "fast_gru_layer.h"

namespace houyi {
namespace train {

FastGruLayer::FastGruLayer(FastGruConfig& conf) : Layer(conf) {
    set_device();
    _config = conf;
    _output_dim = _config.out_dim();
    _skip_num = conf.skip_num();
    _nxt_start = 0;

    _tbptt = _config.tbptt();
    _updatett = _config.updatett();

    _reset_act = Activation::create(_config.reset_act());
    _update_act = Activation::create(_config.update_act());
    _state_act = Activation::create(_config.state_act());

    _final_mean.resize(3, -1.0);
    _final_stdv.resize(3, -1.0);
    _mean.resize(3, 0.0);
    _stdv.resize(3, 0.0);

    _mean_counter = 0;
    _mean_batch_number = _config.mean_statistic_num();
    _threshold = _config.threshold();
    _threshold_ratio = _config.threshold_ratio();
    
    build_map();
}

FastGruLayer::FastGruLayer(FastGruLayer* from) : Layer(from) {
    set_device();
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) FastGruLayer(from->config());
    // TODO
    layer_set(from->get_input(), from->get_sample_num());

    // w 
    _w.resize_like(from->_w);
    _w.copy_from(from->_w);
    
    // u
    _u.resize_like(from->_u);
    _u.copy_from(from->_u);

    if (_config.has_bias()) {
        //bias
        _bias.resize_like(from->_bias);
        _bias.copy_from(from->_bias);
    }
}

FastGruLayer::~FastGruLayer() {
    if (_reset_act) {
        delete _reset_act;
        _reset_act = NULL;
    }

    if (_update_act) {
        delete _update_act;
        _update_act = NULL;
    }

    if (_state_act) {
        delete _state_act;
        _state_act = NULL;
    }
}

void FastGruLayer::set_device() {
    _back_error.set_device(gpu_device());
    _seq_len.set_device(gpu_device());
    _reverse.set_device(gpu_device());
    _reverse_out.set_device(gpu_device());
    _reverse_in_diff.set_device(gpu_device());
}

/*
 * 根据输入的大小确定所有tensor的大小，包括weight，bias和输出等
 */
void FastGruLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num * _skip_num;

    _input_dim = inputs[0]->get_width();
    _output_dim = _config.out_dim();
    int frame_num = inputs[0]->get_size()[0];
    _sub_seq_size = frame_num / _sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _w.resize(Dim(_input_dim, _output_dim * 3), gpu_device());
    _u.resize(Dim(_output_dim, _output_dim * 3), gpu_device());

    if (_config.need_update()) { 
        _dw.resize(Dim(_input_dim, _output_dim * 3), gpu_device());
        _du.resize(Dim(_output_dim, _output_dim * 3), gpu_device());
    }

    if (_config.has_bias()) {
        _bias.resize(Dim(1, _output_dim * 3), gpu_device());

        if (need_update()) {
            _dbias.resize(Dim(1, _output_dim * 3), gpu_device());
        }
    }
    
    //resize out
    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void FastGruLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int frame_num = inputs[0]->get_size()[0];
    CHECK(frame_num % _skip_num == 0, "frame num must be divisible by skip num");
    //int frame_dim = inputs[0]->get_size()[1];
    _sample_num = sample_num * _skip_num;
    _sub_seq_size = frame_num / _sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(
                Dim(frame_num, _output_dim), inputs[i]->get_mask(), gpu_device());
    }

    resize_tensor(inputs, _sample_num);
}

void FastGruLayer::resize_tensor(std::vector<IOPackage*>& inputs, 
        int sample_num) {
    CHECK2(inputs.size() == 1);
    // set batch size
    int frame_num = inputs[0]->get_size()[0];
    if (_updatett >= 0) {
        _tbptt = frame_num / sample_num;
    }

    _hidden_state.resize(frame_num, _tbptt * sample_num, _output_dim);
    _partial_hidden.resize(frame_num, _tbptt * sample_num, _output_dim);
    _back_error.resize(Dim(sample_num, _output_dim));
    _back_error_tmp.resize(Dim(sample_num, _output_dim * 3));
    _w_x_bias.resize(Dim(frame_num, _output_dim * 3), gpu_device());
    _u_h_t_1.resize(Dim(sample_num, _output_dim * 3), gpu_device());
    _out.resize(Dim(_sub_seq_size * _sample_num * 3, _output_dim), gpu_device());
    _out_error.resize(Dim(_sub_seq_size * _sample_num, _output_dim * 3), gpu_device());
}

/*
 * 构造w字典和dw字典
 */
void FastGruLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }
    _w_map.insert(WeightsMap::value_type(pre + "w", &_w));
    _w_map.insert(WeightsMap::value_type(pre + "u", &_u));
    _w_map.insert(WeightsMap::value_type(pre + "bias", &_bias));

    if (_config.need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "w", &_dw));
        _dw_map.insert(WeightsMap::value_type(pre + "u", &_du));
        _dw_map.insert(WeightsMap::value_type(pre + "bias", &_dbias));
    }
}

void FastGruLayer::set_next_start() {
    //TODO
    //_w_reset, _w_update, _w_state
    _nxt_start += 1;

    //_u_reset, _u_update, _u_state
    _nxt_start += 1;

    //_bias_reset, _bias_update, _bias_state
    _nxt_start += 1;
}

void FastGruLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();
    Dim dim = in->get_size();

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        _reverse.resize(dim);
        _reverse_out.resize(out->get_size());
        _seq_len.resize(Dim(real_sample_num));
        _seq_len.count_valid_label(*mask, real_sample_num, real_sub_seq_size);
        _reverse.mask_reverse(*in, _seq_len, real_sample_num, real_sub_seq_size);
        in = &_reverse;
        out = &_reverse_out;
    }

    in->reshape(Dim(in->get_size(0), in->get_element_count() / in->get_size(0)));

    CHECK2(in->get_height() % _sample_num == 0);
    size_t frame_num = in->get_height() / _sample_num;

    // reset_out = reset_w * x + reset_bias
    // update_out = update_w * x + update_bias
    // state_out = state_w * x + state_bias
    // w = col_append(reset_w, update_w, state_w)
    // bias = col_append(reset_bias, update_bias, state_bias)
    // w_x_bias = w * x + bias
    _w_x_bias.mul(*in, *_w.w());
    if (_has_bias) {
        _w_x_bias.row_add_vec(_w_x_bias, *_bias.w());
    }
    // sample_num 句子的帧数
    for (size_t t = 0; t < frame_num; t++) {
        size_t st_row = _tbptt + t - 1;
        size_t ed_row = _tbptt + t;
        CHECK2(_config.update_act() == ACT_SIGMOID);
        CHECK2(_config.reset_act() == ACT_SIGMOID);
        CHECK2(_config.state_act() == ACT_TANH);
        // u = col_append(reset_u, update_u, state_u)
        // u_h_t_1 = u * h(t - 1)
        Tensor<DType> hidden_state_all_o = _hidden_state._all_o.range_row(st_row, ed_row, _sample_num);
        _u_h_t_1.mul(hidden_state_all_o, *_u.w());

        // reset_out(t) = sigmoid(u_h_t_1(reset) + w_x_bias(reset, t))
        // update_out(t) = sigmoid(u_h_t_1(update) + w_x_bias(update, t))
        // partial = u_h_t_1(state)
        // state_out(t) = tanh(reset_out(t) @ u_h_t_1(state) + w_x_bias(state,t))
        // h(t) = (1 - update_out(t)) @ h(t-1) + update_out(t) @ state_out(t)
        wind_gru_forward(
            _out, _u_h_t_1, _w_x_bias,
            *_partial_hidden._cur_o,
            *_hidden_state._cur_o,
            _hidden_state._all_o,
            t, st_row, _sample_num, _sub_seq_size);
    }


    out->copy_from(*_hidden_state._cur_o);

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        out = output(_output_keys[0]).get_ten();
        in = in_pack[0]->get_ten();
        out->mask_reverse(_reverse_out, _seq_len, real_sample_num, real_sub_seq_size);
    }

    in->reshape(dim);
    in = out = NULL;
}

void FastGruLayer::cal_time_gradient() {
    int s_row = _hidden_state._all_o.get_height() / _sample_num - _tbptt - 1;
    int e_row = _hidden_state._all_o.get_height() / _sample_num - 1;

    if (need_update()) {
        get_du(W_STATE).mul(_partial_hidden._all_o.range_row(s_row, e_row, _sample_num),
                true, get_out_error(W_STATE) ,false, 1.0, 0.0);
        get_du(W_UPDATE).mul(_hidden_state._all_o.range_row(s_row, e_row, _sample_num),
                true, get_out_error(W_UPDATE), false, 1.0, 0.0);
        get_du(W_RESET).mul(_hidden_state._all_o.range_row(s_row, e_row, _sample_num),
                true, get_out_error(W_RESET), false, 1.0, 0.0);
    }
}

void FastGruLayer::store_history() {
    _hidden_state.store_cur_out();
}

void FastGruLayer::linear_gradient(const Tensor<DType>& x) {
    if (need_update()) {
        _dw.w()->mul(x, true, _out_error, false, 1.0f, 0.0f);
        if (_config.has_bias()) {
            _dbias.w()->collect_bias(_out_error, 1.0f, 0.0f);
        }
    }
}

void FastGruLayer::inter_bprop_diff(
        std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {

    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }

    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Dim dim = out_diff->get_size();
    out_diff->reshape(Dim(out_diff->get_size(0),
                out_diff->get_element_count() / out_diff->get_size(0)));

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        _reverse_in_diff.resize(in_diff->get_size());
        _reverse_pre_diff.resize(out_diff->get_size());
        _reverse_in_diff.mask_reverse(*in_diff, _seq_len, real_sample_num, real_sub_seq_size);
        in_diff = &_reverse_in_diff;
        out_diff = &_reverse_pre_diff;
    }
    CHECK2(_updatett);
    if (_updatett > 0) {
        // h_error = in_error
        _hidden_state._error.copy_from(*in_diff);
        CHECK(_tbptt == _sub_seq_size, 
                "the bptt must be equal with the size of subsequence");
        //wind_set_sync_flag(false);
        //两个kernel完成
        for (int t = _tbptt - 1; t >= 0; t--) {
            int s_row = _hidden_state._all_o.get_size(0) / _sample_num - (_tbptt - t);
            // back_error = 
            //          col_append(reset_error(t + 1), update_error(t + 1), partital_error(t + 1))
            //          * transpose(u)
            //          + (1 - update(t +1)) @ h_error(t + 1)
            // h_error(t) = in_error + back_error
            // update_error(t) = h_error(t) @ (state_error(t) - h(t -1)) 
            //                  @ update_out(t) @ (update_out(t) - 1)
            //
            // state_error(t) = h_error(t) @ update_out(t) @ (1 - state_out(t) ^ 2)
            // reset_error(t) = h_error(t) @ partital(t) @ reset(t) @ (1 - reset(t))
            // partital_error(t) = state_error(t) @ reset(t)
            // back_error_tmp = col_append(reset_error(t), update_error(t), partital_error(t))
            // back_error = (1 - update(t)) @ h_error(t)
            //
            // tmp_out_error(t) = col_append(reset_error(t), update_gatei(t), partial_error(t))
            wind_gru_backward(_hidden_state._error,
                    _back_error,
                    _out_error,
                    _out,
                    _hidden_state._all_o,
                    _partial_hidden._all_o,
                    _partial_hidden._error,
                    _back_error_tmp,
                    t, s_row,
                    _sample_num, _sub_seq_size
                    );

            // back_error = back_error_tmp * transpose(u) 
            _back_error.mul(_back_error_tmp, false,
                    *_u.w(), true, 1.0f, 1.0f);
        }
        //wind_set_sync_flag(true);
    }
    else {
        CHECK(false, "not support");
    }

    input_error_backprop(*out_diff);
    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;

        out_diff = out_pack[0]->get_ten();
        out_diff->mask_reverse(_reverse_pre_diff, _seq_len, real_sample_num, real_sub_seq_size);
    }

    out_diff->reshape(dim);
}

void FastGruLayer::input_error_backprop(Tensor<DType>& out_error) {
    out_error.mul(_out_error, false, *_w.w(), true, 1.0f, 1.0f);
}

void FastGruLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {

    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }

    Tensor<DType>* in_feat = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Dim dim = in_feat->get_size();

    if (_is_reversal) {
        in_feat = &_reverse;
        out_diff = &_reverse_pre_diff;
    }

    in_feat->reshape(Dim(in_feat->get_size(0), in_feat->get_element_count() / in_feat->get_size(0)));

    cal_time_gradient();
    // dwx
    linear_gradient(*in_feat);

    // store the cell & recurrent state
    store_history();

    if (!clip_gradient()) {
        clear_gradient();
        out_diff->zero();
        if (_is_reversal) {
            _reverse_pre_diff.zero();
            out_diff = out_pack[0]->get_ten();
        }
        out_diff->zero();
        weight_flag(false);
    }

    in_feat->reshape(dim);
    // wind_device_synchronize();
}

void FastGruLayer::clear_gradient() {
    if (need_update()) {
        _dw.zero();
        _du.zero();
        if (_config.has_bias()) {
            _dbias.zero();
        }
    }
}

bool FastGruLayer::clip_gradient() {
    bool ret_flag = true;

    if (need_update()) {
        std::vector<DType> norm(3, 0.0);
        std::vector<int> flag_vec;
        std::vector<Tensor<DType>*> dw = {_dw.w(), _du.w(), _dbias.w()};

        std::vector<std::string> dw_name = {
            "dw",
            "du",
            "dbias"};

        for (int i = 0; i < 3; i++) {
            bool flag = check_dw_norm(
                    *dw[i],
                    norm[i],
                    _final_mean[i],
                    _final_stdv[i],
                    dw_name[i].c_str());
            flag_vec.push_back(static_cast<int>(flag));
        }
        ret_flag = std::accumulate(flag_vec.begin(), flag_vec.end(), 0) == 3;

        if (ret_flag && _threshold_ratio > 0.0) {
            for (int i = 0; i < 3; i++) {
                _mean[i] += norm[i];
                _stdv[i] += norm[i] * norm[i];
            }

            _mean_counter++;
            if (_mean_batch_number > 0 &&_mean_counter >= _mean_batch_number) {
                for (int i = 0; i < 3; i++) {
                    _final_mean[i] = _mean[i] / _mean_counter;
                    _final_stdv[i] = sqrt(_stdv[i] / _mean_counter - _final_mean[i] * _final_mean[i]);
                    _mean[i] = 0;
                    _stdv[i] = 0;
                }
                _mean_counter = 0;
            }
        }
    }
    return ret_flag;
}

Layer* FastGruLayer::clone() {
    return new FastGruLayer(this);
}

void FastGruLayer::clear_history() {
    //TODO
    _hidden_state.reset();
}

void FastGruLayer::clear_history(int sent_idx) {
    //TODO
    _hidden_state.reset(sent_idx, _sample_num);
}

void FastGruLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    std::vector<WType> type{W_RESET, W_UPDATE, W_STATE};

    std::vector<std::function<Tensor<DType>(WType)>> fun{
        std::bind(&FastGruLayer::get_w, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_u, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_bias, this, std::placeholders::_1)};

    std::vector<bool> has_w {true, true, _config.has_bias()};
    switch (t) {
        case WEIGHT: 
            {
                for (size_t i = 0; i < fun.size(); i++) {
                    if (!has_w[i]) {
                        continue;
                    }
                    for (size_t j = 0; j < type.size(); j++) {
                        Tensor<DType> tmp {fun[i](type[j]).get_size(), cpu_device()};
                        tmp.copy_from(fun[i](type[j]));
                        tmp.write(output);
                    }
                }
                break;
            }
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the FastGruLayer has no this parameter: %d", t);
            }
    }
}

void FastGruLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    std::vector<WType> type{W_RESET, W_UPDATE, W_STATE};

    std::vector<std::function<Tensor<DType>(WType)>> fun{
        std::bind(&FastGruLayer::get_w, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_u, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_bias, this, std::placeholders::_1)};

    std::vector<bool> has_w {true, true, _config.has_bias()};

    switch (t) {
        case WEIGHT: 
            {
                for (size_t i = 0; i < fun.size(); i++) {
                    if (!has_w[i]) {
                        continue;
                    }
                    for (size_t j = 0; j < type.size(); j++) {
                        Tensor<DType>tmp{fun[i](type[j]).get_size(), cpu_device()};
                        tmp.read(input);
                        fun[i](type[j]).copy_from(tmp);
                    }
                }
            }
            break;
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the FastGruLayer has no this parameter: %d", t);
            }
    }
}

void FastGruLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    std::vector<WType> type{W_RESET, W_UPDATE, W_STATE};

    std::vector<std::function<Tensor<DType>(WType)>> fun{
        std::bind(&FastGruLayer::get_w, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_u, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_bias, this, std::placeholders::_1)};

    std::vector<bool> has_w {true, true, _config.has_bias()};

    switch (t) {
        case WEIGHT: 
            {
                for (size_t i = 0; i < fun.size(); i++) {
                    if (!has_w[i]) {
                        continue;
                    }
                    for (size_t j = 0; j < type.size(); j++) {
                        Tensor<DType>tmp{fun[i](type[j]).get_size(), cpu_device()};
                        tmp.read_hfnn(input);
                        fun[i](type[j]).copy_from(tmp);
                    }
                }
            }
            break;
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the FastGruLayer has no this parameter: %d", t);
            }
    }
}

bool FastGruLayer::check_dw_norm(Tensor<DType> &dw, DType &norm, DType final_mean,
        DType final_stdv, const char* dw_name) {
    CHECK2(dw.is_contiguous());
    //TODO no contiguous tensor norm2
    norm = dw.norm2();
    if (_threshold > 0.0f && norm > _threshold) {
        dw.mul(_threshold / norm);
        INTER_LOG("norm_%s = %f, threshold = %f", dw_name, norm, _threshold);
    }

    if (final_mean > 0.0 && _threshold_ratio > 0.0 &&
            norm > final_mean + _threshold_ratio * final_stdv) {
        INTER_LOG("%s : norm = %f, mean = %f, stdv = %f",
                dw_name, norm, final_mean, final_stdv);
        return false;
    }
    return true;
}

void FastGruLayer::gauss_init_weight(DType mean, DType stdv) {
    std::vector<WType> type{W_RESET, W_UPDATE, W_STATE};
    std::vector<std::function<Tensor<DType>(WType)>> fun{
        std::bind(&FastGruLayer::get_w, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_u, this, std::placeholders::_1),
            std::bind(&FastGruLayer::get_bias, this, std::placeholders::_1)};

    for (size_t i = 0; i < fun.size(); i++) {
        for (size_t j = 0; j < type.size(); j++) {
            Tensor<DType>tmp{cpu_device()};
            Tensor<DType>from = fun[i](type[j]);
            tmp.resize(from.get_size());
            tmp.gauss_random(mean, stdv);
            from.copy_from(tmp);
        }
    }
}

}
}
