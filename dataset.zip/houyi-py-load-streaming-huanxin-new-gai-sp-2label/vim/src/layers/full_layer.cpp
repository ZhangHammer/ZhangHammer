/**
 * full_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-20
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "full_layer.h"

namespace houyi {
namespace train {

FullLayer::FullLayer(FullConfig& config) : Layer(config) {
    set_device();
    _config    = config;

    build_map();
}
void FullLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    Dim dim = inputs[0]->get_size();
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());
    int input = dim.product() / dim[0];

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _w.resize(Dim(input, _config.get_output_dim()), gpu_device());

    if (need_update()) {
        _dw.resize(Dim(input, _config.get_output_dim()), gpu_device());
    }

    if (_has_bias) {
        _bias.resize(Dim(1, _config.get_output_dim()), gpu_device());

        if (need_update()) {
            _d_bias.resize(Dim(1, _config.get_output_dim()), gpu_device());
        }
    }

	if (_inq) {
		_w_t.resize(Dim(input, _config.get_output_dim()), GPU);
		_w_t.w()->set_element(1);

		if (_has_bias) {
			_bias_t.resize(Dim(1, _config.get_output_dim()), GPU);  
			_bias_t.w()->set_element(1);
		}
	}

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}
void FullLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int bat_size = inputs[0]->get_size()[0];

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(bat_size, _config.get_output_dim()), inputs[i]->get_mask(), 
                          gpu_device());
    }
}

void FullLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "weight", &_w));

    if (_has_bias) {
        _w_map.insert(WeightsMap::value_type(pre + "bias", &_bias));
    }

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_dw));

        if (_has_bias) {
            _dw_map.insert(WeightsMap::value_type(pre + "bias", &_d_bias));
        }
    }
	if (_inq) {
		_w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_w_t));      
		if (_has_bias) {
			_w_map.insert(WeightsMap::value_type(pre + "bias_binary", &_bias_t)); 
		}
	}
}

FullLayer::FullLayer(FullLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) FullLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    //bn的不合理继承导致
    _w.resize(from->w()->get_size(), from->w()->get_device());
    _w.copy_from(from->w());

	if (_inq) {
        _w_t.resize_like(*from->w_t());
		_w_t.copy_from(from->w_t());
		if (_has_bias) {
            _bias_t.resize_like(*from->bias_t());
			_bias_t.copy_from(from->bias_t());
		}
	}

    if (_has_bias) {
        //bn的不合理继承导致
        _bias.resize(from->bias()->get_size(), from->bias()->get_device());
        _bias.copy_from(from->bias());
    }
}

FullLayer::~FullLayer() {

}

void FullLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Dim dim = pre_in->get_size();

    pre_in->reshape(Dim(pre_in->get_size(0), pre_in->get_element_count() / pre_in->get_size(0)));
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    out->mul(*pre_in, *_w.w(), 1.0f, 1.0f);

    // add bias
    if (_has_bias) {
        out->row_add_vec(*out, *_bias.w());
    }

    pre_in->reshape(dim);
}

void FullLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    CHECK2(local_diff);

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    Dim dim = pre_diff->get_size();

    pre_diff->reshape(Dim(pre_diff->get_size(0),
                          pre_diff->get_element_count() / pre_diff->get_size(0)));

    pre_diff->mul(*local_diff, false, *_w.w(), true, 1.0f, 1.0f);
    pre_diff->reshape(dim);
}

void FullLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    CHECK2(local_diff);
    Tensor<DType>* in = in_pack[0]->get_ten();
    Dim dim = in->get_size();

    if (need_update()) {
        in->reshape(Dim(in->get_size(0), in->get_element_count() / in->get_size(0)));
        _dw.w()->mul(*in, true, *local_diff, false, 1.0f, 1.0f);

        if (_has_bias) {
            _d_bias.w()->col_sum(*local_diff, 1.0f, 1.0f);
        }

        in->reshape(dim);
    }
}

Layer* FullLayer::clone() {
    return new FullLayer(this);
}

void FullLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        /*
        if(name() == "bbox_pred"){
            Tensor<DType>tmp{_w.w()->get_size(), cpu_device()};
            tmp.copy_from(*(_w.w()));
            for(int i = 0; i < tmp.get_element_count() / 4; i++){
                tmp.get_data()[i * 4 + 0] *= 0.1;
                tmp.get_data()[i * 4 + 1] *= 0.1;
                tmp.get_data()[i * 4 + 2] *= 0.2;
                tmp.get_data()[i * 4 + 3] *= 0.2;
            }
            _w.w()->copy_from(tmp);
        }*/
        _w.w()->write(output);
        if (_inq) {
            _w_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_weight_max.front());
            max.write(output);
        }

        if (_has_bias) {
            /*
            if(name() == "bbox_pred"){
                Tensor<DType>tmp{_bias.w()->get_size(), cpu_device()};
                tmp.copy_from(*(_bias.w()));
                for(int i = 0; i < tmp.get_element_count() / 4; i++){
                    tmp.get_data()[i * 4 + 0] *= 0.1;
                    tmp.get_data()[i * 4 + 1] *= 0.1;
                    tmp.get_data()[i * 4 + 2] *= 0.2;
                    tmp.get_data()[i * 4 + 3] *= 0.2;
                }
            }*/
            _bias.w()->write(output);
            if (_inq) {
                _bias_t.w()->write(output);
                Tensor<DType> max(Dim(1), CPU);
                max.set_element(Dim(0), _inq_bias_max.front());
                max.write(output);
            }
        }

        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }
}

void FullLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> tmp;
    tmp.set_device(cpu_device());
    Tensor<DType> t_bias;
    t_bias.set_device(cpu_device());
    //int repeace = 1;
    //size_t cpy_dim = 0;
    //size_t trans_dim_n = 0;
    size_t trans_dim_m = 0;

    switch (t) {
    case WEIGHT:
        tmp.read(input);
        //trans_dim_n = tmp.get_width();
        trans_dim_m = tmp.get_height();
        CHECK2(trans_dim_m == _w.height());

        //cpy_dim = trans_dim_n;
        //repeace = _w.width() / cpy_dim;
        //INTER_LOG("repeace: %d", repeace);
        /*
        if(name() == "bbox_pred"){
            for(int i = 0; i < tmp.get_element_count() / 4; i++){
                tmp.get_data()[i * 4 + 0] /= 0.1;
                tmp.get_data()[i * 4 + 1] /= 0.1;
                tmp.get_data()[i * 4 + 2] /= 0.2;
                tmp.get_data()[i * 4 + 3] /= 0.2;
            }
        }
        */
        if (_config.get_insert_model_col() == -1) {
            _w.w()->copy_from(tmp);
        }
        else {
            //TODO be config 
            _w.gauss_init_weight(0.0f, 0.02f);
            int len = _config.get_insert_model_len();
            //没有填长度，直接全部拷贝
            if (len == -1) {
                len = tmp.get_w() - 1;
            }
            CHECK2(_config.get_insert_model_col() + (size_t)len <= _w.w()->get_w());
            CHECK2((size_t)len <= tmp.get_w());

            _w.w()->range_col(
                    _config.get_insert_model_col(),
                    _config.get_insert_model_col() + len, 1).copy_from(
                    tmp.range_col(0, len, 1));

            _w.w()->range_col(_w.w()->get_w() - 1, 
                    _w.w()->get_w(), 1).copy_from(
                    tmp.range_col(tmp.get_w() - 1, tmp.get_w(), 1)
                    );
        }

        if (_has_bias) {
            t_bias.read(input);
            /*
            if(name() == "bbox_pred"){
                for(int i = 0; i < t_bias.get_element_count() / 4; i++){
                    t_bias.get_data()[i * 4 + 0] /= 0.1;
                    t_bias.get_data()[i * 4 + 1] /= 0.1;
                    t_bias.get_data()[i * 4 + 2] /= 0.2;
                    t_bias.get_data()[i * 4 + 3] /= 0.2;
                }
            }
            */
            if (_config.get_insert_model_col() == -1) {
                _bias.w()->copy_from(t_bias);
            }
            else {
                //TODO be config 
                int len = _config.get_insert_model_len();
                //没有填，全部拷贝
                if (len == -1) {
                    len = t_bias.get_w() - 1;
                }

                _bias.gauss_init_weight(0.0f, 0.02f);
                CHECK2(_config.get_insert_model_col() + size_t(len) <= _bias.w()->get_w());
                _bias.w()->range_col(
                        _config.get_insert_model_col(),
                        _config.get_insert_model_col() + len, 1).copy_from(
                        t_bias.range_col(0, len, 1));

                _bias.w()->range_col(
                        _bias.w()->get_w() - 1, _bias.w()->get_w(), 1).copy_from(
                        t_bias.range_col(t_bias.get_w() - 1, t_bias.get_w(), 1)
                        );
            }
        }

        //for (size_t i = 0; i < _w.height(); i++) {
        //    for (size_t j = 0; j < (size_t)repeace; j++) {
        //        _w.w()->range_row(i, i + 1).copy_from(
        //            tmp.get_row(i), cpy_dim * j, cpy_dim);
        //    }
        //}
        //if (_has_bias) {
        //    t_bias.read(input, sizeof(size_t));
        //    for (size_t j = 0; j < (size_t)repeace; j++) {
        //        _bias.w()->copy_from(
        //            t_bias.get_data(), cpy_dim * j, cpy_dim);
        //    }
        //}
        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }
}

void FullLayer::read_inq_model(std::ifstream &input, SPEECH_NN_W_TYPE t)
{
    CHECK2(_config.get_insert_model_col() != -1);
    Tensor<DType> tmp;
    tmp.set_device(CPU);
    Tensor<DType> t_bias;
    t_bias.set_device(CPU);
    size_t trans_dim_m = 0;
    
    switch (t) {
        case WEIGHT:
            tmp.read(input);
            trans_dim_m = tmp.get_height();
            CHECK2(trans_dim_m == _w.height());
            _w.w()->copy_from(tmp);

            if (_inq) {
                tmp.read(input);
                _w_t.w()->copy_from(tmp);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_weight_max.push_back(max.get_element(Dim(0)));
            }

            if (_has_bias) {
                t_bias.read(input);
                _bias.w()->copy_from(t_bias);

                if (_inq) {
                    t_bias.read(input);
                    _bias_t.w()->copy_from(t_bias);
                    Tensor<DType> max(Dim(1), CPU);
                    max.read(input);
                    _inq_bias_max.push_back(max.get_element(Dim(0)));
                }
            }
            break;

        case MD_WEIGHT:
        default:
            INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }            
}

void FullLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    Tensor<DType> tmp;
    tmp.set_device(cpu_device());
    Tensor<DType> t_bias;
    t_bias.set_device(cpu_device());
    int repeace = 1;
    size_t trans_dim_n = 0;
    size_t trans_dim_m = 0;
    size_t cpy_dim = 0;

    //
    switch (t) {
    case WEIGHT:
        tmp.read_hfnn(input, sizeof(size_t));
        trans_dim_n = tmp.get_width();
        trans_dim_m = tmp.get_height();
        CHECK2(trans_dim_m == _w.height());

        cpy_dim = trans_dim_n;
        repeace = _w.width() / cpy_dim;
        INTER_LOG("repeace: %d", repeace);

        for (size_t i = 0; i < _w.height(); i++) {
            for (size_t j = 0; j < (size_t)repeace; j++) {
                _w.w()->range_row(i, i + 1).copy_from(
                    tmp.get_row(i), cpy_dim * j, cpy_dim);
            }
        }

        if (_has_bias) {
            t_bias.read_hfnn(input, sizeof(size_t));

            for (size_t j = 0; j < (size_t)repeace; j++) {
                _bias.w()->copy_from(
                    t_bias.get_data(), cpy_dim * j, cpy_dim);
            }
        }

        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }
}

void FullLayer::read_heter_model(std::ifstream& input) {
    CHECK2(_config.get_insert_model_col() != -1);
    Tensor<DType> tmp;
    tmp.set_device(cpu_device());
    bool has_bias = true;
    tmp.read_hfnn(input, sizeof(int));
    size_t trans_dim_m = tmp.get_height();
    size_t trans_dim_n = tmp.get_width();
    INTER_LOG("read a FullLayer: height:= %lu, width:= %lu",
              trans_dim_m, trans_dim_n);
    /*if (transDimM != _w.height()) {
        CHECK2(transDimM - 1 == _w.height()
                && (transDimN - 1 == _w.width()
                        || transDimN == _w.width()));
    } else {
        hasBias = false;
    }
    size_t cpy_dim = (transDimN == _w.width()) ? transDimN : transDimN - 1;

    for (size_t i = 0; i < _w.height(); i++) {
        _w.w()->range_row(i, i + 1).copy_from(tmp.get_row(i), 0, cpy_dim);
    }
    if (hasBias) {
        _bias.w()->copy_from(tmp.get_row(transDimM - 1), 0, cpy_dim);
    }
    */
    int repeace = 1;

    if (trans_dim_m != _w.height()) {
        CHECK2((trans_dim_m - 1 == _w.height()
                && (trans_dim_n - 1 == _w.width()
                    || trans_dim_n == _w.width()))
               || _w.width() % trans_dim_n == 0);
    } else {
        has_bias = false;
    }

    //size_t cpy_dim = (transDimN == _w.width()) ? transDimN : transDimN - 1;
    size_t cpy_dim = (_w.width() % trans_dim_n == 0) ? \
                     trans_dim_n : trans_dim_n - 1;
    repeace = _w.width() / cpy_dim;
    INTER_LOG("repeace: %d", repeace);

    for (size_t i = 0; i < _w.height(); i++) {
        for (size_t j = 0; j < (size_t)repeace; j++) {
            _w.w()->range_row(i, i + 1).copy_from(
                tmp.get_row(i), cpy_dim * j, cpy_dim);
        }
    }

    if (has_bias) {
        for (size_t j = 0; j < (size_t)repeace; j++) {
            _bias.w()->copy_from(
                tmp.get_row(trans_dim_m - 1), cpy_dim * j, cpy_dim);
        }
    }
}

}
}

