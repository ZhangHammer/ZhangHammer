/**
 * linear_layer.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-30
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "linear_layer.h"
#include "image_utils.h"

namespace houyi {
namespace train {

LinearLayer::LinearLayer(LinearConfig& cfg) : Layer(cfg) {
    set_device();

    _scalars = NULL;
    int in_num = input_num();
    _scalars = (float*) malloc(sizeof(float) * in_num);
    memset(_scalars, 0, sizeof(float) * in_num);

    for (int i = 0; i < in_num; i++) {
        _scalars[i] = cfg.scalars(i);
    }

    _op = cfg.op();
    build_map();
}

LinearLayer::LinearLayer(LinearLayer* from) : Layer(from) {
    set_device();

    _scalars = NULL;
    _op = from->op();
    int in_num = input_num();
    _scalars = (float*) malloc(sizeof(float) * in_num);
    memcpy(_scalars, from->scalars(), sizeof(float) * in_num);

    layer_set(from->get_input(), from->get_sample_num());
}

void LinearLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void LinearLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    int output_maps = 0;

    switch (_op) {
    case OP_ADD:
        for (size_t i = 1; i < inputs.size(); i++) {
            CHECK(inputs[i]->get_size() == inputs[0]->get_size(), "input dim error");
        }

        output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
        break;

    case OP_CHANNEL_APPEND:
        output_maps = 0;

        for (auto d : inputs) {
            output_maps += d->get_size(1);
            CHECK(inputs[0]->get_size(2) == d->get_size(2), "input dim error");
            CHECK(inputs[0]->get_size(3) == d->get_size(3), "input dim error");
        }

        output(_output_keys[0]).resize(Dim(inputs[0]->get_size(0),
                   output_maps, inputs[0]->get_size(2),
                   inputs[0]->get_size(3)), inputs[0]->get_mask(), gpu_device());
        break;

    case OP_COL_APPEND: {
        int feat_dim = 0;
        for (auto d : inputs) {
            feat_dim += d->get_size(1);
            CHECK2(d->get_dim() == 2);
        } 
        output(_output_keys[0]).resize(Dim(inputs[0]->get_size(0),
                    feat_dim), inputs[0]->get_mask(), gpu_device());
    }
    break;
    case OP_ROW_ALTERNATE_APPEND: {
        CHECK2(inputs.size());
        size_t height = inputs[0]->get_ten()->get_height();
        size_t width = inputs[0]->get_ten()->get_width();
        CHECK2(0 == height % sample_num);
        _sample_num = sample_num;
        output(_output_keys[0]).resize(Dim(height * 2, width), gpu_device());
    }
    break;
    default:
        CHECK(false, "op type not support");
    }
}

void LinearLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    std::vector<IOPackage*> out_pack;
    switch (_op) {
    case OP_ADD:
        add(in_pack, output(_output_keys[0]).get_ten());//////
        break;

    case OP_CHANNEL_APPEND:
        channel_append(in_pack, output(_output_keys[0]).get_ten());
        break;

    case OP_COL_APPEND:
        col_append(in_pack, output(_output_keys[0]).get_ten());
        break;

    case OP_ROW_ALTERNATE_APPEND:
        out_pack.push_back(&output(_output_keys[0]));
        row_alternate_append(in_pack, out_pack);
        break;

    default:
        INTER_CHECK(false, "unknown op-type:%d", (int)_op);
    }
}

void LinearLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    zero_buf(D_WEIGHT);

    std::vector<IOPackage*> diff_vec;
    for (size_t i = 0; i < _output_keys.size(); i++) {
        IOPackage *io = &diff(_output_keys[i]);
        diff_vec.push_back(io);
    }
    switch (_op) {
    case OP_ADD:
        add_derivative(diff_vec, out_pack);//////
        break;

    case OP_CHANNEL_APPEND:
        channel_append_derivative(diff_vec, out_pack);
        break;

    case OP_COL_APPEND:
        col_append_derivative(diff_vec, out_pack);
        break;

    case OP_ROW_ALTERNATE_APPEND:
        row_alternate_append_derivative(diff_vec, out_pack);
        break;

    default:
        INTER_CHECK(false, "unknown op-type:%d", (int)_op);
    }
}

void LinearLayer::add(std::vector<IOPackage*>& src, Tensor<DType>* dst) {
    CHECK2(dst && src.size());

    if (src.size() == 2){                                                                    
        dst->elem_add(*(src[0]->get_ten()), *(src[1]->get_ten()), _scalars[0], _scalars[1]);
    }                                                                                       
    else {                                                                                   
        for (size_t i = 0; i < src.size(); i++) {                                           
            dst->elem_add(*dst, *(src[i]->get_ten()), 1.0f, _scalars[i]);                   
        }
    }
}

void LinearLayer::add_derivative(std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst) {
    CHECK2(src.size() && dst.size());

    for (size_t i = 0; i < dst.size(); i++) {
        if (_bp_down[i]) {
            dst[i]->get_ten()->elem_add(
                    *dst[i]->get_ten(), *(src[0]->get_ten()), 1.0f, _scalars[i]);
        }
    }
}

void LinearLayer::channel_append(std::vector<IOPackage*>& src, Tensor<DType>* dst) {
    CHECK2(dst && src.size());

    std::vector<Tensor<DType>*> src_ten;
    for (auto i : src) {
        src_ten.push_back(i->get_ten());
    }
    dst->channel_append(src_ten, _address, 1.0f, 0.0f);
}

void LinearLayer::channel_append_derivative(std::vector<IOPackage*>& src, 
            std::vector<IOPackage*>& dst) {
    std::vector<bool> filters;

    for (auto i : _bp_down) {
        filters.push_back((bool)i);
    }

    std::vector<Tensor<DType>*> dst_ten;
    for (auto i : dst) {
        dst_ten.push_back(i->get_ten());
    }

    src[0]->get_ten()->channel_append_bp(dst_ten, filters, _address);
}

void LinearLayer::col_append(std::vector<IOPackage*>& src, Tensor<DType>* dst) {
    CHECK2(dst && src.size());
    size_t cnt = src.size();

    if (cnt == 1) {
        dst->copy_from(*(src[0]->get_ten()));
    } else {
        size_t start = 0;
        for (size_t i = 0; i < cnt; i++) {
            Tensor<DType> sub_dst = dst->range_col(start, start + src[i]->get_ten()->get_width(), 1);
            sub_dst.copy_from(*(src[i]->get_ten()));
            start += src[i]->get_ten()->get_width();
        }
    }
}

template <typename T>  
void LinearLayer::alternate_merge_tensor(Tensor<T>&dst, Tensor<T>&src1, Tensor<T>&src2) {
    bool reshape = 0;
    if (dst.get_size().get_axis() == 1) {
        dst.reshape(Dim(dst.get_size(0), 1));
        src1.reshape(Dim(src1.get_size(0), 1));
        src2.reshape(Dim(src2.get_size(0), 1));
        reshape = true;
    }

    dst.resize(Dim(src1.get_size(0) * 2, src1.get_size(1)), false);
    Dim src1_ori_dim = src1.get_size();
    Dim src2_ori_dim = src2.get_size();
    Dim dst_ori_dim = dst.get_size();

    Dim src1_dst_dim = Dim(src1_ori_dim.get_size(0) / _sample_num, src1.get_size(1) * _sample_num );
    Dim src2_dst_dim = Dim(src2_ori_dim.get_size(0) / _sample_num, src2.get_size(1) * _sample_num );
    Dim dst_dst_dim = Dim(dst_ori_dim.get_size(0) / _sample_num, dst_ori_dim.get_size(1) * _sample_num);

    src1.reshape(src1_dst_dim);
    src2.reshape(src2_dst_dim);
    dst.reshape(dst_dst_dim);

    size_t height = src1.get_height();
    size_t width = src1.get_width();
    dst.reshape(Dim(height, width * 2));
    dst.get_block(Dim(0, 0), Dim(height, width)).copy_from(src1);
    dst.get_block(Dim(0, width), Dim(height, width * 2)).copy_from(src2);
    
    dst.reshape(dst_ori_dim);
    src1.reshape(src1_ori_dim);
    src2.reshape(src2_ori_dim);

    if (reshape) {
        dst.reshape(Dim(dst.get_size(0)));
        src1.reshape(Dim(src1.get_size(0)));
        src2.reshape(Dim(src2.get_size(0)));
    }
}

template <typename T>  
void LinearLayer::alternate_split_tensor(Tensor<T>&src, Tensor<T>&dst1, Tensor<T>&dst2) {
    CHECK2(dst1.get_size() == dst2.get_size());
    bool reshape = false;
    if (src.get_size().get_axis() == 1) {
        src.reshape(Dim(src.get_size(0), 1));
        dst1.reshape(Dim(dst1.get_size(0), 1));
        dst2.reshape(Dim(dst2.get_size(0), 1));
        reshape = true;
    }

    dst1.resize(Dim(src.get_size(0) / 2, src.get_size(1)), false);
    dst2.resize(Dim(src.get_size(0) / 2, src.get_size(1)), false);

    Dim dst1_ori_dim = dst1.get_size();
    Dim dst2_ori_dim = dst2.get_size();
    Dim src_ori_dim = src.get_size();

    Dim dst1_dst_dim = Dim(dst1_ori_dim.get_size(0) / _sample_num, dst1_ori_dim.get_size(1) * _sample_num);
    Dim dst2_dst_dim = Dim(dst2_ori_dim.get_size(0) / _sample_num, dst2_ori_dim.get_size(1) * _sample_num);
    Dim src_dst_dim = Dim(src_ori_dim.get_size(0) / _sample_num, src_ori_dim.get_size(1) * _sample_num);

    dst1.reshape(dst1_dst_dim);
    dst2.reshape(dst2_dst_dim);
    src.reshape(src_dst_dim);

    size_t height = src.get_height() / 2;
    size_t width = src.get_width();
    src.reshape(Dim(height, width * 2));

    dst1.copy_from(src.get_block(Dim(0, 0), Dim(height, width)));
    dst2.copy_from(src.get_block(Dim(0, width), Dim(height, 2 * width)));

    src.reshape(src_ori_dim);
    dst1.reshape(dst1_ori_dim);
    dst2.reshape(dst2_ori_dim);

    if (reshape) {
        src.reshape(Dim(src.get_size(0)));
        dst1.reshape(Dim(dst1.get_size(0)));
        dst2.reshape(Dim(dst2.get_size(0)));
    }
}

void LinearLayer::row_alternate_append(std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst) {
    CHECK2(dst.size() == 1);
    CHECK2(src.size() == 2);

    CHECK2(src[0]->get_ten()->get_size() == src[1]->get_ten()->get_size());

    alternate_merge_tensor<DType>(*dst[0]->get_ten(), *src[0]->get_ten(), *src[1]->get_ten());
    alternate_merge_tensor<int>(*dst[0]->get_mask(), *src[0]->get_mask(), *src[1]->get_mask());
}

void LinearLayer::row_alternate_append_derivative(
    std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst) {
    CHECK2(src.size() == 1);
    CHECK2(dst.size() == 2);

    alternate_split_tensor<DType>(*src[0]->get_ten(), *dst[0]->get_ten(), *dst[1]->get_ten());  
    alternate_split_tensor<int>(*src[0]->get_mask(), *dst[0]->get_mask(), *dst[1]->get_mask());
}

void LinearLayer::col_append_derivative(
    std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst) {

    CHECK2(dst.size() && src.size());

    size_t start = 0;
    for (size_t i = 0; i < dst.size(); i++) {
        if (dst[i] == NULL) {
            continue;
        }
        Tensor<DType> sub_src = src[0]->get_ten()->range_col(start, start + dst[i]->get_ten()->get_width(), 1);
        dst[i]->get_ten()->copy_from(sub_src);
        start += dst[i]->get_ten()->get_width();
    }
}


}
}

