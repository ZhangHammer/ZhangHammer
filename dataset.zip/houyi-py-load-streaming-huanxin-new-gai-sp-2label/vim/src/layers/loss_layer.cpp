/**
 * loss_layer.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include <vector>
#include <new>
#include "wind/wind.h"
#include "layer_config.h"
#include "loss_layer.h"
#include "image_utils.h"
#include "user_ops.h"
#include "mix_lr_op.h"

namespace houyi {
namespace train {

void LossLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() + _label_key.size() + _feat_desc_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void LossLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    Dim dim = inputs[0]->get_size();
    Dim out_dim;

    _sample_num = sample_num;

    switch (_type) {
    case LOSS_SMOOTH_L1:
    case LOSS_SMOOTH_OHEM_L1: {
        for (auto it : inputs) {
            CHECK(it->get_size() == inputs[0]->get_size(),
                  "smooth l1 loss input dim must be same");
        }

        if (dim.get_size() == 2) {
            out_dim = Dim(dim[0], 1);
        } else if (dim.get_size() == 4) {
            out_dim = Dim(dim[0], 1, dim[2], dim[3]);
        } else {
            CHECK(false, "error");
        }

        break;
    }
    case LOSS_MIX_LR: {
        CHECK2(inputs.size());
        CHECK2(dim.get_size() == 2);
        out_dim = dim;
        
        break;
    } 

    default:
        out_dim = Dim(dim[0], 1);
    }

    output(_output_keys[0]).resize(out_dim, inputs[0]->get_mask(), gpu_device());
}

void LossLayer::forward(Argument& args) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif

    std::vector<IOPackage*> inputs;
    for (std::string key : _input_keys) {
        inputs.push_back(args.get_pack(key));
    }

    /* todo remove */
    zero_out_pack();

    //中英文多头训练时，label没有ready，直接返回
    std::vector<IOPackage*> label_vec;
    for (size_t i = 0; i < _label_key.size(); i++) {
        IOPackage* io = args.get_pack(_label_key[i]);
        if (io == NULL && _feature_share_input) {
            return; 
        }                        
        label_vec.push_back(io);
    }

    std::vector<IOPackage*> in_vec;
    for (size_t i = 0; i < _input_keys.size(); i++) {
        in_vec.push_back(args.get_pack(_input_keys[i]));
#ifdef __TRAIN_OUTPUT_RESULT__

        //判断文件夹是否存在，不存在则创建
        if (access("layer_result_out", 0) == -1) {
            mkdir("layer_result_out", S_IRWXU);
        }

        char name[128];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_input_%d",
                device, batch_cnt, _name.c_str(), (int)i);
        write_tensor(*in_vec[i]->get_ten(), name);
#endif
    }
    
    //TODO by zhxfl, insert into iopackage
    if (_type == LOSS_CTC) {
        _batch_file_name = args.get_feat_desc()->get_default_file_name();
    }

    std::vector<IOPackage*> out_vec;
    for (size_t i = 0; i < _output_keys.size(); i++) {
        out_vec.push_back(&output()[i]);
    }
    _in_vec = in_vec;
    _label_vec = label_vec;
    _out_vec = out_vec;

    cal_target(in_vec, label_vec, out_vec);

#ifdef __TRAIN_OUTPUT_RESULT__
    char name_output[128];
    sprintf(name_output, "./layer_result_out/device_%d_batch_%d_%s_output",
            device, batch_cnt, _name.c_str());
    write_tensor(*(out_vec[0]->get_ten()), name_output);
#endif

}

bool LossLayer::backward(Argument& in_arg, Argument& diff_arg) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {
        batch_cnt = (int)g_batch_cnt;
    } else {
        batch_cnt = (int)g_thread_batch_cnt[device];
    }
#endif
    bool bp_flag = std::find(_bp_down.begin(), _bp_down.end(), true) != _bp_down.end();
    //INTER_LOG("Layer: %s backward %d %d", _name.c_str(), bp_flag, _enable_bp);
    if (bp_flag && _enable_bp == true) {

        std::vector<IOPackage*> label_vec;
        for (size_t i = 0; i < _label_key.size(); i++) {
            IOPackage* io = in_arg.get_pack(_label_key[i]);
            label_vec.push_back(io);
        }

#ifdef __TRAIN_OUTPUT_RESULT__
        //print label
        char name_label[1024];

        for (size_t i = 0; i < _label_key.size(); i++) {
            sprintf(name_label, "./layer_result_out/device_%d_batch_%d_%s_label_%d",
                    device, batch_cnt,  _name.c_str(), (int)i);
            write_tensor(*(label_vec[i]->get_ten()), name_label, _layer_result_output_num);
        }

#endif

        std::vector<IOPackage*> in_vec;
        std::vector<IOPackage*> pre_diff_vec;

        for (size_t i = 0; i < _input_keys.size(); i++) {
            in_vec.push_back(in_arg.get_pack(_input_keys[i]));
            pre_diff_vec.push_back(diff_arg.get_pack(_input_keys[i]));
        }

        for (auto it : _input_keys) {                 
            IOPackage* in = in_arg.get_pack(it);           

            if (in_arg.is_feat_key(it) == false) {         
                IOPackage* pre_diff = diff_arg.get_pack(it);
                pre_diff->resize(in->get_size(), in->get_device());
            }                                                      
        }                                                          

        cal_loss(in_vec, label_vec, pre_diff_vec);
#ifdef __TRAIN_OUTPUT_RESULT__
        //per_diff
        char name_pre_diff[1024];

        for (size_t i = 0; i < _input_keys.size(); i++) {
            if (pre_diff_vec[i]->get_ten()) {
                sprintf(name_pre_diff, "./layer_result_out/device_%d_batch_%d_%s_pre_diff_%d",
                        device, batch_cnt, _name.c_str(), (int)i);
                write_tensor(*(pre_diff_vec[i]->get_ten()), name_pre_diff, _layer_result_output_num);
            }
        }
#endif
    }
    return true;
}

size_t LossLayer::get_real_sample_num(Tensor<DType>& label, Tensor<int>& mask, DType ignore_label) {
    size_t count = 0;
    count = mask.sum();
    //TODO ignore_label ???
    //label.count_valid_label(mask, ignore_label, &count);
    return count;
}

DType LossLayer::get_normalizer(LossNormMode norm_mode, Tensor<DType>& input,
                                DType real_sample_count, DType pre_fixed_normalizer) {
    DType normalizer = 1.0f;

    switch (norm_mode) {
    case LOSS_NORM_FULL:
        normalizer = DType(input.get_element_count());
        break;

    case LOSS_NORM_VALID:
        normalizer = DType(real_sample_count);
        break;

    case LOSS_NORM_BATCH_SIZE:
        normalizer = DType(_sample_num);
        break;

    case LOSS_NORM_PRE_FIXED:
        normalizer = pre_fixed_normalizer;
        break;

    case LOSS_NORM_UNKNOWN:
        normalizer = DType(1.0);
        break;

    default:
        CHECK(false, "norm mode error");
    }

    return std::max(DType(1.0), normalizer);
}

void CrossEntryLossLayer::cal_target(std::vector<IOPackage*>& output,
                                     std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {
    CHECK2(output[0] && label[0] && target[0]);
    Dim in_dim = output[0]->get_ten()->get_size();
    Tensor<int>& label_mask = *label[0]->get_mask();

    int start_real_axis = in_dim.canonical_axis_index(_start_axis);
    int end_real_axis = in_dim.canonical_axis_index(_end_axis);
    _outer = output[0]->get_ten()->count(0, start_real_axis);
    _channel = output[0]->get_ten()->count(start_real_axis, end_real_axis + 1);
    _inner = output[0]->get_ten()->count(end_real_axis + 1);
    _real_sample_count = get_real_sample_num(*label[0]->get_ten(), label_mask,
                _cfg.get_ignore_label());
    _cur_norm = get_normalizer(_cfg.get_norm_mode(), *output[0]->get_ten(),
            _real_sample_count, _cfg.get_pre_fixed());

    switch (_cost_type) {
    case TGT_ACU:
    case TGT_ERR: {
        target[0]->get_ten()->cross_entropy(*output[0]->get_ten(), *label[0]->get_ten(),
                    *label[0]->get_mask(), _outer, _channel, _inner);

        break;
    }

    case CLASSIFY_ACU:
    case CLASSIFY_ERR: {
        CHECK(output[0]->get_ten()->get_dim() == 2, "only dim == 2 is supported") ;
        _row_max_idx.resize(Dim(label[0]->get_size(1), label[0]->get_size(0)));
        size_t right_sample = 0u;
        target[0]->get_ten()->cal_classify_acu_target(
                *output[0]->get_ten(),
                *label[0]->get_ten(),
                label_mask,
                _row_max_idx,
                _cfg.get_ignore_label(),
                &right_sample);
        _right_sample = static_cast<int>(right_sample);
        break;
    }

    default:
        CHECK(false, "tgt-type:%d, not support", (int)_cost_type);
    }
}

void CrossEntryLossLayer::cal_loss(std::vector<IOPackage*>& output,
                                   std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);

    if (_bp_down[0]) {
#ifdef __GRADIENT_NORM__
        loss[0]->get_ten()->cross_entropy_bp(*output[0]->get_ten(), *label[0]->get_ten(),
                *label[0]->get_mask(), _outer, _channel, _inner,
                _cfg.get_loss_weight() / _cur_norm, 1.0f);
#else
        loss[0]->get_ten()->cross_entropy_bp(*output[0]->get_ten(), *label[0]->get_ten(),
                *label[0]->get_mask(), _outer, _channel, _inner,
                _cfg.get_loss_weight(), 1.0f);
#endif
    }
}

Loss& CrossEntryLossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;

    /* 统计loss的时候会自动除去batch size, 所以这里要乘batch size */
    switch (type) {
    case TGT_ACU: {
        cost = output(_output_keys[0]).get_ten()->sum();
        break;
    }

    case TGT_ERR:
        _cost_buf.resize(output(_output_keys[0]).get_size());
        _cost_buf.copy_from(*output(_output_keys[0]).get_ten());
        _cost_buf.log();
        _cost_buf.mul(-1.0f);
        cost = _cost_buf.sum();
        break;

    case CLASSIFY_ACU:
        cost = _right_sample;
        break;

    case CLASSIFY_ERR:
        cost = _real_sample_count - _right_sample;
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    _loss->set_frame_counter(_real_sample_count);
    _loss->set_sample_counter(_sample_num);
    return *_loss;
}

void MSELossLayer::cal_target(std::vector<IOPackage*>& output,
                              std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {
    CHECK2(output[0] && label[0] && target[0]);
    //size_t h = output[0]->get_height();
    //target[0]->resize(Dim(h, 1), gpu_device());
    //_real_sample_count = get_real_sample_num(*label[0]->get_ten(), *label[0]->get_mask(),
    //            _cfg.get_ignore_label());
    _real_sample_count = label[0]->get_mask()->sum();

    target[0]->get_ten()->mean_squre_error(*output[0]->get_ten(),
            *label[0]->get_ten(), *label[0]->get_mask());
}

void MSELossLayer::cal_loss(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);

    if (_bp_down[0]) {
#ifdef __GRADIENT_NORM__
        loss[0]->get_ten()->mean_squre_error_bp(*output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight() / _real_sample_count, 1.0f);
#else
        loss[0]->get_ten()->mean_squre_error_bp(*output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight(), 1.0f);
#endif
    }
}

Loss& MSELossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;

    switch (type) {
    case TGT_ACU:
    case TGT_ERR:
        cost = output(_output_keys[0]).get_ten()->sum();
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    _loss->set_frame_counter(_real_sample_count);
    _loss->set_sample_counter(_sample_num);
    return *_loss;
}

void LRLossLayer::cal_target(std::vector<IOPackage*>& output,
                                     std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {
    CHECK2(output[0] && label[0] && target[0]);
    _real_sample_count = get_real_sample_num(*label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_ignore_label());
    wind_lr_loss_op(*target[0]->get_ten(), *output[0]->get_ten(),
            *label[0]->get_ten(), *label[0]->get_mask());
}

void LRLossLayer::cal_loss(std::vector<IOPackage*>& output,
                                   std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);

    if (_bp_down[0]) {
#ifdef __GRADIENT_NORM__
        wind_lr_bp_op(*loss[0]->get_ten(), *output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight() / sample_num, 1.0f);
#else
        wind_lr_bp_op(*loss[0]->get_ten(), *output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight(), 1.0f);
#endif
    }
}

Loss& LRLossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;

    switch (type) {
    case TGT_ACU:
    case TGT_ERR:
        cost = output(_output_keys[0]).get_ten()->sum();
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    _loss->set_frame_counter(_real_sample_count);
    _loss->set_sample_counter(_sample_num);
    return *_loss;
}

void MixLRLossLayer::cal_target(std::vector<IOPackage*>& output,
                                     std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {
    CHECK2(output[0] && label[0] && target[0]);
    _real_sample_count = get_real_sample_num(*label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_ignore_label());
    wind_mix_lr_loss_op(*target[0]->get_ten(), *output[0]->get_ten(),
            *label[0]->get_ten(), *label[0]->get_mask());
    // INTER_LOG("target");
}

void MixLRLossLayer::cal_loss(std::vector<IOPackage*>& output,
                                   std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);

    if (_bp_down[0]) {
#ifdef __GRADIENT_NORM__
        wind_mix_lr_bp_op(*loss[0]->get_ten(), *output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight() / sample_num, 1.0f);
#else
        wind_mix_lr_bp_op(*loss[0]->get_ten(), *output[0]->get_ten(),
                *label[0]->get_ten(), *label[0]->get_mask(),
                _cfg.get_loss_weight(), 1.0f);
#endif
    }
}

Loss& MixLRLossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = output(_output_keys[0]).get_ten()->sum();
    // loss
    _loss->set_loss(cost);
    _count1.resize(_in_vec[0]->get_ten()->get_size());
    _count2.resize(_in_vec[0]->get_ten()->get_size());
    _value1.resize(_in_vec[0]->get_ten()->get_size());
    _value2.resize(_in_vec[0]->get_ten()->get_size());
    _value3.resize(_in_vec[0]->get_ten()->get_size());
    _value4.resize(_in_vec[0]->get_ten()->get_size());

    MixLrLoss* mix_lr_loss = static_cast<MixLrLoss*>(_loss);
    mix_lr_loss->set_frame_counter(_real_sample_count * output(_output_keys[0]).get_ten()->get_size(1));
    mix_lr_loss->set_sample_counter(_sample_num * output(_output_keys[0]).get_ten()->get_size(1));

    wind_mix_lr_one_sigmoid_loss(
            *_in_vec[0]->get_ten(), 
            *_label_vec[0]->get_ten(),
            *_label_vec[0]->get_mask(),
            _value1,
            _value2,
            _value3,
            _value4,
            _count1,
            _count2);

    int one_count = _count1.sum();
    int zero_count = _count2.sum();

    mix_lr_loss->get_loss_vec()[0] = _value1.sum();
    mix_lr_loss->get_loss_vec()[1] = _value2.sum();
    mix_lr_loss->get_loss_vec()[2] = _value3.sum();
    mix_lr_loss->get_loss_vec()[3] = _value4.sum();
    mix_lr_loss->get_loss_vec()[4] = one_count;
    mix_lr_loss->get_loss_vec()[5] = one_count;
    mix_lr_loss->get_loss_vec()[6] = zero_count;
    mix_lr_loss->get_loss_vec()[7] = zero_count;

    return *_loss;
}

} //namespace train
}
