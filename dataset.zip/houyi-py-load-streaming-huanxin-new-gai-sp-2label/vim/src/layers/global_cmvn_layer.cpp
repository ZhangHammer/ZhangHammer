/**
 * GlobalCmvnLayer.cpp
 * Author: zhuweixin (zhuweixin@baidu.com)
 * Created on: 2018-06-10
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 */

#include "global_cmvn_layer.h"

namespace houyi {
namespace train {

GlobalCmvnLayer::GlobalCmvnLayer(GlobalCmvnConfig& config)
    : Layer(config) {
    set_device();
    _config = config;

    if (config.mean_var_file().size() != 0) {
        _global_mean_var = (char*)(config.mean_var_file().c_str());
    } else {
        _global_mean_var = NULL;
    }
}

void GlobalCmvnLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);
    printf("in global_mean_var %s\n", _global_mean_var);
    if (_global_mean_var != NULL) {
        read_initial_mean_var();
    }

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}


void GlobalCmvnLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int height = inputs[0]->get_size()[0];
    int width = inputs[0]->get_size()[1];
    _sample_num = sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(height, width),  inputs[i]->get_mask(),
                          gpu_device());
    }
}


GlobalCmvnLayer::GlobalCmvnLayer(GlobalCmvnLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) GlobalCmvnLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void GlobalCmvnLayer::read_initial_mean_var() {

    std::ifstream fin(_global_mean_var);
    INTER_CHECK(!fin.fail(), "Open file error %s", _global_mean_var);
    char str[4096];
    float m = 0.0f;
    float v = 0.0f;
    std::vector<DType> mean;
    std::vector<DType> std_inv_var;

    while (fin.getline(str, 4096)) {
        sscanf (str, "%f %f", &m, &v);
        mean.push_back(m);
        std_inv_var.push_back(v);
        std::cout<<m<<" "<<v<<std::endl;
    }

    for (size_t i = 0; i < mean.size(); ++i) {
        std_inv_var[i] = 1.0f / sqrt(std_inv_var[i]);
        if (std_inv_var[i] > 100000.0f) {
            std_inv_var[i] = 100000.0f;
        }
    }

    _cpu_mean.resize(Dim(mean.size()));
    _cpu_std_inv_var.resize(Dim(std_inv_var.size()));

    _mean.resize(Dim(mean.size()));
    _std_inv_var.resize(Dim(std_inv_var.size()));

    for (size_t i = 0; i < (size_t)mean.size(); i++) {
        _cpu_mean.set_element(Dim(i), mean[i]);
        _cpu_std_inv_var.set_element(Dim(i), std_inv_var[i]);
    }

    _mean.copy_from(_cpu_mean);
    _std_inv_var.copy_from(_cpu_std_inv_var);


}

void GlobalCmvnLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    wind_global_cmvn(*pre_in, *out, *output(_output_keys[0]).get_mask(),
                     _mean,
                     _std_inv_var,
                     _sample_num);
}

void GlobalCmvnLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    if (out_pack.size() == 0 || out_pack[0] == NULL) return;
    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    pre_diff->zero();

}

void GlobalCmvnLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
}

Layer* GlobalCmvnLayer::clone() {
    return new GlobalCmvnLayer(this);
    //return new GlobalCmvnLayer(this);
}
void GlobalCmvnLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
}

void GlobalCmvnLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
}


} //namespace houyi
} //namespace train
