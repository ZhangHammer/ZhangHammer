/**
 * file: loss_norm_mode.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2017年05月19日 10时58分44秒
 *
 * copyright: Copyright (c) 2017, baidu.com, Inc. All Rights Reserved
 *
 */
#include "loss_norm_mode.h"
namespace houyi {
namespace train {

const char* LossNormModeName[] = {
    "full",
    "valid",
    "batchSize",
    "preFixed",
    "unknown"
};

}   /* namespace of houyi */
}   /* namespace of train */

