/**
 * norm2_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-26
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "norm2_layer.h"

namespace houyi {
namespace train {

Norm2Layer::Norm2Layer(Norm2Config& config) : Layer(config) {
    set_device();
    _config    = config;
}

Norm2Layer::Norm2Layer(Norm2Layer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) Norm2Layer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void Norm2Layer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void Norm2Layer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();

    if (input_size.get_size() == 2) {
        output(_output_keys[0]).resize(Dim(input_size[0], 1, 1,
                                           input_size[1]), inputs[0]->get_mask(), gpu_device());
    } else if (input_size.get_size() == 4) {
        output(_output_keys[0]).resize(input_size, inputs[0]->get_mask(), gpu_device());
    } else {
        CHECK(false, "Norm2Layer input should be 2D|4D vs dim %d", input_size.get_size());
    }
}

void Norm2Layer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Dim dim = pre_in->get_size();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    CHECK(pre_in->get_element_count() % pre_in->get_size(0) == 0, "param error");
    pre_in->reshape(Dim(pre_in->get_size(0), pre_in->get_element_count() / pre_in->get_size(0)));
    out->reshape(Dim(pre_in->get_size(0), pre_in->get_element_count() / pre_in->get_size(0)));

    _in_buf.resize(pre_in->get_size());
    _in_buf.square(*pre_in);

    //norm2倒数
    _norm2.resize(Dim(1, _in_buf.get_h()));
    _norm2.row_sum(_in_buf);
    _norm2.sqrt();
    _norm2.reciprocal();

    out->col_mul_vec(*pre_in, _norm2, 1.0f, 1.0f);

    pre_in->reshape(dim);
    out->reshape(dim);
}

void Norm2Layer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    Dim dim = pre_diff->get_size();
    pre_diff->reshape(Dim(pre_diff->get_size(0),
                          pre_diff->get_element_count() / pre_diff->get_size(0)));
    local_diff->reshape(Dim(pre_diff->get_size(0),
                            pre_diff->get_element_count() / pre_diff->get_size(0)));
    out->reshape(Dim(pre_diff->get_size(0), pre_diff->get_element_count() / pre_diff->get_size(0)));

    _diff_buf.resize(pre_diff->get_size());
    _diff_buf.elem_mul(*local_diff, *out, 1.0f, 0.0f);
    _vec_buf.resize(Dim(1, _diff_buf.get_h()));
    _vec_buf.row_sum(_diff_buf);

    _diff_buf.col_mul_vec(*out, _vec_buf, -1.0f, 0.0f);
    _diff_buf.elem_add(*local_diff, _diff_buf, 1.0f, 1.0f);

    //div norm2
    pre_diff->col_mul_vec(_diff_buf, _norm2, 1.0f, 1.0f);

    pre_diff->reshape(dim);
    local_diff->reshape(dim);
    out->reshape(dim);
}

Layer* Norm2Layer::clone() {
    return new Norm2Layer(this);
}

}
}

