/**
 * layer.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-12-17
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <math.h>   
#include "wind/wind.h"
#include "user_ops.h"
#include "layer.h"
#include "roi_pool_layer.h"
#include "ps_roi_pool_layer.h"
#include "image_utils.h"
#include "bat_norm_layer.h"
#include "bat_renorm_layer.h"
#include "skip_layer.h"
#include "fast_lstm.h"
#include "box_annotator_ohem_layer.h"

namespace houyi {
namespace train {

/* from big to little */ 
bool big_sort_fun(const std::pair<int, DType> &i, const std::pair<int, DType> &j) 
{return (i.second > j.second);}
/* from little to big*/
bool little_sort_fun(const std::pair<int, DType> &i, const std::pair<int, DType> &j) 
{return (i.second < j.second);}

#ifdef __TRAIN_OUTPUT_RESULT__
int g_batch_cnt = -1;
int g_thread_batch_cnt[8] = { -1, -1, -1, -1, -1, -1, -1, -1};
#endif
int data_make_count = 0;

Layer::Layer(LayerConfig& cfg) {
    init();
    set_device();
    _id   = cfg.layer_id();
    _name = cfg.layer_name();
    _job_type = cfg.job_type();
    _global_job_type = cfg.global_job_type();
    _label_key = cfg.get_label_key();
    _feat_desc_keys = cfg.get_feat_desc_keys();

    //inputs
    _input_keys.clear();
    _input_keys = cfg.input_keys();

#if 0
    for (size_t i = 0; i < _input_keys.size(); i++) {
        INTER_LOG("id: %d\tname: %s\tinputs: %s", _id, _name.c_str(), _input_keys[i].c_str());
    }
#endif

    //outputs
    _output_keys.clear();
    _output_keys = cfg.output_keys();

#if 0
    for (size_t i = 0; i < _output_keys.size(); i++) {
        INTER_LOG ("id: %d\tname: %s\toutputs: %s", _id, _name.c_str(), _output_keys[i].c_str());
    }
#endif

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output.push_back(std::move(IOPackage()));
        _diff.push_back(std::move(IOPackage()));
    }

    _type = cfg.type();
    _act_type = cfg.act();
    _act = Activation::create(cfg.act());

    _updater = BaseUpdater::create(cfg.up_cfg(), cfg.get_global_up_cfg());

    _has_bias = cfg.has_bias();
    _need_update = cfg.need_update();

    if (_need_update) {
        _need_update = (_updater->learn_rate() < 0.0f) ? false : true;
    }

    _read        = cfg.read();

    _sample_num = cfg.get_batch_size();
    _is_reversal  = cfg.is_reversal();
    _nxt_start    = 0;
    _weight_flag  = true;

    _init_mean = cfg.get_model_init_cfg().init_mean();
    _init_stdv = cfg.get_model_init_cfg().init_stdv();

    _layer_result_output_num = cfg.layer_result_output_num();
    _bp_down = cfg.get_bp_down();

    _model_init_cfg = cfg.get_model_init_cfg();

    _inq = cfg.get_inq();            
    _inq_ratio = cfg.get_inq_ratio();
    _inq_bit = cfg.get_inq_bit();    

    _feature_share_input = cfg.get_feature_share_input();

    _intl_quant_bits = cfg.intl_quant_bits();
    _intl_quant_algo = cfg.intl_quant_algo();
}

Layer::Layer(Layer* from) {
    _input_keys.clear();
    _id   = from->id();
    _name = from->name();
    _input_keys = from->input_keys();
    _output_keys = from->output_keys();

    _output.resize(_output_keys.size());
    _diff.resize(_output_keys.size());

    _type = from->type();
    _act_type = from->act_type();
    _act = Activation::create(_act_type);
    _has_bias = from->has_bias();
    _label_key = from->get_label_key();

    _read = from->need_read();

    _sample_num = from->get_sample_num();
    _is_reversal  = from->is_reversal();
    _nxt_start = from->nxt_start();
    _weight_flag  = from->weight_flag();

    _updater = from->updater()->clone();
    _need_update = (_updater->learn_rate() < 0.0f) ? false : true;

    _layer_result_output_num = from->layer_result_output_num();
    _bp_down = from->get_bp_down();

    _model_init_cfg = from->model_init_cfg();

    _feature_share_input = from->get_feature_share_input();
}

void Layer::update() {
    if (need_update()) {
        _updater->collect(_dw_map, _w_map, 1);
        _updater->update(_w_map);
    }
}

void Layer::update(WeightsMap& w_map, WindStream cp_in_stream) {
    if (need_update()) {
        copy_weight_map(_w_map, w_map, cp_in_stream);
    }
}

void Layer::copy_out_async(
    WeightsMap& w_map, SPEECH_NN_W_TYPE t, WindStream cp_out_stream) {
    if (need_update()) {
        if (w_map.size() == 0) {
            init_weight_map(w_map, _w_map, cpu_pinned_device());
        }

        switch (t) {
        case WEIGHT:
            copy_weight_map(w_map, _w_map, cp_out_stream);
            break;

        case D_WEIGHT:
            copy_weight_map(w_map, _dw_map, cp_out_stream);
            break;

        case MD_WEIGHT:
        default:
            CHECK2(false);
        }

    }
}

void Layer::init_grad(WeightsMap& grad_map) {
    if (need_update()) {
        init_weight_map(grad_map, _dw_map, gpu_device());
    }
}

void Layer::accum_grad(WeightsMap& dw_vec, DType alpha, DType beta) {
    if (need_update()) {
        if (dw_vec.size() == 0) {
            init_grad(dw_vec);
        }

        _updater->accum_to(dw_vec, alpha, beta);
    }
}

void Layer::clean_delta_w() {
    if (need_update()) {
        zero_weight_map(_dw_map);
    }
}

void Layer::copy_in(
    WeightsMap& w_map, SPEECH_NN_W_TYPE t) {
    if (w_map.size() == 0) {
        //INTER_LOG("bufVec.size is 0, copy_in will do nothing");
        return;
    }

    switch (t) {
    case WEIGHT:
        copy_weight_map(_w_map, w_map);
        break;

    case D_WEIGHT:
        if (need_update()) {
            copy_weight_map(_dw_map, w_map);
        }

        break;

    case MD_WEIGHT:
        if (need_update()) {
            _updater->copy_from(w_map);
        }

        break;

    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }
}

int Layer::copy_out(
    WeightsMap& w_map, SPEECH_NN_W_TYPE t) {
    //if (_need_update == false && fabs(_updater->learn_rate() - 0.0f) < 0.00000001f) {
    //    INTER_LOG("_need_update is false, copy_out will do nothing");
    //    return 0;
    //}
    //if (bufVec.size() == 0 && (t == WEIGHT || _need_update)) {
    if (w_map.size() == 0 && (t == WEIGHT || _need_update)) {
        init_weight_map(w_map, _w_map, cpu_pinned_device());
    }

    switch (t) {
    case WEIGHT:
        copy_weight_map(w_map, _w_map);
        break;

    case D_WEIGHT:
        if (need_update()) {
            copy_weight_map(w_map, _dw_map);
        }

        break;

    case MD_WEIGHT:
        if (need_update()) {
            _updater->copy_to(w_map);
        }

        break;

    default:
        INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }

    return count_elem_num(w_map);
}

void Layer::zero_buf(SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        zero_weight_map(_w_map);
        break;

    case D_WEIGHT:
        if (need_update()) {
            zero_weight_map(_dw_map);
        }

        break;

    case MD_WEIGHT:
        if (need_update()) {
            _updater->zero();
        }

        break;

    default:
        INTER_CHECK(false, "the Layer has no this parameter: %d", t);
    }
}

void Layer::init_weight(const ModelInitConfig& global_cfg) {
    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
        gauss_init_weight(_model_init_cfg.weight_mean(), _model_init_cfg.weight_stdv());
        break;

    case CONSTANT_INIT:
        constant_init_weight(_model_init_cfg.weight_value());
        break;

    case UNIFORM_INIT:
        uniform_init_weight(_model_init_cfg.weight_min(), _model_init_cfg.weight_mean());
        break;

    case MSRA_INIT:
        msra_init_weight(_model_init_cfg.weight_msra_type());
        break;

    case XAVIER_INIT:
        xavier_init_weight(_model_init_cfg.weight_xavier_type());
        break;

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN:
        switch (global_cfg.weight_init_type()) {
        case GAUSS_INIT:
            gauss_init_weight(global_cfg.weight_mean(), global_cfg.weight_stdv());
            break;

        case CONSTANT_INIT:
            constant_init_weight(global_cfg.weight_value());
            break;

        case UNIFORM_INIT:
            uniform_init_weight(global_cfg.weight_min(), global_cfg.weight_mean());
            break;

        case MSRA_INIT:
            msra_init_weight(global_cfg.weight_msra_type());
            break;

        case XAVIER_INIT:
            xavier_init_weight(_model_init_cfg.weight_xavier_type());
            break;

        default:
            CHECK(false, "model init type error");
        }

        break;

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
        gauss_init_bias(_model_init_cfg.bias_mean(), _model_init_cfg.bias_stdv());
        break;

    case CONSTANT_INIT:
        constant_init_bias(_model_init_cfg.bias_value());
        break;

    case UNIFORM_INIT:
        gauss_init_bias(_model_init_cfg.bias_min(), _model_init_cfg.bias_mean());
        break;

    case MSRA_INIT:
        msra_init_bias(_model_init_cfg.bias_msra_type());
        break;

    case XAVIER_INIT:
        xavier_init_bias(_model_init_cfg.bias_xavier_type());
        break;

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN:
        switch (global_cfg.bias_init_type()) {
        case GAUSS_INIT:
            gauss_init_bias(global_cfg.bias_mean(), global_cfg.bias_stdv());
            break;

        case CONSTANT_INIT:
            constant_init_bias(global_cfg.bias_value());
            break;

        case UNIFORM_INIT:
            gauss_init_bias(global_cfg.bias_min(), global_cfg.bias_mean());
            break;

        case MSRA_INIT:
            msra_init_bias(global_cfg.bias_msra_type());
            break;

        case XAVIER_INIT:
            xavier_init_bias(_model_init_cfg.bias_xavier_type());
            break;

        default:
            CHECK(false, "model init type error");
        }

        break;

    default:
        CHECK(false, "model init type error");
    }
}
void Layer::init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers) {
    CHECK(global_cfg.weight_init_type() == MODEL_INIT, "model init type must be model init");

    /* for weight */
    switch (_model_init_cfg.weight_init_type()) {
    case GAUSS_INIT:
        gauss_init_weight(_model_init_cfg.weight_mean(), _model_init_cfg.weight_stdv());
        break;

    case CONSTANT_INIT:
        constant_init_weight(_model_init_cfg.weight_value());
        break;

    case UNIFORM_INIT:
        gauss_init_weight(_model_init_cfg.weight_min(), _model_init_cfg.weight_mean());
        break;

    case MSRA_INIT:
        msra_init_weight(_model_init_cfg.weight_msra_type());
        break;

    case XAVIER_INIT:
        xavier_init_weight(_model_init_cfg.weight_xavier_type());
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的weight */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.weight_name().size() != 0) ? _model_init_cfg.weight_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) == std::string::npos && 
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight *src = i->w_map().find(name)->second;
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) == std::string::npos && 
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);
                        if (itr != i->w_map().end()) {
                            BaseWeight *src = itr->second;
                            dst->copy_from(src);
                            _inq_weight_max = i->get_inq_weight_max();
                        }
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "weight not found in model");
		/* for inq train */   
		if (_inq) {           
			inq_init_weight();
		}                     

        break;
    }

    default:
        CHECK(false, "model init type error");
    }

    /* for bias */
    switch (_model_init_cfg.bias_init_type()) {
    case GAUSS_INIT:
        gauss_init_bias(_model_init_cfg.bias_mean(), _model_init_cfg.bias_stdv());
        break;

    case CONSTANT_INIT:
        constant_init_bias(_model_init_cfg.bias_value());
        break;

    case UNIFORM_INIT:
        gauss_init_bias(_model_init_cfg.bias_min(), _model_init_cfg.bias_mean());
        break;

    case MSRA_INIT:
        msra_init_bias(_model_init_cfg.bias_msra_type());
        break;

    case XAVIER_INIT:
        xavier_init_bias(_model_init_cfg.bias_xavier_type());
        break;

    case MODEL_INIT:

        /* 局部没有设置，使用全局配置  */
    case MODEL_INIT_TYPE_UNKNOWN: {
        bool got_it = false;

        /* 根据当前层的名字查找需要的bias */
        for (auto i : layers) {
            std::string src_name;
            src_name = (_model_init_cfg.bias_name().size() != 0) ? _model_init_cfg.bias_name() : _name;

            if (src_name == i->name()) {
                WeightsMap::iterator itr1 = _w_map.begin();

                for (; itr1 != _w_map.end(); ++itr1) {
                    BaseWeight* dst = itr1->second;
                    std::string name = itr1->first;

                    if (name.find("bias", 0) != std::string::npos && 
                                name.find("binary", 0) == std::string::npos) {
                        BaseWeight *src = i->w_map().find(name)->second;
                        dst->copy_from(src);
                    }
                    else if (name.find("bias", 0) != std::string::npos && 
                                name.find("binary", 0) != std::string::npos) {
                        WeightsMap::iterator itr = i->w_map().find(name);
                        if (itr != i->w_map().end()) {
                            BaseWeight *src = itr->second;
                            dst->copy_from(src);
                            _inq_bias_max = i->get_inq_bias_max();
                        }
                    }
                }

                got_it = true;
            }
        }

        CHECK(got_it == true || _w_map.size() == 0, "bias not found in model");
        /* for inq train */   
        if (_inq) {
            inq_init_bias();
        }

        break;
    }

    default:
        CHECK(false, "model init type error");
    }
}

void Layer::inq_init_weight() {
    CHECK(_inq_ratio.size() != 0, "inq ratio error");
    WeightsMap::iterator itr1 = _w_map.begin();
    Tensor<DType> w_t_cpu{CPU};
    Tensor<DType> w_cpu{CPU};
    std::vector<DType> max_vec;
    int max_idx = 0;
    if (_inq_weight_max.size() > 0) {
        max_vec = _inq_weight_max;
    }

    for (; itr1 != _w_map.end(); ++itr1 ) {
        BaseWeight *dst = itr1->second;
        Tensor<DType> &w_t = *dst->w();
        std::string name = itr1->first;

        if (name.find("binary", 0) != std::string::npos && name.find("bias", 0) == std::string::npos ) {
            w_t_cpu.resize(w_t.get_size());
            w_t_cpu.copy_from(w_t);

            std::string w_name = name.substr(0, name.find("_binary"));
            Tensor<DType> &w = *_w_map.find(w_name)->second->w();
            CHECK(w.get_size() == w_t.get_size(), "dim error");
            w_cpu.resize(w.get_size());
            w_cpu.copy_from(w);

            DType max = FLT_MAX;
            if (_inq_weight_max.size() > 0) {
                max = max_vec[max_idx];
            }
            inq_quantization(w_cpu, w_t_cpu, max);
            if (_inq_weight_max.size() == 0) {
                max_vec.push_back(max);
            }

            w_t.copy_from(w_t_cpu);
            w.copy_from(w_cpu);

            max_idx++;
        }
    }
    _inq_weight_max = max_vec;
}
void Layer::inq_init_bias() {
    CHECK(_inq_ratio.size() != 0, "inq ratio error");
    WeightsMap::iterator itr1 = _w_map.begin();
    Tensor<DType> w_t_cpu{CPU};
    Tensor<DType> w_cpu{CPU};
    std::vector<DType> max_vec;
    int max_idx = 0;
    if (_inq_bias_max.size() > 0) {
        max_vec = _inq_bias_max;
    }

    for (; itr1 != _w_map.end(); ++itr1 ) {
        BaseWeight *dst = itr1->second;
        Tensor<DType> &w_t = *dst->w();
        std::string name = itr1->first;

        if (name.find("binary", 0) != std::string::npos && name.find("bias", 0) != std::string::npos ) {
            w_t_cpu.resize(w_t.get_size());
            w_t_cpu.copy_from(w_t);

            std::string w_name = name.substr(0, name.find("_binary"));
            Tensor<DType> &w = *_w_map.find(w_name)->second->w();
            CHECK(w.get_size() == w_t.get_size(), "dim error");
            w_cpu.resize(w.get_size());
            w_cpu.copy_from(w);

            DType max = FLT_MAX;
            if (_inq_bias_max.size() > 0) {
                max = max_vec[max_idx];
            }
            inq_quantization(w_cpu, w_t_cpu, max);
            if (_inq_bias_max.size() == 0) {
                max_vec.push_back(max);
            }

            w_t.copy_from(w_t_cpu);
            w.copy_from(w_cpu);

            max_idx++;
        }
    }
    _inq_bias_max = max_vec;
}
void Layer::inq_quantization(Tensor<DType> &w, Tensor<DType> &w_t, DType &max) {
    Tensor<DType> w_square{CPU};

    if (_inq_ratio[0] == 0) {
        return;
    }

    /* 0表示需要量化的权重，非0表示不需要量化的权重， 查找非0元素的数量，记录位置 */
    int elem_num = w_t.get_element_count();
    std::vector<std::pair<int, DType>> idx;
    int cnt = 0;

    for (int i = 0; i < elem_num; i++) {
        DType *data_t = w_t.get_data();
        DType *data = w.get_data();
        if (data_t[i] > 0) {
            idx.push_back(std::pair<int, DType>(i, fabs(data[i])));
            cnt ++;
        }
    }

    DType cur_ratio = 1 - cnt * 1.0 / elem_num;
    if (_inq_ratio[0] > cur_ratio) {
        /* 
         * 设置weight对应的矩阵Tl 
         * 0值未达到比例，将一定比例的非0值，设置为0 
         * */
        /* 随机量化*/
#if 0
        random_shuffle(idx.begin(), idx.end());
#endif
        /* DNS量化*/
        sort(idx.begin(), idx.end(), big_sort_fun);
        int num = floor((_inq_ratio[0] - cur_ratio) * elem_num);
        idx.erase(idx.begin() + num, idx.end());
        INTER_LOG("*********************cur layer: %s*********************", _name.c_str());
        INTER_LOG("model cur ratio: %f, dst ratio: %f", cur_ratio, _inq_ratio[0]);
        INTER_LOG("cur quantize fabs max: %.8f, fabs min: %.8f", 
                    idx.begin()->second, (idx.end() - 1)->second);

        DType *data = w_t.get_data();
        std::vector<std::pair<int, DType>>::iterator it;
        for (it = idx.begin(); it != idx.end(); ++it) {
            data[it->first] = 0;
        }

        /* max */
        if (max == FLT_MAX) {
            w_square.resize(w.get_size());
            w_square.square(w);
            max = sqrt(w_square.max());
        }

        /* n1, n2 */
        /* n1 = floor(log2(4s/3)), s = max(fabs(Wl)) */
        int n1 = (int)floor(log2f(max * 4.0 / 3.0));
        /* n2 = n1 + 1 - 2^(b-2) */
        int n2 = n1 + 1 - (int)pow(2, _inq_bit - 2);
        INTER_LOG("INQ: max: %.8f n1: %d n2: %d", max, n1, n2);
        INTER_LOG("************************end of %s**********************", _name.c_str());

        /* pl */
        std::vector<DType> pl;
        pl.push_back(0);
        for (int i = n2; i <= n1; i++) {
            pl.push_back(pow(2, i));
        }

        /* 量化 */
        int w_elem_cnt = w.get_element_count();
        DType *w_data = w.get_data();
        DType *w_t_data = w_t.get_data();
        for (int i = 0; i < w_elem_cnt; i++) {
            DType elem = fabs(w_data[i]);
            if (w_t_data[i] == 0) {
                int sgn = 0;
                SGN(w_data[i], sgn);
                w_data[i] = 0;
                for (int j = 1; j < (int)pl.size(); j++) {
                    if (elem > (pl[j - 1] + pl[j]) / 2.0 && elem < 3.0 * pl[j] / 2.0 ) {
                        w_data[i] = pl[j] * sgn;
                        break;
                    }
                }
            }
        }
    }
    else {
        INTER_LOG("inq cur 0 is enough");
    }
}

void Layer::uniform_init_weight(DType lo, DType hi) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            src->random(lo, hi);
        }
    }
}

void Layer::uniform_init_bias(DType lo, DType hi) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) != std::string::npos) {
            src->random(lo, hi);
        }
    }
}

void Layer::constant_init_weight(DType const_value) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            src->set_const(const_value);
        }
    }
}

void Layer::constant_init_bias(DType const_value) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) != std::string::npos) {
            src->set_const(const_value);
        }
    }
}

void Layer::constant_init(DType const_value) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;
        src->set_const(const_value);
    }
}

void Layer::gauss_init_weight(DType mean, DType stdv) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            src->gauss_random(mean, stdv);
        }
    }
}

void Layer::msra_init_weight(MSRAType type) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            CHECK(src->w()->get_dim() == 4 || src->w()->get_dim() == 2, 
                        "tensor dim must be 4 or 2");
            DType n = 0;
            DType n1 = 0;
            DType n2 = 0;

            if (src->w()->get_dim() == 4) {
                n1 = src->w()->get_c() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n1 = src->w()->get_h();
            }

            if (src->w()->get_dim() == 4) {
                n2 = src->w()->get_n() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n2 = src->w()->get_w();
            }

            switch (type) {
            case IN_MSRA_TYPE:
                n = n1;
                break;
            case OUT_MSRA_TYPE:
                n = n2;
                break;
            case AVG_MSRA_TYPE: {
                n = (n1 + n2) / 2;
                break;
            }
            default:
                CHECK(false, "msra type error");
            }

            DType stdv = sqrt(2.0f / n);
            src->gauss_random(0, stdv);
        }
    }
}

void Layer::xavier_init_weight(XavierType type) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) == std::string::npos) {
            CHECK(src->w()->get_dim() == 4 || src->w()->get_dim() == 2, "tensor dim must be 4 or 2");
            DType n = 0;
            DType n1 = 0;
            DType n2 = 0;

            if (src->w()->get_dim() == 4) {
                n1 = src->w()->get_c() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n1 = src->w()->get_h();
            }

            if (src->w()->get_dim() == 4) {
                n2 = src->w()->get_n() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n2 = src->w()->get_w();
            }

            switch (type) {
            case IN_XAVIER_TYPE:
                n = n1;
                break;

            case OUT_XAVIER_TYPE:
                n = n2;
                break;

            case AVG_XAVIER_TYPE: {
                n = (n1 + n2) / 2;
                break;
            }

            default:
                CHECK(false, "xavier type error");
            }

            DType scale = sqrt(3.0f / n);
            src->random(-scale, scale);
        }
    }
}

void Layer::gauss_init_bias(DType mean, DType stdv) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) != std::string::npos) {
            src->gauss_random(mean, stdv);
        }
    }
}

void Layer::msra_init_bias(MSRAType type) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) != std::string::npos) {
            CHECK(src->w()->get_dim() == 4, "tensor dim must be 4");
            DType n = 0;

            switch (type) {
            case IN_MSRA_TYPE:
                n = src->w()->get_c() * src->w()->get_h() * src->w()->get_w();
                break;

            case OUT_MSRA_TYPE:
                n = src->w()->get_n() * src->w()->get_h() * src->w()->get_w();
                break;

            case AVG_MSRA_TYPE: {
                DType in = src->w()->get_c() * src->w()->get_h() * src->w()->get_w();
                DType out = src->w()->get_n() * src->w()->get_h() * src->w()->get_w();
                n = (in + out) / 2;
                break;
            }

            default:
                CHECK(false, "msra type error");
            }

            DType stdv = sqrt(2.0f / n);
            src->gauss_random(0, stdv);
        }
    }
}

void Layer::xavier_init_bias(XavierType type) {
    WeightsMap::iterator itr1 = _w_map.begin();

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        if (name.find("bias", 0) != std::string::npos) {
            CHECK(src->w()->get_dim() == 4 || src->w()->get_dim() == 2, "tensor dim must be 4 or 2");
            DType n = 0;
            DType n1 = 0;
            DType n2 = 0;

            if (src->w()->get_dim() == 4) {
                n1 = src->w()->get_c() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n1 = src->w()->get_h();
            }

            if (src->w()->get_dim() == 4) {
                n2 = src->w()->get_n() * src->w()->get_h() * src->w()->get_w();
            } else if (src->w()->get_dim() == 2) {
                n2 = src->w()->get_w();
            }

            switch (type) {
            case IN_XAVIER_TYPE:
                n = n1;
                break;

            case OUT_XAVIER_TYPE:
                n = n2;
                break;

            case AVG_XAVIER_TYPE: {
                n = (n1 + n2) / 2;
                break;
            }

            default:
                CHECK(false, "xavier type error");
            }

            DType scale = sqrt(3.0f / n);
            src->random(-scale, scale);
        }
    }
}

//当前layer有均值方差则使用，否则使用全局的
void Layer::gauss_init(DType mean, DType stdv) {
    WeightsMap::iterator itr1 = _w_map.begin();
    DType local_mean = 0.0f;
    DType local_stdv = 0.0f;

    for (; itr1 != _w_map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        std::string name = itr1->first;

        //if(name.find("bias", 0) == std::string::npos) {
        local_mean = (_init_mean < 0.0f) ? mean : _init_mean;
        local_stdv = (_init_stdv < 0.0f) ? stdv : _init_stdv;
        src->gauss_random(local_mean, local_stdv);
        //}
        //else {
        //    src->init_weight(0);
        //}
    }
}

void Layer::reverse_encode(const IOPackage& src, IOPackage& dest) {
    //_fwd_map_vec_d.resize(_fwd_map_vec.get_size());
    //_fwd_map_vec_d.copy_from(dynamic_cast<AbstractTensor &>(_fwd_map_vec));
    //IOPackage* src_ptr = const_cast<IOPackage*>(&src);
    //dest.resize(src_ptr->mat_height(), src_ptr->mat_width(), src_ptr->vec_size(), true);
    //dest.get_ten()->zero();
    //dest.get_ten()->add_by_idx(*src_ptr->get_ten(), _fwd_map_vec_d);
}

void Layer::reverse_decode(const IOPackage& src, IOPackage& dest) {
    //_bwd_map_vec_d.resize(_bwd_map_vec.get_size());
    //_bwd_map_vec_d.copy_from(dynamic_cast<AbstractTensor &>(_bwd_map_vec));

    //IOPackage* src_ptr = const_cast<IOPackage*>(&src);
    //dest.resize(src_ptr->mat_height(), src_ptr->mat_width(), src_ptr->vec_size(), true);
    //dest.get_ten()->add_by_idx(*src_ptr->get_ten(), _bwd_map_vec_d);
}

void Layer::zero_out_pack() {
    for (size_t i = 0; i < _output.size(); i++) {
        if (_output[i].is_init()) {
            CHECK2(_output[i].get_ten());
            _output[i].get_ten()->zero();
        }
    }
}

void Layer::zero_diff_pack() {
    for (size_t i = 0; i < _diff.size(); i++) {
        if (_diff[i].is_init()) {
            CHECK2(_diff[i].get_ten());
            _diff[i].get_ten()->zero();
        }
    }
}

void Layer::forward(Argument& args) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif

    std::vector<IOPackage*> inputs;
    /* put ouput to vector */
    for (size_t i = 0; i < _input_keys.size(); i++) {
        IOPackage* io = args.get_pack(_input_keys[i]);
        if (io == NULL && _feature_share_input) {
            continue;
        }
        CHECK(io != NULL, "layer %s input key error", _name.c_str());
        inputs.push_back(io);
#ifdef __TRAIN_OUTPUT_RESULT__

        //判断文件夹是否存在，不存在则创建
        if (access("layer_result_out", 0) == -1) {
            mkdir("layer_result_out", S_IRWXU);
        }

        char name[1024];
        snprintf(name, 1024, "./layer_result_out/device_%d_batch_%d_%s_input_%d",
                 device, batch_cnt, _name.c_str(), (int)i);
        write_tensor(*(io->get_ten()), name, _layer_result_output_num);
#endif
    }

    /* put label to vector */
    for (size_t i = 0; i < _label_key.size(); i++) {
        IOPackage* io = args.get_pack(_label_key[i]);
        if (io == NULL && _feature_share_input) {
            continue;
        }
        CHECK(io != NULL, "layer %s label key error", _name.c_str());
        inputs.push_back(io);
#ifdef __TRAIN_OUTPUT_RESULT__
        //判断文件夹是否存在，不存在则创建
        if (access("layer_result_out", 0) == -1) {
            mkdir("layer_result_out", S_IRWXU);
        }

        char name[1024];
        sprintf(name, "./layer_result_out/device_%d_batch_%d_%s_label_%d",
                device, batch_cnt, _name.c_str(), (int)i);
        if (io->get_ten() != NULL) {
            write_tensor(*(io->get_ten()), name, _layer_result_output_num);
        }
        else {
            write_tensor(*(io->get_ten()), name, _layer_result_output_num);
        }
#endif
    }

    IOPackage desc;
    /* put desc to vector */
    if (_feat_desc_keys.size() > 0) {
        CHECK(_feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
        int desc_num = args.get_feat_desc()->get_origin_height(_feat_desc_keys[0]).size();
        desc.resize(Dim(desc_num, 3), GPU);

        for (auto j = 0; j < desc_num; j++) {
            desc.get_ten()->set_element(Dim(j, 0),
                    args.get_feat_desc()->get_origin_height(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 1),
                    args.get_feat_desc()->get_origin_width(_feat_desc_keys[0])[j]);
            desc.get_ten()->set_element(Dim(j, 2),
                    args.get_feat_desc()->get_scale(_feat_desc_keys[0])[j]);
        }
        inputs.push_back(&desc);
    }

    inter_forward(inputs);

    _act->forward(*output(_output_keys[0]).get_ten(), *output(_output_keys[0]).get_ten());

#ifdef __TRAIN_OUTPUT_RESULT__

    for (size_t oi = 0; oi < _output_keys.size(); oi++) {
        char name_output[128];
        snprintf(name_output, 128, "./layer_result_out/device_%d_batch_%d_%s_output_%d", 
                    device, batch_cnt, _name.c_str(), (int)oi);
        write_tensor(*(output(_output_keys[oi]).get_ten()), name_output,
                    _layer_result_output_num);
    }

    std::map<std::string, BaseWeight*>::iterator it;
    int count = 0;

    for (it = _w_map.begin(); it != _w_map.end(); it++) {
        char name[128];
        snprintf(name, 128, "./layer_result_out/device_%d_batch_%d_%s_%s_%d", device,
                 batch_cnt, _name.c_str(), it->first.c_str(), count);
        write_tensor(*(dynamic_cast<DenseWeight* >(it->second)->w()), name, _layer_result_output_num);
        count++;
    }

#endif
}

bool Layer::backward(Argument& args, Argument& diff) {
#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif
    bool bp_flag = std::find(_bp_down.begin(), _bp_down.end(), true) != _bp_down.end();
    //INTER_LOG("Layer: %s backward %d %d", _name.c_str(), bp_flag, _enable_bp);
    if (bp_flag && _enable_bp == true) {
        //todo: 移到具体的layer中
        int i = 0;
        for (auto& it : _output_keys) {
            Tensor<DType>* tmp_diff = Layer::diff(it).get_ten();
            if (tmp_diff == NULL) {
                continue;
            }
            if (_diff_ready[i]) {
                _act->backward(*tmp_diff, *output(it).get_ten(), *tmp_diff);
            }
            i++;
        }

        zero_buf(D_WEIGHT);
        IOPackage* pre_diff = NULL;
        IOPackage* in = NULL;
        std::vector<IOPackage*> in_vec;
        std::vector<IOPackage*> pre_diff_vec;

        /* put output to vector */
        for (size_t i = 0; i < _input_keys.size(); i++) {
            in = args.get_pack(_input_keys[i]);
            in_vec.push_back(in);

            if (args.is_feat_key(_input_keys[i]) == false) {
                pre_diff = diff.get_pack(_input_keys[i]);
            }
            pre_diff_vec.push_back(pre_diff);
        }

        /* put label to vector */
        for (size_t i = 0; i < _label_key.size(); i++) {
            IOPackage* io = args.get_pack(_label_key[i]);
            in_vec.push_back(io);
        }

        IOPackage desc;
        /* put desc to vector */
        if (_feat_desc_keys.size() > 0) {
            CHECK(_feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
            int desc_num = args.get_feat_desc()->get_origin_height(_feat_desc_keys[0]).size();
            desc.resize(Dim(desc_num, 3), GPU);

            for (auto j = 0; j < desc_num; j++) {
                desc.get_ten()->set_element(Dim(j, 0),
                        args.get_feat_desc()->get_origin_height(_feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 1),
                        args.get_feat_desc()->get_origin_width(_feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 2),
                        args.get_feat_desc()->get_scale(_feat_desc_keys[0])[j]);
            }
            in_vec.push_back(&desc);
        }

        for (auto it : _input_keys) {                 
            IOPackage* in = args.get_pack(it);           

            if (args.is_feat_key(it) == false && _feature_share_input == false) {         
                IOPackage* pre_diff = diff.get_pack(it);
                if (pre_diff == NULL) {
                    continue;
                }
                pre_diff->resize(in->get_size(), in->get_device());
            }                                                      
        }                                                          

        inter_bprop_diff(in_vec, pre_diff_vec);

#ifdef __TRAIN_OUTPUT_RESULT__
        char name_cur_diff[128];
        char name_pre_diff[128];

        for (size_t i = 0; i < _output_keys.size(); i++) {
            if (Layer::diff(_output_keys[i]).get_ten()) {
                snprintf(name_cur_diff, 128, "./layer_result_out/device_%d_batch_%d_%s_cur_diff_%d",
                            device, batch_cnt, _name.c_str(), (int)i);
                write_tensor(*(Layer::diff(_output_keys[i]).get_ten()), name_cur_diff,
                             _layer_result_output_num);
            }
        }

        for (size_t i = 0; i < _input_keys.size(); i++) {
            pre_diff = pre_diff_vec[i];

            if (pre_diff != NULL) {
                snprintf(name_pre_diff, 128, "./layer_result_out/device_%d_batch_%d_%s_pre_diff_%d",
                         device, batch_cnt, _name.c_str(), (int)i);
                write_tensor(*(pre_diff->get_ten()), name_pre_diff, _layer_result_output_num);
            }
        }

#endif

        inter_bprop_grad(in_vec, pre_diff_vec);

#ifdef __TRAIN_OUTPUT_RESULT__
        std::map<std::string, BaseWeight*>::iterator it;
        int count = 0;

        for (it = _dw_map.begin(); it != _dw_map.end(); it++) {
            char name[128];
            snprintf(name, 128, "./layer_result_out/device_%d_batch_%d_%s_d%s_%d",
                        device, batch_cnt, _name.c_str(), it->first.c_str(), count);
            write_tensor(*(dynamic_cast<DenseWeight* >(it->second)->w()), name,
                        _layer_result_output_num);
            count++;
        }

#endif
    }
    return true;
}

size_t Layer::count_elem_num(WeightsMap& map) {
    size_t n = 0;
    WeightsMap::iterator itr1 = map.begin();

    for (; itr1 != map.end(); ++itr1) {
        BaseWeight* src = itr1->second;
        n += src->get_element_cnt();
    }

    return n;
}

void Layer::print_input_dim(std::string prefix, std::vector<IOPackage*>& in) {
    // CHECK(_input_keys.size() + _label_key.size() == in.size(), "input size not match");
    if (_feature_share_input == false) {
        CHECK(_input_keys.size() + _label_key.size() == in.size(), "input size not match");
    }
    for (size_t i = 0; i < _input_keys.size(); i++) {
        if (i >= in.size()) {
            continue;
        }
        Dim dim = in[i]->get_size();

        if (dim.get_axis() == 5) {
            INTER_LOG("%s input key: %s input size: %d %d %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3], dim[4]);
        } else if (dim.get_axis() == 4) {
            INTER_LOG("%s input key: %s input size: %d %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3]);
        } else if (dim.get_axis() == 3) {
            INTER_LOG("%s input key: %s input size: %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2]);
        } else if (dim.get_axis() == 2) {
            INTER_LOG("%s input key: %s input size: %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1]);
        } else {
            CHECK(false, "input dim error");
        }
    }
    for (size_t i = 0; i < _label_key.size(); ++i) {
        Dim dim = in[i + _input_keys.size()]->get_size();
        if (dim.get_axis() == 5) {
            INTER_LOG("%s label key: %s input size: %d %d %d %d %d",
                      _name.c_str(), _label_key[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3], dim[4]);
        } else if (dim.get_axis() == 4) {
            INTER_LOG("%s label key: %s input size: %d %d %d %d",
                      _name.c_str(), _label_key[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3]);
        } else if (dim.get_axis() == 3) {
            INTER_LOG("%s label key: %s input size: %d %d %d",
                      _name.c_str(), _label_key[i].c_str(), dim[0],
                      dim[1], dim[2]);
        } else if (dim.get_axis() == 2) {
            INTER_LOG("%s label key: %s input size: %d %d",
                      _name.c_str(), _label_key[i].c_str(), dim[0],
                      dim[1]);
        } else {
            CHECK(false, "label dim error");
        }
    }
}

void Layer::print_input_dim(std::string prefix, std::vector<IOPackage>& in) {
    for (size_t i = 0; i < in.size(); i++) {
        Dim dim = in[i].get_size();

        if (dim.get_axis() == 5) {
            INTER_LOG("%s input key: %s input size: %d %d %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3], dim[4]);
        } else if (dim.get_axis() == 4) {
            INTER_LOG("%s input key: %s input size: %d %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3]);
        } else if (dim.get_axis() == 3) {
            INTER_LOG("%s input key: %s input size: %d %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1], dim[2]);
        } else if (dim.get_axis() == 2) {
            INTER_LOG("%s input key: %s input size: %d %d",
                      _name.c_str(), _input_keys[i].c_str(), dim[0],
                      dim[1]);
        } else {
            CHECK(false, "input dim error");
        }
    }
}

void Layer::print_output_dim(std::string prefix, std::vector<IOPackage*>& in) {
    for (size_t i = 0; i < in.size(); i++) {
        Dim dim = in[i]->get_size();

        if (dim.get_axis() == 5) {
            INTER_LOG("%s output key: %s size: %d %d %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3], dim[4]);
        } else if (dim.get_axis() == 4) {
            INTER_LOG("%s output key: %s size: %d %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3]);
        } else if (dim.get_axis() == 3) {
            INTER_LOG("%s output key: %s size: %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2]);
        } else if (dim.get_axis() == 2) {
            INTER_LOG("%s output key: %s size: %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1]);
        } else {
            CHECK(false, "input dim error");
        }
    }
}

void Layer::print_output_dim(std::string prefix, std::vector<IOPackage>& in) {
    for (size_t i = 0; i < in.size(); i++) {
        Dim dim = in[i].get_size();

        if (dim.get_axis() == 5) {
            INTER_LOG("%s output key: %s size: %d %d %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3], dim[4]);
        } else if (dim.get_axis() == 4) {
            INTER_LOG("%s output key: %s size: %d %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2], dim[3]);
        } else if (dim.get_axis() == 3) {
            INTER_LOG("%s output key: %s size: %d %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1], dim[2]);
        } else if (dim.get_axis() == 2) {
            INTER_LOG("%s output key: %s size: %d %d",
                      _name.c_str(), _output_keys[i].c_str(), dim[0],
                      dim[1]);
        } else {
            CHECK(false, "input dim error");
        }
    }
}

void Layer::greedy_quantize(Tensor<DType> inout, size_t nbits) {
    if (_intl_quant_alpha_vec.size() == 0) {
        Tensor<DType> tmp(Dim(inout.get_height(), nbits), gpu_device());
        _intl_quant_alpha_vec.push_back(tmp);
    }

    wind_greedy_quantize(inout, nbits, _intl_quant_alpha_vec[0]);
}

bool Layer::bit_quantize(Tensor<DType> inout, size_t idx) {
    bool ret = false;

    if (_intl_quant_alpha_vec.size() < idx + 1) {
        for (size_t i = _intl_quant_alpha_vec.size(); i < idx + 1; i++) {
            Tensor<DType> tmp(Dim(1, _intl_quant_bits), gpu_device());
            _intl_quant_alpha_vec.push_back(tmp);
            Tensor<DType> tmp2(Dim(inout.get_height(), _intl_quant_bits), gpu_device());
            _batch_quant_alpha_vec.push_back(tmp2);
        }
    }

    wind_fixed_alpha(_intl_quant_alpha_vec[idx], inout);
    wind_quantize(inout, _intl_quant_alpha_vec[idx]);

    return ret;
}
}
}
