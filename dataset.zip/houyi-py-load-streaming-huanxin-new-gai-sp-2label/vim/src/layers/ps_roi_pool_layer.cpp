// by zzxfl 2017.05.03

#include "ps_roi_pool_layer.h"

namespace houyi {
namespace train {
PSROIPoolLayer::PSROIPoolLayer(PSROIPoolConfig& cfg) : Layer(cfg) {
    init();
    set_device();
    _cfg = cfg;

    _output_maps = cfg.get_output_maps();
    _spatial_scale = cfg.get_spatial_scale();
    _group_size = cfg.get_group_size();

    _ps_roi_pool_dec.out_dim = _output_maps;
    _ps_roi_pool_dec.group_size = _group_size;
    _ps_roi_pool_dec.spatial_scale = _spatial_scale;

    build_map();
}

void PSROIPoolLayer::init() {
    _spatial_scale = 1.0f;
    _group_size = 0;
    _output_maps = 0;
}

void PSROIPoolLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void PSROIPoolLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size0 = inputs[0]->get_size();
    const Dim& input_size1 = inputs[1]->get_size();
    CHECK(4 == input_size0.get_size(), "PSROIPoolLayer input0 must be 4D");
    CHECK(2 == input_size1.get_size(), "PSROIPoolLayer input1 must be 2D");
    output(_output_keys[0]).resize(Dim(input_size1[0],
                                       _output_maps,
                                       _group_size,
                                       _group_size), inputs[0]->get_mask(), gpu_device());
}

void PSROIPoolLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input0 = in_pack[0]->get_ten();
    Tensor<DType>* input1 = in_pack[1]->get_ten();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();

    _max_channel.resize(Dim(output->get_size(0), _output_maps, _group_size, _group_size));
    output->psroi_pool_fwd(_ps_roi_pool_dec, *input0, *input1, _max_channel, 1.0f, 0.0f);

}

void PSROIPoolLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* label = in_pack[1]->get_ten();
    label->reshape(Dim(label->get_size(0), label->get_size(1), 1, 1));

    out_diff->psroi_pool_bp(_ps_roi_pool_dec, *in_diff, *label, _max_channel, 1.0f, 0.0f);
    label->reshape(Dim(label->get_size(0), label->get_size(1)));
}

void PSROIPoolLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    // nothing to do
}

}
}
