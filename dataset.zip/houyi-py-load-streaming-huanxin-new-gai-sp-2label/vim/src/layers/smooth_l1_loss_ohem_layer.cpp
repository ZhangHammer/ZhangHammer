#include "wind/wind.h"
#include "layer_config.h"
#include "smooth_l1_loss_ohem_layer.h"
#include "image_utils.h"

namespace houyi {
namespace train {

/**
 * brief:
 *
 * param: output[0]: b0, 预测的坐标
 *        output[1]: b1, target坐标
 *        output[2]: in weight, 有物体(fg)时为1，否则为0，对应于论文中的pi*
 *        output[3]: out weight, 正负样本的权重或1/Nreg
 *        label[0]: 空
 *        target[0]: 训练的损失，对应于论文中的L({pi}, {ti})
 *
 * return:
 *
 */
void SmoothL1LossOHEMLayer::cal_target(
    std::vector<IOPackage*>& output,
    std::vector<IOPackage*>& label,
    std::vector<IOPackage*>& target) {

#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif
    Tensor<DType>* w_in = NULL;

    if (output.size() >= 3) {
        _has_weight = true;
        CHECK2(output[2]);
        w_in = output[2]->get_ten();
    }

    CHECK2(output[0] && output[1]);
    CHECK2(target[0]);

    size_t bat_size = output[0]->get_ten()->get_size(0);

    Tensor<DType>* predict = output[0]->get_ten();
    Tensor<DType>* label0 = output[1]->get_ten();
    CHECK2(predict->get_element_count() == label0->get_element_count());
    label0->reshape(predict->get_size());
    target[0]->resize(Dim(bat_size, 1), gpu_device());

    _outer_num = bat_size;
    _inner_num = output[0]->get_ten()->get_size(2) * output[0]->get_ten()->get_size(3);

    _w_in_b0_b1.resize(predict->get_size());
    _err.resize(predict->get_size());

    /* x = w_in * (b0 - b1) */
    _w_in_b0_b1.elem_add(*predict, *label0, 1.0f, -1.0f);
#ifdef __TRAIN_OUTPUT_RESULT__
    char name_output[1024];
    snprintf(name_output, 1024, "./layer_result_out/device_%d_batch_%d_%s_b0_b1_%d",
             device, batch_cnt, _name.c_str(), 0);
    write_tensor(_w_in_b0_b1, name_output);
#endif

    if (_has_weight) {
        CHECK2(w_in->get_element_count() == w_in->get_size(0) * w_in->get_size(1));
        w_in->reshape(Dim(w_in->get_size(0), w_in->get_size(1), 1, 1));
        _w_in_b0_b1.elem_mul(*w_in, _w_in_b0_b1, 1.0f, 0.0f);
    }

#ifdef __TRAIN_OUTPUT_RESULT__
    snprintf(name_output, 1024,
             "./layer_result_out/device_%d_batch_%d_%s_w_b0_b1_%d",
             device, batch_cnt,
             _name.c_str(), 0);
    write_tensor(_w_in_b0_b1, name_output);
#endif

    _err.smooth_l1(_w_in_b0_b1, 1.0);

    /* caffe_gpu_asum */
    //DType loss = _err.norm1();

    _normalization = _cfg.get_norm_mode();

#ifdef __TRAIN_OUTPUT_RESULT__
    snprintf(name_output, 1024,
             "./layer_result_out/device_%d_batch_%d_%s_output_%d",
             device, batch_cnt,
             _name.c_str(), 0);
    write_tensor(_err, name_output);
#endif
    _err.reshape(Dim(_err.get_size(0), _err.get_element_count() / _err.get_size(0)));
    target[0]->get_ten()->row_sum(_err);
}


/**
 * brief:
 *
 * param: output[0]: b0, 预测的坐标
 *        output[1]: b1, target坐标
 *        output[2]: in weight, 有物体(fg)时为1，否则为0，对应于论文中的pi*
 *        output[3]: out weight, 正负样本的权重或1/Nreg
 *        label[0]: 空
 *        loss[0]: 预测坐标的梯度
 *        loss[1]: target坐标的梯度
 *
 * return:
 *
 */
void SmoothL1LossOHEMLayer::cal_loss(std::vector<IOPackage*>& output,
                                     std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0]);

    _cost_buf.resize(_w_in_b0_b1.get_size());

    _cost_buf.smooth_l1_bp(_w_in_b0_b1, 1.0);

    for (int i = 0; i < 2; i++) {
        if (_bp_down[i]) {
            const DType sign = (i == 0) ? -1.0 : 1.0;

            /* LossParameter::set_pre_fixed_normalizer(from.pre_fixed_normalizer()); */
            _normalization = _cfg.get_norm_mode();
            int real_sample_count = output[i]->get_ten()->get_size(0);
            DType pre_fixed_normalizer = _cfg.get_pre_fixed();
            _cur_norm  =
                get_normalizer(_normalization, *output[0]->get_ten(),
                               real_sample_count, pre_fixed_normalizer);
            DType alpha = sign / _cur_norm;
            _loss_buf[i].resize(_w_in_b0_b1.get_size());
            _loss_buf[i].copy_from(_cost_buf);
            _loss_buf[i].mul(alpha);

            loss[i]->get_ten()->elem_add(
                    *loss[i]->get_ten(), _loss_buf[i], 1.0f, _cfg.get_loss_weight());
        }
    }
}

Loss& SmoothL1LossOHEMLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;
    int bp_flag = 0;

    for (auto f : _bp_down) {
        if (f) {
            bp_flag = 1;
        }
    }

    if (bp_flag == 0) {
        _loss->set_loss(0);
        return *_loss;
    }

    switch (type) {
    case TGT_ACU:
    case TGT_ERR: {
        cost = output(_output_keys[0]).get_ten()->sum();
        //cost = _output[0].get_ten()->sum();
        /* _output[0]的维度是(1,x） */
        cost = cost / _cur_norm * _sample_num;
        break;
    }

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    return *_loss;
}

} //namespace train
}
