/**
 * conv_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-9
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "conv_layer.h"

namespace houyi {
namespace train {

ConvLayer::ConvLayer(ConvConfig& config) : Layer(config) {
    set_device();
    _filter_num = config.filter_num();
    _group_num  = config.group_num();
    _filter_size = config.filter_size();
    _filter_num = config.filter_num();
    _fbank_dim = config.fbank_num();
    _temporal_dim = config.temporal_dim();
    _conv_out_dim = config.conv_out_dim();
    _delta = config.delta();
    _conv_start_pos.resize(Dim(_group_num));
    _conv_end_pos.resize(Dim(_group_num));
    _conv_size.resize(Dim(_group_num));
    _pooling_pivot.resize(Dim(config.pooling_out_dim()));
    _conv_start_pos.copy_from(config.conv_start(), 0, _group_num);
    _conv_end_pos.copy_from(config.conv_end(), 0, _group_num);
    _conv_size.copy_from(config.conv_size(), 0, _group_num);

    _pooling_size = config.pooling_size();
    _pooling_out_dim = config.pooling_out_dim();
    _pooling_pivot.copy_from(config.pooling_pivot(), 0, _pooling_out_dim);

    _bias_vec.resize(_group_num);
    _bias_vec_t.resize(_group_num);

    if (need_update()) {
        _d_bias_vec.resize(_group_num);
    }

    build_map();

    _config = config;
    _frame_num = 0;
}

void ConvLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
#if 0
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
#endif
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _w.resize(Dim(_filter_num, _filter_size * _temporal_dim), gpu_device());

    if (need_update()) {
        _dw.resize(Dim(_filter_num, _filter_size * _temporal_dim), gpu_device());
    }

	if (_has_bias) {
        for (int i = 0; i < _group_num; i++) {
            _bias_vec[i].resize(Dim(1, _filter_num / _group_num), gpu_device());

            if (need_update()) {
                _d_bias_vec[i].resize(Dim(1, _filter_num / _group_num),
                        gpu_device());
            }
        }
	}

    if (_inq) {
        _w_t.resize(Dim(_filter_num, _filter_size * _temporal_dim), GPU);
        _w_t.w()->set_element(1);

        if (_has_bias) {
            for (int i = 0; i < _group_num; i++) {
                _bias_vec_t[i].resize(Dim(1, _filter_num / _group_num), gpu_device());
                _bias_vec_t[i].w()->set_element(1);
            }
        }
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ConvLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int out_dim = _filter_num / _group_num * _pooling_pivot.get_size(0);
    int frame_num = inputs[0]->get_size()[0];
    _frame_num = frame_num;
    _sample_num = sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(frame_num, out_dim), inputs[i]->get_mask(), 
                          gpu_device());
    }

    _out_conv.resize(Dim(frame_num * _conv_out_dim, _filter_num / _group_num));
    _out.resize(Dim(frame_num,  _filter_num * _pooling_out_dim / _group_num));
    _idx.resize(Dim(frame_num * _filter_num * _pooling_out_dim / _group_num));
    _e.resize(Dim(frame_num,  _filter_num * _pooling_out_dim / _group_num));
    _x.resize(Dim(frame_num * _conv_out_dim, _filter_size * _temporal_dim));
    _dx.resize(Dim(frame_num * _conv_out_dim, _filter_size * _temporal_dim));
}

ConvLayer::ConvLayer(ConvLayer* from) : Layer(from) {
    bool is_update = need_update();
    from->config().set_update(is_update);

    new(this) ConvLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
    //from->config().set_update(is_update);

    _w.resize_like(*from->w());
    _w.copy_from(from->w());

    if (_has_bias) {
        for (int i = 0; i < _group_num; i++) {
            _bias_vec[i].resize_like(*from->bias(i));
            _bias_vec[i].copy_from(from->bias(i));
        }
    }

    if (_inq) {
        _w_t.resize_like(*from->w_t());
        _w_t.copy_from(from->w_t());

        if (_has_bias) {
            for (int i = 0; i < _group_num; i++) {
                _bias_vec_t[i].resize_like(*from->bias_t(i));
                _bias_vec_t[i].copy_from(from->bias_t(i));
            }
        }
    }
}

void ConvLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "weight", &_w));

    if (_has_bias) {
        for (int i = 0; i < _group_num; i++) {
            char app[16] = {0};
            snprintf(app, 16, "%d", i);
            std::string key = "bias";
            key.append(app);
            _w_map.insert(WeightsMap::value_type(pre + key, &_bias_vec[i]));
        }
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_w_t));

        if (_has_bias) {
            for (int i = 0; i < _group_num; i++) {
                char app[16] = {0};
                snprintf(app, 16, "%d", i);
                std::string key = "bias";
                key.append(app);
                _w_map.insert(WeightsMap::value_type(pre + key + "_binary", &_bias_vec_t[i]));
            }
        }
    }

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_dw));

        if (_has_bias) {
            for (int i = 0; i < _group_num; i++) {
                char app[16] = {0};
                snprintf(app, 16, "%d", i);
                std::string key = "bias";
                key.append(app);
                _dw_map.insert(WeightsMap::value_type(pre + key, &_d_bias_vec[i]));
            }
        }
    }

}

Layer* ConvLayer::clone() {
    return new ConvLayer(this);
}

ConvLayer::~ConvLayer() {
    //for (size_t i = 0; i < _bias_vec.size(); i++) {
    //    if (_bias_vec[i]) {
    //        delete _bias_vec[i];
    //        _bias_vec[i] = NULL;
    //    }
    //}

    //for (size_t i = 0; i < _d_bias_vec.size(); i++) {
    //    if (_d_bias_vec[i]) {
    //        delete _d_bias_vec[i];
    //        _d_bias_vec[i] = NULL;
    //    }
    //}

    _bias_vec.clear();
    _d_bias_vec.clear();
}

void ConvLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();

    /* expand the input data for convalution */
    _x.expand_feat(*in, _fbank_dim, _delta, _conv_out_dim,
                   _filter_size, _conv_start_pos, _conv_end_pos);

    CHECK2(_w.width() == _x.get_width());

    int tmp_w_h = (_filter_num / _group_num);
    int oc_start = 0;

    for (int g = 0; g < _group_num; g++) {
        int tmp_o_h = _frame_num * _config.conv_size(g);
        Tensor<DType>* tmp_w = new Tensor<DType>(
            _w.w()->get_row(tmp_w_h * g), Dim(tmp_w_h, _w.width()), gpu_device());
        Tensor<DType>* tmp_o = new Tensor<DType>(
            _out_conv.get_row(oc_start), Dim(tmp_o_h, _out_conv.get_width()), gpu_device());
        Tensor<DType>* tmp_i = new Tensor<DType>(
            _x.get_row(oc_start), Dim(tmp_o_h, _x.get_width()), gpu_device());

        tmp_o->mul(*tmp_i, false, *tmp_w, true);
        tmp_o->row_add_vec(*tmp_o, *(_bias_vec[g].w()));

        oc_start += tmp_o_h;

        tmp_i->clear();
        tmp_o->clear();
        tmp_w->clear();
        delete tmp_w;
        delete tmp_o;
        delete tmp_i;
        tmp_w = NULL;
        tmp_o = NULL;
        tmp_i = NULL;
    }

    _out.max_pooling(_out_conv, _conv_size, _filter_num, _pooling_size, _idx);
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    out->elem_add(*out, _out);
}

void ConvLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    _out_conv.zero();
    _out_conv.max_pooling_bp(*local_diff, _conv_size,
                             _filter_num, _pooling_size, _idx);

    //XXX out_pack must be nullptr
    if (out_pack[0]) {
        input_error_bp(*out_pack[0]->get_ten());
    }
}

void ConvLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    //Tensor<DType>* local_diff = _diff.get_ten();
    //_out_conv.zero();
    //_out_conv.max_pooling_bp(*local_diff, _conv_size,
    //     _filter_num, _pooling_size, _idx);
    if (need_update()) {
        int tmp_w_h = (_filter_num / _group_num);
        int o_c_start = 0;

        for (int g = 0; g < _group_num; g++) {
            int tmp_o_h = _frame_num * _config.conv_size(g);
            Tensor<DType>* tmp_w = new Tensor<DType>(
                _dw.w()->get_row(tmp_w_h * g),
                Dim(tmp_w_h, _dw.width()), gpu_device());
            Tensor<DType>* tmp_e = new Tensor<DType>(
                _out_conv.get_row(o_c_start),
                Dim(tmp_o_h, _out_conv.get_width()), gpu_device());
            Tensor<DType>* tmp_i = new Tensor<DType>(
                _x.get_row(o_c_start),
                Dim(tmp_o_h, _x.get_width()), gpu_device());

            tmp_w->mul(*tmp_e, true, *tmp_i, false, 1.0f, 1.0f);
            _d_bias_vec[g].w()->collect_bias(*tmp_e, 1.0f, 1.0f);
            o_c_start += tmp_o_h;

            tmp_i->clear();
            tmp_e->clear();
            tmp_w->clear();
            delete tmp_w;
            delete tmp_e;
            delete tmp_i;
            tmp_w = tmp_e = tmp_i = NULL;
        }
    }
}

void ConvLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->write(output);
        if (_inq) {                                          
            _w_t.w()->write(output);                         
            Tensor<DType> max(Dim(1), CPU);                  
            max.set_element(Dim(0), _inq_weight_max.front());
            max.write(output);                               
        }                                                    

        if (_has_bias) {
            for (int g = 0; g < _group_num; g++) {
                _bias_vec[g].w()->write(output);
                Tensor<DType> max(Dim(1), CPU);                  
                if (_inq) {                                          
                    _bias_vec_t[g].w()->write(output);
                    max.set_element(Dim(0), _inq_bias_max[g]);
                    max.write(output);
                }                                                    
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void ConvLayer::read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read(input);
        if (_inq) {
            _w_t.w()->read(input);
            Tensor<DType> max(Dim(1), CPU);                     
            max.read(input);                                    
            _inq_weight_max.push_back(max.get_element(Dim(0))); 
        }

        if (_has_bias) {
            for (int g = 0; g < _group_num; g++) {
                _bias_vec[g].w()->read(input);
                Tensor<DType> max(Dim(1), CPU);                     
                if (_inq) {
                    _bias_vec_t[g].w()->read(input);
                    max.read(input);                                    
                    _inq_weight_max.push_back(max.get_element(Dim(0))); 
                }
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void ConvLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read(input);

        if (_has_bias) {
            for (int g = 0; g < _group_num; g++) {
                _bias_vec[g].w()->read(input);
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void ConvLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read_hfnn(input);

        if (_has_bias) {
            for (int g = 0; g < _group_num; g++) {
                _bias_vec[g].w()->read_hfnn(input);
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void ConvLayer::read_heter_model(std::ifstream& input) {
    Tensor<DType> tmp {cpu_device()};
    tmp.read_hfnn(input, sizeof(int));
    size_t trans_dim_m = tmp.get_height();
    size_t trans_dim_n = tmp.get_width();
    INTER_LOG("read a convLayer: height:=%lu, width:=%lu\n", trans_dim_m, trans_dim_n);

    CHECK2(trans_dim_n - 1 == _w.width()
           && (trans_dim_m - 1 == _w.height()
               || trans_dim_m == _w.height()));

    size_t group_len = _filter_num / _group_num;

    for (size_t i = 0; i < _w.height(); i++) {
        _w.w()->range_row(i, i + 1).copy_from(tmp.get_row(i), 0, trans_dim_n - 1);
        _bias_vec[i / group_len].w()->copy_from(
            tmp.get_row(i) + trans_dim_n - 1, i % group_len, 1);
    }
}

void ConvLayer::input_error_bp(Tensor<DType>& inputError) {
    int tmp_w_h = (_filter_num / _group_num);
    int o_c_start = 0;
    _dx.zero();

    for (int g = 0; g < _group_num; g++) {
        int tmp_o_h = _frame_num * _config.conv_size(g);
        Tensor<DType>* tmp_w = new Tensor<DType>(
            _w.w()->get_row(tmp_w_h * g),
            Dim(tmp_w_h, _w.width()), gpu_device());
        Tensor<DType>* tmp_o = new Tensor<DType>(
            _out_conv.get_row(o_c_start),
            Dim(tmp_o_h, _out_conv.get_width()), gpu_device());
        Tensor<DType>* tmp_i = new Tensor<DType>(
            _dx.get_row(o_c_start),
            Dim(tmp_o_h, _dx.get_width()), gpu_device());

        tmp_i->mul(*tmp_o, *tmp_w);
        o_c_start += tmp_o_h;

        tmp_i->clear();
        tmp_o->clear();
        tmp_w->clear();
        delete tmp_w;
        delete tmp_o, delete tmp_i;
        tmp_w = NULL;
        tmp_o = NULL;
        tmp_i = NULL;
    }

    inputError.resize(Dim(_dx.get_height() / _conv_out_dim,
                          _fbank_dim * _temporal_dim));
    inputError.shrink_errors(
        _dx, _fbank_dim, _delta, _conv_out_dim,
        _filter_size, _conv_start_pos, _conv_end_pos); // TODO:
}

}
}

