/**
 * activation.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include <algorithm>
#include "activation.h"
#include "util.h"

namespace houyi {
namespace train {
Activation* Activation::create(ActiveType type, int pooling_size) {
    switch (type) {
    case ACT_LINEAR:
        return new LinearActivation();
        break;

    case ACT_SIGMOID:
        return new SigmoidActivation();
        break;

    case ACT_TANH:
        return new TanhActivation();
        break;

    case ACT_RELU:
        return new ReluActivation();
        break;

    case ACT_LOGRELU:
        return new LogReluActivation();
        break;

    case ACT_MAXOUT:
        return new MaxOutActivation(pooling_size);

    default:
        INTER_CHECK(false, "unknown act-type: %d", type);
    }

    return NULL;
}

void MaxOutActivation::forward(const Tensor<DType>& in, Tensor<DType>& out, int t, int sample_num) {
    if (!out.is_init()) {
        out.resize(Dim(in.get_height(), in.get_width() / _pooling_size));
    }

    CHECK2(in.get_height() == out.get_height());
    CHECK2(in.get_width() == out.get_width()*_pooling_size);

    if (sample_num > (int)_idx_mat.size()) {
        _idx_mat.resize(sample_num);
    }

    _idx_mat[t].resize(Dim(out.get_height() * out.get_width()));
    _idx_mat[t].zero();

    CHECK(false, "max out not support");
    //out.max_out_fwd(in, _pooling_size, _idx_mat[t]);
}

void MaxOutActivation::backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                                Tensor<DType>& outDiff,
                                int t, int sample_num, DType alpha, DType beta) {
    if (!outDiff.is_init()) {
        outDiff.resize(Dim(inDiff.get_height(), inDiff.get_width()*_pooling_size));
    }

    CHECK2(inDiff.get_height() == out.get_height()
           && inDiff.get_width() == out.get_width());
    CHECK2(inDiff.get_height() == outDiff.get_height()
           && inDiff.get_width() * _pooling_size == outDiff.get_width());
    outDiff.zero();
    //outDiff.max_out_bwd(inDiff, _pooling_size, _idx_mat[t], alpha, beta);
    CHECK(false, "max out not support");
}

void LinearActivation::forward(const Tensor<DType>& in, Tensor<DType>& out) {
    if (!out.is_init()) {
        out.resize(in.get_size());
    }

    if (out.get_data() == in.get_data()) {
        return;
    }

    out.copy_from(in);
}

void LinearActivation::backward(
    const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff) {
    if (!outDiff.is_init()) {
        outDiff.resize(inDiff.get_size());
    }

    CHECK2(inDiff.get_size() == out.get_size());

    if (out.get_data() == outDiff.get_data()) {
        return;
    }

    outDiff.copy_from(inDiff);
}

void SigmoidActivation::forward(const Tensor<DType>& in, Tensor<DType>& out) {
    out.sigmoid(*(const_cast<Tensor<DType>*>(&in)));
}

void SigmoidActivation::backward(
    const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff) {
    outDiff.sigmoid_bp(
        *(const_cast<Tensor<DType>*>(&inDiff)),
        *(const_cast<Tensor<DType>*>(&out)));
}

void TanhActivation::forward(const Tensor<DType>& in, Tensor<DType>& out) {
    out.tanh(*(const_cast<Tensor<DType>*>(&in)));
}

void TanhActivation::backward(
    const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff) {
    outDiff.tanh_bp(
        *(const_cast<Tensor<DType>*>(&inDiff)),
        *(const_cast<Tensor<DType>*>(&out)));
}

void ReluActivation::forward(const Tensor<DType>& in, Tensor<DType>& out) {
    out.relu(*(const_cast<Tensor<DType>*>(&in)));
    //_pnorm.pnorm(out);
}

void ReluActivation::backward(
    const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff) {
    //outDiff.pnorm_bprop(inDiff, _pnorm);
    outDiff.relu_bp(
        *(const_cast<Tensor<DType>*>(&inDiff)),
        *(const_cast<Tensor<DType>*>(&out)));
}

void LogReluActivation::forward(const Tensor<DType>& in, Tensor<DType>& out) {
    out.relu(*(const_cast<Tensor<DType>*>(&in)));
    _relu_out.resize(Dim(out.get_height(), out.get_width()));
    _relu_out.copy_from(out);

    //lifeng 8.8
    //out.add(0.00001);
    _rep.resize(Dim(out.get_height(), out.get_width()));
    //out.reciprocal(_rep);

    out.log();
}

void LogReluActivation::backward(
    const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff) {
    _relu_diff.resize(Dim(inDiff.get_height(), inDiff.get_width()));
    _relu_diff.elem_mul(inDiff, _rep);

    outDiff.relu_bp(
        *(const_cast<Tensor<DType>*>(&_relu_diff)),
        *(const_cast<Tensor<DType>*>(&_relu_out)));
}

}
} //namespace houyi

