/**
 * file: smooth_l1_loss_layer.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年12月03日 00时37分44秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#include "wind/wind.h"
#include "layer_config.h"
#include "smooth_l1_loss_layer.h"

namespace houyi {
namespace train {

/**
 * brief:
 *
 * param: output[0]: b0, 预测的坐标
 *        output[1]: b1, target坐标
 *        output[2]: in weight, 有物体(fg)时为1，否则为0，对应于论文中的pi*
 *        output[3]: out weight, 正负样本的权重或1/Nreg
 *        label[0]: 空
 *        target[0]: 训练的损失，对应于论文中的L({pi}, {ti})
 *
 * return:
 *
 */
void SmoothL1LossLayer::cal_target(std::vector<IOPackage*>& output,
                                   std::vector<IOPackage*>& label,
                                   std::vector<IOPackage*>& target) {

#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
    int batch_cnt = 0;

    if (g_batch_cnt >= 0) {             //单卡
        batch_cnt = (int)g_batch_cnt;
    } else {                            //多卡
        batch_cnt = (int)g_thread_batch_cnt[device];
    }

#endif
    Tensor<DType>* w_in = NULL;
    Tensor<DType>* w_out = NULL;

    if (output.size() >= 4) {
        _has_weight = true;
        CHECK2(output[2] && output[3]);
        w_in = output[2]->get_ten();
        w_out = output[3]->get_ten();
    }

    CHECK2(output[0] && output[1]);
    CHECK2(target[0]);

    size_t bat_size = output[0]->get_ten()->get_size(0);
    Tensor<DType>* predict = output[0]->get_ten();
    Tensor<DType>* label0 = output[1]->get_ten();
    target[0]->resize(Dim(bat_size, 1), gpu_device());

    _w_in_b0_b1.resize(predict->get_size());
    _err.resize(predict->get_size());

    /* x = w_in * (b0 - b1) */
    _w_in_b0_b1.elem_add(*predict, *label0, 1.0f, -1.0f);

    if (_has_weight) {
        _w_in_b0_b1.elem_mul(*w_in, _w_in_b0_b1, 1.0f, 0.0f);
    }

    /* w_out * smooth(x) */
    _err.smooth_l1(_w_in_b0_b1, _sigma_square);

    if (_has_weight) {
        _err.elem_mul(*w_out, _err, 1.0f, 0.0f);
    }

#ifdef __TRAIN_OUTPUT_RESULT__
    char name_output[1024];
    snprintf(name_output,
             1024,
             "./layer_result_out/device_%d_batch_%d_%s_output_%d",
             device, batch_cnt,
             _name.c_str(), 0);
    _err.write(name_output, _layer_result_output_num);
#endif

    _err.reshape(Dim(_err.get_size(0), _err.get_element_count() / _err.get_size(0)));
    target[0]->get_ten()->row_sum(_err);

}


/**
 * brief:
 *
 * param: output[0]: b0, 预测的坐标
 *        output[1]: b1, target坐标
 *        output[2]: in weight, 有物体(fg)时为1，否则为0，对应于论文中的pi*
 *        output[3]: out weight, 正负样本的权重或1/Nreg
 *        label[0]: 空
 *        loss[0]: 预测坐标的梯度
 *        loss[1]: target坐标的梯度
 *
 * return:
 *
 */
void SmoothL1LossLayer::cal_loss(std::vector<IOPackage*>& output,
                                 std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    Tensor<DType>* w_in = NULL;
    Tensor<DType>* w_out = NULL;

    if (_has_weight) {
        CHECK2(output[2] && output[3]);
        w_in = output[2]->get_ten();
        w_out = output[3]->get_ten();
    }

    CHECK2(output[0]);

    _cost_buf.resize(_w_in_b0_b1.get_size());
    _cost_buf.smooth_l1_bp(_w_in_b0_b1, _sigma_square);

    for (int i = 0; i < 2; i++) {
        if (_bp_down[i]) {
            const DType sign = (i == 0) ? -1.0 : 1.0;
            _loss_buf[i].resize(_w_in_b0_b1.get_size());
            _loss_buf[i].copy_from(_cost_buf);
            _loss_buf[i].mul(sign / output[i]->get_ten()->get_size(0));

            if (_has_weight) {
                _loss_buf[i].elem_mul(*w_in, _loss_buf[i], 1.0, 0.0);
                _loss_buf[i].elem_mul(*w_out, _loss_buf[i], 1.0, 0.0);
            }

            loss[i]->get_ten()->elem_add(
                    *loss[i]->get_ten(), _loss_buf[i], 1.0f, _cfg.get_loss_weight());
        }
    }
}

Loss& SmoothL1LossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;

    switch (type) {
    case TGT_ACU:
    case TGT_ERR:
        cost = _output[0].get_ten()->sum();
        /* _output[0]的维度是(1,x） */
        cost = cost / _output[0].get_ten()->get_size(1);
        break;

    default:
        INTER_CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    _loss->set_loss(cost);
    return *_loss;
}

} //namespace train
}
