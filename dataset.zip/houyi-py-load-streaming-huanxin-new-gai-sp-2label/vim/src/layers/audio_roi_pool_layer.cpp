#include "audio_roi_pool_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {
AudioROIPoolLayer::AudioROIPoolLayer(AudioROIPoolConfig& cfg) : Layer(cfg) {
    _max_idx.set_device(gpu_device());
    init();
    set_device();
    _cfg = cfg;
    _pool_type = _cfg.get_pool_type();

    _group_size = cfg.get_group_size();

    build_map();
}

void AudioROIPoolLayer::init() {
    _group_size = 0;
}

void AudioROIPoolLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void AudioROIPoolLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size0 = inputs[0]->get_size();
    CHECK(4 == input_size0.get_size(), "AudioROIPoolLayer input0 must be 4D");
    //注意：必须保证batch_size放在第一维
    //_out_feat_mask.resize(Dim(input_size0.get_size(0) *_group_size), false);
    _out_feat_mask.resize(Dim(input_size0.get_size(0)), false);
    _out_feat_mask.set_element(1);
    output(_output_keys[0]).resize(Dim(input_size0[0],
                input_size0[1],
                _group_size,
                input_size0[3]), &_out_feat_mask, gpu_device());
    _max_idx.resize(output(_output_keys[0]).get_size());
}

void AudioROIPoolLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input = in_pack[0]->get_ten();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();

    int batch_size = input->get_size(0);
    //注意：时间维必须放在第三维
    int max_seq_size = mask->get_size(0) / batch_size;
    //经过卷积池化之后，时间维可能会被压缩
    float input_seq_size = static_cast<float>(input->get_size(2));
    //压缩系数 
    _scale = input_seq_size / static_cast<float>(max_seq_size);

    _seq_len.resize(Dim(batch_size));
    _seq_len.count_valid_label(*mask, batch_size, max_seq_size);
    wind_audio_roi_pool_fwd(*input, _max_idx, _seq_len, *output, _group_size, _scale, _pool_type);
}

void AudioROIPoolLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    if (in_pack[0] == NULL || out_pack[0] == NULL) {
        return;
    }
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();

    wind_audio_roi_pool_bp(*in_diff, _max_idx, _seq_len, *out_diff, _group_size, _scale, _pool_type);
}

void AudioROIPoolLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    // nothing to do
}

}
}
