/**
 * drop_out_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-30
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "drop_out_layer.h"

namespace houyi {
namespace train {

DropOutLayer::DropOutLayer(DropOutConfig& config) : Layer(config) {
    set_device();
    _config    = config;

    //dropout param
    _scale_train = config.get_scale_train();
    _drop_rate = config.drop_rate();
}

DropOutLayer::DropOutLayer(DropOutLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) DropOutLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

DropOutLayer::~DropOutLayer() {

}

void DropOutLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void DropOutLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);

    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}

void DropOutLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    JobType type = (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;

    if (!is_predict_job(type)) {
        if (_drop_rate > 0.0 && !_scale_train) {
            _input_mask.resize(in->get_size());
            _input_mask.zero_random(_drop_rate);
            out->elem_mul(_input_mask, *in, 1.0f, 0.0f);
        } else if (_drop_rate > 0.0 && _scale_train) {
            _input_mask.resize(in->get_size());
            _input_mask.zero_random(_drop_rate);
            out->elem_mul(_input_mask, *in, 1.0f / (1.0f - _drop_rate), 0.0f);
        } else {
            out->copy_from(*in);
        }
    } else {
        if (_drop_rate > 0.0 && !_scale_train) {
            out->copy_from(*in);
            out->mul(1.0f - _drop_rate);
        } else {
            out->copy_from(*in);
        }
    }
}

void DropOutLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* diff = out_pack[0]->get_ten();

    if (_drop_rate > 0.0 && !_scale_train) {
        diff->elem_mul(*local_diff, _input_mask, 1.0f, 1.0f);
    } else if (_drop_rate > 0.0 && _scale_train) {
        diff->elem_mul(*local_diff, _input_mask, 1.0f / (1.0f - _drop_rate), 1.0f);
    } else {
        diff->elem_add(*diff, *local_diff, 1.0f, 1.0f);
    }
}

Layer* DropOutLayer::clone() {
    return new DropOutLayer(this);
}

}
}

