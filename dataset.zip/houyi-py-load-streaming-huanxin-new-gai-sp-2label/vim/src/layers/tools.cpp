#include <vector>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <sys/time.h>
#include <string.h>
#include "tools.h"
#include "util.h"

namespace houyi {
namespace train {

static int g_train_size = -1;
__thread int g_train_rank = -1;

void set_train_size(int train_size) {
    g_train_size = train_size; 
}

int get_train_size() {
    return g_train_size;
}

void set_train_rank(int train_rank) {
    g_train_rank = train_rank;
}

int get_train_rank() {
    return g_train_rank;
}

void get_datetime(char* datetime) {
    time_t now;
    struct tm* timenow;
    time(&now);
    timenow = localtime(&now);
    strftime(datetime, 20, "%Y%m%d%H%M%S", timenow);
}

int get_max(int* data, int cnt) {
    int d_max = 0;

    for (int i = 0; i < cnt; i++) {
        if (d_max < data[i]) {
            d_max = data[i];
        }
    }

    return d_max;
}

void get_job_type(char* str, JobType& jobType) {
    char* p = str;
    int find = 0;
    int j = 0;

    for (j = 0; jobTypeName[j] != NULL; ++j) {
        if (strncmp(p, jobTypeName[j], strlen(p)) == 0) {
            find = 1;
            break;
        }
    }

    CHECK(find != 0, "job: %s not support", p);
    jobType = (enum JobType)j;
}

int get_item_num(const char* str) {
    const char* p = str;
    int count = 1;

    while (*p) {
        if (*p == ':') {
            count++;
        }

        ++p;
    }

    return count;
}

void get_item_from_str(char* str, const char* format,
                       int num, int itemSize, char* dest) {
    char* p = str;
    int count = 1;

    while (*p) {
        if (*p == ':') {
            *p = ' ', count++;
        }    ++p;
    }

    if (count != num) {
        std::cout << "different layers: layerNum="
                  << num << " dims=" << count << std::endl;
        exit(0);
    }

    p = str;

    for (int i = 0; i < num; ++i, p = strchr(p, ' ') + 1) {
        sscanf(p, format, &dest[i * itemSize]);
    }
}
}
}

