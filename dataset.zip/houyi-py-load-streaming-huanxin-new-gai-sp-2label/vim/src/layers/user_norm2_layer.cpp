/**
 * user_norm2_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-26
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "user_norm2_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {

UserNorm2Layer::UserNorm2Layer(Norm2Config& config) : Layer(config) {
    set_device();
    _config    = config;
}

UserNorm2Layer::UserNorm2Layer(UserNorm2Layer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) UserNorm2Layer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void UserNorm2Layer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void UserNorm2Layer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);

    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}

void UserNorm2Layer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Dim dim = pre_in->get_size();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    CHECK(pre_in->get_element_count() % pre_in->get_size(0) == 0, "param error");
    pre_in->reshape(Dim(pre_in->get_size(0), pre_in->get_element_count() / pre_in->get_size(0)));
    out->reshape(Dim(pre_in->get_size(0), pre_in->get_element_count() / pre_in->get_size(0)));

    // _norm2 在bp 时需要使用
    _norm2.resize(Dim(1, pre_in->get_h()));
    wind_norm2_op(*pre_in, _norm2, *out);

    pre_in->reshape(dim);
    out->reshape(dim);
}

void UserNorm2Layer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    Dim dim = pre_diff->get_size();
    pre_diff->reshape(Dim(pre_diff->get_size(0),
                          pre_diff->get_element_count() / pre_diff->get_size(0)));
    local_diff->reshape(Dim(pre_diff->get_size(0),
                            pre_diff->get_element_count() / pre_diff->get_size(0)));
    out->reshape(Dim(pre_diff->get_size(0), pre_diff->get_element_count() / pre_diff->get_size(0)));

    _diff_buf.resize(pre_diff->get_size());
    _diff_buf.elem_mul(*local_diff, *out, 1.0f, 0.0f);
    _vec_buf.resize(Dim(1, _diff_buf.get_h()));
    _vec_buf.row_sum(_diff_buf);

    _diff_buf.col_mul_vec(*out, _vec_buf, -1.0f, 0.0f);
    _diff_buf.elem_add(*local_diff, _diff_buf, 1.0f, 1.0f);

    //div norm2
    pre_diff->col_mul_vec(_diff_buf, _norm2, 1.0f, 1.0f);

    pre_diff->reshape(dim);
    local_diff->reshape(dim);
    out->reshape(dim);
}

Layer* UserNorm2Layer::clone() {
    return new UserNorm2Layer(this);
}

}
}

