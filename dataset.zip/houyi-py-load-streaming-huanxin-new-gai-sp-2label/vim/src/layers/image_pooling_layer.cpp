/**
 * PoolingLayer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-22
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <glog/logging.h>
#include "image_pooling_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {
PoolingLayer::PoolingLayer(ImagePoolingConfig& cfg) : Layer(cfg) {
    _mask.set_device(gpu_device());
    init();
    _cfg = cfg;

    _pooling_type = cfg.get_pooling_type();
    _win_height = cfg.get_win_height();
    _win_width = cfg.get_win_width();
    _stride_height = cfg.get_stride_height();
    _stride_width = cfg.get_stride_width();
    _padding_width = cfg.get_padding_width();
    _padding_height = cfg.get_padding_height();
    _cal_mask = cfg.get_cal_mask();
    _skip_label = cfg.get_skip_label();

    _pooling_desc.win_height = _win_height;
    _pooling_desc.win_width = _win_width;
    _pooling_desc.stride_h = _stride_height;
    _pooling_desc.stride_w = _stride_width;
    _pooling_desc.pad_h = _padding_height;
    _pooling_desc.pad_w = _padding_width;
    _pooling_desc.pooling_type = _pooling_type;

    build_map();
}
void PoolingLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK2(inputs.size() == 2 || inputs.size() == 1);
    _sample_num = sample_num;

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void PoolingLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();
    CHECK(4 == input_size.get_size(), "ImagePoolingLayer input must be 4D");
    _sample_num = sample_num;
    int in_h = input_size[2];
    int in_w = input_size[3];
    int out_h = 0;
    int out_w = 0;

    if (_cfg.get_global_pooling()) {
        _pooling_desc.win_height = in_h;
        _win_height = in_h;
        _pooling_desc.win_width = in_w;
        _win_width = in_w;
        out_h = 1;
        out_w = 1;
    } else {
        // according to caffe
        out_h = 1 + ceil(1.0 * (in_h - _win_height + 2 * _padding_height) / _stride_height);
        out_w = 1 + ceil(1.0 * (in_w - _win_width + 2 * _padding_width) / _stride_width);
        if ((out_h - 1) * _stride_height >= in_h + _padding_height) {
            --out_h;
        }
        if ((out_w - 1) * _stride_width >= in_w + _padding_width) {
            --out_w;
        }
    }

    output(_output_keys[0]).resize(Dim(input_size[0], input_size[1], out_h,
                                       out_w), inputs[0]->get_mask(), gpu_device());

    // 时间维发生变化，对label进行处理
    if (inputs.size() == 2) {
        CHECK2(_skip_label);
        Dim dim = inputs[1]->get_size();
        CHECK2(dim[1] == 1);
        Layer::output(_output_keys[1]).resize(Dim(out_h * sample_num, 1), gpu_device());
    }
}

void PoolingLayer::init() {
    _pooling_type = POOL_TYPE_UNKNOWN;
    _win_height = 0;
    _win_width = 0;
    _stride_height = 0;
    _stride_width = 0;
}

void PoolingLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input = in_pack[0]->get_ten();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();

    output->pool_fwd(_pooling_desc, *input, 1.0f, 1.0f);

    //注意：必须保证是语音的输入, mask数据分布为frame_num * batch_size
    //特征batch_size 必须放在第一维batch_size 放在第一维
    if (_cal_mask) {
        int batch_size = in_pack[0]->get_size(0);
        int max_out_h = output->get_size(2);
        _mask.resize(mask->get_size(), false);
        _mask.copy_from(*mask);
        mask->resize(Dim(max_out_h * batch_size), false);
        wind_image_pool_cal_mask(*output, *mask, _mask, _win_height, _padding_height, _stride_height);
    }
    
    // 时间维发生变化
    if (_skip_label) {
        CHECK2(_output_keys.size() == 2);
        CHECK2(in_pack.size() == 2);

        Tensor<DType>* input2 = in_pack[1]->get_ten();
        Tensor<DType>* output2 = Layer::output(_output_keys[1]).get_ten();

        // copy output1 mask to output2 mask
        Tensor<int>* mask1 = Layer::output(_output_keys[0]).get_mask();
        Tensor<int>* mask2 = Layer::output(_output_keys[1]).get_mask();
        CHECK2(mask1->get_size() == mask2->get_size());
        mask2->copy_from(*mask1);
        // in_h - _win_height + 2 * _padding_height) / _stride_height)
        wind_image_conv_skip_label(*input2, *output2,
                _win_height,
                _padding_height,
                _stride_height, _sample_num);
    }
}

void PoolingLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();
    Tensor<DType>* input = in_pack[0]->get_ten();

    out_diff->pool_bp(_pooling_desc, *output, *in_diff, *input, 1.0f, 1.0f);
}

void PoolingLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    // nothing to do
}

}
}
