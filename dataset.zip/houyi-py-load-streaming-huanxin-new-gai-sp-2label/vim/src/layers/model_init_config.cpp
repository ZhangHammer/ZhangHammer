/**
 * model_init_config.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-04-28
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "nn_config.h"
#include "tools.h"

namespace houyi {
namespace train {

const char* ModelInitTypeName[] = {
    "gauss",
    "constant",
    "model",
    "uniform",
    "MSRA",
    "Xavier",
    "modelInitTypeUnknown"
};

const char* MSRATypeName[] = {
    "in",
    "out",
    "avg",
    "typeUnknown"
};

const char* XavierTypeName[] = {
    "in",
    "out",
    "avg",
    "typeUnknown"
};

void ModelInitConfig::read(std::string& cfg_lines) {
    // config for model initalization
    parse_from_string("initMean", &cfg_lines, &_init_mean);
    parse_from_string("initStdv", &cfg_lines, &_init_stdv);
    parse_from_string("modelFile", &cfg_lines, &_model_name);
    parse_from_string("modelCfg", &cfg_lines, &_model_cfg);
    parse_from_string("modelStart", &cfg_lines, &_model_start);
    parse_from_string("modelEnd", &cfg_lines, &_model_end);
    parse_from_string("heterFile", &cfg_lines, &_heter_name);
    parse_from_string("heterStart", &cfg_lines, &_heter_start);
    parse_from_string("heterEnd", &cfg_lines, &_heter_end);
    parse_from_string("hfnnFile", &cfg_lines, &_hfnn_name);
    parse_from_string("hfnnStart", &cfg_lines, &_hfnn_start);
    parse_from_string("hfnnEnd", &cfg_lines, &_hfnn_end);
    parse_from_string("mdModelFile", &cfg_lines, &_md_model_name);
    parse_from_string("inqModelFile", &cfg_lines, &_inq_model_name);

    std::string param;

    if (parse_tuple_from_string("weightFiller", &cfg_lines, &param)) {
        INTER_LOG("<weightFiller>");

        std::string type;

        if (parse_from_string("type", &param, &type)) {
            string_to_enum(type, ModelInitTypeName, &_weight_init_type);
            INTER_LOG("type = %s", type.c_str());
        }

        switch (_weight_init_type) {
        case GAUSS_INIT:
            parse_from_string("mean", &param, &_weight_mean);
            INTER_LOG("mean = %f", _weight_mean);
            parse_from_string("stdv", &param, &_weight_stdv);
            INTER_LOG("stdv = %f", _weight_stdv);
            break;

        case CONSTANT_INIT:
            parse_from_string("value", &param, &_weight_value);
            INTER_LOG("value = %f", _weight_value);
            break;

        case MODEL_INIT:
            parse_from_string("name", &param, &_weight_name);
            INTER_LOG("name = %s", _weight_name.c_str());
            break;

        case UNIFORM_INIT:
            parse_from_string("max", &param, &_weight_max);
            INTER_LOG("max = %f", _weight_max);
            parse_from_string("min", &param, &_weight_min);
            INTER_LOG("min = %f", _weight_min);
            break;

        case MSRA_INIT: {
            std::string msra_type;

            if (parse_from_string("MSRAType", &param, &msra_type)) {
                string_to_enum(msra_type, MSRATypeName, &_weight_msra_type);
                INTER_LOG("MSRAType = %s", msra_type.c_str());
            }

            break;
        }

        case XAVIER_INIT: {
            std::string xavier_type;

            if (parse_from_string("XavierType", &param, &xavier_type)) {
                string_to_enum(xavier_type, XavierTypeName, &_weight_xavier_type);
                INTER_LOG("XavierType = %s", xavier_type.c_str());
            }

            break;
        }

        default:
            CHECK(false, "weigit init type error");
        }

        INTER_LOG("</weightFiller>");
    }

    if (parse_tuple_from_string("biasFiller", &cfg_lines, &param)) {
        INTER_LOG("<biasFiller>");

        std::string type;

        if (parse_from_string("type", &param, &type)) {
            string_to_enum(type, ModelInitTypeName, &_bias_init_type);
            INTER_LOG("type = %s", type.c_str());
        }

        switch (_bias_init_type) {
        case GAUSS_INIT:
            parse_from_string("mean", &param, &_bias_mean);
            INTER_LOG("mean = %f", _bias_mean);
            parse_from_string("stdv", &param, &_bias_stdv);
            INTER_LOG("stdv = %f", _bias_stdv);
            break;

        case CONSTANT_INIT:
            parse_from_string("value", &param, &_bias_value);
            INTER_LOG("value = %f", _bias_value);
            break;

        case MODEL_INIT:
            parse_from_string("name", &param, &_bias_name);
            INTER_LOG("value = %s", _bias_name.c_str());
            break;

        case UNIFORM_INIT:
            parse_from_string("max", &param, &_bias_max);
            INTER_LOG("max = %f", _bias_max);
            parse_from_string("min", &param, &_bias_min);
            INTER_LOG("min = %f", _bias_min);
            break;

        case MSRA_INIT: {
            std::string msra_type;

            if (parse_from_string("MSRAType", &param, &msra_type)) {
                string_to_enum(msra_type, MSRATypeName, &_bias_msra_type);
                INTER_LOG("MSRAType = %s", msra_type.c_str());
            }
        }
        break;

        case XAVIER_INIT: {
            std::string xavier_type;

            if (parse_from_string("XavierType", &param, &xavier_type)) {
                string_to_enum(xavier_type, XavierTypeName, &_bias_xavier_type);
                INTER_LOG("XavierType = %s", xavier_type.c_str());
            }

            break;
        }

        default:
            CHECK(false, "weigit init type error");
        }

        INTER_LOG("</biasFiller>");
    }

    CHECK((_bias_init_type != MODEL_INIT && _weight_init_type != MODEL_INIT) ||
          (_bias_init_type == MODEL_INIT && _weight_init_type == MODEL_INIT),
          "weight init type and  bias init type must be model init in same time");

}

}
} //namespace houyi

