/**
 * layer_config.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include <string>
#include "tools.h"
#include "layer_config.h"

namespace houyi {
namespace train {

/*
 * param:解析的字符
 * value:存储在变量value里面
 * format打印的格式声明
 */
#define PARSE_PARAM(param, value, format) \
    parse_from_string(#param, &cfg_line, &value); \
    INTER_LOG(#param#format, value)

static const char* actTypeName[] = {
    "linear",
    "sigmoid",
    "tanh",
    "relu",
    "maxout",
    "logrelu",
    NULL
};

static const char* bitQuantAlgo[] = {
    "bit",
    "greedy",
    "fixed",
    NULL
};

static const char* layerTypeName[] = {
    "full",
    "lstm",
    "conv",
    "batNorm",
    "statisc",
    "linear",
    "image_conv",
    "image_pool",
    "softmax",
    "loss_ce",
    "loss_mse",
    "loss_ctc",
    "drop_out",
    "image_bat_norm",
    "norm2",
    "loss_triplet",
    "roi_pool",
    "softmax_norm",
    "reshape",
    "python",
    "loss_smooth_l1",
    "anchor_target",
    "proposal",
    "proposal_target",
    "faster_rcnn_acu",
    "PSROIPooling",
    "rfcn_acu",
    "loss_smooth_ohem_l1",
    "transpose",
    "expand",
    "skip",
    "box_annotator_ohem",
    "data_layer",
    "batRenorm",
    "split",
    "gru",
    "redim",
    "fast_gru",
    "loss_focal",
    "audio_delta",
    "audio_splice",
    "bit_quant",
    "audio_roi_pool",
    "image_conv_quant",
    "global_cmvn",
    "loss_lr",
    "loss_mix_lr",
    NULL
};

static const char* g_image_conv_algo_seeker_type[] = {
    "get",
    "find",
};

static const char* g_image_pooling_type_name[] = {
    "maxPooling",
    "avgPoolingPadding",
    "avgPooling"
};

static const char* g_audio_roi_pooling_type_name[] = {
    "max",
    "avg"
};

static const char* g_image_bat_norm_type_name[] = {
    "norm_1chw",
    "norm_1c11"
};

static const char* costTypeName[] = {
    /* 似然值 */
    "acu",
    /* loss layer的loss */
    "err",
    /* 分类的精度 */
    "classify_acu",
    /* 分类的loss */
    "classify_err",
};

bool is_loss_layer(LayerType type) {
    switch (type) {
    case LOSS_CE:
    case LOSS_MSE:
    case LOSS_TRIPLET:
    case LOSS_CTC:
    case LOSS_SMOOTH_L1:
    case LOSS_SMOOTH_OHEM_L1:
    case LOSS_LR:
    case LOSS_MIX_LR:
        return true;

    default:
        return false;
    }
}

std::string get_layer_type_str(LayerType type) {
    CHECK(type < sizeof(layerTypeName), "get_layer_type_str error"); 
    return layerTypeName[(size_t)type];
}

void UpdaterConfig::read(std::string& cfg_line) {
    std::string lr_param;

    if (parse_tuple_from_string("gd", &cfg_line, &lr_param)) {
        INTER_LOG("<gd>");

        parse_from_string("type", &lr_param, &_type);
        INTER_LOG("type = %s", _type.c_str());

        parse_from_string("l2Penalty", &lr_param, &_l2_penalty);
        INTER_LOG("l2Penalty = %f", _l2_penalty);

        parse_from_string("threshold", &lr_param, &_threshold);
        INTER_LOG("threshold = %f", _threshold);
        parse_from_string("ratioThreshold", &lr_param, &_threshold_ratio);
        INTER_LOG("ratioThreshold = %f", _threshold_ratio);

        /* sgd */
        if (_type == "sgd") {
            parse_from_string("learnRate", &lr_param, &_learn_rate);
            INTER_LOG("learnRate = %f", _learn_rate);
            parse_from_string("momentum", &lr_param, &_momentum);
            INTER_LOG("momentum = %f", _momentum);
        }
        else if (_type == "nesterov-sgd") {
            parse_from_string("learnRate", &lr_param, &_learn_rate);
            INTER_LOG("learnRate = %f", _learn_rate);
            parse_from_string("momentum", &lr_param, &_momentum);
            INTER_LOG("momentum = %f", _momentum);
        }
        /* adam */
        else if (_type == "adam") {
            parse_from_string("beta1", &lr_param, &_beta1);
            INTER_LOG("beta1 = %f", _beta1);
            parse_from_string("beta2", &lr_param, &_beta2);
            INTER_LOG("beta2 = %f", _beta2);
            parse_from_string("lambda", &lr_param, &_lambda);
            INTER_LOG("lambda = %f", _lambda);
            parse_from_string("alpha", &lr_param, &_alpha);
            INTER_LOG("alpha= %f", _alpha);
        }
        /* rms */
        else if (_type == "rms") {
            parse_from_string("rmsGamma", &lr_param, &_rms_gamma);
            INTER_LOG("rmsGamma= %f", _rms_gamma);
            parse_from_string("rmsEta", &lr_param, &_rms_eta);
            INTER_LOG("rmsEta = %f", _rms_eta);
        } else {
            CHECK(false, "updater type error");
        }

        INTER_LOG("</gd>");
    }

    //todo: remove
    parse_from_string("updateType", &cfg_line, &_type);
    INTER_LOG("updateType = %s", _type.c_str());
    parse_from_string("learnRate", &cfg_line, &_learn_rate);
    INTER_LOG("learnRate = %f", _learn_rate);
    parse_from_string("momentum", &cfg_line, &_momentum);
    INTER_LOG("momentum = %f", _momentum);
    parse_from_string("l2Penalty", &cfg_line, &_l2_penalty);
    INTER_LOG("l2Penalty = %f", _l2_penalty);
    parse_from_string("threshold", &cfg_line, &_threshold);
    INTER_LOG("threshold = %f", _threshold);
    parse_from_string("ratioThreshold", &cfg_line, &_threshold_ratio);
    INTER_LOG("ratioThreshold = %f", _threshold_ratio);
}

LayerConfig::LayerConfig() {
    _layer_id  = -1;
    _type = UNKNOWN_LAYER;
    _act = ACT_LINEAR;
    _batch_size = 1;
    _sub_seq_size = 0;

    _has_bias = true;
    _need_update = true;
    _read = true;

    _is_reversal = false;

    _layer_result_output_num = 500;

    _job_type = UNKNOWN_JOB;
    _global_job_type = UNKNOWN_JOB;

    _inq = false;      
    _inq_ratio.clear();
    _inq_bit = 5;      

    _weight_quantize = false;
    _weight_quant_transpose = true;
    _weight_fixed_transpose = false;
    _weight_quant_bits = 0;
    _intl_quant_bits = 0;
    _intl_quant_algo = QUANT_BIT;
    _feature_share_input = false;
}

void LayerConfig::read_config(std::string& cfg_lines) {
    //INTER_LOG("cfg_line %s", cfg_lines.c_str());
    // config for model initalization
    parse_from_string("name", &cfg_lines, &_layer_name);
    INTER_LOG("name = %s", _layer_name.c_str());
#if 0
    CHECK(!_layer_name.empty(), "layer name must be set");
#endif
    parse_from_string("hasBias", &cfg_lines, &_has_bias);
    INTER_LOG("hasBias = %d", _has_bias);
    parse_from_string("read", &cfg_lines, &_read);
    INTER_LOG("read = %d", _read);
    parse_from_string("inputs", &cfg_lines, &_input_keys);

    for (auto i : _input_keys) {
        INTER_LOG("inputs: %s", i.c_str());
    }
    parse_from_string("featureShareInput", &cfg_lines, &_feature_share_input);
    INTER_LOG("featureShareInput = %d", _feature_share_input);

#if 0
    CHECK(!_input_keys.empty(), "inputs must be set");
#endif
    parse_from_string("outputs", &cfg_lines, &_output_keys);

    for (auto i : _output_keys) {
        INTER_LOG("outputs: %s", i.c_str());
    }

    if (_output_keys.empty()) {
        _output_keys.push_back(_layer_name);
    }

    parse_from_string("desc", &cfg_lines, &_feat_desc_keys);

    parse_from_string("isReversed", &cfg_lines, &_is_reversal);
    INTER_LOG("isReversed = %d", _is_reversal);
    parse_from_string("label", &cfg_lines, &_label_key);

    for (auto i : _label_key) {
        INTER_LOG("label: %s", i.c_str());
    }

    parse_from_string("layerResultOutNum", &cfg_lines, &_layer_result_output_num);
    INTER_LOG("layerResultOutNum = %d", _layer_result_output_num);
    _bp_down = std::vector<int>(_input_keys.size(), 1);
    parse_from_string("bpDown", &cfg_lines, &_bp_down);

    for (auto i : _bp_down) {
        INTER_LOG("bpDown = %d", i);
        CHECK(i == 0 || i == 1, "bpDown must be 0 or 1");
    }

    std::string act_str;

    if (parse_from_string("actType", &cfg_lines, &act_str)) {
        string_to_enum(act_str, actTypeName, &_act);
    }

    INTER_LOG("actType = %s", act_str.c_str());
    _up_cfg.read(cfg_lines);

    _model_init_cfg.clear_mean_stdv();
    _model_init_cfg.read(cfg_lines);
    CHECK(_model_init_cfg.model_name().empty(), "model name must be not set");
    CHECK(_model_init_cfg.md_model_name().empty(), "md model name must be not set");
    CHECK(_model_init_cfg.heter_name().empty(), "heter model name must be not set");
    CHECK(_model_init_cfg.hfnn_name().empty(), "hfnn model name must be not set");

    std::string job_str;

    if (parse_from_string("jobType", &cfg_lines, &job_str)) {
        string_to_enum(job_str, jobTypeName, &_job_type);
    }

    parse_from_string("inq", &cfg_lines, &_inq);
    INTER_LOG("inq = %d", _inq);              

    parse_from_string("weightQuant", &cfg_lines, &_weight_quantize);
    INTER_LOG("weightQuant = %d", _weight_quantize);
    parse_from_string("weightQuantTranspose", &cfg_lines, &_weight_quant_transpose);
    INTER_LOG("weightQuantTranspose = %d", _weight_quant_transpose);
    parse_from_string("weightQuantBits", &cfg_lines, &_weight_quant_bits);
    INTER_LOG("weightQuantBits = %lu", _weight_quant_bits);
    parse_from_string("intlQuantBits", &cfg_lines, &_intl_quant_bits);
    INTER_LOG("intlQuantBits = %lu", _intl_quant_bits);
    parse_from_string("intlQuantAlpha", &cfg_lines, &_intl_quant_alpha);
    for (auto i : _intl_quant_alpha) {
        INTER_LOG("internal quantization alpha = %f", i);
    }

    std::string intl_quant_algo_str;
    if (parse_from_string("intlQuantAlgo", &cfg_lines, &intl_quant_algo_str)) {
        string_to_enum(intl_quant_algo_str, bitQuantAlgo, &_intl_quant_algo); 
        INTER_LOG("internal quantization algo = %s", intl_quant_algo_str.c_str());
    }
}

LayerConfig* LayerConfig::creat_layer_cfg(LayerType type) {
    LayerConfig* cfg = nullptr;

    switch (type) {
    case FULL: {
        cfg = new FullConfig();
        break;
    }

    case LSTM: {
        cfg = new LstmConfig();
        break;
    }

    case CONV: {
        cfg = new ConvConfig();
        break;
    }

    case BAT_NORM: {
        cfg = new BatNormConfig();
        break;
    }

    case IMAGE_BAT_NORM: {
        cfg = new ImageBatNormConfig();
        break;
    }

    case STATISC: {
        cfg = new StatisConfig();
        break;
    }

    case LINEAR: {
        cfg = new LinearConfig();
        break;
    }

    case IMAGE_CONV: {
        cfg = new ImageConvConfig();
        break;
    }

    case IMAGE_POOL: {
        cfg = new ImagePoolingConfig();
        break;
    }

    case SOFTMAX_WITH_LOSS: {
        cfg = new SoftmaxWithLossConfig();
        break;
    }

    case SOFTMAX_NORM: {
        cfg = new NormSoftmaxConfig();
        break;
    }

    case LOSS_CE: {
        cfg = new LossConfig(LOSS_CE);
        break;
    }

    case LOSS_MSE: {
        cfg = new LossConfig(LOSS_MSE);
        break;
    }

    case LOSS_CTC: {
        cfg = new LossConfig(LOSS_CTC);
        break;
    }

    case LOSS_TRIPLET: {
        cfg = new LossConfig(LOSS_TRIPLET);
        break;
    }

    case LOSS_SMOOTH_L1: {
        cfg = new LossConfig(LOSS_SMOOTH_L1);
        break;
    }

    case LOSS_SMOOTH_OHEM_L1: {
        cfg = new LossConfig(LOSS_SMOOTH_OHEM_L1);
        break;
    }

    case DROP_OUT: {
        cfg = new DropOutConfig();
        break;
    }

    case NORM2: {
        cfg = new Norm2Config();
        break;
    }

    case ROI_POOL: {
        cfg = new ROIPoolConfig();
        break;
    }

    case PS_ROI_POOL: {
        cfg = new PSROIPoolConfig();
        break;
    }

    case RESHAPE: {
        cfg = new ReshapeConfig();
        break;
    }

    case REDIM: {
        cfg = new RedimConfig();
        break;
    }

    case TRANSPOSE: {
        cfg = new TransposeConfig();
        break;
    }

    case PYTHON: {
        cfg = new PythonConfig();
        break;
    }

    case FASTER_RCNN_ACU: {
        cfg = new FasterRCNNACUConfig();
        break;
    }

    case RFCN_ACU: {
        cfg = new RfcnAcuConfig();
        break;
    }

    case EXPAND: {
        cfg = new ExpandConfig();
        break;
    }

    case SKIP: {
        cfg = new SkipConfig();
        break;
    }

    case BOX_ANNOTATOR_OHEM: {
        cfg = new BoxAnnotatorOHEMConfig();
        break;
    }

    case BAT_RENORM: {
        cfg = new BatRenormConfig();
        break;
    }

    case GRU: {
        cfg = new GruConfig();
        break;
    }

    case FAST_GRU: {
        cfg = new FastGruConfig();
        break;
    }
    case LOSS_FOCAL : {
        cfg = new LossConfig(LOSS_FOCAL);
        break;
    }
    
    case AUDIO_DELTA: {
        cfg = new AudioDeltaConfig();
        break;
    }
    case AUDIO_SPLICE: {
        cfg = new AudioSpliceConfig();
        break;
    }
    case BIT_QUANT: {
        cfg = new BitQuantConfig();
        break;
    }
    case AUDIO_ROI_POOL: {
        cfg = new AudioROIPoolConfig();
        break;
    }
    case IMAGE_CONV_QUANT: {
        cfg = new ImageConvQuantConfig();
        break;
    }
    case GLOBAL_CMVN: {
        cfg = new GlobalCmvnConfig();
        break;
    }
    case LOSS_LR: {
        cfg = new LossConfig(LOSS_LR);
        break;
    }

    case LOSS_MIX_LR: {
        cfg = new LossConfig(LOSS_MIX_LR);
        break;
    }
    default:
        CHECK(false, "error layer type");
    }

    return cfg;
}

LayerConfig* LayerConfig::read(std::ifstream& input) {
    std::string cfg_line;
    std::string type;
    LayerType em_type = UNKNOWN_LAYER;
    LayerConfig* cfg = NULL;

    stream_to_string(input, "[end]", cfg_line);

    if (parse_from_string("type", &cfg_line, &type)) {
        string_to_enum(type, layerTypeName, &em_type);
    }

    cfg = creat_layer_cfg(em_type);

    if (cfg) {
        cfg->read_config(cfg_line);
    }

    return cfg;
}

FullConfig::FullConfig() : LayerConfig() {
    _type   = FULL;
    _output_dim = 0;
}

void FullConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("insertModelCol", &cfg_line, &_insert_model_col);
    INTER_LOG("insertModelCol = %d", _insert_model_col);

    parse_from_string("insertModelLen", &cfg_line, &_insert_model_len);
    INTER_LOG("insertModelLen = %d", _insert_model_len);

    parse_from_string("outDim", &cfg_line, &_output_dim);
    INTER_LOG("outDim = %d", _output_dim);
    CHECK(_output_dim > 0, "outDim must be set");
}

ConvConfig::ConvConfig() : LayerConfig() {
    _type     = CONV;
    _group_num = 0;
    _filter_size = 0;
    _filter_num  = 0;
    _fbank_dim   = 0;
    _temporal_dim = 0;
    _conv_out_dim  = 0;
    _delta = 0;

    _conv_start_pos = NULL;
    _conv_end_pos   = NULL;
    _conv_size      = NULL;

    _pooling_size  = 0;
    _pooling_pivot = NULL;
    _pooling_out_dim = 0;
    
    _weight_quant_transpose = false;
    _weight_fixed_transpose = true;
}

ConvConfig::~ConvConfig() {
    if (_conv_start_pos) {
        free(_conv_start_pos);
        _conv_start_pos = NULL;
    }

    if (_conv_end_pos) {
        free(_conv_end_pos);
        _conv_end_pos = NULL;
    }

    if (_conv_size) {
        free(_conv_size);
        _conv_size = NULL;
    }

    if (_pooling_pivot) {
        free(_pooling_pivot);
        _pooling_pivot = NULL;
    }
}

void ConvConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    std::vector<int> start_vec;
    start_vec.clear();
    std::vector<int> end_vec;
    end_vec.clear();
    std::vector<int> pivot_vec;
    pivot_vec.clear();

    parse_from_string("groupNum", &cfg_line, &_group_num);
    INTER_LOG("groupNum = %d", _group_num);
    parse_from_string("filterSize", &cfg_line, &_filter_size);
    INTER_LOG("filterSize = %d", _filter_size);

    parse_from_string("filterNum", &cfg_line, &_filter_num);
    INTER_LOG("filterNum = %d", _filter_num);
    parse_from_string("fbankDim", &cfg_line, &_fbank_dim);
    INTER_LOG("fbankDim = %d", _fbank_dim);
    parse_from_string("splice", &cfg_line, &_temporal_dim);
    INTER_LOG("splice = %d", _temporal_dim);
    parse_from_string("delta", &cfg_line, &_delta);
    INTER_LOG("delta = %d", _delta);
    parse_from_string("poolingSize", &cfg_line, &_pooling_size);
    INTER_LOG("poolingSize = %d", _pooling_size);

    parse_from_string("convStart", &cfg_line, &start_vec);
    CHECK2(start_vec.size() == (size_t)_group_num);
    _conv_start_pos = (int*)malloc(_group_num * sizeof(int));

    for (int i = 0; i < _group_num; i++) {
        _conv_start_pos[i] = start_vec[i];
        INTER_LOG("convStart: %d", _conv_start_pos[i]);
    }

    parse_from_string("convEnd", &cfg_line, &end_vec);
    CHECK2(end_vec.size() == (size_t)_group_num);
    _conv_end_pos = (int*)malloc(_group_num * sizeof(int));

    for (int i = 0; i < _group_num; i++) {
        _conv_end_pos[i] = end_vec[i];
        INTER_LOG("convEnd: %d", _conv_end_pos[i]);
    }

    parse_from_string("poolingPivot", &cfg_line, &pivot_vec);
    _pooling_out_dim = pivot_vec.size();
    _pooling_pivot = (int*)malloc(_pooling_out_dim * sizeof(int));

    for (int i = 0; i < _pooling_out_dim; i++) {
        _pooling_pivot[i] = pivot_vec[i];
        INTER_LOG("poolingPivot: %d", _pooling_pivot[i]);
    }

    _temporal_dim *= _delta;
    _conv_out_dim = 0;
    _conv_size = (int*)malloc(sizeof(int) * _group_num);

    for (int i = 0; i < _group_num; ++i) {
        _conv_size[i] = _conv_end_pos[i] - _conv_start_pos[i] + 1;
        _conv_out_dim += _conv_size[i];
    }
}

ConvConfig& ConvConfig::operator=(ConvConfig& cfgIn) {
    LayerConfig::operator=(cfgIn);

    _filter_num = cfgIn.filter_num();
    _group_num  = cfgIn.group_num();
    _filter_size = cfgIn.filter_size();
    _filter_num = cfgIn.filter_num();
    _fbank_dim = cfgIn.fbank_num();
    _temporal_dim = cfgIn.temporal_dim();
    _conv_out_dim = cfgIn.conv_out_dim();
    _delta = cfgIn.delta();
    _conv_start_pos = (int*) malloc(sizeof(int) * _group_num);
    _conv_end_pos = (int*) malloc(sizeof(int) * _group_num);
    _conv_size = (int*) malloc(sizeof(int) * _group_num);
    _pooling_pivot = (int*) malloc(sizeof(int) * cfgIn.pooling_out_dim());

    cfgIn.conv_pos(_conv_start_pos, _conv_end_pos, _conv_size);
    cfgIn.pooling(_pooling_pivot, _pooling_size, _pooling_out_dim);

    _layer_id = cfgIn.layer_id();
    return *(this);
}

LstmConfig::LstmConfig() : LayerConfig() {
    _type    = LSTM;
    _cell_dim = 1024;
    _rec_dim = 0;
    _prj_dim = 0;
    _output_dim = 178;
    _rec_act = ACT_TANH;
    _mid_act = ACT_UNKNOWN;
    _pooling_size = 0;
    _no_forget_gate = 0;

    _skip_num = 1;

    _tbptt    = 1;
    _updatett = -1;
    _batch_size = 1;
    _sub_seq_size = 20;

    _error_statistic_num = _cec_o_statistic_num = 0;
    _cec_out_limit_lo = -1.0f;
    _cec_out_limit_hi = -1.0f;
    _dr_threshold = _dc_threshold = -1.0f;
    _drop_gradient = false;

    _mean_statistic_num = 0;
}

void LstmConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    CHECK(_label_key.size() == 0, "label don't requre to be set now");

    parse_from_string("skipNum", &cfg_line, &_skip_num);
    INTER_LOG("skipNum = %d", _skip_num);
    parse_from_string("cellDim", &cfg_line, &_cell_dim);
    INTER_LOG("cellDim = %d", _cell_dim);

    parse_from_string("recDim", &cfg_line, &_rec_dim);
    INTER_LOG("recDim = %d", _rec_dim);
    parse_from_string("prjDim", &cfg_line, &_prj_dim);
    INTER_LOG("prjDim = %d", _prj_dim);
    parse_from_string("outDim", &cfg_line, &_output_dim);
    INTER_LOG("outDim = %d", _output_dim);
    parse_from_string("Tbptt", &cfg_line, &_tbptt);
    INTER_LOG("Tbptt = %d", _tbptt);
    parse_from_string("Updatett", &cfg_line, &_updatett);
    INTER_LOG("Updatett = %d", _updatett);

    parse_from_string("meanStatisticNum", &cfg_line, &_mean_statistic_num);
    INTER_LOG("meanStatisticNum = %d", _mean_statistic_num);
    parse_from_string("errorStatisticNum", &cfg_line, &_error_statistic_num);
    INTER_LOG("errorStatisticNum = %d", _error_statistic_num);
    parse_from_string("cec_o_statistic_num", &cfg_line, &_cec_o_statistic_num);
    INTER_LOG("cec_o_statistic_num = %d", _cec_o_statistic_num);
    parse_from_string("cecOutLimitLow", &cfg_line, &_cec_out_limit_lo);
    INTER_LOG("cecOutLimitLow = %f", _cec_out_limit_lo);
    parse_from_string("cecOutLimitHight", &cfg_line, &_cec_out_limit_hi);
    INTER_LOG("cecOutLimitHight = %f", _cec_out_limit_hi);
    parse_from_string("dRThreshold", &cfg_line, &_dr_threshold);
    INTER_LOG("dRThreshold = %f", _dr_threshold);
    parse_from_string("dCThreshold", &cfg_line, &_dc_threshold);
    INTER_LOG("dCThreshold = %f", _dc_threshold);
    parse_from_string("dropGradient", &cfg_line, &_drop_gradient);
    INTER_LOG("dropGradient = %d", _drop_gradient);
    parse_from_string("noForgetGate", &cfg_line, &_no_forget_gate);
    INTER_LOG("noForgetGate = %d", _no_forget_gate);
    parse_from_string("poolingSize", &cfg_line, &_pooling_size);
    INTER_LOG("poolingSize = %d", _pooling_size);

    std::string type;

    if (parse_from_string("recActType", &cfg_line, &type)) {
        string_to_enum(type, actTypeName, &_rec_act);
        INTER_LOG("recActType = %s", type.c_str());
    }

    if (parse_from_string("midActType", &cfg_line, &type)) {
        string_to_enum(type, actTypeName, &_mid_act);
        INTER_LOG("midActType = %s", type.c_str());
    }
}

void GruConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    PARSE_PARAM(outDim, _out_dim, =%d);
    PARSE_PARAM(Tbptt, _tbptt, %d); 
    PARSE_PARAM(Updatett, _updatett, %d); 
    // PARSE_PARAM(threshold, _threshold, %f); 
    // PARSE_PARAM(ratioThreshold, _threshold_ratio, %f); 
    PARSE_PARAM(meanStatisticNum, _mean_statistic_num, %d); 
    PARSE_PARAM(skipNum, _skip_num, %d);
}

void FastGruConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    PARSE_PARAM(outDim, _out_dim, =%d);
    PARSE_PARAM(Tbptt, _tbptt, %d); 
    PARSE_PARAM(Updatett, _updatett, %d); 
    // PARSE_PARAM(threshold, _threshold, %f); 
    // PARSE_PARAM(ratioThreshold, _threshold_ratio, %f); 
    PARSE_PARAM(meanStatisticNum, _mean_statistic_num, %d); 
    PARSE_PARAM(skipNum, _skip_num, %d);
}

BatNormConfig::BatNormConfig() : LayerConfig() {
    _type   = BAT_NORM;
    _eta = 1.0;
    _moving_average_fraction = 0.9;
}

BatNormConfig::~BatNormConfig() {
}

void BatNormConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("globalMeanVar", &cfg_line, &_mean_var_file);
    INTER_LOG("globalMeanVar = %s", _mean_var_file.c_str());
    parse_from_string("eta", &cfg_line, &_eta);
    INTER_LOG("eta = %f", _eta);
    parse_from_string("movingAverageFraction", &cfg_line, &_moving_average_fraction);
    INTER_LOG("movingAverageFraction = %f", _moving_average_fraction);
    CHECK(_label_key.size() == 0, "label don't requre to be set now");
}

BatRenormConfig::BatRenormConfig() {
    _type   = BAT_RENORM;
    _epsilon = 1e-6;
    _deta = 0.01;
    _r_max = 1.0;
    _d_max = 0.0;
}

BatRenormConfig::~BatRenormConfig() {
}

void BatRenormConfig::read_config(std::string& cfg_line) {
    FullConfig::read_config(cfg_line);
    parse_from_string("globalMeanVar", &cfg_line, &_mean_var_file);
    INTER_LOG("globalMeanVar = %s", _mean_var_file.c_str());
    parse_from_string("deta", &cfg_line, &_deta);
    INTER_LOG("deta = %f", _deta);
    parse_from_string("rMax", &cfg_line, &_r_max);
    INTER_LOG("rmax = %f", _r_max);
    parse_from_string("dMax", &cfg_line, &_d_max);
    INTER_LOG("dmax = %f", _d_max);
}

ImageBatNormConfig::ImageBatNormConfig() : LayerConfig() {
    _type   = IMAGE_BAT_NORM;

    _statis_threshold = 20000;
    _moving_average_fraction = 0.99;

    _epsilon = 0.0001;
    _norm_type = BAT_NORM_UNKNOWN;
}

ImageBatNormConfig::~ImageBatNormConfig() {
}

void ImageBatNormConfig::read_config(std::string& cfg_line) {
    std::string norm_type;
    LayerConfig::read_config(cfg_line);
    parse_from_string("globalMeanVar", &cfg_line, &_mean_var_file);
    INTER_LOG("globalMeanVar = %s", _mean_var_file.c_str());
    parse_from_string("epsilon", &cfg_line, &_epsilon);
    INTER_LOG("epsilon = %f", _epsilon);
    parse_from_string("normType", &cfg_line, &norm_type);
    INTER_LOG("normType = %s", norm_type.c_str());
    string_to_enum(norm_type, g_image_bat_norm_type_name, &_norm_type);
    parse_from_string("statisThreshold", &cfg_line, &_statis_threshold);
    INTER_LOG("statisThreshold = %d", _statis_threshold);
    parse_from_string("movingAverageFraction", &cfg_line, &_moving_average_fraction);
    INTER_LOG("movingAverageFraction = %f", _moving_average_fraction);
}

static const char* opTypeName[] = {
    "add", "max", "avg",
    "elem_mul", "elem_div",
    "channel_append",
    "col_append", "row_append", "cross_append", 
    "row_alternate_append",
    NULL
};

void LinearConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    int in_num = input_num();

    /* default scalars */
    if (_scalars == NULL) {
        _scalars = (float*) malloc(sizeof(float) * in_num);
    }

    for (int i = 0; i < in_num; i++) {
        _scalars[i] = 1.0f;
    }

    std::string op_str;

    if (parse_from_string("op", &cfg_line, &op_str)) {
        string_to_enum(op_str, opTypeName, &_op);
        INTER_LOG("op = %s", op_str.c_str());
    }

    std::vector<float> scls;
    scls.clear();
    parse_from_string("scalars", &cfg_line, &scls);

    if (scls.size() != 0) {
        INTER_CHECK(scls.size() == _input_keys.size(),
                    "the scalars number must be equal with inputNum");
    }

    for (size_t i = 0; i < scls.size(); i++) {
        _scalars[i] = scls[i];
        INTER_LOG("scalars::%f", _scalars[i]);
    }
}

void ImageConvConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    std::string conv_algo_type;
    std::string conv_grad_algo_type;
    std::string conv_diff_algo_type;
    std::string algo_seeker_type;

    parse_from_string("outputMaps", &cfg_line, &_output_maps);
    INTER_LOG("outputMaps = %d", _output_maps);

    // 可以直接指定filter，默认height和width的大小都是这么大
    parse_from_string("filter", &cfg_line, &_filter_height);
    _filter_width = _filter_height;
    parse_from_string("filterHeight", &cfg_line, &_filter_height);
    parse_from_string("filterWidth", &cfg_line, &_filter_width);
    INTER_LOG("filterHeight = %d", _filter_height);
    INTER_LOG("filterWidth = %d", _filter_width);

    parse_from_string("stride", &cfg_line, &_stride_height);
    _stride_width = _stride_height;
    parse_from_string("strideHeight", &cfg_line, &_stride_height);
    parse_from_string("strideWidth", &cfg_line, &_stride_width);
    INTER_LOG("strideHeight = %d", _stride_height);
    INTER_LOG("strideWidth = %d", _stride_width);

    parse_from_string("padding", &cfg_line, &_padding_height);
    _padding_width = _padding_height;
    parse_from_string("paddingHeight", &cfg_line, &_padding_height);
    parse_from_string("paddingWidth", &cfg_line, &_padding_width);
    INTER_LOG("paddingHeight = %d", _padding_height);
    INTER_LOG("paddingWidth = %d", _padding_width);

    // NOTE 不能通过配置来设置算法了
    parse_from_string("convAlgoType", &cfg_line, &conv_algo_type);
    parse_from_string("convGradAlgoType", &cfg_line, &conv_grad_algo_type);
    parse_from_string("convDiffAlgoType", &cfg_line, &conv_diff_algo_type);
    parse_from_string("algoSeekerType", &cfg_line, &algo_seeker_type);
    INTER_LOG("algoSeekerType = %s", algo_seeker_type.c_str());
    string_to_enum(algo_seeker_type, g_image_conv_algo_seeker_type, &_algo_seeker_type);

    parse_from_string("dilation", &cfg_line, &_dilation_height);
    _dilation_width = _dilation_height;
    parse_from_string("dilationHeight", &cfg_line, &_dilation_height);
    parse_from_string("dilationWidth", &cfg_line, &_dilation_width);
    INTER_LOG("dilationHeight = %d", _dilation_height);
    INTER_LOG("dilationWidth = %d", _dilation_width);

    parse_from_string("calMask", &cfg_line, &_cal_mask);
    INTER_LOG("calMask %d", _cal_mask);

    parse_from_string("skipLabel", &cfg_line, &_skip_label);
    INTER_LOG("skipLabel %d", _skip_label);
}

void ImageConvQuantConfig::read_config(std::string& cfg_line) {
    ImageConvConfig::read_config(cfg_line); 
    parse_from_string("nbits", &cfg_line, &_nbits);
    INTER_LOG("nbits = %d", _nbits);
}

void ImagePoolingConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    std::string pooling_type;

    parse_from_string("poolingType", &cfg_line, &pooling_type);
    INTER_LOG("poolingType = %s", pooling_type.c_str());
    string_to_enum(pooling_type, g_image_pooling_type_name, &_pooling_type);

    /* wim == filter */
    parse_from_string("win", &cfg_line, &_win_height);
    parse_from_string("filter", &cfg_line, &_win_height);
    _win_width = _win_height;
    parse_from_string("winHeight", &cfg_line, &_win_height);
    parse_from_string("filterHeight", &cfg_line, &_win_height);
    INTER_LOG("winHeight = %d", _win_height);
    parse_from_string("winWidth", &cfg_line, &_win_width);
    parse_from_string("filterWidth", &cfg_line, &_win_width);
    INTER_LOG("winWidth = %d", _win_width);

    parse_from_string("stride", &cfg_line, &_stride_height);
    _stride_width = _stride_height;
    parse_from_string("strideHeight", &cfg_line, &_stride_height);
    INTER_LOG("strideHeight = %d", _stride_height);
    parse_from_string("strideWidth", &cfg_line, &_stride_width);
    INTER_LOG("strideWidth = %d", _stride_width);

    parse_from_string("padding", &cfg_line, &_padding_height);
    _padding_width = _padding_height;
    parse_from_string("paddingHeight", &cfg_line, &_padding_height);
    INTER_LOG("paddingHeight = %d", _padding_height);
    parse_from_string("paddingWidth", &cfg_line, &_padding_width);
    INTER_LOG("paddingWidth = %d", _padding_width);

    parse_from_string("globalPooling", &cfg_line, &_global_pooling);
    INTER_LOG("globalPooling = %d", _global_pooling);

    parse_from_string("calMask", &cfg_line, &_cal_mask);
    INTER_LOG("calMask %d", _cal_mask);

    parse_from_string("skipLabel", &cfg_line, &_skip_label);
    INTER_LOG("skipLabel %d", _skip_label);
}

void SoftmaxWithLossConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    /* 做softmax空间的起始坐标 */
    parse_from_string("startAxis", &cfg_line, &_start_axis);
    /* 做softmax空间的终止坐标，区间包括此坐标 */
    parse_from_string("endAxis", &cfg_line, &_end_axis);
    /* 是否取log，由rfcn衍生的需求*/
    parse_from_string("withLog", &cfg_line, &_with_log);
    INTER_LOG("withLog = %d", (int)_with_log);
}

void NormSoftmaxConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    /* 做softmax空间的起始坐标 */
    parse_from_string("startAxis", &cfg_line, &_start_axis);
    /* 做softmax空间的终止坐标，区间包括此坐标 */
    parse_from_string("endAxis", &cfg_line, &_end_axis);
}


void LossConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    /* 做softmax空间的起始坐标 */
    parse_from_string("startAxis", &cfg_line, &_start_axis);
    /* 做softmax空间的终止坐标，区间包括此坐标 */
    parse_from_string("endAxis", &cfg_line, &_end_axis);

    /* 计算loss时忽略的label */
    parse_from_string("ignoreLabel", &cfg_line, &_ignore_label);

    /* 计算出的loss和梯度除做归一化的类型 */
    std::string norm_str;

    if (parse_from_string("normMode", &cfg_line, &norm_str)) {
        string_to_enum(norm_str, LossNormModeName, &_norm_mode);
        INTER_LOG("normMode = %s", norm_str.c_str());
        parse_from_string("preFixed", &cfg_line, &_pre_fixed);
    }

    parse_from_string("pre_fixed_normalizer", &cfg_line, &_pre_fixed_normalizer);
    INTER_LOG("pre_fixed_normalizer = %d", _pre_fixed_normalizer);

    std::string cost_str;

    if (parse_from_string("cost-type", &cfg_line, &cost_str)) {
        string_to_enum(cost_str, costTypeName, &_cost_type);
        INTER_LOG("cost-type = %s", cost_str.c_str());
    }

    std::string prior_file;

    if (parse_from_string("priorFile", &cfg_line, &prior_file)) {
        if (prior_file.size()) {
            read_prior(prior_file.c_str());
        }

        INTER_LOG("priorFile = %s", prior_file.c_str());
    }

    parse_from_string("blankIndex", &cfg_line, &_blank_index);
    INTER_LOG("blankIndex = %d", _blank_index);

    if (_blank_index == -1 && _prior != NULL) {
        // The last id is _blank_index by default
        CHECK2(_prior && _prior->is_init());
        _blank_index = _prior->get_width() - 1;
    }

    parse_from_string("localCtc", &cfg_line, &_local_ctc);
    INTER_LOG("localCtc = %d", _local_ctc);
    parse_from_string("batchClearProb", &cfg_line, &_batch_clear_prob);
    INTER_LOG("batchClearProb = %d", _batch_clear_prob);
    parse_from_string("batchClearNum", &cfg_line, &_batch_clear_num);
    INTER_LOG("batchClearNum = %d", _batch_clear_num);

    parse_from_string("alpha", &cfg_line, &_alpha);
    INTER_LOG("alpha = %f", _alpha);

    parse_from_string("sigma", &cfg_line, &_sigma);
    INTER_LOG("sigma = %f", _sigma);
    parse_from_string("lambda", &cfg_line, &_lambda);
    INTER_LOG("lambda = %f", _lambda);

    parse_from_string("lossWeight", &cfg_line, &_loss_weight);
    INTER_LOG("lossWeight = %f", _loss_weight);

    parse_from_string("pre_fixed_normalizer", &cfg_line, &_pre_fixed_normalizer);
    INTER_LOG("pre_fixed_normalizer = %d", _pre_fixed_normalizer);

    parse_from_string("focalLossGamma", &cfg_line, &_focal_loss_gamma);
    INTER_LOG("focalLossGamma = %f", _focal_loss_gamma);

    parse_from_string("focalLossRatio", &cfg_line, &_focal_loss_ratio);
    INTER_LOG("focalLossRatio = %f", _focal_loss_ratio);
}

void LossConfig::read_prior(const char* prior_name) {
    if (NULL == prior_name) {
        return;
    }

    Tensor<DType> cpu_prior {cpu_device()};
    int state_num = 0;
    int i = 0;

    FILE* f = fopen(prior_name, "rt");
    CHECK(f != NULL, "can not open file %s", prior_name);

    fscanf(f, "%d\n", &state_num);
    cpu_prior.resize(Dim(1, state_num));

    DType* data = cpu_prior.get_data();

    for (i = 0; i < state_num && !feof(f); ++i) {
        fscanf(f, "%e\n", &(data[i]));
    }

    fclose(f);

    CHECK(0 != state_num && i == state_num, \
          "the priorlist %s is wrong format.", prior_name);

    if (_prior == NULL) {
        _prior = new Tensor<DType> {gpu_device()};
    }

    _prior->resize(Dim(1, state_num));
    _prior->copy_from(cpu_prior);
}

LossType LossConfig::convert_loss_type(LayerType type) {
    LossType loss_type;

    switch (type) {
    case LOSS_CE:
        loss_type = LOSS_TYPE_CE;
        break;

    case LOSS_MSE:
        loss_type = LOSS_TYPE_MSE;
        break;

    case LOSS_CTC:
        loss_type = LOSS_TYPE_CTC;
        break;

    case LOSS_TRIPLET:
        loss_type = LOSS_TYPE_TRIPLET;
        break;

    case LOSS_SMOOTH_L1:
        loss_type = LOSS_TYPE_SMOOTH_L1;
        break;

    case LOSS_SMOOTH_OHEM_L1:
        loss_type = LOSS_TYPE_SMOOTH_OHEM_L1;
        break;
    case LOSS_FOCAL:
        loss_type = LOSS_TYPE_FOCAL;
        break;

    case LOSS_LR:
        loss_type = LOSS_TYPE_LR;
        break;

    case LOSS_MIX_LR:
        loss_type = LOSS_TYPE_MIX_LR;
        break;

    default:
        CHECK(false, "error loss layer type");
    }

    return loss_type;
}

void DropOutConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("dropoutRate", &cfg_line, &_dropout_rate);
    INTER_LOG("dropoutRate = %f", _dropout_rate);
    parse_from_string("scaleTrain", &cfg_line, &_scale_train);
    INTER_LOG("scaleTrain = %d", _scale_train);
}

Norm2Config::Norm2Config() : LayerConfig() {
    _type   = NORM2;
}

void Norm2Config::read_config(std::string& cfg_line) {
    std::string norm_type;
    LayerConfig::read_config(cfg_line);
}

void ROIPoolConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    std::string pooling_type;

    parse_from_string("poolingType", &cfg_line, &pooling_type);
    INTER_LOG("poolingType = %s", pooling_type.c_str());
    string_to_enum(pooling_type, g_image_pooling_type_name, &_pooling_type);

    parse_from_string("pooled", &cfg_line, &_pooled_height);
    _pooled_width = _pooled_height;
    parse_from_string("pooledHeight", &cfg_line, &_pooled_height);
    INTER_LOG("pooledHeight = %d", _pooled_height);
    parse_from_string("pooledWidth", &cfg_line, &_pooled_width);
    INTER_LOG("pooledWidth = %d", _pooled_width);
    parse_from_string("roiNum", &cfg_line, &_roi_num);
    INTER_LOG("roiNum = %d", _roi_num);

    parse_from_string("spatialScale", &cfg_line, &_spatial_scale);
    INTER_LOG("spatialScale = %f", _spatial_scale);
}

void BoxAnnotatorOHEMConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);

    parse_from_string("roi_per_img", &cfg_line, &_roi_per_img);
    INTER_LOG("roi_per_img = %d", _roi_per_img);

    parse_from_string("ignore_label", &cfg_line, &_ignore_label);
    INTER_LOG("ignore_label= %d", _ignore_label);
}

void PSROIPoolConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);

    parse_from_string("spatialScale", &cfg_line, &_spatial_scale);
    INTER_LOG("spatialScale = %f", _spatial_scale);

    parse_from_string("outputMaps", &cfg_line, &_output_maps);
    INTER_LOG("outputMaps = %d", _output_maps);

    parse_from_string("groupSize", &cfg_line, &_group_size);
    INTER_LOG("groupSize = %d", _group_size);
}

ReshapeConfig::ReshapeConfig() : LayerConfig() {
    _type = RESHAPE;
    /*
     *  0: 直接从上一层复制
     * -1: 从其他数据推测这一维的维度
    */
}


void ReshapeConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("dim", &cfg_line, &_dim);
    INTER_LOG("dim =%d %d %d %d", _dim[0], _dim[1], _dim[2], _dim[3]);
}

RedimConfig::RedimConfig() : LayerConfig() {
    _type = REDIM;
    _dim.clear();
}

void RedimConfig::read_config(std::string& cfg_line) {
    //str_dim = "0:1,2,3"
    std::string str_dim;
    LayerConfig::read_config(cfg_line);
    parse_from_string("dim", &cfg_line, &str_dim);
    /*
     * 输入dim格式为=0:1,2,3
     */
    std::vector<std::string> vec_dim;
    split_string_to_vector(str_dim, ":", true, &vec_dim);
    CHECK2(vec_dim.size() >=1 && vec_dim.size() <= 4);
    for (size_t i = 0; i < vec_dim.size(); i++) {
        std::string cur_str = vec_dim[i];
        std::vector<int>cur_vec;
        split_string_to_integers(cur_str, ",", "true", &cur_vec);
        //int value = std::accumulate(cur_vec.begin(), cur_vec.end(), 1, std::multiplies<int>());
        _dim.push_back(cur_vec);
    }

    if (_dim.size() == 2) {
        INTER_LOG("dim =%d %d", _dim[0][0], _dim[1][0]);
    }
}

ExpandConfig::ExpandConfig() : LayerConfig() {
    _type   = EXPAND;
}

void ExpandConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("left_context", &cfg_line, &_left_context);
    parse_from_string("right_context", &cfg_line, &_right_context);
    INTER_LOG("left_context/right_context = %d/%d", _left_context, _right_context);
}

SkipConfig::SkipConfig() : LayerConfig() {
    _type   = SKIP;
    _split_num = -1;
    _skip_step = -1;
}

void SkipConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("split_num", &cfg_line, &_split_num);
    parse_from_string("skip_step", &cfg_line, &_skip_step);
    parse_from_string("split_start", &cfg_line, &_split_start);
    CHECK2(_split_num == (int)_split_start.size());
    INTER_LOG("skip_step = %d", _skip_step);
    INTER_LOG("split_num = %d", _split_num);
    CHECK(_output_keys.size() == 2, "new label key must be set");

    for (size_t i = 0; i < _split_start.size(); i++) {
        INTER_LOG("split_start[%lu] = %d", i, _split_start[i]);
    }
}

TransposeConfig::TransposeConfig() : LayerConfig() {
    _type = TRANSPOSE;
}

void TransposeConfig::read_config(std::string& cfg_line) {
    std::string norm_type;
    LayerConfig::read_config(cfg_line);

    parse_from_string("transpose", &cfg_line, &_transpose);
    INTER_LOG("transpose %d", _transpose[0]);
}

PythonConfig::PythonConfig() : LayerConfig() {
    _type = PYTHON;
    _python_layer_type = UNKNOWN_LAYER;
}

void PythonConfig::read_config(std::string& cfg_line) {
    std::string python_param;
    parse_tuple_from_string("pythonParam", &cfg_line, &python_param);
    parse_from_string("model", &python_param, &_python_model);
    parse_from_string("desc", &cfg_line, &_feat_desc_keys);
    INTER_LOG("model = %s", _python_model.c_str());

    if (parse_from_string("layer", &python_param, &_python_layer_type_str)) {
        string_to_enum(_python_layer_type_str, layerTypeName, &_python_layer_type);
        INTER_LOG("layer = %s", _python_layer_type_str.c_str());
    } else {
        CHECK(false, "layer must be set");
    }

    std::string param_str;
    parse_from_string("paramStr", &python_param, &param_str);
    INTER_LOG("paramStr = %s", param_str.c_str());
    _param_str = param_str;
    std::vector<int>dim;

    parse_from_string("featureDim", &cfg_line, &dim);
    _out_dim.push_back(Dim(dim));
    parse_from_string("labelDim", &cfg_line, &dim);
    _out_dim.push_back(Dim(dim));

    LayerConfig::read_config(cfg_line);
}

PythonConfig& PythonConfig::operator=(PythonConfig& cfgIn) {
    LayerConfig::operator=(cfgIn);

    _python_layer_type = cfgIn.get_python_layer_type();
    _python_layer_type_str = cfgIn.get_python_layer_type_str();
    _python_model = cfgIn.get_python_model();
    _param_str = cfgIn.get_param_str();

    return *(this);
}

std::vector<Dim> PythonConfig::get_out_dim() {
    return _out_dim;
}

Dim PythonConfig::get_out_dim(std::string key) {
    for (size_t i = 0; i < _output_keys.size(); i++) {
        if (_output_keys[i] == key) {
            return _out_dim[i];
        }
    }

    CHECK(false, "%s out dim not found", _layer_name.c_str());
    Dim dim;
    return dim;
}

FasterRCNNACUConfig::FasterRCNNACUConfig() : LayerConfig() {
    _type = FASTER_RCNN_ACU;
    _show = false;
    _store_gt_box = true;
    _score_threshold = 0.9;
}

void FasterRCNNACUConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("means", &cfg_line, &_means);

    if (_means.size()) {
        CHECK2(_means.size() == 4);
    }

    parse_from_string("stds", &cfg_line, &_stds);

    if (_stds.size()) {
        CHECK2(_stds.size() == 4);
    }

    parse_from_string("show", &cfg_line, &_show);
    INTER_LOG("show = %d", _show);
    parse_from_string("storeGtBox", &cfg_line, &_store_gt_box);
    INTER_LOG("storeGtBox = %d", _store_gt_box);
    parse_from_string("scoreThreshold", &cfg_line, &_score_threshold);
    INTER_LOG("scoreThreshold = %f", _score_threshold);
}

FasterRCNNACUConfig& FasterRCNNACUConfig::operator=(FasterRCNNACUConfig& cfgIn) {
    LayerConfig::operator=(cfgIn);
    _means = cfgIn.get_means();
    _stds = cfgIn.get_stds();
    _show = cfgIn.is_show();
    return *(this);
}

std::vector<float> FasterRCNNACUConfig::get_stds() {
    return _stds;
}

std::vector<float> FasterRCNNACUConfig::get_means() {
    return _means;
}

RfcnAcuConfig::RfcnAcuConfig() : LayerConfig() {
    _type = RFCN_ACU;
    _show = false;
}

void RfcnAcuConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("means", &cfg_line, &_means);

    if (_means.size()) {
        CHECK2(_means.size() == 4);
    }

    parse_from_string("stds", &cfg_line, &_stds);

    if (_stds.size()) {
        CHECK2(_stds.size() == 4);
    }

    parse_from_string("show", &cfg_line, &_show);
}

RfcnAcuConfig& RfcnAcuConfig::operator=(RfcnAcuConfig& cfgIn) {
    LayerConfig::operator=(cfgIn);
    _means = cfgIn.get_means();
    _stds = cfgIn.get_stds();
    _show = cfgIn.is_show();
    return *(this);
}

std::vector<float> RfcnAcuConfig::get_stds() {
    return _stds;
}

std::vector<float> RfcnAcuConfig::get_means() {
    return _means;
}

void AudioDeltaConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("windows", &cfg_line, &_windows);
}

void AudioSpliceConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("splice", &cfg_line, &_splice);
    INTER_LOG("splice %d", _splice);
    
    parse_from_string("clearDelta", &cfg_line, &_clear_delta);
    INTER_LOG("clearDelta %d", (int)_clear_delta);
}

GlobalCmvnConfig::GlobalCmvnConfig() : LayerConfig() {
    _type = GLOBAL_CMVN;
}

GlobalCmvnConfig::~GlobalCmvnConfig() {
}

void GlobalCmvnConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("globalMeanVar", &cfg_line, &_mean_var_file);
    INTER_LOG("globalMeanVar = %s", _mean_var_file.c_str());
}

void BitQuantConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("nbits", &cfg_line, &_nbits);
    INTER_LOG("quantization nbits = %lu", _nbits);
    parse_from_string("alpha", &cfg_line, &_alpha);
    for (auto i : _alpha) {
        INTER_LOG("quantization alpha = %f", i);
    }

    std::string algo_str;
    if (parse_from_string("algo", &cfg_line, &algo_str)) {
        string_to_enum(algo_str, bitQuantAlgo, &_algo); 
        INTER_LOG("quantization algo = %s", algo_str.c_str());
    }
}

AudioROIPoolConfig::AudioROIPoolConfig() {
    _type = AUDIO_ROI_POOL;
    _group_size = -1;
}

AudioROIPoolConfig& AudioROIPoolConfig::operator=(AudioROIPoolConfig& cfg) {
    LayerConfig::operator=(cfg);
    _group_size = cfg.get_group_size();
    _pool_type = cfg.get_pool_type();
    return *(this);
}

void AudioROIPoolConfig::read_config(std::string& cfg_line) {
    LayerConfig::read_config(cfg_line);
    parse_from_string("groupSize", &cfg_line, &_group_size);
    INTER_LOG("groupSize = %d", _group_size);
    
    std::string pool_type_str;
    if (parse_from_string("poolType", &cfg_line, &pool_type_str)) {
        string_to_enum(pool_type_str, g_audio_roi_pooling_type_name, &_pool_type);
    }
    
    CHECK(_group_size > 0, "groupSize must > 0");
}

} // namespace train
} // namespace houyi

