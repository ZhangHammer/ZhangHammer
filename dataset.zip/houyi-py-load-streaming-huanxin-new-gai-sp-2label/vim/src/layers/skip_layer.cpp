/**
 * skip_layer.cpp
 *
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2017-05-25
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "skip_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {

SkipLayer::SkipLayer(SkipConfig& config) : Layer(config) {
    set_device();
    _config = config;
    _last_len = 0;
    
    CHECK2(_config.get_split_num() == 1);
    _split_start_host = new Tensor<int> (Dim(_config.get_split_num()), CPU);

    for (int i = 0; i < _config.get_split_num(); i++) {
        _split_start_host->set_element(Dim(i), _config.get_split_start()[i]);
    }

    _split_start = new Tensor<int> (Dim(_config.get_split_num()), GPU);
    _split_start->copy_from(*_split_start_host);
}

SkipLayer::SkipLayer(SkipLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) SkipLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void SkipLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() + _label_key.size() == inputs.size(),
          "keys size not equal width dim size");
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void SkipLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();
    CHECK(input_size.get_size() == 2, "skip layer dim must be 2");
    _sample_num = sample_num;

    std::vector<int> output_dim = _config.get_shape(input_size, sample_num);
    std::vector<int> label_dim = _config.get_shape(inputs[1]->get_size(), sample_num);
    output(_output_keys[0]).resize(
            Dim(output_dim[0], output_dim[1]),
            gpu_device());
    output(_output_keys[1]).resize(
            Dim(label_dim[0], label_dim[1]),
            gpu_device());
}

void SkipLayer::inter_forward(std::vector<IOPackage*>& pack) {
    // tensor
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    for (int i = 0; i < _config.get_split_num(); i++) {
        _split_start_host->get_data()[i] = (_split_start_host->get_data()[i] + 1) %
            (_config.get_skip_step() + 1);
        //_split_start_host->get_data()[i] = 0;
    }

    _split_start->copy_from(*_split_start_host);

    Dim dim = pre_in->get_size();
    CHECK2(dim.get_size() == 2);
    wind_skip_op(*out, *pre_in, _sample_num, _config.get_split_num(), _config.get_skip_step(),
            *_split_start, 0.0f);

    // feature mask
    Tensor<int>* feature_mask = pack[0]->get_mask(); 
    Tensor<int>* skip_feature_mask = output(_output_keys[0]).get_mask(); 
    CHECK2(feature_mask->get_dim() == 1);
    wind_skip_1d_op(*skip_feature_mask, *feature_mask, _sample_num, _config.get_split_num(), 
                _config.get_skip_step(), *_split_start, 0);

    // label
    Tensor<DType>* label = pack[1]->get_ten();
    Tensor<DType>* new_label = output(_output_keys[1]).get_ten();
    CHECK2(label->get_dim() == 2);
    wind_skip_op(*new_label, *label, _sample_num, _config.get_split_num(), _config.get_skip_step(),
                 *_split_start, 0.0f);

    // label mask
    Tensor<int>* label_mask = pack[1]->get_mask(); 
    Tensor<int>* new_label_mask = output(_output_keys[1]).get_mask(); 
    CHECK2(label_mask->get_dim() == 1);
    wind_skip_1d_op(*new_label_mask, *label_mask, _sample_num, _config.get_split_num(), _config.get_skip_step(),
            *_split_start, 0);
}

void SkipLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* in = in_pack[0]->get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    pre_diff->resize(in->get_size());

    wind_skip_bp_op(*pre_diff, *local_diff, _sample_num, _config.get_split_num(),
                    _config.get_skip_step(), *_split_start);
}

Layer* SkipLayer::clone() {
    return new SkipLayer(this);
}

}
}

