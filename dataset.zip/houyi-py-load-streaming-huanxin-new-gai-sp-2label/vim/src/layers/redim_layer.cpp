/**
 * reshape_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-12-08
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "redim_layer.h"

namespace houyi {
namespace train {

RedimLayer::RedimLayer(RedimConfig& config) : Layer(config) {
    set_device();
    _config = config;
}

RedimLayer::RedimLayer(RedimLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) RedimLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void RedimLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void RedimLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();
    CHECK(input_size.get_size() == 4, "dim size error");
    std::vector<int>output_dim = _config.get_shape(input_size);

    _sample_num = sample_num;
    Dim out_dim(output_dim);

    output(_output_keys[0]).resize(out_dim, inputs[0]->get_mask(), 
            gpu_device());
}

void RedimLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Dim dim = pre_in->get_size();
    CHECK(dim.get_size() == 4, "dim size error");
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    //copy 
    out->reshape(dim);
    out->copy_from(*pre_in);
    //reshape
    std::vector<int>output_dim = _config.get_shape(dim);

    Dim out_dim(output_dim);
    CHECK2(dim.product() == out_dim.product());
    out->reshape(out_dim);
}

void RedimLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* in = in_pack[0]->get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    pre_diff->reshape(local_diff->get_size());
    pre_diff->elem_add(*pre_diff, *local_diff, 1.0f, 1.0f);
    pre_diff->reshape(in->get_size());
}

Layer* RedimLayer::clone() {
    return new RedimLayer(this);
}

}
}

