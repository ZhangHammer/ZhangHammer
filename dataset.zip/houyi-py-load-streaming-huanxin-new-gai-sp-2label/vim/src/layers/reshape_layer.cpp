/**
 * reshape_layer.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-12-08
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "reshape_layer.h"

namespace houyi {
namespace train {

ReshapeLayer::ReshapeLayer(ReshapeConfig& config) : Layer(config) {
    set_device();
    _config = config;
}

ReshapeLayer::ReshapeLayer(ReshapeLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) ReshapeLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void ReshapeLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ReshapeLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();
    std::vector<int>output_dim = _config.get_shape(input_size);
    _sample_num = sample_num;

    output(_output_keys[0]).resize(Dim(output_dim[0],
                                       output_dim[1], output_dim[2], output_dim[3]), inputs[0]->get_mask(), 
                                   gpu_device());
}

void ReshapeLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Dim dim = pre_in->get_size();
    //CHECK(dim.get_size() == 4, "dim size error");
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    std::vector<int>output_dim = _config.get_shape(dim);

    out->resize(dim);
    out->copy_from(*pre_in);

    Dim tmp_dim(output_dim);
    CHECK2(dim.product() == tmp_dim.product());
    out->reshape(tmp_dim);
}

void ReshapeLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* in = in_pack[0]->get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();

    pre_diff->reshape(local_diff->get_size());
    pre_diff->elem_add(*pre_diff, *local_diff, 1.0f, 1.0f);
    pre_diff->reshape(in->get_size());
}

Layer* ReshapeLayer::clone() {
    return new ReshapeLayer(this);
}

}
}

