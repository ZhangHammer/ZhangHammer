/**
 * out_config.cpp
 *
 * Author: madongpeng (madongpeng@baidu.com)
 * Created on: 2015-08-10
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include "tools.h"
#include "out_config.h"

namespace houyi {
namespace train {
static const char* pool_type_name[] = {"max", "target", "avg", NULL};
static const char* outputTypeName[] = {"single-softmax",
                                       "multi-softmax", "ctc-softmax", "mix-softmax",
                                       "linear", "mix-linear", NULL
                                      };

void OutputConfig::read_prior(const char* prior_name) {
    if (NULL == prior_name) {
        return;
    }

    Tensor<DType> cpu_prior;
    cpu_prior.set_device(cpu_device());
    int state_num = 0;
    int i = 0;

    FILE* f = fopen(prior_name, "rt");
    CHECK(f != NULL, "can not open file %s", prior_name);

    fscanf(f, "%d\n", &state_num);
    cpu_prior.resize(Dim(1, state_num));

    DType* data = cpu_prior.get_data();

    for (i = 0; i < state_num && !feof(f); ++i) {
        fscanf(f, "%e\n", &(data[i]));
    }

    fclose(f);

    CHECK(0 != state_num && i == state_num, \
          "the priorlist %s is wrong format.", prior_name);

    if (_prior == NULL) {
        _prior = new Tensor<DType>();
        _prior->set_device(cpu_device());
    }

    _prior->resize(Dim(1, state_num));
    _prior->copy_from(cpu_prior);
}

OutputConfig* OutputConfig::create(OutType t) {
    OutputConfig* r = NULL;

    switch (t) {
    case O_SINGLE_SOFTMAX:
        r = new SingleSoftMaxCfg();
        break;

    case O_MULTI_SOFTMAX:
        r = new MultiSoftMaxCfg();
        break;

    case O_CTC_SOFTMAX:
        r = new CtcSoftMaxCfg();
        break;

    case O_MIX_SOFTMAX:
        r = new MixSoftMaxCfg();
        break;

    case O_LINEAR:
        r = new LinearOutCfg();
        break;

    case O_MIX_LINEAR:
        r = new MixLinearOutCfg();
        break;

    default:
        CHECK(false, "unknown out-type: %d", t);
    }

    return r;
}

void OutputConfig::set_out_info(int n, int* ids, DType* scalars) {
    _o_layer_num = n;
    _o_layer_ids.clear();
    _o_scalars.clear();

    for (int i = 0; i < n; i++) {
        _o_layer_ids.push_back(ids[i]);
        _o_scalars.push_back(scalars[i]);
    }
}

void OutputConfig::read_config(std::string& cfg_line) {

    parse_from_string("outputs", &cfg_line, &_o_layer_ids);
    _o_layer_num = (size_t)_o_layer_ids.size();

    parse_from_string("scalars", &cfg_line, &_o_scalars);

    std::string prior_file;

    if (parse_from_string("priorFile", &cfg_line, &prior_file)) {
        read_prior(prior_file.c_str());
    }

    CHECK(_o_layer_num > 0, "no output layer");

    if (_o_scalars.size() == 0) {
        _o_scalars.resize(_o_layer_num);

        for (int i = 0; i < _o_layer_num; i++) {
            _o_scalars[i] = 1.0f;
        }
    }
}

OutputConfig* OutputConfig::read(std::ifstream& input) {
    std::string cfg_line;
    std::string type;
    OutType em_type = O_SINGLE_SOFTMAX;
    stream_to_string(input, "[end]", cfg_line);

    if (parse_from_string("type", &cfg_line, &type)) {
        string_to_enum(type, outputTypeName, &em_type);
    }

    OutputConfig* out_cfg = OutputConfig::create(em_type);
    out_cfg->read_config(cfg_line);
    return out_cfg;
}

void MixSoftMaxCfg::read_config(std::string& cfg_line) {

    OutputConfig::read_config(cfg_line);
    parse_from_string("poolingSize", &cfg_line, &_pooling_size);
    parse_from_string("poolingOutDim", &cfg_line, &_pooling_out_dim);
    std::string type;

    if (parse_from_string("poolingType", &cfg_line, &type)) {
        string_to_enum(type, pool_type_name, &_pooling_type);
    }
}

void MixLinearOutCfg::read_config(std::string& cfg_line) {
    OutputConfig::read_config(cfg_line);
    parse_from_string("poolingSize", &cfg_line, &_pooling_size);
    parse_from_string("poolingOutDim", &cfg_line, &_pooling_out_dim);
}

}
} //namespace houyi
