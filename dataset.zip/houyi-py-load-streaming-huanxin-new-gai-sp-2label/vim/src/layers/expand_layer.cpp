/**
 * expand_layer.cpp
 *
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2017-05-23
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <string>
#include "expand_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {

ExpandLayer::ExpandLayer(ExpandConfig& config) : Layer(config) {
    set_device();
    _config = config;
}

ExpandLayer::ExpandLayer(ExpandLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) ExpandLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}
void ExpandLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ExpandLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    Dim dim = inputs[0]->get_size();
    int output_dim = dim[3] * (1 + _config.get_left_context() + _config.get_right_context());

    output(_output_keys[0]).resize(Dim(dim[0], dim[1], dim[2], output_dim), inputs[0]->get_mask(), 
                                   gpu_device());
}

void ExpandLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    Dim output_dim = out->get_size();

    int dim_n = output_dim[-1];
    int dim_m = product(output_dim) / dim_n;

    wind_expand_op(*pre_in, *out, _sample_num, _config.get_left_context(),
                   _config.get_right_context(), dim_m, dim_n);
}

void ExpandLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();

    Dim dim = pre_diff->get_size();
    int dim_n = dim[dim.get_size() - 1];
    int dim_m = dim.product() / dim_n;
    wind_shrink_op(*local_diff, *pre_diff, _sample_num, _config.get_left_context(),
                   _config.get_right_context(), dim_m, dim_n);

}

Layer* ExpandLayer::clone() {
    return new ExpandLayer(this);
}

}
}

