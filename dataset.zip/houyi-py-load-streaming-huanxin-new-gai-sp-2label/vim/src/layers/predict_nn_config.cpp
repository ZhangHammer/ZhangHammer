/**
 * predict_nn_config.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-10-18
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "predict_nn_config.h"
#include "tools.h"
namespace houyi {
namespace train {

void InOutFileConfig::read(std::string& cfg_lines) {
    parse_from_string("modelFile", &cfg_lines, &_model_file);
    parse_from_string("inqModelFile", &cfg_lines, &_inq_model_file);
    parse_from_string("modelFileList", &cfg_lines, &_model_file_list);
    parse_from_string("scoreStoreDir", &cfg_lines, &_score_store_dir);
    parse_from_string("scoreStoreKaldiDir", &cfg_lines, &_score_store_kaldi_dir);
    parse_from_string("lossFile", &cfg_lines, &_loss_file);
    parse_from_string("classifyStoreDir", &cfg_lines, &_classify_store_dir);
}

void PredictPeriodConfig::read(std::string& cfg_lines) {
    parse_from_string("predictPeriod", &cfg_lines, &_predict_period);
}

PredictNnConfig::PredictNnConfig() : NNConfig() {
    _device_ids.clear();
    _thread_num = 0;

    _batch_size = 1;
    _job_type = PREDICT;
    _keep_history = true;
    _cfg_vec.clear();
}

PredictNnConfig::~PredictNnConfig() {
    for (size_t i = 0; i < _cfg_vec.size(); i++) {
        delete _cfg_vec[i];
        _cfg_vec[i] = NULL;
    }
}

void PredictNnConfig::read_config(const char* file) {
    std::ifstream input(file);
    CHECK(input, "configure file open error: %s", file);

    std::string line;
    std::string conf_line;

    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }

        remove_white_space_comment(line);

        if (line.size() == 0) {
            continue;
        }

        if (line == "[Layer]") {
            LayerConfig* new_cfg = LayerConfig::read(input);
            CHECK(new_cfg != NULL, "new layer configure error");

            if (new_cfg->layer_id() < 0) {
                new_cfg->set_layer_id(_cfg_vec.size());
            }

            _cfg_vec.push_back(new_cfg);
        } else {
            conf_line.append("\t");
            conf_line.append(line);
        }
    }

    parse_from_string("deviceId", &conf_line, &_device_ids);
    parse_from_string("keepHistory", &conf_line, &_keep_history);
    parse_from_string("skipNum", &conf_line, &_skip_num);
    parse_from_string("dataCfgFile", &conf_line, &_data_cfg_file);
    parse_from_string("pythonPath", &conf_line, &_python_path);
    parse_from_string("pythonGlobalCfgFile", &conf_line, &_python_global_cfg_file);

    for (auto i : _cfg_vec) {
        i->set_global_cfg_file(_python_global_cfg_file);
    }

    parse_from_string("threadNum", &conf_line, &_thread_num);
    parse_from_string("callBeforePredict", &conf_line, &_call_before_predict);
    parse_from_string("callAfterPredict", &conf_line, &_call_after_predict);

    std::string job_str;

    if (parse_from_string("jobType", &conf_line, &job_str)) {
        string_to_enum(job_str, jobTypeName, &_job_type);
    }

    for (size_t i = 0; i < _cfg_vec.size(); i++) {
        _cfg_vec[i]->set_global_job_type(_job_type);
    }

    _in_out_file_cfg.read(conf_line);// initialize

	_model_init_cfg.read(conf_line);// initialize
	for (auto i : _cfg_vec) {
		i->set_global_model_init_cfg(_model_init_cfg);
	} 

	parse_from_string("inq", &conf_line, &_inq);
	parse_from_string("inqRatio", &conf_line, &_inq_ratio);
	parse_from_string("inqBit", &conf_line, &_inq_bit); 
	CHECK((_inq == true && _inq_ratio.size() != 0) || _inq == false, "inq ratio error");
	for (size_t i = 0; i < _cfg_vec.size(); i++) {
		_cfg_vec[i]->set_inq(_inq);
		_cfg_vec[i]->set_inq_ratio(_inq_ratio);
		_cfg_vec[i]->set_inq_bit(_inq_bit);
	}

    _period_cfg.read(conf_line);    // period
    _disc_cfg.read(conf_line);      // DiscTrainConfig
    _data_cfg.read(_data_cfg_file.c_str()); // DataConfig
    gen_feat_label_key(_data_cfg);

    /* if no set, the set some default values */
    _batch_size = _data_cfg.get_batch_size();
    CHECK2(_batch_size!= 0);

    //for (size_t i = 0; i < _cfg_vec.size(); i++) {
    //    _cfg_vec[i]->set_batch_size(_sub_seq_size, _batch_size);
    //}

    if (_thread_num == 0) {
        _thread_num = (int)_device_ids.size();
    }

    parse_from_string("loadByPython", &conf_line, &_load_by_python);
    INTER_LOG("loadByPython = %d", _load_by_python);

    input.close();
}
}
} //namespace houyi

