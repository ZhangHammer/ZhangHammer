/**
 * image_conv_quant_layer.cpp
 *
 * Author: wolf(wangkai35@baidu.com)
 * Created on: 2018-07-11
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"
#include "image_conv_quant_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {
ImageConvQuantLayer::ImageConvQuantLayer(
    ImageConvQuantConfig& config) : ImageConvLayer(config) {
    init(config);
}

ImageConvQuantLayer::ImageConvQuantLayer(ImageConvQuantLayer* from): ImageConvLayer(from) {
    mask().set_device(gpu_device());
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) ImageConvQuantLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    w().resize_like(from->w());
    w().copy_from(from->w());
    if (_has_bias) {                          
        bias().resize_like(from->bias());
        bias().copy_from(from->bias());        
    }
}

Layer* ImageConvQuantLayer::clone() {
    return new ImageConvQuantLayer(this);
}

void ImageConvQuantLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input = in_pack[0]->get_ten();
    Tensor<DType>* weight = w().w();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();
    Tensor<int>* io_mask = in_pack[0]->get_mask();
    
    int w_n_s = weight->get_size(1) * weight->get_size(2) * weight->get_size(3);
    int out_h = output->get_size(2);
    int out_w = output->get_size(3);

    _conv_work_space_size_byte = w_n_s * out_h * out_w * sizeof(float);
    if (_conv_work_space_size_byte > 0u) {
        _workspace->resize(Dim(_conv_work_space_size_byte), false);
    }
    
    wind_quant_conv_gemm_fwd(conv_desc(), *input, *weight, *output,
        (void*)_workspace->get_data(),
        _conv_work_space_size_byte,
        1.0f, 1.0f, _transpose_buffer, _alpha);

    if (_has_bias) {
        //INTER_LOG("add bias not support");
        output->add_tensor(*bias().w());
    }

    //注意：必须保证是语音的输入, mask数据分布为frame_num * batch_size
    //batch_size 放在第一维
    if (cal_mask()) {
        int batch_size = in_pack[0]->get_size(0);
        int kernel_height = get_dilation_height() * (get_filter_height() - 1) + 1;
        int max_out_h = output->get_size(2);
        mask().resize(io_mask->get_size(), false);
        mask().copy_from(*io_mask);
        io_mask->resize(Dim(max_out_h * batch_size), false);
        wind_image_conv_cal_mask(*output, *io_mask, mask(), kernel_height, 
            get_padding_height(), get_stride_height());
    }
    

    // 根据实际情况对label进行skip
    if (skip_label()) {
        CHECK2(_output_keys.size() == 2);
        CHECK2(in_pack.size() == 2);
        int kernel_height = get_dilation_height() * (get_filter_height() - 1) + 1;
    
        Tensor<DType>* input2 = in_pack[1]->get_ten();
        Tensor<DType>* output2 = Layer::output(_output_keys[1]).get_ten();
        
        // copy output1 mask to output2 mask
        Tensor<int>* mask1 = Layer::output(_output_keys[0]).get_mask();
        Tensor<int>* mask2 = Layer::output(_output_keys[1]).get_mask();
        CHECK2(mask1->get_size() == mask2->get_size());
        mask2->copy_from(*mask1);
        wind_image_conv_skip_label(*input2, *output2, 
                kernel_height, 
                get_padding_height(), 
                get_stride_height(), _sample_num);
    }
}

}
}
