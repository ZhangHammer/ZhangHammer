/**
 * file: loss_store.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年11月07日 20时26分32秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#include <string>
#include "loss_store.h"
#include "focal_loss_layer.h"
#include "util.h"

namespace houyi {
namespace train {

Loss* creat_loss(const LossType type, const std::string name) {
    switch (type) {
    case LOSS_TYPE_CE:
    case LOSS_TYPE_MSE:
    case LOSS_TYPE_SMOOTH_L1:
    case LOSS_TYPE_SMOOTH_OHEM_L1:
    case LOSS_TYPE_LR:
        return new Loss(type, name);
        break;

    case LOSS_TYPE_CTC:
        return new CtcLoss(type, name);
        break;

    case LOSS_TYPE_TRIPLET:
        return new TripletLoss(type, name);
        break;
    case LOSS_TYPE_FOCAL:
        return new Loss(type, name);
        break;
    case LOSS_TYPE_MIX_LR:
        return new MixLrLoss(type, name);
        break;
    default:
        CHECK(false, "unsupport loss type");
    }

    return NULL;
}

}   /* namespace of houyi */
}   /* namespace of train */

