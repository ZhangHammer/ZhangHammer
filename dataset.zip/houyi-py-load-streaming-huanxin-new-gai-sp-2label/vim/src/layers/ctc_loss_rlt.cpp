/**
 * ctc_loss_layer.h
 * Author: baijinfeng (baijinfeng@conew.com)
 * Created on: 2016-08-01
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include <new>
#include <algorithm>
#include "activation.h"
#include "ctc_loss_layer.h"
#include "util.h"

namespace houyi {
namespace train {
/**
 * @brief ����������LCS����
 * @str1 : ���봮1 (��ע���)
 * @str2 : ���봮2 (ʶ����)
 * @return : LCS����
 */
std::vector<ItemPair> lcs_valueing(std::vector<int>& fc1, std::vector<int>& fc2) {
    std::vector<std::vector<MatchType> > lcs_mm;
    std::vector<std::vector<double> > lcs_ff;
    lcs_ff.resize(fc1.size() + 1);
    lcs_mm.resize(fc1.size() + 1);

    for (int ct1 = 0; ct1 < (int)fc1.size() + 1; ct1++) {
        lcs_ff[ct1].resize(fc2.size() + 1);
        lcs_mm[ct1].resize(fc2.size() + 1);
    }

    lcs_ff[0][0] = 0.;
    lcs_mm[0][0] = MATCH;

    for (int ct1 = 1; ct1 <= (int)fc1.size(); ct1++) {
        lcs_ff[ct1][0] = ct1;
        lcs_mm[ct1][0] = DEL;
    }

    for (int ct2 = 1; ct2 <= (int)fc2.size(); ct2++) {
        lcs_ff[0][ct2] = ct2;
        lcs_mm[0][ct2] = INS;
    }

    for (int ct1 = 1; ct1 <= (int)fc1.size(); ct1++) {
        for (int ct2 = 1; ct2 <= (int)fc2.size(); ct2++) {
            double cur_judge = (fc1[ct1 - 1] != fc2[ct2 - 1]);
            double min_ov    = lcs_ff[ct1 - 1][ct2] + 1;
            double cur_v     = lcs_ff[ct1][ct2 - 1] + 1;
            MatchType match_type = DEL;

            if (cur_v < min_ov) {
                min_ov     = cur_v;
                match_type = INS;
            }

            cur_v = lcs_ff[ct1 - 1][ct2 - 1] + cur_judge;

            if (cur_v < min_ov) {
                min_ov = cur_v;

                if (fc1[ct1 - 1] == fc2[ct2 - 1]) {
                    match_type = MATCH;
                } else {
                    match_type = SUB;
                }
            }

            lcs_ff[ct1][ct2] = min_ov;
            lcs_mm[ct1][ct2] = match_type;
        }
    }

    //backtrace
    std::vector<ItemPair> result;
    int ct2 = fc2.size();
    int ct1 = fc1.size();
    Item item1;
    Item item2;

    while (ct1 > 0 || ct2 > 0) {
        MatchType match_type = lcs_mm[ct1][ct2];

        switch (match_type) {
        case DEL:
            item1._idx = ct1 - 1;
            item1._value = fc1[ct1 - 1];
            item2._idx   = -1;
            item2._value = -1;
            result.insert(result.begin(), std::make_pair(item1, item2));
            ct1--;
            break;

        case INS:
            item1._idx   = -1;
            item1._value = -1;
            item2._idx = ct2 - 1;
            item2._value = fc2[ct2 - 1];
            result.insert(result.begin(), std::make_pair(item1, item2));
            ct2--;
            break;

        default:
            item1._idx = ct1 - 1;
            item1._value = fc1[ct1 - 1];
            item2._idx = ct2 - 1;
            item2._value = fc2[ct2 - 1];
            result.insert(result.begin(), std::make_pair(item1, item2));
            ct1--;
            ct2--;
            break;
        }
    }

    return result;
}

} //namespace houyi
} //namespace train

