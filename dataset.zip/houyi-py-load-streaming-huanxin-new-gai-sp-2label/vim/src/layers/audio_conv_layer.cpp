/**
 * conv_layer.cpp
 *
 * Author: chencheng19 (chencheng19@baidu.com)
 * Created on: 2017-11-6
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "audio_conv_layer.h"
#include <limits>

namespace houyi {
namespace train {

AudioConvLayer::AudioConvLayer(ConvConfig& config) : Layer(config) {
    set_device();
    _filter_num = config.filter_num();
    _group_num  = config.group_num();
    _filter_size = config.filter_size();
    _filter_num = config.filter_num();
    _fbank_dim = config.fbank_num();
    _temporal_dim = config.temporal_dim();
    _conv_out_dim = config.conv_out_dim();
    _delta = config.delta();
    _conv_start_pos.resize(Dim(_group_num));
    _conv_end_pos.resize(Dim(_group_num));
    _conv_size.resize(Dim(_group_num));
    _pooling_pivot.resize(Dim(config.pooling_out_dim()));
    _conv_start_pos.copy_from(config.conv_start(), 0, _group_num);
    _conv_end_pos.copy_from(config.conv_end(), 0, _group_num);
    _conv_size.copy_from(config.conv_size(), 0, _group_num);

    int conv_size = config.conv_size()[0];
    for (int i = 1; i < _group_num; ++i) {
        CHECK(conv_size == config.conv_size()[i],
                "audio_conv_layer, conv_size must be same %d %d %d",
                i, conv_size, config.conv_size()[i]);
    }

    _pooling_size = config.pooling_size();
    _pooling_out_dim = config.pooling_out_dim();
    _pooling_pivot.copy_from(config.pooling_pivot(), 0, _pooling_out_dim);

    build_map();

    _config = config;
    _frame_num = 0;
}
void AudioConvLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    _w.resize(Dim(_filter_num, _filter_size * _temporal_dim), gpu_device());

    if (need_update()) {
        _dw.resize(Dim(_filter_num, _filter_size * _temporal_dim), gpu_device());
    }

	if (_has_bias) {
        _bias.resize(Dim(_group_num, _filter_num / _group_num), gpu_device());
        _d_bias.resize(Dim(_group_num, _filter_num / _group_num), gpu_device());
	}

    if (_inq) {
        _w_t.resize(Dim(_filter_num, _filter_size * _temporal_dim), GPU);
        _w_t.w()->set_element(1);

        if (_has_bias) {
            _bias_t.resize(Dim(_group_num, _filter_num / _group_num), gpu_device());
            _bias_t.w()->set_element(1);
        }
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void AudioConvLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int out_dim = _filter_num / _group_num * _pooling_pivot.get_size(0);
    int frame_num = inputs[0]->get_size()[0];
    _frame_num = frame_num;
    _sample_num = sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(frame_num, out_dim), inputs[i]->get_mask(), gpu_device());
    }

    _out_conv.resize(Dim(frame_num * _conv_out_dim, _filter_num     / _group_num));
    _out.resize(Dim(frame_num,  _filter_num * _pooling_out_dim / _group_num));
    _idx.resize(Dim(frame_num * _filter_num * _pooling_out_dim / _group_num));
    _e.resize(Dim(frame_num,  _filter_num * _pooling_out_dim / _group_num));
    _x.resize(Dim(frame_num * _conv_out_dim, _filter_size * _temporal_dim));
}

AudioConvLayer::AudioConvLayer(AudioConvLayer* from) : Layer(from) {
    bool is_update = need_update();
    from->config().set_update(is_update);

    new(this) AudioConvLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
    //from->config().set_update(is_update);

    _w.resize_like(*from->w());
    _w.copy_from(from->w());

    if (_has_bias) {
        _bias.resize_like(*from->bias());
        _bias.copy_from(from->bias());
    }

    if (_inq) {
        _w_t.resize_like(*from->w_t());
        _w_t.copy_from(from->w_t());

        if (_has_bias) {
            _bias_t.resize_like(*from->bias_t());
            _bias_t.copy_from(from->bias_t());
        }
    }
}

void AudioConvLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "weight", &_w));

    if (_has_bias) {
        _w_map.insert(WeightsMap::value_type(pre + "bias", &_bias));
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_w_t));

        _w_map.insert(WeightsMap::value_type(pre + "bias_binary", &_bias_t));
    }

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_dw));

        if (_has_bias) {
            _dw_map.insert(WeightsMap::value_type(pre + "bias", &_d_bias));
        }
    }

}

Layer* AudioConvLayer::clone() {
    return new AudioConvLayer(this);
}

AudioConvLayer::~AudioConvLayer() {}

void AudioConvLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();

    /* expand the input data for convalution */
    _x.expand_feat(*in, _fbank_dim, _delta, _conv_out_dim,
                   _filter_size, _conv_start_pos, _conv_end_pos);

    CHECK2(_w.width() == _x.get_width());

    int offset_x = _x.get_element_count() / _group_num;
    int offset_w = _w.w()->get_element_count() / _group_num;
    int offset_y = _out_conv.get_element_count() / _group_num;
    _out_conv.batch_mul(
            _x, false, offset_x,
            *_w.w(), true, offset_w,
            offset_y, _group_num);
    _out_conv.audio_conv_batch_bias(*_bias.w(), _group_num);
    _out.max_pooling(_out_conv, _conv_size, _filter_num, _pooling_size, _idx);
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    out->elem_add(*out, _out);
}

void AudioConvLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    _out_conv.zero();
    _out_conv.max_pooling_bp(*local_diff, _conv_size,
                             _filter_num, _pooling_size, _idx);

    //XXX out_pack must be nullptr
    if (out_pack[0]) {
        input_error_bp(*out_pack[0]->get_ten());
    }
}

void AudioConvLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
            std::vector<IOPackage*>& out_pack) {
    //Tensor<DType>* local_diff = _diff.get_dtype_ten();
    //_out_conv.zero();
    //_out_conv.max_pooling_bp(*local_diff, _conv_size,
    //     _filter_num, _pooling_size, _idx);
    if (need_update()) {
        int offset_x = _x.get_element_count() / _group_num;
        int offset_w = _dw.w()->get_element_count() / _group_num;
        int offset_y = _out_conv.get_element_count() / _group_num;
        _dw.w()->batch_mul(
                _out_conv, true, offset_y,
                _x, false, offset_x,
                offset_w, _group_num, 1.0f, 1.0f);
        _d_bias.w()->audio_conv_batch_bias_bp(
                _out_conv, _group_num);
    }
}

void AudioConvLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->write(output);
        if (_inq) {
            _w_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_weight_max.front());
            max.write(output);
        }

        if (_has_bias) {
            for (int g = 0; g < _group_num; g++) {
                _bias.w()->range_row(g, g + 1).write(output);
                Tensor<DType> max(Dim(1), CPU);
                if (_inq) {
                    _bias_t.w()->range_row(g, g + 1).write(output);
                    // 现在 bias 为一整块内存，为了兼容，将 _inq_bias_max[0] 写 group 遍
                    max.set_element(Dim(0), _inq_bias_max[0]);
                    max.write(output);
                }
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void AudioConvLayer::read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read(input);
        if (_inq) {
            _w_t.w()->read(input);
            Tensor<DType> max(Dim(1), CPU);
            max.read(input);
            _inq_weight_max.push_back(max.get_element(Dim(0)));
        }

        if (_has_bias) {
            _bias.resize(Dim(_group_num, _w.height() / _group_num), gpu_device());
            if (_inq) {
                _bias_t.resize(Dim(_group_num, _w.height() / _group_num), gpu_device());
            }
            DType max_val = std::numeric_limits<DType>::lowest();
            for (int g = 0; g < _group_num; g++) {
                Tensor<DType> bias {cpu_device()};
                bias.read(input);
                _bias.w()->range_row(g, g + 1).copy_from(bias);
                if (_inq) {
                    Tensor<DType> bias_t {cpu_device()};
                    bias_t.read(input);
                    _bias_t.w()->range_row(g, g + 1).copy_from(bias_t);
                    Tensor<DType> max(Dim(1), CPU);
                    max.read(input);
                    if (max_val < max[Dim(0)]) {
                        max_val = max[Dim(0)];
                    }
                }
            }
            // 现在 group_num 个bias 合并为1个bias, max 取 group_num 个 max 中的最大值
            _inq_weight_max.push_back(max_val);
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void AudioConvLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read(input);

        if (_has_bias) {
            _bias.resize(Dim(_group_num, _w.height() / _group_num), gpu_device());
            for (int g = 0; g < _group_num; g++) {
                Tensor<DType> bias {cpu_device()};
                bias.read(input);
                _bias.w()->range_row(g, g + 1).copy_from(bias);
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void AudioConvLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read_hfnn(input);

        if (_has_bias) {
            _bias.resize(Dim(_group_num, _w.height() / _group_num), gpu_device());
            for (int g = 0; g < _group_num; g++) {
                Tensor<DType> bias {cpu_device()};
                bias.read_hfnn(input);
                _bias.w()->range_row(g, g + 1).copy_from(bias);
            }
        }

        break;

    case MD_WEIGHT:

    default:
        INTER_CHECK(false, "the ConvLayer has no this parameter: %d", t);
    }
}

void AudioConvLayer::read_heter_model(std::ifstream& input) {
    Tensor<DType> tmp {cpu_device()};
    tmp.read_hfnn(input, sizeof(int));
    size_t trans_dim_m = tmp.get_height();
    size_t trans_dim_n = tmp.get_width();
    INTER_LOG("read a convLayer: height:=%lu, width:=%lu\n", trans_dim_m, trans_dim_n);

    CHECK2(trans_dim_n - 1 == _w.width()
           && (trans_dim_m - 1 == _w.height()
               || trans_dim_m == _w.height()));

    // XXX 直接拷贝一块
    for (size_t i = 0; i < _w.height(); i++) {
        _w.w()->range_row(i, i + 1).copy_from(tmp.get_row(i), 0, trans_dim_n - 1);
        _bias.w()->copy_from(tmp.get_row(i) + trans_dim_n - 1, i, 1);
    }
}

void AudioConvLayer::input_error_bp(Tensor<DType>& inputError) {
    _x.zero();
    int offset_x = _x.get_element_count() / _group_num;
    int offset_w = _w.w()->get_element_count() / _group_num;
    int offset_y = _out_conv.get_element_count() / _group_num;
    _x.batch_mul(
            _out_conv, false, offset_y,
            *_w.w(), false, offset_w,
            offset_x, _group_num);

    inputError.resize(Dim(_x.get_height() / _conv_out_dim,
                          _fbank_dim * _temporal_dim));
    inputError.shrink_errors(
        _x, _fbank_dim, _delta, _conv_out_dim,
        _filter_size, _conv_start_pos, _conv_end_pos); // TODO:
}

}
}

