//by zhxfl 2017.10.17
#include <vector>
#include "gru_layer.h"
#include "gru_ops.h"

namespace houyi {
namespace train {

GruLayer::GruLayer(GruConfig& conf) : Layer(conf) {
    set_device();
    _config = conf;
    _output_dim = _config.out_dim();
    _skip_num = conf.skip_num();
    _nxt_start = 0;

    _tbptt = _config.tbptt();
    _updatett = _config.updatett();

    _reset_act = Activation::create(_config.reset_act());
    _update_act = Activation::create(_config.update_act());
    _state_act = Activation::create(_config.state_act());

    _final_mean_dw_reset = -1.0;
    _final_mean_dw_update = -1.0;
    _final_mean_dw_state = -1.0;
    _final_mean_du_reset = -1.0;
    _final_mean_du_update = -1.0;
    _final_mean_du_state = -1.0;
    _final_mean_d_bias_reset = -1.0;
    _final_mean_d_bias_update = -1.0;
    _final_mean_d_bias_state = -1.0;

    _final_stdv_dw_reset = -1.0;
    _final_stdv_dw_update = -1.0;
    _final_stdv_dw_state = -1.0;
    _final_stdv_du_reset = -1.0;
    _final_stdv_du_update = -1.0;
    _final_stdv_du_state = -1.0;
    _final_stdv_d_bias_reset = -1.0;
    _final_stdv_d_bias_update = -1.0;
    _final_stdv_d_bias_state = -1.0;

    _mean_dw_reset = 0.0;
    _mean_dw_update = 0.0;
    _mean_dw_state = 0.0;
    _mean_du_reset = 0.0;
    _mean_du_update = 0.0;
    _mean_du_state = 0.0;
    _mean_d_bias_reset = 0.0;
    _mean_d_bias_update = 0.0;
    _mean_d_bias_state = 0.0;

    _stdv_dw_reset = 0.0;
    _stdv_dw_update = 0.0;
    _stdv_dw_state = 0.0;
    _stdv_du_reset = 0.0;
    _stdv_du_update = 0.0;
    _stdv_du_state = 0.0;
    _stdv_d_bias_reset = 0.0;
    _stdv_d_bias_update = 0.0;
    _stdv_d_bias_state = 0.0;

    _mean_counter = 0;
    _mean_batch_number = _config.mean_statistic_num();
    _threshold = _config.threshold();
    _threshold_ratio = _config.threshold_ratio();
    
    build_map();
}

GruLayer::GruLayer(GruLayer* from) : Layer(from) {
    set_device();
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) GruLayer(from->config());
    //TODO
    layer_set(from->get_input(), from->get_sample_num());

    //w 
    _w_reset.resize_like(*from->w_reset());
    _w_reset.copy_from(*from->w_reset());

    _w_update.resize_like(*from->w_update());
    _w_update.copy_from(*from->w_update());

    _w_state.resize_like(*from->w_state());
    _w_state.copy_from(*from->w_state());

    //u
    _u_reset.resize_like(*from->u_reset());
    _u_reset.copy_from(*from->u_reset());

    _u_update.resize_like(*from->u_update());
    _u_update.copy_from(*from->u_update());

    _u_state.resize_like(*from->u_state());
    _u_state.copy_from(*from->u_state());

    //bias
    if (_config.has_bias()) {
        _bias_reset.resize_like(*from->bias_reset());
        _bias_reset.copy_from(*from->bias_reset());

        _bias_update.resize_like(*from->bias_update());
        _bias_update.copy_from(*from->bias_update());

        _bias_state.resize_like(*from->bias_state());
        _bias_state.copy_from(*from->bias_state());
    }
}

GruLayer::~GruLayer() {
    if (_reset_act) {
        delete _reset_act;
        _reset_act = NULL;
    }

    if (_update_act) {
        delete _update_act;
        _update_act = NULL;
    }

    if (_state_act) {
        delete _state_act;
        _state_act = NULL;
    }
}

void GruLayer::set_device() {
    _back_error.set_device(gpu_device());
    _seq_len.set_device(gpu_device());
    _reverse.set_device(gpu_device());
    _reverse_out.set_device(gpu_device());
    _reverse_in_diff.set_device(gpu_device());
}

/*
 * 根据输入的大小确定所有tensor的大小，包括weight，bias和输出等
 */
void GruLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num * _skip_num;

    _input_dim = inputs[0]->get_width();
    _output_dim = _config.out_dim();
    int frame_num = inputs[0]->get_size()[0];
    _sub_seq_size = frame_num / _sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    //resize weight and bias dweight
    _w_reset.resize(Dim(_input_dim, _output_dim), gpu_device());
    _w_update.resize(Dim(_input_dim, _output_dim), gpu_device());
    _w_state.resize(Dim(_input_dim, _output_dim), gpu_device());

    _u_reset.resize(Dim(_output_dim, _output_dim), gpu_device());
    _u_update.resize(Dim(_output_dim, _output_dim), gpu_device());
    _u_state.resize(Dim(_output_dim, _output_dim), gpu_device());

    if (_config.need_update()) { 
        _dw_reset.resize(Dim(_input_dim, _output_dim), gpu_device());
        _dw_update.resize(Dim(_input_dim, _output_dim), gpu_device());
        _dw_state.resize(Dim(_input_dim, _output_dim), gpu_device());

        _du_reset.resize(Dim(_output_dim, _output_dim), gpu_device());
        _du_update.resize(Dim(_output_dim, _output_dim), gpu_device());
        _du_state.resize(Dim(_output_dim, _output_dim), gpu_device());
    }

    if (_config.has_bias()) {
        _bias_reset.resize(Dim(1, _output_dim), gpu_device());
        _bias_update.resize(Dim(1, _output_dim), gpu_device());
        _bias_state.resize(Dim(1, _output_dim), gpu_device());

        if (need_update()) {
            _d_bias_reset.resize(Dim(1, _output_dim), gpu_device());
            _d_bias_update.resize(Dim(1, _output_dim), gpu_device());
            _d_bias_state.resize(Dim(1, _output_dim), gpu_device());
        }
    }
    
    //resize out
    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void GruLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int frame_num = inputs[0]->get_size()[0];
    CHECK(frame_num % _skip_num == 0, "frame num must be divisible by skip num");
    //int frame_dim = inputs[0]->get_size()[1];
    _sample_num = sample_num * _skip_num;
    _sub_seq_size = frame_num / _sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(
                Dim(frame_num, _output_dim), inputs[i]->get_mask(), gpu_device());
    }

    resize_tensor(inputs, _sample_num);
}

void GruLayer::resize_tensor(std::vector<IOPackage*>& inputs, 
        int sample_num) {
    CHECK2(inputs.size() == 1);
    // set batch size
    int frame_num = inputs[0]->get_size()[0];
    if (_updatett >= 0) {
        //_updatett = frame_num / sample_num - 1;
        _tbptt = frame_num / sample_num;
    }

    _reset_gate.resize(frame_num, _tbptt * sample_num, _output_dim);
    _update_gate.resize(frame_num, _tbptt * sample_num, _output_dim);
    _hidden_state.resize(frame_num, _tbptt * sample_num, _output_dim);
    _quasi_state.resize(frame_num, _tbptt * sample_num, _output_dim);
    _partial_hidden.resize(frame_num, _tbptt * sample_num, _output_dim);

    _back_error.resize(Dim(sample_num, _output_dim));
}

/*
 * 构造w字典和dw字典
 */
void GruLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "w_reset", &_w_reset));
    _w_map.insert(WeightsMap::value_type(pre + "bias_reset", &_bias_reset));

    _w_map.insert(WeightsMap::value_type(pre + "w_update", &_w_update));
    _w_map.insert(WeightsMap::value_type(pre + "bias_update", &_bias_update));

    _w_map.insert(WeightsMap::value_type(pre + "w_state", &_w_state));
    _w_map.insert(WeightsMap::value_type(pre + "bias_state", &_bias_state));

    _w_map.insert(WeightsMap::value_type(pre + "u_reset", &_u_reset));
    _w_map.insert(WeightsMap::value_type(pre + "u_update", &_u_update));
    _w_map.insert(WeightsMap::value_type(pre + "u_state", &_u_state));

    if (_config.need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "w_reset", &_dw_reset));
        _dw_map.insert(WeightsMap::value_type(pre + "bias_reset", &_d_bias_reset));

        _dw_map.insert(WeightsMap::value_type(pre + "w_update", &_dw_update));
        _dw_map.insert(WeightsMap::value_type(pre + "bias_update", &_d_bias_update));

        _dw_map.insert(WeightsMap::value_type(pre + "w_state", &_dw_state));
        _dw_map.insert(WeightsMap::value_type(pre + "bias_state", &_d_bias_state));

        _dw_map.insert(WeightsMap::value_type(pre + "u_reset", &_du_reset));
        _dw_map.insert(WeightsMap::value_type(pre + "u_update", &_du_update));
        _dw_map.insert(WeightsMap::value_type(pre + "u_state", &_du_state));
    }
}

void GruLayer::set_next_start() {
    //_w_reset, _w_update, _w_state
    _nxt_start += 3;

    //_u_reset, _u_update, _u_state
    _nxt_start += 3;

    //_bias_reset, _bias_update, _bias_state
    _nxt_start += 3;
}

void GruLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();
    Dim dim = in->get_size();

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        _reverse.resize(dim);
        _reverse_out.resize(out->get_size());
        _seq_len.resize(Dim(real_sample_num));
        _seq_len.count_valid_label(*mask, real_sample_num, real_sub_seq_size);
        _reverse.mask_reverse(*in, _seq_len, real_sample_num, real_sub_seq_size);
        in = &_reverse;
        out = &_reverse_out;
    }

    in->reshape(Dim(in->get_size(0), in->get_element_count() / in->get_size(0)));

    CHECK2(in->get_height() % _sample_num == 0);
    size_t frame_num = in->get_height() / _sample_num;

    //r = Wr*X + br
    //z = Wz*X + bz
    //h' = W*X + b
    _reset_gate._cur_o->mul(*in, *_w_reset.w());
    _update_gate._cur_o->mul(*in, *_w_update.w());
    _quasi_state._cur_o->mul(*in, *_w_state.w());
    if (_has_bias) {
        _reset_gate._cur_o->row_add_vec(*_reset_gate._cur_o, *_bias_reset.w());
        _update_gate._cur_o->row_add_vec(*_update_gate._cur_o, *_bias_update.w());
        _quasi_state._cur_o->row_add_vec(*_quasi_state._cur_o, *_bias_state.w());
    }
    wind_set_sync_flag(false);
    // sample_num 句子的帧数
    for (size_t t = 0; t < frame_num; t++) {
        size_t st_row = _tbptt + t - 1;
        size_t ed_row = _tbptt + t;
        // r(t) = Wr * X(t) + Ur*h(t - 1) + br
        _reset_gate._cur_o->range_row(t, t + 1, _sample_num).mul(
                _hidden_state._all_o.range_row(st_row, ed_row, _sample_num),
                *_u_reset.w(), 1.0f, 1.0f);
        // z(t) = Wz * X(t) + Uz*h(t - 1) + b 
        _update_gate._cur_o->range_row(t, t + 1, _sample_num).mul(
                _hidden_state._all_o.range_row(st_row, ed_row, _sample_num),
                *_u_update.w(), 1.0f, 1.0f);
        // r(t) = 6(Wr * X(t) + Ur * h(t - 1) + br)
        Tensor<DType> reset_gate_cur_o = _reset_gate._cur_o->range_row(t, t + 1, _sample_num);
        _reset_act->forward(reset_gate_cur_o, reset_gate_cur_o);
        // z(t) = 6(Wz * X(t) + Uz * h(t - 1) + bz)
        Tensor<DType> update_gate_cur_o = _update_gate._cur_o->range_row(t, t + 1, _sample_num);
        _update_act->forward(update_gate_cur_o, update_gate_cur_o);

        //h'(t) = W*X(t) + r(t) @ (U * h(t - 1)) + b
        //partial = U * h(t - 1)
        _partial_hidden._cur_o->range_row(t, t + 1, _sample_num).mul(
                _hidden_state._all_o.range_row(st_row, ed_row, _sample_num),
                *_u_state.w(), 1.0f, 0.0f);

        _quasi_state._cur_o->range_row(t, t + 1, _sample_num).elem_mul(
                _reset_gate._cur_o->range_row(t, t + 1, _sample_num),
                _partial_hidden._cur_o->range_row(t, t + 1, _sample_num), 1.0f, 1.0f);
        // h'(t) = 6(W*X(t) + r(t) @ (U * h(t - 1)) + b)
        Tensor<DType>quasi_state_cur_o = _quasi_state._cur_o->range_row(t, t + 1, _sample_num);

        _state_act->forward(quasi_state_cur_o, quasi_state_cur_o);
        wind_interpolate_elem_mul(_update_gate._cur_o->range_row(t, t + 1, _sample_num),
                _hidden_state._all_o.range_row(st_row, ed_row, _sample_num),
                _quasi_state._cur_o->range_row(t, t + 1, _sample_num),
                _hidden_state._cur_o->range_row(t, t + 1, _sample_num)); 
        // h(t) = (1 - z(t)) @ h(t-1) + z(t) @ h'(t)
        //// 1) h(t) = h(t-1) 
        //_hidden_state._cur_o->range_row(t, t + 1, _sample_num).copy_from(
        //        _hidden_state._all_o.range_row(st_row, ed_row, _sample_num));
        //// 2) h(t) = h(t-1) - z(t) @ h(t-1)
        //_hidden_state._cur_o->range_row(t, t + 1, _sample_num).elem_mul(
        //        _update_gate._cur_o->range_row(t, t + 1, _sample_num),
        //        _hidden_state._all_o.range_row(st_row, ed_row, _sample_num),
        //        -1.0, 1.0);
        //// 3) h(t) = h(t-1) - z(t) @ h(t-1) + z(t) @ h'(t)
        //_hidden_state._cur_o->range_row(t, t + 1, _sample_num).elem_mul(
        //        _update_gate._cur_o->range_row(t, t + 1, _sample_num),
        //        _quasi_state._cur_o->range_row(t, t + 1, _sample_num),
        //        1.0, 1.0);
    }

    wind_set_sync_flag(true);

    out->copy_from(*_hidden_state._cur_o);

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        out = output(_output_keys[0]).get_ten();
        in = in_pack[0]->get_ten();
        out->mask_reverse(_reverse_out, _seq_len, real_sample_num, real_sub_seq_size);
    }

    in->reshape(dim);
    in = out = NULL;
}

void GruLayer::cal_time_gradient() {
    int s_row = _hidden_state._all_o.get_height() / _sample_num - _tbptt - 1;
    int e_row = _hidden_state._all_o.get_height() / _sample_num - 1;

    if (need_update()) {
        // du_state
        _du_state.w()->mul(
                _partial_hidden._all_o.range_row(s_row, e_row, _sample_num), true,
                _quasi_state._error, false, 1.0, 0.0);

        // du_reset_gat
        _du_reset.w()->mul(
                _hidden_state._all_o.range_row(s_row, e_row, _sample_num), true,
                _reset_gate._error, false, 1.0, 0.0);

        // du_update_gat
        _du_update.w()->mul(
                _hidden_state._all_o.range_row(s_row, e_row, _sample_num),  true,
                _update_gate._error, false, 1.0, 0.0);
    }
}

void GruLayer::store_history() {
    _hidden_state.store_cur_out();
    //_reset_gate.store_cur_out();
    //_update_gate.store_cur_out();
    //_quasi_state.store_cur_out();
    //_partial_hidden.store_cur_out();
}

void GruLayer::linear_gradient(const Tensor<DType>& x) {
    if (need_update()) {
        // state
        _dw_state.w()->mul(
                x, true, _quasi_state._error, false, 1.0f, 0.0f);
        // reset_gate
        _dw_reset.w()->mul(
                x, true, _reset_gate._error, false, 1.0f, 0.0f);
        // update_gate
        _dw_update.w()->mul(
                x, true, _update_gate._error, false, 1.0f, 0.0f);

        if (_config.has_bias()) {
            _d_bias_state.w()->collect_bias(
                    _quasi_state._error, 1.0f, 0.0f);
            _d_bias_reset.w()->collect_bias(
                    _reset_gate._error, 1.0f, 0.0f);
            _d_bias_update.w()->collect_bias(
                    _update_gate._error, 1.0f, 0.0f);
        }
    }
}

void GruLayer::inter_bprop_diff(
        std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {

    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }

    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Dim dim = out_diff->get_size();
    out_diff->reshape(Dim(out_diff->get_size(0),
                out_diff->get_element_count() / out_diff->get_size(0)));

    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;
        _reverse_in_diff.resize(in_diff->get_size());
        _reverse_pre_diff.resize(out_diff->get_size());
        _reverse_in_diff.mask_reverse(*in_diff, _seq_len, real_sample_num, real_sub_seq_size);
        in_diff = &_reverse_in_diff;
        out_diff = &_reverse_pre_diff;
    }

    if (_updatett > 0) {
        // copy in_diff 
        _hidden_state._error.copy_from(*in_diff);
        CHECK(_tbptt == _sub_seq_size, 
                "the bptt must be equal with the size of subsequence");
        //_back_error.resize(Dim(_sample_num, _output_dim));
        //_back_error.zero();
        wind_set_sync_flag(false);
        for (int t = _tbptt - 1; t >= 0; t--) {
            size_t s_row = _hidden_state._all_o.get_size(0) / _sample_num - (_tbptt - t);
            size_t e_row = s_row + 1;

            // delta_h(t) += delta_h(t+1)
            _hidden_state._error.range_row(t, t + 1, _sample_num).elem_add(
                    _hidden_state._error.range_row(t, t + 1, _sample_num),
                    _back_error);

            // delta_z(t) = h(t)' - h(t - 1)
            _update_gate._error.range_row(t, t + 1, _sample_num).copy_from(
                    _quasi_state._all_o.range_row(s_row, e_row, _sample_num));
            _update_gate._error.range_row(t, t + 1, _sample_num).elem_add(
                    _update_gate._error.range_row(t, t + 1, _sample_num),
                    _hidden_state._all_o.range_row(s_row - 1, e_row - 1, _sample_num), 1.0, -1.0);

            // delta_z(t) @= delta_h(t)
            _update_gate._error.range_row(t, t + 1, _sample_num).elem_mul(
                    _update_gate._error.range_row(t, t + 1, _sample_num),
                    _hidden_state._error.range_row(t, t + 1, _sample_num));

            // delta_z(t) @= 6'(z(t))
            Tensor<DType>update_gate_error = _update_gate._error.range_row(t, t + 1, _sample_num);
            Tensor<DType>update_gate_all_o = _update_gate._all_o.range_row(s_row, e_row, _sample_num);
            _update_act->backward(
                    update_gate_error, update_gate_all_o, update_gate_error);

            // _delta_h'(t) = delta_h(t) @ z(t) @ 6'(h'(t))
            _quasi_state._error.range_row(t, t + 1, _sample_num).elem_mul(
                    _hidden_state._error.range_row(t, t + 1, _sample_num),
                    _update_gate._all_o.range_row(s_row, e_row, _sample_num));
            Tensor<DType>quasi_state_error = _quasi_state._error.range_row(t, t + 1, _sample_num);
            Tensor<DType>quasi_state_all_o =  _quasi_state._all_o.range_row(s_row, e_row, _sample_num);
            _state_act->backward(
                    quasi_state_error, quasi_state_all_o, quasi_state_error);

            // delta_r(t) = delta_h'(t) @ part(t) @ 6'(r(t))
            _reset_gate._error.range_row(t, t + 1, _sample_num).elem_mul(
                    _quasi_state._error.range_row(t, t + 1, _sample_num),
                    _partial_hidden._all_o.range_row(s_row, e_row, _sample_num));

            Tensor<DType> reset_gate_error = _reset_gate._error.range_row(t, t + 1, _sample_num);
            Tensor<DType> reset_gate_all_o =_reset_gate._all_o.range_row(s_row, e_row, _sample_num);
            _reset_act->backward(
                    reset_gate_error, reset_gate_all_o, reset_gate_error);

            // delta_part(t) = delta_h'(t) @ r(t)
            _partial_hidden._error.range_row(t, t + 1, _sample_num).elem_mul(
                    _quasi_state._error.range_row(t, t + 1, _sample_num),
                    _reset_gate._all_o.range_row(s_row, e_row, _sample_num));

            /*back error*/
            // delta_h(t - 1) += (1 - z(t)) @ delta_h
            _back_error.copy_from(_hidden_state._error.range_row(t, t + 1, _sample_num));
            _back_error.elem_mul(_update_gate._all_o.range_row(s_row, e_row, _sample_num),
                    _hidden_state._error.range_row(t, t + 1, _sample_num), -1.0f, 1.0f);
            // delta_h(t - 1) += delta_part * transpose(U)
            _back_error.mul(_partial_hidden._error.range_row(t, t + 1, _sample_num), false,
                    *_u_state.w(), true, 1.0f, 1.0f);
            // delta_h(t - 1) += delta_r * transpose(Ur)
            _back_error.mul(_reset_gate._error.range_row(t, t + 1, _sample_num), false,
                    *_u_reset.w(), true, 1.0f, 1.0f);
            // delta_h(t - 1) += delta_z * transpose(Uz)
            _back_error.mul(_update_gate._error.range_row(t, t + 1, _sample_num), false,
                    *_u_update.w(), true, 1.0f, 1.0f);
        }
        wind_set_sync_flag(true);
    }
    else {
        CHECK(false, "not support");
    }

    input_error_backprop(*out_diff);
    if (_is_reversal) {
        int real_sample_num = _sample_num;
        int real_sub_seq_size = _sub_seq_size;

        out_diff = out_pack[0]->get_ten();
        out_diff->mask_reverse(_reverse_pre_diff, _seq_len, real_sample_num, real_sub_seq_size);
    }

    out_diff->reshape(dim);
}

void GruLayer::input_error_backprop(Tensor<DType>& out_error) {
    // state
    out_error.mul(_quasi_state._error, false, *_w_state.w(), true, 1.0, 1.0);

    //reset_gate
    out_error.mul(_reset_gate._error, false, *_w_reset.w(), true, 1.0, 1.0);

    //update_gate
    out_error.mul(_update_gate._error, false, *_w_update.w(), true, 1.0, 1.0);
}

void GruLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {

    if (!out_pack.size() || (out_pack.size() == 1 && out_pack[0] == NULL)) {
        return;
    }

    Tensor<DType>* in_feat = in_pack[0]->get_ten();
    Tensor<DType>* out_diff = out_pack[0]->get_ten();
    Dim dim = in_feat->get_size();

    if (_is_reversal) {
        in_feat = &_reverse;
        out_diff = &_reverse_pre_diff;
    }

    in_feat->reshape(Dim(in_feat->get_size(0), in_feat->get_element_count() / in_feat->get_size(0)));

    cal_time_gradient();
    // dwx
    linear_gradient(*in_feat);

    // store the cell & recurrent state
    store_history();

    if (!clip_gradient()) {
        clear_gradient();
        out_diff->zero();
        if (_is_reversal) {
            _reverse_pre_diff.zero();
            out_diff = out_pack[0]->get_ten();
        }
        out_diff->zero();
        weight_flag(false);
    }

    in_feat->reshape(dim);
}

void GruLayer::clear_gradient() {
    if (need_update()) {
        _dw_reset.zero();
        _dw_update.zero();
        _dw_state.zero();

        _du_reset.zero();
        _du_update.zero();
        _du_state.zero();
        if (_config.has_bias()) {
            _d_bias_reset.zero();
            _d_bias_update.zero();
            _d_bias_state.zero();
        }
    }
}

bool GruLayer::clip_gradient() {
    bool ret_flag = true;

    if (need_update()) {
        DType norm_dw_reset=0.0;
        DType norm_dw_update=0.0;
        DType norm_dw_state=0.0;
        DType norm_du_reset=0.0;
        DType norm_du_update=0.0;
        DType norm_du_state=0.0;
        DType norm_d_bias_reset=0.0;
        DType norm_d_bias_update=0.0;
        DType norm_d_bias_state=0.0;

        bool flag_dw_reset=check_dw_norm(_dw_reset, norm_dw_reset,
                _final_mean_dw_reset,_final_stdv_dw_reset, "dw_reset");
        bool flag_dw_update=check_dw_norm(_dw_update,norm_dw_update,
                _final_mean_dw_update,_final_stdv_dw_update,"dw_update");
        bool flag_dw_state=check_dw_norm(_dw_state,norm_dw_state,
                _final_mean_dw_reset,_final_stdv_dw_state,"dw_state");

        bool flag_du_reset=check_dw_norm(_du_reset,norm_du_reset,
                _final_mean_du_reset,_final_stdv_du_reset,"du_reset");
        bool flag_du_update=check_dw_norm(_du_update,norm_du_update,
                _final_mean_du_update,_final_stdv_du_update,"du_update");
        bool flag_du_state=check_dw_norm(_du_state,norm_du_state,
                _final_mean_du_state,_final_stdv_du_state,"du_state");

        bool flag_d_bias_reset=check_dw_norm(_d_bias_reset,norm_d_bias_reset,
                _final_mean_d_bias_reset,_final_stdv_d_bias_reset,"d_bias_reset");
        bool flag_d_bias_update=check_dw_norm(_d_bias_update,norm_d_bias_update,
                _final_mean_d_bias_update,_final_stdv_d_bias_update,"d_bias_update");
        bool flag_d_bias_state=check_dw_norm(_d_bias_state,norm_d_bias_state,
                _final_mean_d_bias_state,_final_stdv_d_bias_state,"d_bias_state");

        ret_flag=flag_dw_reset&&flag_dw_update&&flag_dw_state&&
            flag_du_reset&&flag_du_update&&flag_du_state&&
            flag_d_bias_reset&&flag_d_bias_update&&flag_d_bias_state;

        if (ret_flag&&_threshold_ratio > 0.0) {
            _mean_dw_reset+=norm_dw_reset;
            _stdv_dw_reset+=norm_dw_reset*norm_dw_reset;
            _mean_dw_update+=norm_dw_update;
            _stdv_dw_update+=norm_dw_update*norm_dw_update;
            _mean_dw_state+=norm_dw_state;
            _stdv_dw_state+=norm_dw_state*norm_dw_state;

            _mean_du_reset+=norm_du_reset;
            _stdv_du_reset+=norm_du_reset*norm_du_reset;
            _mean_du_update+=norm_du_update;
            _stdv_du_update+=norm_du_update*norm_du_update;
            _mean_du_state+=norm_du_state;
            _stdv_du_state+=norm_du_state*norm_du_state;

            _mean_d_bias_reset+=norm_d_bias_reset;
            _stdv_d_bias_reset+=norm_d_bias_reset*norm_d_bias_reset;
            _mean_d_bias_update+=norm_d_bias_update;
            _stdv_d_bias_update+=norm_d_bias_update*norm_d_bias_update;
            _mean_d_bias_state+=norm_d_bias_state;
            _stdv_d_bias_state+=norm_d_bias_state*norm_d_bias_state;

            _mean_counter++;
            if (_mean_batch_number > 0 &&_mean_counter >=_mean_batch_number) {
                _final_mean_dw_reset=_mean_dw_reset/_mean_counter;
                _final_stdv_dw_reset=sqrt(_stdv_dw_reset/_mean_counter-
                        _final_mean_dw_reset*_final_mean_dw_reset);
                _mean_dw_reset=0.0f;
                _stdv_dw_reset=0.0f;

                _final_mean_dw_update=_mean_dw_update/_mean_counter;
                _final_stdv_dw_update=sqrt(_stdv_dw_update/_mean_counter-
                        _final_mean_dw_update*_final_mean_dw_update);
                _mean_dw_update=0.0f;
                _stdv_dw_update=0.0f;

                _final_mean_dw_state=_mean_dw_state/_mean_counter;
                _final_stdv_dw_state=sqrt(_stdv_dw_state/_mean_counter-
                        _final_mean_dw_state*_final_mean_dw_state);
                _mean_dw_state=0.0f;
                _stdv_dw_state=0.0f;

                _final_mean_du_reset=_mean_du_reset/_mean_counter;
                _final_stdv_du_reset=sqrt(_stdv_du_reset/_mean_counter-
                        _final_mean_du_reset*_final_mean_du_reset);
                _mean_du_reset=0.0f;
                _stdv_du_reset=0.0f;

                _final_mean_du_update=_mean_du_update/_mean_counter;
                _final_stdv_du_update=sqrt(_stdv_du_update/_mean_counter-
                        _final_mean_du_update*_final_mean_du_update);
                _mean_du_update=0.0f;
                _stdv_du_update=0.0f;

                _final_mean_du_state=_mean_du_state/_mean_counter;
                _final_stdv_du_state=sqrt(_stdv_du_state/_mean_counter-
                        _final_mean_du_state*_final_mean_du_state);
                _mean_du_state=0.0f;
                _stdv_du_state=0.0f;

                _final_mean_d_bias_reset=_mean_d_bias_reset/_mean_counter;
                _final_stdv_d_bias_reset=sqrt(_stdv_d_bias_reset/_mean_counter-
                        _final_mean_d_bias_reset*_final_mean_d_bias_reset);
                _mean_d_bias_reset=0.0f;
                _stdv_d_bias_reset=0.0f;

                _final_mean_d_bias_update=_mean_d_bias_update/_mean_counter;
                _final_stdv_d_bias_update=sqrt(_stdv_d_bias_update/_mean_counter-
                        _final_mean_d_bias_update*_final_mean_d_bias_update);
                _mean_d_bias_update=0.0f;
                _stdv_d_bias_update=0.0f;

                _final_mean_d_bias_state=_mean_d_bias_state/_mean_counter;
                _final_stdv_d_bias_state=sqrt(_stdv_d_bias_state/_mean_counter-
                        _final_mean_d_bias_state*_final_mean_d_bias_state);
                _mean_d_bias_state=0.0f;
                _stdv_d_bias_state=0.0f;

                _mean_counter=0;
            }
        }
    }

    return ret_flag;
}

Layer* GruLayer::clone() {
    return new GruLayer(this);
}

void GruLayer::clear_history() {
    //TODO
    _hidden_state.reset();
}

void GruLayer::clear_history(int sent_idx) {
    //TODO
    _hidden_state.reset(sent_idx, _sample_num);
}

void GruLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
        case WEIGHT: 
            {
                _w_reset.w()->write(output);
                _w_update.w()->write(output);
                _w_state.w()->write(output);
                _u_reset.w()->write(output);
                _u_update.w()->write(output);
                _u_state.w()->write(output);
                if (_config.has_bias()) {
                    _bias_reset.w()->write(output);
                    _bias_update.w()->write(output);
                    _bias_state.w()->write(output);
                }
                break;
            }
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the GruLayer has no this parameter: %d", t);
            }
    }
}

void GruLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
        case WEIGHT: 
            {
                _w_reset.w()->read(input);
                _w_update.w()->read(input);
                _w_state.w()->read(input);
                _u_reset.w()->read(input);
                _u_update.w()->read(input);
                _u_state.w()->read(input);
                if (_has_bias) {
                    _bias_reset.w()->read(input);
                    _bias_update.w()->read(input);
                    _bias_state.w()->read(input);
                }
                break;
            }
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the GruLayer has no this parameter: %d", t);
            }
    }
}

void GruLayer::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
        case WEIGHT: 
            {
                _w_reset.w()->read_hfnn(input);
                _w_update.w()->read_hfnn(input);
                _w_state.w()->read_hfnn(input);
                _u_reset.w()->read_hfnn(input);
                _u_update.w()->read_hfnn(input);
                _u_state.w()->read_hfnn(input);
                if (_has_bias) {
                    _bias_reset.w()->read_hfnn(input);
                    _bias_update.w()->read_hfnn(input);
                    _bias_state.w()->read_hfnn(input);
                }
                break;
            }
        case MD_WEIGHT:
        default:
            {
                INTER_CHECK(false, "the GruLayer has no this parameter: %d", t);
            }
    }
}

bool GruLayer::check_dw_norm(DenseWeight &dw, DType &norm, DType final_mean,
        DType final_stdv, const char* dw_name) {
    norm = dw.w()->norm2();
    if (_threshold > 0.0f && norm > _threshold) {
        dw.w()->mul(_threshold / norm);
        INTER_LOG("norm_%s = %f, threshold = %f", dw_name, norm, _threshold);
    }

    if (final_mean > 0.0 && _threshold_ratio > 0.0 &&
            norm > final_mean + _threshold_ratio * final_stdv) {
        INTER_LOG("%s : norm = %f, mean = %f, stdv = %f",
                dw_name, norm, final_mean, final_stdv);
        return false;
    }
    return true;
}
void GruLayer::gauss_init_weight(DType mean, DType stdv) {
    std::vector<DenseWeight*> weight {
        &_w_reset, &_w_update, &_w_state,
        &_u_reset, &_u_update, &_u_state,
        &_bias_reset, &_bias_update, &_bias_state};

    for (size_t i = 0; i < weight.size(); i++) {
        Tensor<DType>tmp{weight[i]->w()->get_size(), cpu_device()};
        tmp.gauss_random(mean, stdv);
        weight[i]->w()->copy_from(tmp);
    }
}

}
}
