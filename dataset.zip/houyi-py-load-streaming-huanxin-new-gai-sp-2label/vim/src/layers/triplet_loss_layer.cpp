/**
 * file: triplet_loss_layer.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年11月27日 00时35分43秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#include <triplet_loss_layer.h>

namespace houyi {
namespace train {

void TripletLossLayer::cal_target(std::vector<IOPackage*>& output,
                                  std::vector<IOPackage*>& label, std::vector<IOPackage*>& target) {
    CHECK2(output[0] && label[0] && target[0]);
    size_t h = output[0]->get_height();
    size_t w = output[0]->get_width();
    CHECK(h % 3 == 0, "batsh size error");
    Tensor<DType>& apn = *output[0]->get_ten();
    Tensor<DType>& local_label = *label[0]->get_ten();
    CHECK(local_label.get_element(Dim(0, 0)) == local_label.get_element(Dim(1, 0)),
          "label error, a p label is not same");

    if (!is_predict_job(_job_type)) {
        CHECK(local_label.get_element(Dim(0, 0)) != local_label.get_element(Dim(2, 0)),
              "label error, a n label is same");
    }

    size_t apn_num = h / 3;
    _a.resize(Dim(apn_num, w));
    _p.resize(Dim(apn_num, w));
    _n.resize(Dim(apn_num, w));
    _a_sub_p.resize(Dim(apn_num, w));
    _a_sub_n.resize(Dim(apn_num, w));
    _n_sub_p.resize(Dim(apn_num, w));
    _a_p_square.resize(Dim(apn_num, w));
    _a_n_square.resize(Dim(apn_num, w));
    _a_p_norm2.resize(Dim(apn_num));
    _a_n_norm2.resize(Dim(apn_num));
    target[0]->resize(Dim(apn_num), gpu_device());

    for (size_t i = 0; i < apn_num; i++) {
        _a.range_row(i, i + 1).copy_from(apn.range_row(i * 3, i * 3 + 1));
        _p.range_row(i, i + 1).copy_from(apn.range_row(i * 3 + 1, i * 3 + 2));
        _n.range_row(i, i + 1).copy_from(apn.range_row(i * 3 + 2, i * 3 + 3));
    }

    _a_sub_p.elem_add(_a, _p, 1.0f, -1.0f);
    _a_sub_n.elem_add(_a, _n, 1.0f, -1.0f);
    _n_sub_p.elem_add(_n, _p, 1.0f, -1.0f);

    _a_p_square.square(_a_sub_p);
    _a_n_square.square(_a_sub_n);

    //norm2^2
    _a_p_norm2.row_sum(_a_p_square);
    _a_n_norm2.row_sum(_a_n_square);

    //a_p - a_n
    target[0]->get_ten()->elem_add(_a_p_norm2, _a_n_norm2, 1.0f, -1.0f);

    // add alpha
    target[0]->get_ten()->add(_alpha);

    //mask when loss <= 0
    _positive_apn = 0;

    for (size_t i = 0; i < apn_num; i++) {
        if (target[0]->get_ten()->get_element(Dim(i)) <= 0) {
            _n_sub_p.range_row(i, i + 1).zero();
            _a_sub_p.range_row(i, i + 1).zero();
            _a_sub_n.range_row(i, i + 1).zero();

            //_a_p_square.range_row(i, i + 1).zero();
            //_a_n_square.range_row(i, i + 1).zero();
            target[0]->get_ten()->set_element(Dim(i), 0.0f);
        } else {
            _positive_apn++;
        }
    }
}

void TripletLossLayer::cal_loss(std::vector<IOPackage*>& output,
                                std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss) {
    CHECK2(output[0] && label[0] && loss[0]);
    size_t apn_num = _a_sub_p.get_h();
    Tensor<DType>& pre_diff = *loss[0]->get_ten();
    _pre_diff_buf.resize(pre_diff.get_size());

    _n_sub_p.mul(-2.0f / apn_num);
    _a_sub_p.mul(2.0f / apn_num);
    _a_sub_n.mul(-2.0f / apn_num);

    for (size_t i = 0; i < apn_num; i++) {
        _pre_diff_buf.range_row(i * 3, i * 3 + 1).copy_from(_n_sub_p.range_row(i, i + 1));
        _pre_diff_buf.range_row(i * 3 + 1, i * 3 + 2).copy_from(_a_sub_p.range_row(i, i + 1));
        _pre_diff_buf.range_row(i * 3 + 2, i * 3 + 3).copy_from(_a_sub_n.range_row(i, i + 1));
    }

    pre_diff.elem_add(pre_diff, _pre_diff_buf, 1.0f, _cfg.get_loss_weight());
}

Loss& TripletLossLayer::get_cost_value(TGT_COST_TYPE type) {
    DType cost = 0.0f;
    DType an_distance = 0.0f;
    DType ap_distance = 0.0f;
    TripletLoss* loss = dynamic_cast<TripletLoss*>(_loss);

    switch (type) {
    case TGT_ACU:
    case TGT_ERR: {
        /* 乘3.0是因为在统计样本数时是按照图片数统计的，不是按照apn对统计的 */
        cost = output(_output_keys[0]).get_ten()->sum() * 3.0f;
        an_distance = _a_n_square.sum();
        ap_distance = _a_p_square.sum();
    }
    break;

    default:
        CHECK(false, "tgt-type:%d, not support", (int)type);
    }

    loss->set_loss(cost);
    /* 乘3.0是因为在统计样本数时是按照图片数统计的，不是按照apn对统计的 */
    loss->set_an_distance(an_distance * 3.0f);
    loss->set_ap_distance(ap_distance * 3.0f);
    loss->set_positive_apn(_positive_apn * 3.0f);
    return *_loss;
}

}   /* namespace of houyi */
}   /* namespace of train */

