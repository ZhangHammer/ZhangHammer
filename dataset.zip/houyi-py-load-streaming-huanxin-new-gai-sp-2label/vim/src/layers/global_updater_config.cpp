/**
 * global_updater_config.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-02-31
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "parse_string.h"
#include "text_utils.h"
#include "util.h"
#include "global_updater_config.h"

namespace houyi {
namespace train {

const char* lrAdjustTypeName[] = {
    "fixed",
    "step",
    "linear_step",
    "exp",
    "inv",
    "multi_step",
    "poly",
    "sigmoid",
    "linear_multi_step"
    "NULL"
};

GlobalUpdaterCfg::GlobalUpdaterCfg() {
    _lr_adjust_type = FIXED_LR;
    _gamma = 1.0;
    _step = 1;
    _power = 1.0;
    _max_iter = 1;

    _gd_type = "sgd";
    _learn_rate = 0.0;
    _momentum  = 0.5;
    _l2_penalty = -1.0f;
    _threshold = -1.0f;
    _threshold_ratio = -1.0f;

    _adam_beta1 = 0.9f;
    _adam_beta2 = 0.999f;
    _adam_lambda = 1.0f;
    _adam_alpha = 0.001f;

    _rms_gamma = 0.9;
    _rms_eta = 0.001;

    _iter_size = 1;
    _device_num = 1;

    _lars = false;
    _lars_ratio = 0.001f;

    _warmup = false;
    _warmup_iter = 1;
    _warmup_lr = 1;

    _lr_print_period = 1;
}

void GlobalUpdaterCfg::read(std::string& cfg_lines) {
    std::string lr_adjust_param;

    if (parse_tuple_from_string("lrAdjustParam", &cfg_lines, &lr_adjust_param)) {
        INTER_LOG("<lrAdjustParam>");
        std::string lr_adjust_type;

        if (parse_from_string("type", &lr_adjust_param, &lr_adjust_type)) {
            string_to_enum(lr_adjust_type, lrAdjustTypeName, &_lr_adjust_type);
            INTER_LOG("type = %s", lr_adjust_type.c_str());
        } else {
            CHECK(false, "lr adjust type errro");
        }

        parse_from_string("gamma", &lr_adjust_param, &_gamma);
        INTER_LOG("gamma = %f", _gamma);
        parse_from_string("step", &lr_adjust_param, &_step);
        INTER_LOG("step = %d", _step);
        parse_from_string("stepValue", &lr_adjust_param, &_step_value);
        for (auto i : _step_value) {
            INTER_LOG("stepValue = %d", i);
        }
        parse_from_string("power", &lr_adjust_param, &_power);
        INTER_LOG("power = %f", _power);
        parse_from_string("maxIter", &lr_adjust_param, &_max_iter);
        INTER_LOG("maxIter = %d", _max_iter);
        parse_from_string("lrPrintPeriod", &lr_adjust_param, &_lr_print_period);
        INTER_LOG("lrPrintPeriod = %d", _lr_print_period);

        INTER_LOG("</lrAdjustParam>");
    }

    std::string lr_param;

    if (parse_tuple_from_string("gd", &cfg_lines, &lr_param)) {
        INTER_LOG("<gd>");

        parse_from_string("type", &lr_param, &_gd_type);
        INTER_LOG("type = %s", _gd_type.c_str());

        parse_from_string("l2Penalty", &lr_param, &_l2_penalty);
        INTER_LOG("l2Penalty = %f", _l2_penalty);

        /* sgd */
        if (_gd_type == "sgd" || _gd_type == "nesterov-sgd") {
            parse_from_string("learnRate", &lr_param, &_learn_rate);
            INTER_LOG("learnRate = %f", _learn_rate);
            parse_from_string("momentum", &lr_param, &_momentum);
            INTER_LOG("momentum = %f", _momentum);
            parse_from_string("threshold", &lr_param, &_threshold);
            INTER_LOG("threshold = %f", _threshold);
            parse_from_string("ratioThreshold", &lr_param, &_threshold_ratio);
            INTER_LOG("ratioThreshold = %f", _threshold_ratio);
            parse_from_string("lars", &lr_param, &_lars);
            INTER_LOG("lars = %d", _lars);
            parse_from_string("larsRatio", &lr_param, &_lars_ratio);
            INTER_LOG("larsRatio = %f", _lars_ratio);
            parse_from_string("warmup", &lr_param, &_warmup);
            INTER_LOG("warmup = %d", _warmup);
            parse_from_string("warmupIter", &lr_param, &_warmup_iter);
            INTER_LOG("warmupIter = %d", _warmup_iter);
            parse_from_string("warmupLr", &lr_param, &_warmup_lr);
            INTER_LOG("warmupLr = %f", _warmup_lr);
        }
        /* adam */
        else if (_gd_type == "adam") {
            parse_from_string("beta1", &lr_param, &_adam_beta1);
            INTER_LOG("beta1 = %f", _adam_beta1);
            parse_from_string("beta2", &lr_param, &_adam_beta2);
            INTER_LOG("beta2 = %f", _adam_beta2);
            parse_from_string("lambda", &lr_param, &_adam_lambda);
            INTER_LOG("lambda = %f", _adam_lambda);
            parse_from_string("alpha", &lr_param, &_adam_alpha);
            INTER_LOG("alpha= %f", _adam_alpha);
        }
        /* rms */
        else if (_gd_type == "rms") {
            parse_from_string("rmsGamma", &lr_param, &_rms_gamma);
            INTER_LOG("rmsGamma = %f", _rms_gamma);
            parse_from_string("rmsEta", &lr_param, &_rms_eta);
            INTER_LOG("rmsEta = %f", _rms_eta);
        } else {
            CHECK(false, "updater type error");
        }

        INTER_LOG("</gd>");
    }
}

}
} //namespace houyi

