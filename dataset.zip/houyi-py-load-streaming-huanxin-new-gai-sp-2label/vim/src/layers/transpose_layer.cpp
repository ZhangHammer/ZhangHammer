//by zzxfl 2017.05.12
#include <string>
#include "transpose_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {

TransposeLayer::TransposeLayer(TransposeConfig& config) : Layer(config) {
    set_device();
    _config = config;
    //transpose
    _transpose.set_device(gpu_device());
    Tensor<int>tmp(Dim(_config.get_transpose().size()), cpu_device());

    for (int i = 0; i < (int)_config.get_transpose().size(); i++) {
        tmp.get_data()[i] = _config.get_transpose()[i];
    }

    _transpose.resize(tmp.get_size());
    _transpose.copy_from(tmp);

    //retranspose
    _re_transpose.set_device(gpu_device());

    for (int i = 0; i < (int) _config.get_transpose().size(); i++) {
        int k = _config.get_ori_position(i);
        tmp.get_data()[i] = k;
    }

    _re_transpose.resize(tmp.get_size());
    _re_transpose.copy_from(tmp);

}

TransposeLayer::TransposeLayer(TransposeLayer* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) TransposeLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void TransposeLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1 ,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

std::vector<int> TransposeLayer::get_transpose_dim(const Dim& dim) {
    std::vector<int> output_dim;

    for (int i = 0; i < (int)dim.get_size(); i++) {
        // TODO _transpose 是一个 gpu Tensor, 每次访问都会触发一次 gpu->cpu 的拷贝
        // 可以考虑在cpu 上放置一个副本
        output_dim.push_back(dim[_transpose[Dim(i)]]);
    }

    return output_dim;
}

void TransposeLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    const Dim& input_size = inputs[0]->get_size();

    output(_output_keys[0]).resize(Dim(get_transpose_dim(input_size)), inputs[0]->get_mask(),
                                   gpu_device());
}

void TransposeLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    //transpose
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    wind_transpose(*pre_in, *out, _transpose);
}

void TransposeLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    Dim dim = local_diff->get_size();
    std::vector<int>pre_dim;

    for (int j = 0; j < dim.get_size(); j++) {
        int k = _config.get_ori_position(j);
        pre_dim.push_back(dim[k]);
    }

    pre_diff->reshape(Dim(pre_dim));
    //pre_diff->add(*local_diff, 1.0f, 1.0f);
    //TODO 支持多输入
    wind_transpose(*local_diff, *pre_diff, _re_transpose);
}

Layer* TransposeLayer::clone() {
    return new TransposeLayer(this);
}

}
}

