/**
 * Argument.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-19
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "argument.h"

namespace houyi {
namespace train {

void Argument::append_train_data(Argument& args2) {
    PacksMap& src = args2.pack_map();
    PacksMap::iterator itr1 = src.begin();

    for (; itr1 != src.end(); ++itr1) {
        std::string key = itr1->first;
        //CHECK2(_pack_map.find(key) == _pack_map.end());
        insert(key, itr1->second);
    }

    _feat_key = args2.feat_key();
    _label_key = args2.label_key();
    _feat_desc_key = args2.get_feat_desc_key();
    _feat_desc = args2.get_feat_desc();
    _sample_num = args2.get_sample_num();
}

void Argument::remove_train_data(Argument& args2) {
    PacksMap& src = args2.pack_map();
    PacksMap::iterator itr1 = src.begin();

    for (; itr1 != src.end(); ++itr1) {
        std::string key = itr1->first;
        PacksMap::iterator itr2 = _pack_map.find(key);

        if (itr2 != _pack_map.end()) {
            _pack_map.erase(itr2);
        }
    }

    _feat_desc = NULL;
    _sample_num = 0;
}

void Argument::insert_prior(Tensor<DType>* prior) {
    CHECK2(prior);
    IOPackage* pri_pack = new IOPackage(prior->get_size(), gpu_device());
    pri_pack->get_ten()->copy_from(*prior);
    insert("prior", pri_pack);
}

Tensor<DType>* Argument::get_prior() {
    IOPackage* io = get_pack("prior");

    if (io) {
        return io->get_ten();
    }

    return NULL;
}

IOPackage* Argument::get_pack(std::string key) {
    IOPackage* pack = NULL;
    PacksMap::iterator itr = _pack_map.find(key);

    if (itr != _pack_map.end()) {
        pack = itr->second;
    }

    return pack;
}

BaseBatchDesc* Argument::get_feat_desc() {
    return _feat_desc;
}

}
} //namespace houyi
