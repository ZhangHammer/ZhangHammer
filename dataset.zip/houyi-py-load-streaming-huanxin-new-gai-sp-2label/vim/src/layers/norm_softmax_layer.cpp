/**
 * norm_softmax_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-28
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include <new>
#include "wind/wind.h"
#include "layer_config.h"
#include "norm_softmax_layer.h"

namespace houyi {
namespace train {

void NormSoftmaxLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void NormSoftmaxLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);

    output(_output_keys[0]).resize(inputs[0]->get_size(), inputs[0]->get_mask(), gpu_device());
}
void NormSoftmaxLayer::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* in = pack[0]->get_ten();
    output(_output_keys[0]).resize(in->get_size(), gpu_device());

    Dim in_dim = in->get_size();
    int start_real_axis = in_dim.canonical_axis_index(_start_axis);
    int end_real_axis = in_dim.canonical_axis_index(_end_axis);
    index_t outer = in->count(0, start_real_axis);
    index_t channel = in->count(start_real_axis, end_real_axis + 1);
    index_t inner = in->count(end_real_axis + 1);

    output(_output_keys[0]).get_ten()->softmax(*in, outer,
            channel, inner, 1.0f, 0.0f);
}

void NormSoftmaxLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    //Dim in_dim = pre_diff->get_size();

    Tensor<DType>* in_diff = diff(_output_keys[0]).get_ten();
    index_t outer = in_diff->count(0, _start_axis);
    index_t channel = in_diff->count(_start_axis, _end_axis + 1);
    index_t inner = in_diff->count(_end_axis + 1);

    //  pre_diff->resize(diff(_output_keys[0]).get_size());
    _buf.resize(diff(_output_keys[0]).get_size());
    _sft_row_sum.resize(Dim(outer, 1, inner));

    _buf.softmax_bp_normal(*output(_output_keys[0]).get_ten(),
                           *in_diff, _sft_row_sum, outer, channel, inner);
    pre_diff->elem_add(*pre_diff, _buf, 1.0f, 1.0f);

    //pre_diff->reshape(in_dim);
}

} //namespace train
}
