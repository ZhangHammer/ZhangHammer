/**
 * file: faster_rcnn_acu_layer.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2017年4月22日 00时37分44秒
 *
 * copyright: Copyright (c) 2017, baidu.com, Inc. All Rights Reserved
 *
 */

#include "util.h"
#include "wind/wind.h"
#include "faster_rcnn_acu_layer.h"
#include "image_utils.h"

namespace houyi {
namespace train {

FasterRCNNACULayer::FasterRCNNACULayer(FasterRCNNACUConfig& config) : Layer(config) {
    set_device();
    _config = config;
    init();
    FILE* file = fopen("all_bbox", "w");
    fclose(file);
}

FasterRCNNACULayer::FasterRCNNACULayer(FasterRCNNACULayer* from): Layer(from) {
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) FasterRCNNACULayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

void FasterRCNNACULayer::layer_set(std::vector<IOPackage*>& inputs,
                                   int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void FasterRCNNACULayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
}

Layer* FasterRCNNACULayer::clone() {
    return new FasterRCNNACULayer(this);
}

void FasterRCNNACULayer::save_all_box(int image_idx, int c, float image_scale,
                                      std::vector<std::tuple<DType, DType, DType, DType, DType, int> >&
                                      score_proposal, std::vector<int>& idx) {
    FILE* file = fopen("all_bbox", "aw");

    for (int i = 0; i < (int)idx.size(); i++) {
        float score = 0.0;
        float x1 = 0.0;
        float y1 = 0.0;
        float x2 = 0.0;
        float y2 = 0.0;
        int proposal_idx = 0;
        std::tie(x1, y1, x2, y2, score, proposal_idx) = score_proposal[idx[i]];

        if (score < _config.get_score_threshold()) {
            continue;
        }

        fprintf(file, "%d %d %f %f %f %f %f\n",
                image_idx, c, x1 / image_scale, y1 / image_scale, x2 / image_scale,
                y2 / image_scale, score);
    }

    fclose(file);
}

void FasterRCNNACULayer::inter_forward(std::vector<IOPackage*>& pack) {
    static int image_idx = 0;
    float image_scale = 1.0;

    if (_feat_desc_keys.size()) {
        if (_input_keys.size() > 4) {
            image_scale = pack[6]->get_ten()->get_element(Dim(0, 2));
            INTER_LOG("image_scale %d %f", image_idx, image_scale);
        }
        else {
            image_scale = pack[5]->get_ten()->get_element(Dim(0, 2));
            INTER_LOG("image_scale %d %f", image_idx, image_scale);
        }
    }

    //image
    Tensor<DType>& gpu_image = *(pack[0]->get_ten());
    CHECK(gpu_image.get_size(0) == 1, "only one image per batch");
    _image.resize(Dim(gpu_image.get_size(1), gpu_image.get_size(2), gpu_image.get_size(3)));
    _image.copy_from(gpu_image.get_block(Dim(0, 0, 0, 0),
                                         Dim(1, gpu_image.get_size(1), gpu_image.get_size(2), gpu_image.get_size(3))));

    //rpn_rois
    Tensor<DType>& gpu_rpn_rois = *(pack[1]->get_ten());
    _rpn_rois.resize(gpu_rpn_rois.get_size());
    _rpn_rois.copy_from(gpu_rpn_rois);

    //bbox
    Tensor<DType>& gpu_bbox = *(pack[2]->get_ten());
    _bbox.resize(gpu_bbox.get_size());
    _bbox.copy_from(gpu_bbox);

    //box stv[0.1, 0.1, 0.2, 0.2]
    if (_config.get_stds().size() && _config.get_means().size()) {
        CHECK2(_config.get_stds().size() == 4);
        CHECK2(_config.get_means().size() == 4);

        DType* bbox_ptr = _bbox.get_data();

        for (int i = 0; i < (int)_bbox.get_element_count() / 4; i += 1) {
            bbox_ptr[i * 4 + 0] = bbox_ptr[i * 4 + 0] * _config.get_stds()[0] + _config.get_means()[0];
            bbox_ptr[i * 4 + 1] = bbox_ptr[i * 4 + 1] * _config.get_stds()[1] + _config.get_means()[1];
            bbox_ptr[i * 4 + 2] = bbox_ptr[i * 4 + 2] * _config.get_stds()[2] + _config.get_means()[2];
            bbox_ptr[i * 4 + 3] = bbox_ptr[i * 4 + 3] * _config.get_stds()[3] + _config.get_means()[3];
        }
    }

    //score
    Tensor<DType>& gpu_score = *(pack[3]->get_ten());
    _score.resize(gpu_score.get_size());
    _score.copy_from(gpu_score);


    //bbox_target
    if (_input_keys.size() > 4) {
        Tensor<DType>& gpu_bbox_target = *(pack[4]->get_ten());
        _bbox_target.resize(gpu_bbox_target.get_size());
        _bbox_target.copy_from(gpu_bbox_target);

        //label
        Tensor<DType>& gpu_label = *(pack[5]->get_ten());
        _label.resize(gpu_label.get_size());
        _label.copy_from(gpu_label);
    }
    else {
        //label
        Tensor<DType>& gpu_label = *(pack[4]->get_ten());
        _label.resize(gpu_label.get_size());
        _label.copy_from(gpu_label);
    }

    //box stv[0.1, 0.1, 0.2, 0.2]
    if (_config.get_stds().size() && _config.get_means().size()) {
        CHECK2(_config.get_stds().size() == 4);
        CHECK2(_config.get_means().size() == 4);

        DType* bbox_ptr = _bbox_target.get_data();

        for (int i = 0; i < (int)_bbox_target.get_element_count() / 4; i += 1) {
            bbox_ptr[i * 4 + 0] = bbox_ptr[i * 4 + 0] * _config.get_stds()[0] + _config.get_means()[0];
            bbox_ptr[i * 4 + 1] = bbox_ptr[i * 4 + 1] * _config.get_stds()[1] + _config.get_means()[1];
            bbox_ptr[i * 4 + 2] = bbox_ptr[i * 4 + 2] * _config.get_stds()[2] + _config.get_means()[2];
            bbox_ptr[i * 4 + 3] = bbox_ptr[i * 4 + 3] * _config.get_stds()[3] + _config.get_means()[3];
        }
    }

    //bbox_transform_inv
    _pred_boxes.resize(_bbox.get_size());
    bbox_transform_inv(_rpn_rois, _bbox, _pred_boxes);

    if (_input_keys.size() > 4) {
        _bbox_target_xy.resize(_bbox_target.get_size());
        bbox_transform_inv(_rpn_rois, _bbox_target, _bbox_target_xy);
    }

    clip_boxes(_pred_boxes, _image.get_w(), _image.get_h());

    std::vector<std::tuple<int, DType, DType, DType, DType, DType> > result;

    //add means
    Tensor<DType>means {Dim(3, 1), cpu_device()};
    means.get_data()[0] = 102.9801;
    means.get_data()[1] = 115.9465;
    means.get_data()[2] = 122.7717;
    _image.add_tensor(means);
#ifdef __WITH_OPENCV__
    size_t score_height = _score.get_size(0);
    int class_num = _score.get_size(1);
    cv::Mat image_mat(_image.get_h(), _image.get_w(), CV_32FC3);
    tensor_to_mat(_image, image_mat);
    const char* label_names[] = {"background", "aeroplane", "bicycle", "bird", "boat", "bottle",
                                 "bus", "car", "cat", "chair", "cow", "diningtable", "dog", "horse", "motorbike",
                                 "person", "pottedplant", "sheep", "sofa", "train", "tvmonitor"
                                };

    //分类个数，c = 0 是背景类不考虑
    for (int c = 1; c < class_num; c++) {
        std::vector<std::tuple<DType, DType, DType, DType, DType, int> >score_proposal;

        //窗口个数
        for (int b = 0; b < (int)score_height; b++) {
            if (_score.get_element(Dim(b, c)) <= 0.05) {
                continue;
            }

            score_proposal.push_back(std::make_tuple(
                                         _pred_boxes.get_element(Dim(b, c * 4 + 0)),
                                         _pred_boxes.get_element(Dim(b, c * 4 + 1)),
                                         _pred_boxes.get_element(Dim(b, c * 4 + 2)),
                                         _pred_boxes.get_element(Dim(b, c * 4 + 3)),
                                         _score.get_element(Dim(b, c)),
                                         b
                                     ));
        }

        std::vector<int>idx;
        sort(score_proposal.begin(), score_proposal.end(), [](
                 const std::tuple<DType, DType, DType, DType, DType, int>& a1,
        const std::tuple<DType, DType, DType, DType, DType, int>& a2) {
            return std::get<4>(a1) > std::get<4>(a2);
        });

        nms_cpu(score_proposal, idx, 0.3);

        if (_config.get_store_gt_box()) {
            save_all_box(image_idx, c, image_scale, score_proposal, idx);
        }
        if (_config.is_show()) {
            cv::Mat cur_image_mat;
            image_mat.copyTo(cur_image_mat);
            int count = 0;
            cv::putText(cur_image_mat,  label_names[c], cvPoint(100, 50),
                        CV_FONT_HERSHEY_COMPLEX, 0.8, cvScalar(0, 0 , 255), 1, CV_AA);

            for (int i = 0; i < std::min((int)idx.size(), 10); i++) {
                float score = 0.0f;
                float x1 = 0.0f;
                float y1 = 0.0f;
                float x2 = 0.0f;
                float y2 = 0.0f;
                int proposal_idx = 0;
                std::tie(x1, y1, x2, y2, score, proposal_idx) = score_proposal[idx[i]];

                if (score < _config.get_score_threshold()) {
                    continue;
                }

                cv::Rect rect;
                rect.x = x1;
                rect.y = y1;
                rect.width = x2 - x1;
                rect.height = y2 - y1;
                count++;
                cv::rectangle(cur_image_mat, rect, cv::Scalar(0, 0, 255), 3, 8, 0);
                char str[1024];
                sprintf(str, "%.3f", score);
                cv::putText(cur_image_mat,  str, cvPoint(x1, y1 + 25),
                            CV_FONT_HERSHEY_COMPLEX, 0.8, cvScalar(0, 0 , 255), 1, CV_AA);
                result.push_back(std::make_tuple(c, x1, y1, x2, y2, score));

                if (_input_keys.size() > 4) {
                    cv::Rect rect;
                    rect.x = _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 0));
                    rect.y = _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 1));
                    rect.width = _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 2)) -
                                 _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 0));
                    rect.height = _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 3)) -
                                  _bbox_target_xy.get_element(Dim(proposal_idx, c * 4 + 1));
                    cv::rectangle(cur_image_mat, rect, cv::Scalar(255, 0, 0), 3, 8, 0);
                }
            }

            char image_name[1024];
            static int image_id = 0;
            sprintf(image_name, "%d.jpg", image_id++);

            if (count) {
                //draw label
                for (int li = 0; li < (int)_label.get_element_count() / 5; li++) {
                    cv::Rect rect;
                    float x1 = 0.0f;
                    float y1 = 0.0f;
                    float x2 = 0.0f;
                    float y2 = 0.0f;
                    int class_id = 0;
                    x1 = _label.get_element(Dim(0, li * 5 + 0));
                    y1 = _label.get_element(Dim(0, li * 5 + 1));
                    x2 = _label.get_element(Dim(0, li * 5 + 2));
                    y2 = _label.get_element(Dim(0, li * 5 + 3));
                    class_id = _label.get_element(Dim(0, li * 5 + 4));

                    if (class_id != c) {
                        continue;
                    }

                    rect.x = x1;
                    rect.y = y1;
                    rect.width = x2 - x1;
                    rect.height = y2 - y1;

                    cv::rectangle(cur_image_mat, rect, cv::Scalar(0, 255, 0), 3, 8, 0);
                }

                cv::imwrite(image_name, cur_image_mat);
            }
        }
    }
#endif

    image_idx++;
}

void FasterRCNNACULayer::clip_boxes(Tensor<DType>& boxes, int width, int height) {
    CHECK2(boxes.get_element_count() % 4 == 0);
    int num = boxes.get_size(0);
    int class_num = boxes.get_size(1) / 4;

    for (int i = 0; i < num; i++) {
        for (int j = 0; j < class_num; j++) {
            DType* ptr = boxes.get_data(Dim(i, j * 4));
            ptr[0] = std::max(0.0f, std::min((float)width - 1, ptr[0]));
            ptr[1] = std::max(0.0f, std::min((float)height - 1, ptr[1]));
            ptr[2] = std::max(0.0f, std::min((float)width - 1, ptr[2]));
            ptr[3] = std::max(0.0f, std::min((float)height - 1, ptr[3]));
        }
    }
}

void FasterRCNNACULayer::nms_cpu(std::vector<std::tuple<DType, DType, DType, DType, DType, int>>
                                 & score_proposal, std::vector<int>& idx, float thresh) {
    idx.clear();
    const int RPN_PER_NMS_TOP_N = 2000;
    int ndets = std::min((int)(score_proposal.size()), (int)RPN_PER_NMS_TOP_N);
    idx.clear();
    std::vector<int>suppressed(ndets, 0);

    for (int i = 0; i < ndets; i++) {
        if (suppressed[i] == 1) {
            continue;
        }

        idx.push_back(i);
        float ix1 = 0.0;
        float iy1 = 0.0;
        float ix2 = 0.0;
        float iy2 = 0.0;
        float iscores = 0.0;
        int proposal_idx = 0;
        std::tie(ix1, iy1, ix2, iy2, iscores, proposal_idx) = score_proposal[i];

        float iarea = (ix2 - ix1 + 1) * (iy2 - iy1 + 1);

        for (int j = i + 1; j < ndets; j++) {
            if (suppressed[j] == 1) {
                continue;
            }

            float jx1 = 0.0;
            float jy1 = 0.0;
            float jx2 = 0.0;
            float jy2 = 0.0;
            float jscores = 0.0;
            int proposal_idx = 0;
            std::tie(jx1, jy1, jx2, jy2, jscores, proposal_idx) = score_proposal[j];
            float jarea = (jx2 - jx1 + 1) * (jy2 - jy1 + 1);

            float xx1 = std::max(ix1, jx1);
            float yy1 = std::max(iy1, jy1);
            float xx2 = std::min(ix2, jx2);
            float yy2 = std::min(iy2, jy2);

            float w = std::max(0.0f, xx2 - xx1 + 1);
            float h = std::max(0.0f, yy2 - yy1 + 1);

            float inter = w * h;
            float ovr = inter / (iarea + jarea - inter);

            if (ovr >= thresh) {
                suppressed[j] = 1;
            }
        }
    }
}

void FasterRCNNACULayer::bbox_transform_inv(Tensor<DType>& boxes,
        Tensor<DType>& deltas,
        Tensor<DType>& pred_boxes) {
    CHECK2(boxes.get_element_count() % 5 == 0);
    CHECK2(deltas.get_element_count() % 4 == 0);

    //boxes 是原始数据的label(0~4)是坐标
    int num = (int)(boxes.get_element_count() / 5);
    int class_num = (int)(deltas.get_size(1) / 4);
    pred_boxes.resize(deltas.get_size());

    for (int i = 0; i < num; i++) {
        DType* boxes_ptr = boxes.get_data(Dim(i, 0));

        DType widths = boxes_ptr[3] - boxes_ptr[1] + 1.0;
        DType heights = boxes_ptr[4] - boxes_ptr[2] + 1.0;

        DType ctr_x = boxes_ptr[1] + 0.5 * widths;
        DType ctr_y = boxes_ptr[2] + 0.5 * heights;

        for (int c = 0; c < class_num; c++) {
            DType* deltas_ptr = deltas.get_data(Dim(i, c * 4));
            DType dx = deltas_ptr[0];
            DType dy = deltas_ptr[1];
            DType dw = deltas_ptr[2];
            DType dh = deltas_ptr[3];

            DType pred_ctr_x = dx * widths + ctr_x;
            DType pred_ctr_y = dy * heights + ctr_y;
            DType pred_w = exp(dw) * widths;
            DType pred_h = exp(dh) * heights;

            DType* pred_boxes_ptr = pred_boxes.get_data(Dim(i, c * 4));
            pred_boxes_ptr[0] = pred_ctr_x - 0.5 * pred_w;
            pred_boxes_ptr[1] = pred_ctr_y - 0.5 * pred_h;
            pred_boxes_ptr[2] = pred_ctr_x + 0.5 * pred_w;
            pred_boxes_ptr[3] = pred_ctr_y + 0.5 * pred_h;
        }
    }
}

}
}
