/**
 * image_conv_layer.cpp
 *
 * Author: lifeng20(lifeng20@lifeng.com)
 * Created on: 2016-07-30
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"
#include "image_conv_layer.h"
#include "user_ops.h"

namespace houyi {
namespace train {
ImageConvLayer::ImageConvLayer(
    ImageConvConfig& config) : Layer(config) {
    _mask.set_device(gpu_device());
    init(config);

    build_map();
}

ImageConvLayer::ImageConvLayer(ImageConvLayer* from): Layer(from) {
    _mask.set_device(gpu_device());
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) ImageConvLayer(from->config());
    layer_set(from->get_input(), from->get_sample_num());

    _w.resize_like(from->w());
    _w.copy_from(from->w());
    if (_has_bias) {                          
        _bias.resize_like(from->bias());
        _bias.copy_from(from->bias());        
    }

    if (_inq) {
        _w_t.resize_like(from->w_t());
        _w_t.copy_from(from->w_t());          
        if (_has_bias) {
            _bias_t.resize_like(from->bias_t());
            _bias_t.copy_from(from->bias_t());
        }
    }
}

void ImageConvLayer::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK2(inputs.size() == 1 || inputs.size() == 2);
    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    int input_maps = inputs[0]->get_size()[1];
    _w.resize(Dim(_output_maps, input_maps, _filter_height, _filter_width), gpu_device());
    if (_has_bias) {                                        
        _bias.resize(Dim(_output_maps, 1, 1), GPU); 
    }                                                       

    if (need_update()) {
        _d_w.resize(Dim(_output_maps, input_maps, _filter_height, _filter_width), gpu_device());
        if (_has_bias) {
            _d_bias.resize(Dim(_output_maps, 1, 1), GPU);
        }                                                        
    }

    if (_inq) {
        _w_t.resize(Dim(_output_maps, input_maps, _filter_height, _filter_width), GPU);
        _w_t.w()->set_element(1);

        if (_has_bias) {
            _bias_t.resize(Dim(_output_maps, 1, 1), GPU);
            _bias_t.w()->set_element(1);
        }
    }

    resize_out(inputs, sample_num);
    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void ImageConvLayer::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    const Dim& input_size = inputs[0]->get_size();
    CHECK(4 == input_size.get_size(), "ImageConvLayer input must be 4D");
    int in_h = input_size[2];
    int in_w = input_size[3];
    _sample_num = sample_num;

    int kernel_height = _dilation_height * (_filter_height - 1) + 1;
    int kernel_width = _dilation_width * (_filter_width - 1) + 1;

    int out_h = 1 + (in_h - kernel_height + 2 * _padding_height) / _stride_height;
    int out_w = 1 + (in_w - kernel_width + 2 * _padding_width) / _stride_width;
    output(_output_keys[0]).resize(Dim(input_size[0], _output_maps, out_h,
                                       out_w), inputs[0]->get_mask(), gpu_device());
    
    // skip label 处理
    if (inputs.size() == 2) {
        // 开启了skip_label
        CHECK2(_skip_label);
        Dim dim = inputs[1]->get_size();
        CHECK2(dim[1] == 1);
        output(_output_keys[1]).resize(Dim(out_h * sample_num, 1), gpu_device());
    }
}

void ImageConvLayer::init(ImageConvConfig& conf) {
    init();

    _algo_seeker_type = conf.get_algo_seeker_type();
    _algo_inited = false;
    _grad_algo_inited = false;
    _diff_algo_inited = false;

    _output_maps = conf.get_output_maps();
    _filter_height = conf.get_filter_height();
    _filter_width = conf.get_filter_width();
    _stride_height = conf.get_stride_height();
    _stride_width = conf.get_stride_width();
    _padding_height = conf.get_padding_height();
    _padding_width = conf.get_padding_width();

    _dilation_height = conf.get_dilation_height();
    _dilation_width = conf.get_dilation_width();

    _cal_mask = conf.get_cal_mask();
    _skip_label = conf.get_skip_label();

    _conv_desc.padding_height = _padding_height;
    _conv_desc.padding_width = _padding_width;
    _conv_desc.stride_h = _stride_height;
    _conv_desc.stride_w = _stride_width;
    _conv_desc.algo = _conv_algo_type;
    _conv_desc.diff_algo = _conv_diff_algo_type;
    _conv_desc.grad_algo = _conv_grad_algo_type;
    _conv_desc.dilation_h = _dilation_height;
    _conv_desc.dilation_w = _dilation_width;

    _config = conf;
}

void ImageConvLayer::inter_forward(std::vector<IOPackage*>& in_pack) {
    Tensor<DType>* input = in_pack[0]->get_ten();
    Tensor<DType>* w = _w.w();
    Tensor<DType>* output = Layer::output(_output_keys[0]).get_ten();
    Tensor<int>* mask = in_pack[0]->get_mask();
    // 设置查找算法
    // XXX 是否可以在前向时根据 _enable_bp 来判断是否需要做反向
    if (_algo_seeker_type == FIND_SEEKER) {
        // 如果配置为 find, 需要保证输入尺寸不会变化
        if (!_algo_inited) {
            _pre_input_dim = input->get_size();
            std::vector<ConvAlgoPerf> perfs = output->conv_get_fwd_algo_perf(
                    _conv_desc, *input, *w, *output);
            perfs.erase(
                    std::remove_if(perfs.begin(), perfs.end(),
                        [](const ConvAlgoPerf perf) { return perf.status != CONV_PERF_OK;}),
                    perfs.end());
            std::sort(perfs.begin(), perfs.end(),
                    [](const ConvAlgoPerf a, const ConvAlgoPerf b) {
                        return a.time < b.time;
                     });
            _conv_algo_type = perfs[0].algo;
            _conv_work_space_size_byte = perfs[0].memory;
            _algo_inited = true;
        } else {
            CHECK(_pre_input_dim == input->get_size(),
                    "input size changed, you may set algoSeekerType = get");
        }
    } else {
        // 查找最优算法
        _conv_algo_type = output->conv_get_fwd_algo(_conv_desc, *input, *w, *output,
                                CONV_FWD_SPECIFY_WORKSAPCE_LIMIT, 10 * 1024 * 1024);
        _conv_work_space_size_byte = output->conv_get_fwd_work_space_size(_conv_desc, *input, *w,
                                *output, _conv_algo_type);
    }

    _conv_desc.algo = _conv_algo_type;
    if (_conv_work_space_size_byte > 0u) {
        _workspace->resize(Dim(_conv_work_space_size_byte), false);
    }

    output->conv_fwd(_conv_desc, *input, *w,
                     (void*)_workspace->get_data(),
                     _conv_work_space_size_byte,
                     1.0f, 1.0f);

    if (_has_bias) {
        //INTER_LOG("add bias not support");
        output->add_tensor(*_bias.w());
    }

    //注意：必须保证是语音的输入, mask数据分布为frame_num * batch_size
    //batch_size 放在第一维
    if (_cal_mask) {
        int batch_size = in_pack[0]->get_size(0);
        int kernel_height = _dilation_height * (_filter_height - 1) + 1;
        int max_out_h = output->get_size(2);
        _mask.resize(mask->get_size(), false);
        _mask.copy_from(*mask);
        mask->resize(Dim(max_out_h * batch_size), false);
        wind_image_conv_cal_mask(*output, *mask, _mask, kernel_height, _padding_height, _stride_height);
    }
    

    // 根据实际情况对label进行skip
    if (_skip_label) {
        CHECK2(_output_keys.size() == 2);
        CHECK2(in_pack.size() == 2);
        int kernel_height = _dilation_height * (_filter_height - 1) + 1;
    
        Tensor<DType>* input2 = in_pack[1]->get_ten();
        Tensor<DType>* output2 = Layer::output(_output_keys[1]).get_ten();
        
        // copy output1 mask to output2 mask
        Tensor<int>* mask1 = Layer::output(_output_keys[0]).get_mask();
        Tensor<int>* mask2 = Layer::output(_output_keys[1]).get_mask();
        CHECK2(mask1->get_size() == mask2->get_size());
        mask2->copy_from(*mask1);
        wind_image_conv_skip_label(*input2, *output2, 
                kernel_height, 
                _padding_height, 
                _stride_height, _sample_num);
    }
}

void ImageConvLayer::inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* input = in_pack[0]->get_ten();
    Tensor<DType>* w = _w.w();
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();

    if (out_pack[0] == NULL) {
        return;
    }

    Tensor<DType>* out_diff = out_pack[0]->get_ten();

    if (_algo_seeker_type == FIND_SEEKER) {
        if (!_diff_algo_inited) {
            std::vector<ConvDiffAlgoPerf> perfs = out_diff->conv_get_diff_algo_perf(
                    _conv_desc, *input, *local_diff, *w);
            perfs.erase(
                    std::remove_if(perfs.begin(), perfs.end(),
                        [](const ConvDiffAlgoPerf perf) { return perf.status != CONV_PERF_OK;}),
                    perfs.end());
            std::sort(perfs.begin(), perfs.end(),
                    [](const ConvDiffAlgoPerf a, const ConvDiffAlgoPerf b) {
                        return a.time < b.time;
                     });
            _conv_diff_algo_type = perfs[0].algo;
            _conv_diff_work_space_size_byte = perfs[0].memory;
            _diff_algo_inited = true;
        }
    } else {
        _conv_diff_algo_type = out_diff->conv_get_diff_algo(
                _conv_desc, *input, *local_diff, *w,
                CONV_DIFF_SPECIFY_WORKSAPCE_LIMIT, 10 * 1024 * 1024);
        _conv_diff_work_space_size_byte = out_diff->conv_get_diff_work_space_size(
                _conv_desc, *input, *local_diff, *w, _conv_diff_algo_type);
    }
    _conv_desc.diff_algo = _conv_diff_algo_type;
    if (_conv_diff_work_space_size_byte > 0u) {
        _workspace->resize(Dim(_conv_diff_work_space_size_byte), false);
    }

    out_diff->conv_diff(_conv_desc, *w, *local_diff,
                        (void*)_workspace->get_data(),
                        _conv_diff_work_space_size_byte,
                        1.0f, 1.0f);
}

void ImageConvLayer::inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {
    Tensor<DType>* local_diff = diff(_output_keys[0]).get_ten();
    Tensor<DType>* in = in_pack[0]->get_ten();
    Tensor<DType>* d_w = _d_w.w();

    if (_algo_seeker_type == FIND_SEEKER) {
        if (!_grad_algo_inited) {
            std::vector<ConvGradAlgoPerf> perfs = local_diff->conv_get_grad_algo_perf(
                    _conv_desc, *in, *local_diff, *d_w);
            perfs.erase(
                    std::remove_if(perfs.begin(), perfs.end(),
                        [](const ConvGradAlgoPerf perf) { return perf.status != CONV_PERF_OK;}),
                    perfs.end());
            std::sort(perfs.begin(), perfs.end(),
                    [](const ConvGradAlgoPerf a, const ConvGradAlgoPerf b) {
                        return a.time < b.time;
                     });
            _conv_grad_algo_type = perfs[0].algo;
            _conv_grad_work_space_size_byte = perfs[0].memory;
            _grad_algo_inited = true;
        }
    } else {
        _conv_grad_algo_type = local_diff->conv_get_grad_algo(
                _conv_desc, *in, *local_diff, *d_w,
                CONV_GRAD_SPECIFY_WORKSAPCE_LIMIT, 10 * 1024 * 1024);
        _conv_grad_work_space_size_byte = local_diff->conv_get_grad_work_space_size(
                _conv_desc, *in, *local_diff, *d_w, _conv_grad_algo_type);
    }
    _conv_desc.grad_algo = _conv_grad_algo_type;
    if (_conv_grad_work_space_size_byte > 0u) {
        _workspace->resize(Dim(_conv_grad_work_space_size_byte), false);
    }

    //求梯度
    d_w->conv_grad(_conv_desc, *in, *local_diff,
                   (void*)_workspace->get_data(), _conv_grad_work_space_size_byte, 1.0f, 1.0f);

    if (_has_bias) {
        Tensor<DType>* d_bias = _d_bias.w();
        d_bias->conv_bias(*local_diff, 1.0f, 1.0f);
    }
}

void ImageConvLayer::build_map(const char* prefix) {
    std::string pre;

    if (prefix) {
        pre.append(prefix);
    }

    _w_map.insert(WeightsMap::value_type(pre + "weight", &_w));

    if (_has_bias) {
        _w_map.insert(WeightsMap::value_type(pre + "bias", &_bias));
    }

    if (need_update()) {
        _dw_map.insert(WeightsMap::value_type(pre + "weight", &_d_w));

        if (_has_bias) {
            _dw_map.insert(WeightsMap::value_type(pre + "bias", &_d_bias));
        }
    }

    if (_inq) {
        _w_map.insert(WeightsMap::value_type(pre + "weight_binary", &_w_t));     
        if (_has_bias) {
            _w_map.insert(WeightsMap::value_type(pre + "bias_binary", &_bias_t));
        }
    }

}

Layer* ImageConvLayer::clone() {
    return new ImageConvLayer(this);
}

void ImageConvLayer::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->write(output);
        if (_inq) {
            _w_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_weight_max.front()); 
            max.write(output);
        }                                                     

        if (_has_bias) {
            _bias.w()->write(output);
        }

        if (_inq) {
            _bias_t.w()->write(output);
            Tensor<DType> max(Dim(1), CPU);
            max.set_element(Dim(0), _inq_bias_max.front()); 
            max.write(output);
        }

        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the ImageConvLayer has no this parameter: %d", t);
    }
}

void ImageConvLayer::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
    switch (t) {
    case WEIGHT:
        _w.w()->read(input);

        if (_has_bias) {
            _bias.w()->read(input);
            _bias.w()->reshape(Dim(_bias.w()->get_size()[0], 1, 1));
            //_bias.w()->resize(Dim(_bias.w()->get_size()[0], 1, 1));
        }

        break;

    case MD_WEIGHT:
    default:
        INTER_CHECK(false, "the ImageConvLayer has no this parameter: %d", t);
    }
}

void ImageConvLayer::read_inq_model(std::ifstream &input, SPEECH_NN_W_TYPE t)
{
    switch (t) {
        case WEIGHT:
            _w.w()->read(input);
            if (_inq) {
                _w_t.w()->read(input);
                Tensor<DType> max(Dim(1), CPU);
                max.read(input);
                _inq_weight_max.push_back(max.get_element(Dim(0)));
            }

            if (_has_bias) {
                _bias.w()->read(input);
                if (_inq) {
                    _bias_t.w()->read(input);
                    Tensor<DType> max(Dim(1), CPU);
                    max.read(input);
                    _inq_bias_max.push_back(max.get_element(Dim(0)));
                }
            }
            break;

        case MD_WEIGHT:
        default:
            INTER_CHECK(false, "the FullLayer has no this parameter: %d", t);
    }            
}

void ImageConvLayer::read_heter_model(std::ifstream& input) {

}

}
}
