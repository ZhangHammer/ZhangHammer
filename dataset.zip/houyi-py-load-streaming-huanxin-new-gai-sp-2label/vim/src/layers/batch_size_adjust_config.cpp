/**
 * global_updater_config.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-10-12
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "parse_string.h"
#include "text_utils.h"
#include "util.h"
#include "batch_size_adjust_config.h"

namespace houyi {
namespace train {

const char* batchSizeAdjustTypeName[] = {
    "fixed",
    "step",
    "multi_step",
    "linear",
    "multi_linear",
    "NULL"
};

BatchSizeAdjustCfg::BatchSizeAdjustCfg() {
    _type = FIXED_BS;
    _gamma = 1.0;
    _step = 1;
}

void BatchSizeAdjustCfg::read(std::string& cfg_lines) {
    std::string adjust_param;

    if (parse_tuple_from_string("batchSizeAdjust", &cfg_lines, &adjust_param)) {
        INTER_LOG("<batchSizeAdjust>");
        std::string adjust_type;

        if (parse_from_string("type", &adjust_param, &adjust_type)) {
            string_to_enum(adjust_type, batchSizeAdjustTypeName, &_type);
            INTER_LOG("type = %s", adjust_type.c_str());
        } else {
            CHECK(false, "lr adjust type errro");
        }

        parse_from_string("gamma", &adjust_param, &_gamma);
        INTER_LOG("gamma = %f", _gamma);
        parse_from_string("step", &adjust_param, &_step);
        INTER_LOG("step = %d", _step);
        parse_from_string("stepValue", &adjust_param, &_step_value);
        for (auto i : _step_value) {
            INTER_LOG("stepValue = %d", i);
        }

        INTER_LOG("/<batchSizeAdjust>");
    }
}

}
} //namespace houyi

