/**
 * disc_nn_config.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-14
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "disc_nn_cfg.h"
#include "tools.h"

namespace houyi {
namespace train {

const char* decoder_type_name[] = {
    "decoder",
    "triplet_decoder",
    "select_decoder",
    "unkown_decoder"
};

const char* triplet_select_type_name[] = {
    "random_hard",
    "semi_hard",
    "most_hard",
    "unknown_har"
};

void DecoderConfig::read(const char* cfg_name) {
    std::ifstream input(cfg_name);
    CHECK(input, "configure file open error: %s", cfg_name);

    std::string line;
    std::string cfg_lines;

    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }

        remove_white_space_comment(line);

        if (line.size() == 0) {
            continue;
        } else {
            cfg_lines.append("\t");
            cfg_lines.append(line);
        }
    }

    parse_from_string("decodePeriod", &cfg_lines, &_decode_period);
    parse_from_string("recall", &cfg_lines, &_recall);
    parse_from_string("selectRatio", &cfg_lines, &_select_ratio);
    std::vector<float> pos_neg_ratio;
    parse_from_string("posNegRatio", &cfg_lines, &pos_neg_ratio);

    if (!pos_neg_ratio.empty()) {
        _pos_neg_ratio = pos_neg_ratio[0] / pos_neg_ratio[1];
    }

    parse_from_string("scoreThreshold", &cfg_lines, &_score_threshold);

    std::string decoder_str;

    if (parse_from_string("decoderType", &cfg_lines, &decoder_str)) {
        string_to_enum(decoder_str, decoder_type_name, &_type);
    }

    std::string triplet_select_str;

    if (parse_from_string("tripletSelectType", &cfg_lines, &triplet_select_str)) {
        string_to_enum(triplet_select_str, triplet_select_type_name, &_triplet_select_type);
    }

    input.close();
}

void DiscPeriodConfig::read(std::string& cfg_lines) {
    PeriodConfig::read(cfg_lines);
    parse_from_string("modelUpdatePeriod", &cfg_lines, &_model_update_period);
}

DiscNNConfig::DiscNNConfig() : NNConfig() {
    _disc_score_thread_num = 0;
}

void DiscNNConfig::read_config(const char* file) {
    std::ifstream input(file);
    CHECK(input, "configure file open error: %s", file);

    std::string line;
    std::string conf_line;

    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }

        remove_white_space_comment(line);

        if (line.size() == 0) {
            continue;
        }

        if (line == "[Layer]") {
            LayerConfig* new_cfg = LayerConfig::read(input);
            CHECK(new_cfg != NULL, "new layer configure error");

            if (new_cfg->layer_id() < 0) {
                new_cfg->set_layer_id(_cfg_vec.size());
            }

            _cfg_vec.push_back(new_cfg);
        } else {
            conf_line.append("\t");
            conf_line.append(line);
        }
    }

    parse_from_string("deviceId", &conf_line, &_device_ids);
    parse_from_string("keepHistory", &conf_line, &_keep_history);
    parse_from_string("dataCfgFile", &conf_line, &_data_cfg_file);
    parse_from_string("devDataCfgFile", &conf_line, &_dev_set_data_cfg_file);
    parse_from_string("decoderCfgFile", &conf_line, &_decoder_cfg_file);
    parse_from_string("callBeforePredict", &conf_line, &_call_before_predict);
    parse_from_string("callAfterPredict", &conf_line, &_call_after_predict);
    parse_from_string("pythonPath", &conf_line, &_python_path);

    parse_from_string("threadNum", &conf_line, &_disc_score_thread_num);

    if (_disc_score_thread_num == 0) {
        _disc_score_thread_num = (int)_device_ids.size();
    }

    std::string job_str;

    if (parse_from_string("jobType", &conf_line, &job_str)) {
        string_to_enum(job_str, jobTypeName, &_job_type);
    }

    for (size_t i = 0; i < _cfg_vec.size(); i++) {
        _cfg_vec[i]->set_global_job_type(_job_type);
    }

    _model_init_cfg.read(conf_line);                            // initialize
    _disc_period_cfg.read(conf_line);                           // period
    _data_cfg.read(_data_cfg_file.c_str());                     // DataConfig

    if (!_dev_set_data_cfg_file.empty()) {
        _dev_set_data_cfg.read(_dev_set_data_cfg_file.c_str());     // deveplop set data config
    }

    /* decoder Config */
    _decoder_cfg.read(_decoder_cfg_file.c_str());
    _decoder_cfg.set_epoch(_disc_period_cfg.epoch());
    _decoder_cfg.set_score_thread_num(_disc_score_thread_num);

    /* if no set, the set some default values */
    _batch_size = _data_cfg.get_batch_size();
    CHECK2(_batch_size!= 0);

    _data_cfg.set_device_num(_thread_num);

    input.close();
}

}
} //namespace houyi

