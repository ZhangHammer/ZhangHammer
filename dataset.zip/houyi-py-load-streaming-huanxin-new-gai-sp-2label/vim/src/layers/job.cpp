/*
 *Filename: job.cpp
 *Description:
 *
 *Version: 1.0
 *Created: 2016年09月06日 10时19分49秒
 *Author: lifeng(lifeng20@baidu.com)
 *
 *Copyright: Copyright (c) baidu, Inc. All Rights Reserved
 *
 */
#include "job.h"

namespace houyi {
namespace train {

const char* jobTypeName[] = {
    "train",
    "discTrain",
    "predict",
    "speechPredict",
    "imagePredict",
    "imageVote",
    "imageMsePredict",
    "discPredict",
    "NULL"
};

bool is_predict_job(JobType job_type) {
    if (job_type == PREDICT ||
            job_type == SPEECH_PREDICT ||
            job_type == IMAGE_PREDICT ||
            job_type == IMAGE_VOTE_PREDICT ||
            job_type == IMAGE_MSE_PREDICT ||
            job_type == DISC_PREDICT
       ) {
        return true;
    } else {
        return false;
    }
}

}
}

