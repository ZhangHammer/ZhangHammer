// by zhxfl 2018.06.07
#include <string>
#include "audio_delta.h"
#include "audio_delta_ops.h"

namespace houyi {
namespace train {

AudioDelta::AudioDelta(AudioDeltaConfig& config) : Layer(config) {
    set_device();
    _config = config;
    _windows = config.get_windows();
    _seq_len.set_device(gpu_device());

    build_map();
}

void AudioDelta::layer_set(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK(_input_keys.size() == inputs.size(),
          "keys size not equal width dim size");
    CHECK(inputs.size() == 1,
          "%s layer only have one input", _name.c_str());

    _sample_num = sample_num;

    for (auto it : inputs) {
        _input.push_back(it);
    }

    resize_out(inputs, sample_num);

    print_input_dim(std::string("input"), inputs);
    print_output_dim(std::string("output"), _output);
}

void AudioDelta::resize_out(std::vector<IOPackage*>& inputs, int sample_num) {
    CHECK2(inputs.size() == 1);
    int height = inputs[0]->get_size()[0];
    int width = inputs[0]->get_size()[1];
    _sample_num = sample_num;

    for (size_t i = 0; i < _output_keys.size(); i++) {
        _output[i].resize(Dim(height, width * (_windows + 1)),  inputs[i]->get_mask(), 
                          gpu_device());
    }
}

void AudioDelta::build_map(const char* prefix) {
}

AudioDelta::AudioDelta(AudioDelta* from) : Layer(from) {
    CHECK2(from != NULL);
    bool is_update = need_update();
    from->config().set_update(is_update);
    new(this) AudioDelta(from->config());
    layer_set(from->get_input(), from->get_sample_num());
}

AudioDelta::~AudioDelta() {
}

void AudioDelta::inter_forward(std::vector<IOPackage*>& pack) {
    Tensor<DType>* pre_in = pack[0]->get_ten();
    Tensor<DType>* out = output(_output_keys[0]).get_ten();

    _seq_len.resize(Dim(_sample_num), false);
    _seq_len.count_valid_label(*pack[0]->get_mask(), _sample_num, pre_in->get_size(0) / _sample_num);
    wind_delta(*pre_in, *out, _seq_len, _sample_num, _windows);
}

void AudioDelta::inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
    if (out_pack.size() == 0 || out_pack[0] == NULL) return;
    Tensor<DType>* pre_diff = out_pack[0]->get_ten();
    pre_diff->zero();
}

void AudioDelta::inter_bprop_grad(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
}

Layer* AudioDelta::clone() {
    return new AudioDelta(this);
}

void AudioDelta::store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
}

void AudioDelta::read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
}

void AudioDelta::read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
}

} // namespace houyi
} // namespace train

