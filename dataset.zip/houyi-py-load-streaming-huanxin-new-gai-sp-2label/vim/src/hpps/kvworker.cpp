#include "omp.h"
#include "ps/kvworker.h"
#include "updater/updater.h"

namespace hpps {

KVWorker::KVWorker() : KVBase(WORKER_NODE) {
    _key2svr.clear();
    _callbacks.clear();
    _updater = NULL;
    _prof = new Profiler(role_desc().c_str());
    _prof_counter = 0;
    _comm_method = COMM_PUSHPULL;

    omp_set_num_threads(2);
}

KVWorker::~KVWorker() {
    notify_and_exit();    

    if (_updater) {
        delete _updater;
        _updater = NULL;
    }

    if (_prof) {
        delete _prof;
        _prof = NULL;
    }
}

void KVWorker::set_updater(std::string updater)
{
    if (_updater) {
        delete _updater;
        _updater = NULL;
    }

    _updater = UpdaterFactory::create_updater(role_desc(), updater);
    _updater->set_param(_options);

    INTER_LOG("%s set updater = %s", role_desc().c_str(), updater.c_str());
}

void KVWorker::notify_and_exit()
{
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    Message msg;
    msg.type = ControlMsg;
    msg.node = node();
    msg.control.cmd = ControlExit; 
    coord->bcast_all_servers(*this, msg);
}

void KVWorker::coordinate(std::vector<Key>& key, std::vector<Len>& len) 
{
    std::vector<Key> empty;
    coordinate(key, len, empty); 
}

void KVWorker::coordinate(std::vector<Key>& key, std::vector<Len>& len,
    std::vector<size_t>& color) 
{
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    coord->coordinate(*this, key, len, color);
    _key2svr.clear();
    for (size_t i = 0; i < key.size(); i++) {
        Rank iter = coord->get_svr(key[i]);
        _key2svr.insert(std::make_pair(key[i], iter));
    }
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    _num_workers = coord->worker_num();
    this->init_wins();
#endif

    if (_options.find("update") != _options.end()) {
        set_updater(_options.at("update")); 
    }
    _updater->set_param(_options);
}

void KVWorker::barrier()
{
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    coord->barrier(*this, NULL);
}

bool KVWorker::sync_global_status()
{
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    return coord->sync_global_status(*this);
}

bool KVWorker::reset(const std::vector<Key>& in_keys,
                    const std::vector<Val>& in_vals)
{
    return push(in_keys, in_vals, Reset);
}

bool KVWorker::push(const std::vector<Key>& in_keys,
                    const std::vector<Val>& in_vals,
                    int op)
{
    Message msg;
    std::vector<Key> keys = in_keys;
    std::vector<Val> vals = in_vals;
    CHECK2(keys.size() == vals.size());
    if (check_kvs(keys, vals) == false) {
        return false;
    }
    sort_kvs(keys, vals);

    // collect related servers
    std::set<Rank> svrs = unique_servers(keys); 
    for (auto svr : svrs) {
        std::vector<char*> ptrs;
        ptrs.clear();

        msg.clear();
        msg.type = DataMsg;
        msg.node.role = role();
        msg.node.id = rank();
        msg.data.op = op;

        for (size_t i=0; i<keys.size(); i++) {
            if (svr == _key2svr[keys[i]]) {
                size_t bsize = sizeof(*vals[i].get_ptr());
                msg.data.key.push_back(keys[i]); 
                msg.data.len.push_back(vals[i].get_element_count() * bsize);
                ptrs.push_back((char*)vals[i].get_ptr());
            } 
        } 
        send(msg, svr);
        for (size_t i=0; i<msg.data.len.size(); i++) {
            send(ptrs[i], msg.data.len[i], svr, DataTag);
        } 
    } 
    return true;
}

bool KVWorker::pull(const std::vector<Key>& in_keys,
                    const std::vector<Val>& in_vals)
{
    Message rqt;
    std::vector<Key> keys = in_keys;
    std::vector<Val> vals = in_vals;
    CHECK2(keys.size() == vals.size());
    if (check_kvs(keys, vals) == false) {
        return false;
    }
    sort_kvs(keys, vals);

    std::set<Rank> svrs = unique_servers(keys);

    for (auto svr : svrs) {
        std::vector<char*> ptrs;
        std::vector<Val> t_out_vals;
        ptrs.clear();
        t_out_vals.clear();

        rqt.clear();
        rqt.type = DataMsg;
        rqt.node.role = role();
        rqt.node.id = rank();
        rqt.data.op = Pull;

        for (size_t i=0; i<keys.size(); i++) {
            if (svr == _key2svr[keys[i]]) {
                size_t bsize = sizeof(*vals[i].get_ptr());
                rqt.data.key.push_back(keys[i]);
                rqt.data.len.push_back(vals[i].get_element_count() * bsize);
                ptrs.push_back((char*)vals[i].get_ptr());
            }
        }
        send(rqt, svr); 

        for (size_t i=0; i<rqt.data.len.size(); i++) {
            recv_into<char>(ptrs[i], rqt.data.len[i], svr, DataTag);
        }
    }
    return true;
}

bool KVWorker::push_pull(const std::vector<Key>& in_keys,
            const std::vector<Val>& in_in_vals,
            std::vector<Val>& out_out_vals)
{
    Message rqt;
    std::vector<Key> keys = in_keys;
    std::vector<Val> in_vals = in_in_vals;
    std::vector<Val> out_vals = out_out_vals;
    
    CHECK2(keys.size() == in_vals.size());
    CHECK2(keys.size() == out_vals.size());
    if (check_kvs(keys, in_vals) == false) {
        return false;
    }
    sort_kvs(keys, in_vals, out_vals);

    // collect related servers
    std::set<Rank> svrs = unique_servers(keys); 
    std::vector<mpx::future<void>> futures;
    for (auto svr : svrs) {
        std::vector<char*> in_ptrs;
        std::vector<char*> out_ptrs;
        in_ptrs.clear();
        out_ptrs.clear();

        rqt.clear();
        rqt.type = DataMsg;
        rqt.node.role = role();
        rqt.node.id = rank();
        rqt.data.op = PushPull;

        for (size_t i=0; i<keys.size(); i++) {
            if (svr == _key2svr[keys[i]]) {
                size_t bsize = sizeof(*in_vals[i].get_ptr());
                rqt.data.key.push_back(keys[i]); 
                rqt.data.len.push_back(in_vals[i].get_element_count() * bsize);
                in_ptrs.push_back((char*)in_vals[i].get_ptr());
                out_ptrs.push_back((char*)out_vals[i].get_ptr());
            } 
        } 
        
        send(rqt, svr);
        for (size_t i=0; i<rqt.data.len.size(); i++) {
            mpx::future<void> f = isend<char>(in_ptrs[i], rqt.data.len[i], svr, DataTag);    
            futures.push_back(std::move(f));
        } 
        for (size_t i=0; i<rqt.data.len.size(); i++) {
            mpx::future<void> f = irecv_into<char>(out_ptrs[i], rqt.data.len[i], svr, DataTag);
            futures.push_back(std::move(f));
        }
        
    } 
    wait(futures);

    return true;
}

inline std::set<Rank> KVWorker::unique_servers(const std::vector<Key>& keys)
{
    // collect related servers
    std::set<Rank> svrs;
    for (size_t i=0; i<keys.size(); i++) {
        std::unordered_map<Key, Rank>::iterator iter = _key2svr.find(keys[i]);
        CHECK2(iter != _key2svr.end());
        svrs.insert(iter->second);
    }
    return svrs;
}

bool KVWorker::update(const std::vector<Key>& in_keys,
            const std::vector<Val>& in_in_vals,
            std::vector<Val>& out_out_vals)
{
    bool ret = false;

    PROF_BEGIN(_prof);
    if (_comm_method == COMM_PUSHPULL) {
        ret = push_pull(in_keys, in_in_vals, out_out_vals);
    } 
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3 
    else if (_comm_method == COMM_GETPUT) {
        ret = get_put(in_keys, in_in_vals, out_out_vals);
    } 
#endif
    PROF_END(_prof);

    if (++_prof_counter == 100) {
        PROF_INFO(_prof);
        PROF_CLEAR(_prof);
        _prof_counter = 0;
    }
    return ret;
}

bool KVWorker::check_kvs(const std::vector<Key>& keys, const std::vector<Val>& vals)
{    
    std::vector<Key> t_keys = keys;
    std::sort(t_keys.begin(), t_keys.end());
    auto iter = std::unique(t_keys.begin(), t_keys.end()); 
    if (iter != t_keys.end()) {
        CHECK(false, "keys is not unique");
        return false;
    }

    return true;
}

void KVWorker::sort_kvs(std::vector<Key>& keys, std::vector<Val>& in_vals, std::vector<Val>& out_vals)
{
    std::vector<Key> t_keys = keys;
    
    std::sort(t_keys.begin(), t_keys.end(), std::less<Key>());
    if (t_keys == keys) {
        return;
    }

    std::vector<Val> t_in_vals = in_vals; 
    std::vector<Val> t_out_vals = out_vals; 
    in_vals.clear();
    out_vals.clear();
    for (size_t i=0; i<t_keys.size(); i++) {
        auto iter = std::find(keys.begin(), keys.end(), t_keys[i]);
        size_t idx = iter - keys.begin();
        in_vals.push_back(t_in_vals[idx]);
        out_vals.push_back(t_out_vals[idx]);
    }
    keys = t_keys;
}

void KVWorker::sort_kvs(std::vector<Key>& keys, std::vector<Val>& vals)
{
    std::vector<Key> t_keys = keys;
    
    std::sort(t_keys.begin(), t_keys.end(), std::less<Key>());
    if (t_keys == keys) {
        return;
    }

    std::vector<Val> t_vals = vals; 
    vals.clear();
    for (size_t i=0; i<t_keys.size(); i++) {
        auto iter = std::find(keys.begin(), keys.end(), t_keys[i]);
        size_t idx = iter - keys.begin();
        vals.push_back(t_vals[idx]);
    }
    keys = t_keys;
}

bool KVWorker::major_worker() const {
    KVCoordinator *coord = KVCoordinator::get_obj();
    std::set<Rank> workers = coord->worker_id();
    if (rank() == *std::min_element(workers.begin(), workers.end())) {
        return true;
    } else {
        return false;
    }
}

void KVWorker::set_option(const char* name, const char* var) {
    if (strcmp(name, "CommMethod") == 0) {
        if (strcmp(var, "PushPull") == 0) {
            _comm_method = COMM_PUSHPULL;
            INTER_LOG("comm method is pushpull");
        } else if (strcmp(var, "GetPut") == 0) {
            _comm_method = COMM_GETPUT;
            INTER_LOG("comm method is getput");
        } else {
            CHECK(false, "Unknown comm method = %s", var);
        }
        return;
    }
}

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
void KVWorker::init_wins() {
    for (auto& iter : *_key2wins) {
        std::unique_ptr<mpx::win>& w_win = iter.second.first;
        std::unique_ptr<mpx::win>& dw_win = iter.second.second;

        w_win = std::unique_ptr<mpx::win>(new mpx::win(NULL, 0 ,1 , get_comm()));
	    dw_win = std::unique_ptr<mpx::win>(new mpx::win(0, 1, get_comm()));

    }   
        
}

bool KVWorker::get_put(const std::vector<Key>& in_keys,
                       const std::vector<Val>& in_in_vals,
                       std::vector<Val>& out_out_vals)
{
    Message rqt;
    std::vector<Key> keys = in_keys;
    std::vector<Val> in_vals = in_in_vals;
    std::vector<Val> out_vals = out_out_vals;
        
    CHECK2(keys.size() == in_vals.size());
    CHECK2(keys.size() == out_vals.size());
    if (check_kvs(keys, in_vals) == false) {
        return false;
    }   
    sort_kvs(keys, in_vals, out_vals);
    
    for (size_t i = 0; i < keys.size(); ++i) {
        Key key = keys[i];
        size_t len = in_vals[i].get_element_count();
        Rank srv = _key2svr[key];
        auto& wins = _key2wins->at(key);
        auto& w_win = wins.first;
        auto& dw_win = wins.second;
            
        w_win->shared_lock(srv);
        dw_win->shared_lock(srv);
            
        w_win->get(out_vals[i].get_ptr(), len, srv, 0); 
        dw_win->put(in_vals[i].get_ptr(), len, srv, (rank() % _num_workers) * len);
    }   
    
    // collect related servers
    std::set<Rank> svrs = unique_servers(keys);
    for (auto svr : svrs) {
        rqt.clear();
        rqt.type = DataMsg;
        rqt.node.role = role();
        rqt.node.id = rank();
        rqt.data.op = PutDone;

        for (size_t i=0; i<keys.size(); i++) {
            if (svr == _key2svr[keys[i]]) {
                auto& wins = _key2wins->at(keys[i]);
                auto& w_win = wins.first;
                auto& dw_win = wins.second;
                dw_win->unlock();
                w_win->unlock();

                rqt.data.key.push_back(keys[i]);
                rqt.data.len.push_back(in_vals[i].get_element_count());
            }
        }
        send(rqt, svr);
    }

    for (size_t i = 0; i < in_keys.size(); ++i) {
        _updater->update(out_out_vals[i], out_out_vals[i], in_in_vals[i]);
        //out_out_vals[i].add(in_in_vals[i], out_out_vals[i], 1.0f, 1.0f);
    }

    return true;
}

#endif

}
