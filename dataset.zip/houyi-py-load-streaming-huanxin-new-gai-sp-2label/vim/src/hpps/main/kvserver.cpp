#include <iostream>
#include "ps/kvserver.h"

int main(int argc, char* argv[])
{
    setenv("CUDA_VISIBLE_DEVICES", "0", 1);

    wind::wind_start();
    wind::wind_init(0);

    hpps::KVServer * kv = NULL;
    kv = new hpps::KVServer(argc, argv);
    INTER_LOG("Rank[%d] start KVServer", kv->rank());

    kv->coordinate();

    kv->start_all_threads();
    
    while (!kv->check_exit()) {
        sleep(10);
        INTER_LOG("%s waiting exiture", kv->role_desc().c_str());
    }

    delete kv;

    wind::wind_shutdown();
    
    return 0;
}
