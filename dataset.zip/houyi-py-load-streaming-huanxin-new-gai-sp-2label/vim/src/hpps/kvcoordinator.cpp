#include "ps/kvbase.h"
#include "ps/kvcoordinator.h"
#include "ps/kvserver.h"

namespace hpps {

void KVCoordinator::worker_exited(KVBase& kv, Rank rank) {
    Message msg;
    std::unique_lock<std::mutex> lk(_mutex);
    _workers.erase(rank);
    lk.unlock();
    // Need check whether in barrier procedure
    //barrier(kv, &msg, rank);
} 

void KVCoordinator::split_keys()
{
    std::vector<size_t> loads;
    std::vector<std::pair<Key,Len>> vec(_key2len.begin(), _key2len.end());
    auto cmp = [](std::pair<Key,Len> const & a, std::pair<Key,Len> const & b) 
    { 
        return a.second > b.second;
    }; 
    std::sort(vec.begin(), vec.end(), cmp);

    _key2svr.clear();
    loads.resize(_servers.size(), 0);
    for (auto e=vec.begin(); e<vec.end(); e++) {
        auto iter = std::min_element(loads.begin(), loads.end());
        size_t svr = std::distance(loads.begin(), iter);
        INTER_LOG("Key:Len = %lu:%lu assigned to Server%lu", e->first, e->second, svr);
        _key2svr.insert(std::make_pair(e->first, svr));
        loads[svr] += e->second;
    }
    INTER_LOG("Coordinator split %lu keys into %lu servers", vec.size(), _servers.size()); 
}

void KVCoordinator::split_colors()
{
    std::vector<size_t> loads;
    std::unordered_map<Key, Len> color2len;
    for (auto e : _key2len) {
        Key key = e.first;
        Key color = _key2color[key];
        if (color2len.find(color) != color2len.end()) {
            color2len[color] += e.second;
        } else {
            color2len[color] = e.second;
        } 
    }

    // sorted by length of colors
    std::vector<std::pair<Key,Key>> vec(color2len.begin(), color2len.end());
    auto cmp = [](std::pair<Key,Key> const & a, std::pair<Key,Key> const & b) 
    { 
        return a.second > b.second;
    }; 
    std::sort(vec.begin(), vec.end(), cmp);

    _key2svr.clear();
    loads.resize(_servers.size(), 0);
    for (auto e : vec) {
        auto iter = std::min_element(loads.begin(), loads.end());
        size_t svr = std::distance(loads.begin(), iter);
        for (auto k : _key2len) {
            if (_key2color[k.first] == e.first) {
                _key2svr.insert(std::make_pair(k.first, svr));
                INTER_LOG("Key:Color:Len = %lu:%lu:%lu assigned to Server%lu", k.first, e.first, k.second, svr);
            }
        }
        loads[svr] += e.second;
    }
    INTER_LOG("Coordinator split %lu colors into %lu servers", vec.size(), _servers.size()); 
}

void KVCoordinator::coordinate(KVBase& kv, std::vector<Key>& key, std::vector<Len>& len,
    std::vector<Key>& color)
{
    std::unordered_map<Key, Rank> maps;
    MessageHeader hdr;
    Message msg;
    char* rbuf = NULL; 
    char* buf = NULL;
    Role role = kv.role(); 
    Node node = {role, kv.rank()};

    CHECK(key.size() == len.size(), "Key length DONOT match Len");
    CHECK((color.size() == 0) || (color.size() == key.size()), "Color length DONOT match Key");

    if (role == SERVER_NODE) {
        if (kv.rank() == 0) {
            // master server
            _servers.insert(0);
            for (int i=1; i < kv.comm_size(); i++) {
                kv.KVBase::recv(msg, i);
                CHECK2(msg.type = CoordinateMsg);
                if (msg.node.role == WORKER_NODE) {
                    for (size_t i=0; i<msg.coordinate.key.size(); i++) {
                        _key2len.insert(std::make_pair(msg.coordinate.key[i], msg.coordinate.len[i]));        
                    } 

                    if (msg.coordinate.color.size() > 0) {
                        for (size_t i=0; i<msg.coordinate.key.size(); i++) {
                            _key2color.insert(std::make_pair(msg.coordinate.key[i], msg.coordinate.color[i]));        
                        }
                    }
                   
                    _workers.insert(msg.node.id);

                } else {
                    _servers.insert(msg.node.id);

                }
            }
           
            if (_key2color.size() > 0) {
                split_colors();
            } else {
                split_keys();
            } 
    
            msg.clear();
            msg.node = node; 
            msg.type = CoordinateMsg;
            msg.coordinate.cmd = 1;
            for (auto iter = _key2svr.begin(); iter != _key2svr.end(); iter++) {
                msg.coordinate.key.push_back(iter->first); 
                msg.coordinate.len.push_back(_key2len.find(iter->first)->second);
                msg.coordinate.svr.push_back(iter->second); 
            }
            msg.control.cmd = ControlInfo; 
            // padding server nodes
            for (auto i=_servers.begin(); i!=_servers.end(); i++) {
                msg.control.node.push_back(Node{SERVER_NODE, *i});
            }
            // padding worker nodes
            for (auto i=_workers.begin(); i!=_workers.end(); i++) {
                msg.control.node.push_back(Node{WORKER_NODE, *i});
            }
            // padding options
            for (auto i=kv.options().begin(); i!=kv.options().end(); i++) {
                msg.control.option.push_back(Option{.name = i->first, .val = i->second});
            }
            for (auto i=_workers.begin(); i!=_workers.end(); i++) {
                kv.KVBase::send(msg, *i);
            }
            for (auto i=_servers.begin(); i!=_servers.end(); i++) {
                if (*i == kv.rank()) 
                    continue;
                kv.KVBase::send(msg, *i);
            }
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
            // padding key2wins map
            for (auto iter = _key2svr.cbegin(); iter != _key2svr.cend(); iter++) {
                auto key = iter->first;
                kv.insert_key(key);
            }   
#endif
        } else {
            // other servers
            msg.type = CoordinateMsg;
            msg.coordinate.cmd = 1;
            msg.node = node;
            kv.KVBase::send(msg, 0); 
            kv.KVBase::recv(msg, 0); 
        }
        
    } else if (role == WORKER_NODE) {
        msg.type = CoordinateMsg;
        msg.node = node;
        msg.coordinate.cmd = 1;
        msg.coordinate.key = key;
        msg.coordinate.len = len;
        msg.coordinate.color = color;
        kv.send(msg, 0); 
        kv.recv(msg, 0);
    }

    // gather all servers and workers 
    if (kv.rank() != 0) {
        CHECK(msg.control.cmd == ControlInfo, "Unexpected control type = %d", msg.control.cmd);  
        _servers.clear();
        _workers.clear();
        for (size_t i=0; i<msg.control.node.size(); i++) {
            Node& node = msg.control.node[i];
            if (node.role == SERVER_NODE) {
                _servers.insert(node.id);
            } else if (node.role == WORKER_NODE) {
                _workers.insert(node.id);
            }
        }
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
        Coordinate &co = msg.coordinate;
        for (const auto& key : co.key) {
            kv.insert_key(key);
        }   
#endif
        INTER_LOG("%s found %lu servers", kv.role_desc().c_str(), _servers.size());
    }

    if (kv.rank() != 0 && role == SERVER_NODE) {
        _key2len.clear(); 
        _key2svr.clear(); 
        Coordinate &co = msg.coordinate;
        // gather keys belong to me
        for (size_t i=0; i<co.key.size(); i++) {
            if (co.svr[i] == kv.rank()) {
                _key2len.insert(std::make_pair(co.key[i], co.len[i]));
                _key2svr.insert(std::make_pair(co.key[i], co.svr[i]));
            }
        } 
        kv.set_options(msg.control.option);
        
    } else if (role == WORKER_NODE) {
        _key2len.clear(); 
        _key2svr.clear(); 
        Coordinate &co = msg.coordinate;
        // gather servers for me
        for (size_t i=0; i<key.size(); i++) {
            auto iter = std::find(co.key.begin(), co.key.end(), key[i]);
            CHECK(iter != co.key.end(), "Could not find key = %lu", key[i]);
            int idx = iter - co.key.begin();
            _key2len.insert(std::make_pair(co.key[idx], co.len[idx]));
            _key2svr.insert(std::make_pair(co.key[idx], co.svr[idx]));
        } 
        kv.set_options(msg.control.option);
    }

    if (rbuf) {
        free(rbuf);
    }

    if (buf) {
        free(buf);
    }
}

bool KVCoordinator::barrier(KVBase& kv, Message* imsg, Rank rank)
{
    Message msg;
    msg.clear();
    Role role = kv.role();
    if (role == WORKER_NODE) {
        msg.type = ControlMsg;
        msg.node = kv.node();
        msg.control.cmd = ControlGlobalBarrier;
        // bcast to all servers
        bcast_all_servers(kv, msg);
        recv_all_servers(kv);
        return false;

    } else if (role == SERVER_NODE) {
        std::unique_lock<std::mutex> lk(_mutex);
        INTER_LOG("%s received barrier from Rank[%d]", kv.role_desc().c_str(), rank);
        if (_workers.find(rank) != _workers.end()) {
            _barrier_workers.insert(rank);
        }
        if (_barrier_workers == _workers) {
            CHECK2(imsg);
            imsg->type = ControlMsg;
            imsg->node = kv.node();
            imsg->control.cmd = ControlGlobalBarrier;
            _barrier_workers.clear(); 
            return true;
        } else {
            return false;
        } 
    } else {
        CHECK2(false);
        return false;
    }
}

bool KVCoordinator::sync_global_status(KVBase& kv, Rank dest, int qidx)
{
    bool ret = true;
    Message msg;
    msg.clear();
    msg.type = ControlMsg;
    msg.node = kv.node();
    msg.control.cmd = ControlGlobalStatus;
    
    std::unique_lock<std::mutex> lk(_mutex);
    for (auto i=_servers.begin(); i!=_servers.end(); i++) {
        msg.control.node.push_back(Node{SERVER_NODE, *i});
    }
    for (auto i=_workers.begin(); i!=_workers.end(); i++) {
        msg.control.node.push_back(Node{WORKER_NODE, *i});
    }
    static_cast<KVServer*>(&kv)->KVServer::send(msg, dest, qidx);  

    return ret;
}

bool KVCoordinator::sync_global_status(KVBase& kv)
{
    bool ret = true;
    Message msg;
    msg.clear();
    msg.type = ControlMsg;
    msg.node = kv.node();
    msg.control.cmd = ControlGlobalStatus;
    kv.KVBase::send(msg, 0);
    kv.KVBase::recv(msg, 0);

    std::set<Rank> servers;
    std::set<Rank> workers;
    for (size_t i=0; i<msg.control.node.size(); i++) {
        Node& node = msg.control.node[i];
        if (node.role == SERVER_NODE) {
            servers.insert(node.id);
        } else if (node.role == WORKER_NODE) {
            workers.insert(node.id);
        }
    }        

    if ((_servers != servers) || (_workers != workers)) {
        ret = false;
    }
        
    return ret;
}

}
