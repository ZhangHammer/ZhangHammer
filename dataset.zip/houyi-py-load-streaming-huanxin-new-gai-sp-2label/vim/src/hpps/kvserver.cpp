#include "omp.h"
#include "ps/kvserver.h"

namespace hpps {

KVServer::KVServer(int argc, char* argv[]) : KVBase(SERVER_NODE) {
    _updater = NULL;
    _enable_distance_drop = false;

    _parser.add<std::string>("optimizer", 'o', "optimizer type [easgd/sgd]", false, "sgd", 
        hpps::oneof<std::string>("sgd", "easgd"));
    _parser.add<size_t>("max_dist", 'd', "maximum distance", false, 0, hpps::range(1, 128));
    _parser.add<float>("moving_rate", 'm', "moving rate for easgd", false, 0, 
        hpps::range(0.0f, 1.0f));
    _parser.parse_check(argc, argv);

    // paramter maximum distance
    if (_parser.get<size_t>("max_dist") != 0) {
        _enable_distance_drop = true;
        _max_distance = _parser.get<size_t>("max_dist");
        INTER_LOG("%s option: maximum distance = %lu", role_desc().c_str(), _max_distance);
        _options.insert(std::make_pair<std::string, std::string>
            ("max_dist", std::to_string(_max_distance)));
    }

    // paramter moving rate
    if (_parser.get<float>("moving_rate") != 0) {
        float mr = _parser.get<float>("moving_rate");
        INTER_LOG("%s option moving_rate = %f", role_desc().c_str(), mr);
        _options.insert(std::make_pair<std::string, std::string>("moving_rate", 
            std::to_string(mr)));
    }

    // optimizer type
    std::string update = _parser.get<std::string>("optimizer");
    if (update.compare("sgd") == 0) {
        set_updater(update);
    } else if (update.compare("easgd") == 0) {
        set_updater(update); 
    } else {
        CHECK(false, "Unknown optimizer type = %s", update.c_str());
    }
    _options.insert(std::make_pair<std::string, std::string>("update", std::move(update)));
}

void KVServer::set_updater(std::string updater)
{
    if (_updater) {
        delete _updater;
    }

    _updater = UpdaterFactory::create_updater(role_desc(), updater, true);
    if (!_updater) {
        INTER_LOG("Unknown updater: %s", updater.c_str());
    } 

    set_updater_param(_options);
    INTER_LOG("%s set option updater = %s", role_desc().c_str(), updater.c_str());
}

bool KVServer::wait_exit()
{
    std::unique_lock<std::mutex> lk(_status_mutex);
    KVCoordinator *coord = KVCoordinator::get_obj();
    _worker_quit.wait(lk, [&]{return 0 == coord->worker_num();});
    if (coord->worker_num() == 0) {
        INTER_LOG("%s found all workers exited", role_desc().c_str());
        return true;
    } else {
        return false;
    }
}

bool KVServer::check_exit()
{  
    KVCoordinator *coord = KVCoordinator::get_obj();
    if (coord->worker_num() == 0) {
        INTER_LOG("%s found all workers exited", role_desc().c_str());
        return true;
    } else {
        return false;
    }
}

void KVServer::init_env() {
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    size_t threads = coord->worker_num() + coord->server_num();
    _comm_rqt_vec.resize(threads + 1);  
    _comm_ack_vec.resize(threads + 1);  
    for (size_t i = 0; i < threads + 1; i++) {
        char* message_buffer = (char*)_mm_malloc(max_message_byte_size, 16);
        _comm_buffer_vec.push_back(message_buffer); 
    }
}

void KVServer::clear_env() {
    for (size_t i = 0; i < _comm_buffer_vec.size(); i++) {
        _mm_free(_comm_buffer_vec[i]);
    }
    _comm_buffer_vec.clear(); 
}

void KVServer::start_receiving() {
    _recv_thread = std::thread(&KVServer::receiving, this);
}

void KVServer::start_processing() {
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    int threads = coord->worker_num() + coord->server_num();
    for (int i=0; i<threads; i++) {
        _proc_thread.push_back(std::thread(&KVServer::processing, this, i));
    }
}

void KVServer::start_comming() {
    _comm_thread = std::thread(&KVServer::comm_processing, this);
}

void KVServer::stop_all_threads() {
    Message msg;
    if (_recv_thread.joinable()) {
        _recv_thread_quit = true;
        _recv_thread.join();
    }
    INTER_LOG("%s receiving-thread stopped", role_desc().c_str());

    msg.type = ControlMsg;
    msg.node = node();
    msg.control.cmd = ControlExit;
    for (size_t i=0; i<_proc_thread.size(); i++) {
        if (_proc_thread[i].joinable()) {
            _rqt_queue_vec[i].push(msg);
            _proc_thread[i].join();
        }
    }
    INTER_LOG("%s processing-thread stopped", role_desc().c_str());

    if (_comm_thread.joinable()) {
        _comm_thread_quit = true;
        _comm_thread.join();
    }
    INTER_LOG("%s comming-thread stopped", role_desc().c_str());
}

void KVServer::coordinate() {
    std::vector<Key> key;
    std::vector<Len> len;
    std::vector<Key> empty;
    KVCoordinator *coord = KVCoordinator::get_obj(); 
    coord->coordinate(*this, key, len, empty);
    auto key2svr = coord->get_key2svr();
    auto key2len = coord->get_key2len();

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    _num_workers = coord->worker_num();
#endif
    
    CHECK(_updater, "Set updater before calling coordinate");

    for (auto iter=key2svr.begin(); iter!=key2svr.end(); iter++) {
        if (iter->second == rank()) {
            Key key = iter->first;
            Len len = key2len[key];
            Val val = Val(wind::Dim(len), wind::CPU_PINNED);
            val.zero();
            _kvs.insert(std::make_pair(iter->first, val));
            _key_timestamps.insert(std::make_pair(iter->first, 
                std::vector<size_t>(coord->worker_num() + coord->server_num(), 0)));
            _updater->init_val(iter->first, key2len[iter->first]);
            _key_mutex.insert(std::make_pair(iter->first, new std::mutex()));
        }
    }

    _comm_kvs.resize(coord->worker_num() + coord->server_num());
    for (size_t i=0; i<_comm_kvs.size(); i++) {
        std::unordered_map<Key, Val>& kvs = _comm_kvs[i];
        for (auto iter=key2svr.begin(); iter!=key2svr.end(); iter++) {
            if (iter->second == rank()) {
                Len len = key2len[iter->first];
                kvs.insert(std::make_pair(iter->first, Val(wind::Dim(len), wind::CPU_PINNED)));
            }
        }
    }

    _output_kvs.resize(coord->worker_num() + coord->server_num());
    for (size_t i=0; i<_output_kvs.size(); i++) {
        for (auto iter=key2svr.begin(); iter!=key2svr.end(); iter++) {
            if (iter->second == rank()) {
                Key key = iter->first;
                Len len = key2len[key];
                _output_kvs[i].insert(std::make_pair(iter->first, Val(wind::Dim(len), wind::CPU_PINNED)));
            }
        }
    }

    _rqt_queue_vec.resize(coord->worker_num() + coord->server_num());
    _val_queue_vec.resize(coord->worker_num() + coord->server_num());

    this->init_env();

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    this->init_wins();
#endif
   
    set_updater_param(_options); 

    INTER_LOG("%s gather %lu keys", role_desc().c_str(), _kvs.size());
}

void KVServer::receiving() {
    INTER_LOG("%s recv-thread start", role_desc().c_str());
    PBMessage pb;
    Message msg;
    bool done = false;
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[0];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[0]; 

    while (!done) {
        if (_recv_thread_quit) {
            INTER_LOG("%s recieving quit command from main thread", role_desc().c_str());
            done = true;
        } 

        // receive message body
        msg.clear();
        rqt_que.push(comm_rqt(RECV_HDR, (void*)&msg, 1, mpx::any_source));

        comm_ack ack;
        while (!_recv_thread_quit) {
            if (ack_que.try_pop(ack) == false) {
                std::this_thread::yield();
            } else {
                break;
            }
        }
        if (_recv_thread_quit) {
            INTER_LOG("%s recieving quit command from main thread", role_desc().c_str());
            done = true;
            continue;
        }
        
        Rank wid = ack.peer;
    
        if (msg.type == DataMsg) {
            CHECK(wid < (int)_comm_kvs.size(), "Invalid sender = %d (< %lu)", wid, _comm_kvs.size());
            std::unordered_map<Key, Val> &kv = _comm_kvs[wid];
            // push request first 
            _rqt_queue_vec[wid].push(msg);
            if (msg.data.op == Push || msg.data.op == PushPull || msg.data.op == Reset) {
                for (size_t i=0; i<msg.data.key.size(); i++) {
                    Val val = kv[msg.data.key[i]];
                    size_t bsize = sizeof(*val.get_data());
                    CHECK(msg.data.len[i] == bsize * val.get_element_count(), "Internal error");
                    rqt_que.push(comm_rqt(RECV_DATA, (void*)val.get_data(), msg.data.len[i], msg.node.id));
                    ack_que.pop();
                    _val_queue_vec[wid].push(val);
                }
            }

        } else if (msg.type == ControlMsg) {
            switch (msg.control.cmd) {
                case ControlExit:
                case ControlGlobalBarrier:
                case ControlGlobalStatus:
                    _rqt_queue_vec[wid].push(msg);
                    break;

                default:
                    CHECK(false, "Internal error: unknown control type %d", msg.control.cmd);
            }
        }
    }

    INTER_LOG("%s recv-thread stop", role_desc().c_str());
}

void KVServer::processing(int idx) {
    bool stop = false;
    const int qidx = idx + 1;
    ThreadSafeQueue<Message>& que = _rqt_queue_vec[idx];
    ThreadSafeQueue<Val>& vque = _val_queue_vec[idx];
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[qidx];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[qidx];
    std::unordered_map<Key, Val> &okvs = _output_kvs[idx];
    KVCoordinator *coord = KVCoordinator::get_obj(); 

    // 2-threads is tuned 
    omp_set_num_threads(2);
    while (!stop) {
        Message rqt = que.pop();
        Rank source = rqt.node.id;

        // handle control message
        if (rqt.type == ControlMsg) {
            switch (rqt.control.cmd) {
                case ControlExit: { 
                    if (rqt.node == node()) {
                        stop = true;
                    } else {
                        coord->worker_exited(*this, rqt.node.id);
                        _worker_quit.notify_one();
                    }
                    break;
                }

                case ControlGlobalBarrier: {
                    Message msg;
                    if (coord->barrier(*this, &msg, rqt.node.id)) {
                        for (auto dest : coord->worker_id()) {
                            send(msg, dest, qidx);
                        }
                    } 
                    break;
                }

                case ControlGlobalStatus: {
                    coord->sync_global_status(*this, source, qidx);
                    break;
                }
            }
            continue;
        }

        // handle data message
        if (rqt.data.op == Push) {
            for (size_t i=0; i<rqt.data.key.size(); i++) {
                Key key = rqt.data.key[i];

                std::lock_guard<std::mutex> key_lk(*_key_mutex[key]); 
                Val val = vque.pop();
                if (valid_update(key, source)) {
                    _updater->update(_kvs[key], okvs[key], val);
                }
            }

        } else if (rqt.data.op == Pull) {
            for (size_t i=0; i<rqt.data.key.size(); i++) {
                Key key = rqt.data.key[i];

                std::lock_guard<std::mutex> key_lk(*_key_mutex[key]); 
                size_t bsize = sizeof(*_kvs[key].get_ptr());
                rqt_que.push(comm_rqt(SEND_DATA, 
                    _kvs[key].get_ptr(), _kvs[key].get_element_count() * bsize, source)); 
                ack_que.pop();

                update_timestamp(key, source);
            }

        } else if (rqt.data.op == PushPull) {
            for (size_t i=0; i<rqt.data.key.size(); i++) {
                _key_mutex[rqt.data.key[i]]->lock(); 
            }

            for (size_t i=0; i<rqt.data.key.size(); i++) {
                bool ret = false;
                Key key = rqt.data.key[i];

                // push operation
                Val val = vque.pop(); 
                if (valid_update(key, source)) {
                    ret = _updater->update(_kvs[key], okvs[key], val);
                }
    
                // pull operation
                if (!ret) {
                    Val &data = _kvs[rqt.data.key[i]];
                    size_t len = data.get_element_count();
                    size_t bsize = sizeof(*data.get_ptr());
                    rqt_que.push(comm_rqt(SEND_DATA, data.get_ptr(), len * bsize, source));
                } else {
                    Val &data = okvs[key]; 
                    size_t len = data.get_element_count();
                    size_t bsize = sizeof(*data.get_ptr());
                    rqt_que.push(comm_rqt(SEND_DATA, data.get_ptr(), len * bsize, source));
                }
                update_timestamp(key, source);
            }

            for (size_t i=0; i<rqt.data.key.size(); i++) {
                // wait and unlock key-mutex
                ack_que.pop();
                _key_mutex[rqt.data.key[i]]->unlock(); 
            }

        } else if (rqt.data.op == Reset) {
            for (size_t i=0; i<rqt.data.key.size(); i++) {
                Key key = rqt.data.key[i];
                std::lock_guard<std::mutex> key_lk(*_key_mutex[key]); 

                Val val = vque.pop();
                _kvs[key].copy_from(val);
                INTER_LOG("%s reset key = %lu, sum = %f", role_desc().c_str(), key, _kvs[key].sum());
            }

        } else if (rqt.data.op == PutDone) {
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
            CHECK2(rqt.node.role == WORKER_NODE);
            int offset = source % _num_workers;

            for (size_t i=0; i<rqt.data.key.size(); i++) {
                Key key = rqt.data.key[i];
                Len len = rqt.data.len[i];

                auto& wins = _key2wins->at(key);
                auto& w_win = wins.first;
                auto& dw_win = wins.second;

                exclusive_lock(w_win.get(), qidx);
                exclusive_lock(dw_win.get(), qidx);

                wind::DType* w_buffer = reinterpret_cast<wind::DType*>(w_win->get_rma_buffer());
                wind::DType* dw_buffer = reinterpret_cast<wind::DType*>(dw_win->get_rma_buffer()) + offset * len;
                Val w_tensor(w_buffer, wind::Dim(len), wind::CPU);
                Val dw_tensor(dw_buffer, wind::Dim(len), wind::CPU);
                if (valid_update(key, source)) {
                    _updater->update(w_tensor, dw_tensor);
                }

                unlock(dw_win.get(), qidx);
                unlock(w_win.get(), qidx);
            }
#endif
        }
    }
}

void KVServer::set_updater_param(const std::unordered_map<std::string, std::string>& params) {
    CHECK(_updater != NULL, "updater NOT initialized");
    _updater->set_param(params);    
}

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
void KVServer::init_wins() {
    KVCoordinator *coord = KVCoordinator::get_obj();
    auto key2len = coord->get_key2len();
    for (auto& iter : *_key2wins) {
        Key key = iter.first;
        Len len = key2len[key];
        Val& val = _kvs[key];
        std::unique_ptr<mpx::win>& w_win = iter.second.first;
        std::unique_ptr<mpx::win>& dw_win = iter.second.second;


        w_win = std::unique_ptr<mpx::win>(new mpx::win((char*)val.get_data(),
                                                       sizeof(wind::DType) * len,
                                                       sizeof(wind::DType),
                                                       get_comm()));
        
        dw_win = std::unique_ptr<mpx::win>(new mpx::win(sizeof(wind::DType) * len * _num_workers,
                                           sizeof(wind::DType),
                                           get_comm()));

    }
}
#endif

void KVServer::comm_processing() {
    size_t len = _comm_rqt_vec.size();
    std::vector<std::vector<mpx::future<void>>> future_vec(len);
    std::vector<std::vector<comm_rqt>> local_rqt_vec(len);
    Message *msg = NULL;
    
    INTER_LOG("%s mpi-comm-thread started", role_desc().c_str());

    while (!_comm_thread_quit) {
        for (size_t i = 0; i < _comm_rqt_vec.size(); i++) {
            comm_rqt rqt;
            ThreadSafeQueue<comm_rqt>& rqtq = _comm_rqt_vec[i];
            if (rqtq.try_front(rqt)) {
                switch (rqt.type) {
                case SEND_DATA: {
                    mpx::future<void> f = isend<char>((char*)rqt.buf, rqt.count, rqt.peer, DataTag);
                    future_vec[i].push_back(std::move(f));
                    local_rqt_vec[i].push_back(rqt);
                    rqtq.pop();
                    break; 
                }

                case RECV_DATA: {
                    mpx::future<void> f = irecv_into<char>((char*)rqt.buf, rqt.count, rqt.peer, DataTag);
                    future_vec[i].push_back(std::move(f));
                    local_rqt_vec[i].push_back(rqt);
                    rqtq.pop();
                    break;
                }

                case SEND_HDR: {
                    msg = static_cast<Message*>(rqt.buf);
                    char* buf = _comm_buffer_vec[i];
                    MessageHeader* hdr = (MessageHeader*)buf;
                    hdr->rank = rank();
                    hdr->byte_size = msg->pack(buf + sizeof(MessageHeader),
                        max_message_byte_size - sizeof(MessageHeader));
                    mpx::future<void> f = isend<char>(buf, 
                        sizeof(MessageHeader)+hdr->byte_size, rqt.peer, HeaderTag);
                    future_vec[i].push_back(std::move(f));
                    local_rqt_vec[i].push_back(rqt);
                    rqtq.pop();
                    break;
                }

                case RECV_HDR: {
                    char* buf = _comm_buffer_vec[i];
                    mpx::future<void> f = irecv_into<char>(buf, max_message_byte_size, rqt.peer, HeaderTag);
                    future_vec[i].push_back(std::move(f));
                    local_rqt_vec[i].push_back(rqt);
                    rqtq.pop();
                    break;
                }

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
                case WIN_EXCLUSIVE_LOCK: {
                    if (rqt.win->test_lock()) {
                        rqt.win->exclusive_lock(rank());
                        _comm_ack_vec[i].push(comm_ack());
                        rqtq.pop();
                    }
                    break;
                }

                case WIN_UNLOCK: {
                    rqt.win->unlock();
                    _comm_ack_vec[i].push(comm_ack());
                    rqtq.pop();
                    break;
                }
#endif

                default: {
                    INTER_LOG("Invalid comm request received");
                }
                }
            } 
        }
    
        for (size_t i = 0; i < future_vec.size(); i++) {
            if (future_vec[i].size() == 0) {
                continue;
            }
            if (false == test(future_vec[i].front())) {
                continue;
            }
            comm_ack ack;
            if (local_rqt_vec[i].front().type == RECV_HDR) {
                Message* msg = static_cast<Message*>(local_rqt_vec[i].front().buf);
                MessageHeader* hdr = (MessageHeader*)_comm_buffer_vec[i];
                msg->unpack(((char*)hdr)+sizeof(MessageHeader), hdr->byte_size);
                ack.peer = hdr->rank;
            } else {
                ack.peer = local_rqt_vec[i].front().peer;
            }
            future_vec[i].erase(future_vec[i].begin());
            local_rqt_vec[i].erase(local_rqt_vec[i].begin());
            _comm_ack_vec[i].push(ack);
        }  
    }
   
    // clear buffered requested 
    for (size_t i = 0; i < future_vec.size(); i++) {
        while (future_vec[i].size()) {
            future_vec[i].front().drop();
            future_vec[i].erase(future_vec[i].begin());
        }
    }
}


void KVServer::send(const Message &msg, int dest, int qidx) {
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[qidx];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[qidx]; 

    rqt_que.push(comm_rqt(SEND_HDR, const_cast<void*>((void*)&msg), 1, dest));
    ack_que.pop();
}

Rank KVServer::recv(Message &msg, int src, int qidx) {
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[qidx];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[qidx]; 

    rqt_que.push(comm_rqt(RECV_HDR, static_cast<void*>(&msg), 1, src));
    comm_ack ack = ack_que.pop();
    return ack.peer;
}

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
void KVServer::exclusive_lock(mpx::win* win, int qidx) {
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[qidx];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[qidx]; 

    rqt_que.push(comm_rqt(WIN_EXCLUSIVE_LOCK, win));
    ack_que.pop();
}

void KVServer::unlock(mpx::win* win, int qidx) {
    ThreadSafeQueue<comm_rqt>& rqt_que = _comm_rqt_vec[qidx];
    ThreadSafeQueue<comm_ack>& ack_que = _comm_ack_vec[qidx]; 

    rqt_que.push(comm_rqt(WIN_UNLOCK, win));
    ack_que.pop();
}
#endif

bool KVServer::valid_update(Key key, int rank) {
    if (!_enable_distance_drop) {
        return true;
    }

    std::vector<size_t>& vec = _key_timestamps[key];
    CHECK2(rank < (int)vec.size());
    auto iter = std::max_element(vec.begin(), vec.end());
    size_t diff = *iter - vec[rank];
    if (diff <= _max_distance) {
        vec[rank]++;
        return true;
    } else {
        INTER_LOG("invalid update from Rank[%d] found", rank);
        return false;
    }
}

void KVServer::update_timestamp(Key key, int rank) {
    std::vector<size_t>& vec = _key_timestamps[key];
    CHECK2(rank < (int)vec.size());
    auto iter = std::max_element(vec.begin(), vec.end());
    if (vec[rank] < *iter) {
        vec[rank] = *iter;
    } else {
        vec[rank]++;
    }
}

}
