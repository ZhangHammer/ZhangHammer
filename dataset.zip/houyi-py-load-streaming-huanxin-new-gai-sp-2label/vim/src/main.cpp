#include <time.h>
#include <iostream>
#include <fstream>
#include "wind/wind.h"
#include "gflags/gflags.h"
#include "multi_trainer.h"
#include "predictor.h"
#include "multi_discriminator.h"
#include "generated_version.h"

DEFINE_string(train_config, "",
              "configure file for train");
DEFINE_string(predict_config, "",
              "configure file for predict");
DEFINE_string(disc_config, "",
              "configure file for discriminat train");

const std::string version = "1.3.1";

int main(int argc, char* argv[]) {
    houyi::train::NNConfig nn_cfg;
    houyi::train::PredictNnConfig predict_nn_cfg;
    houyi::train::DiscNNConfig disc_nn_cfg;

    houyi::train::Trainer* trainer = NULL;
    houyi::train::MultiTrainer* m_trainer = NULL;
    houyi::train::Predictor* predictor = NULL;
    houyi::train::MultiDiscriminator* discriminator = NULL;

    /* gflags */
    std::string version_message =
        ":\n\tversion: " + std::string(houyi_build_git_version) +
        "\n\t" + std::string(houyi_build_user) + " " + std::string(houyi_build_host) +
        "\n\tCompiled on: " + std::string(__DATE__) + " " + std::string(__TIME__) +
        "\n\tCopyright (c) baidu.com, Inc. All Rights Reserved\n";
    std::string usage_message =
        "\n\tUsage: \n\t" + std::string(argv[0]) +
        " [--train_config= ] [--predict_config= ] [--disc_config= ]" \
        "\n\nOptions for " + std::string(argv[0]) +
        "\n========================= \
                \n\t--help \
                \n\t\tPrint this help information on this tool.\
                \n\t--version \
                \n\t\tPrint version information on this tool. \
                \n\t--train_config \
                \n\t\tConfigure file for train. \
                \n\t--predict_config \
                \n\t\tPredict file for predict. \
                \n\t--disc_config \
                \n\t\tDisc file for discriminate. \
                \n\t--enable_new_layer \
                \n\t\tEnable new bn layer and new conv layer. \
                \n\t--enable_tensorboard \
                \n\t\tEnable tensorboard record.";
    GFLAGS_NAMESPACE::SetVersionString(version_message);
    GFLAGS_NAMESPACE::SetUsageMessage(usage_message);
    GFLAGS_NAMESPACE::ParseCommandLineFlags(&argc, &argv, true);

    INTER_LOG("\n\ttrain_config: %s\n\tpredict_config: %s\n\tdisc_config: %s",
              FLAGS_train_config.c_str(),
              FLAGS_predict_config.c_str(),
              FLAGS_disc_config.c_str());

    if (FLAGS_predict_config.size() == 0
            && FLAGS_train_config.size() == 0
            && FLAGS_disc_config.size() == 0) {
        INTER_LOG("%s", usage_message.c_str());
        exit(-1);
    }

#if _open_glog_

    if (!getenv("GLOG_logtostderr")) {
        google::LogToStderr();
    }

    google::InstallFailureSignalHandler();
    google::InitGoogleLogging(argv[0]);
#endif

    if (FLAGS_train_config.size() != 0) {
        nn_cfg.read_config(FLAGS_train_config.c_str());
    }

    if (FLAGS_predict_config.size() != 0) {
        predict_nn_cfg.read_config(FLAGS_predict_config.c_str());
    }

    if (FLAGS_disc_config.size() != 0) {
        disc_nn_cfg.read_config(FLAGS_disc_config.c_str());
    }


    if (FLAGS_train_config.size() != 0) {
        int* devices = nn_cfg.device_ids().data();
        int device_num = static_cast<int>(nn_cfg.device_ids().size());
        houyi::train::wind_start(devices, device_num);
        houyi::train::set_train_size(device_num);
        houyi::train::wind_init(nn_cfg.device_id(0));
    } else if (FLAGS_disc_config.size() != 0) {
        int* devices = disc_nn_cfg.device_ids().data();
        int device_num = static_cast<int>(disc_nn_cfg.device_ids().size());
        houyi::train::wind_start(devices, device_num);
        houyi::train::set_train_size(device_num);
        houyi::train::wind_init(disc_nn_cfg.device_id(0));
    } else {
        int* devices = predict_nn_cfg.device_ids().data();
        int device_num = static_cast<int>(predict_nn_cfg.device_ids().size());
        houyi::train::wind_start(devices, device_num);
        houyi::train::set_train_size(device_num);
        houyi::train::wind_init(predict_nn_cfg.device_id(0));
    }

    //predict
    if (FLAGS_predict_config.size() != 0) {
        predictor = creat_predictor(predict_nn_cfg);
        CHECK2(NULL != predictor);
        predictor->start();
    }

    //disc
    if (FLAGS_disc_config.size() != 0) {
        discriminator = new houyi::train::MultiDiscriminator(&disc_nn_cfg);
        CHECK2(NULL != discriminator);
    }

    // Train
    if (FLAGS_train_config.size() != 0) {
        switch (nn_cfg.job_type()) {
        case houyi::train::TRAIN: {
            m_trainer = new houyi::train::MultiTrainer(&nn_cfg);

            if (FLAGS_predict_config.size() != 0) {
                m_trainer->set_model_predict_queue(predictor->get_model_file_queue());
                m_trainer->set_predict_period(predictor->get_predict_period());
            }

            m_trainer->start_multi_train();
        }
        break;

        case houyi::train::DISC_TRAIN: {
            m_trainer = new houyi::train::MultiTrainer(&nn_cfg);

            if (FLAGS_disc_config.size() != 0) {
                m_trainer->set_disc_update_queue(discriminator->get_model_predict_queue());
                m_trainer->set_disc_update_period(discriminator->get_model_update_period());
                discriminator->set_decode_data_reader(m_trainer->data_reader());
                discriminator->start_disc();
            }

            if (FLAGS_predict_config.size() != 0) {
                m_trainer->set_model_predict_queue(predictor->get_model_file_queue());
                m_trainer->set_predict_period(predictor->get_predict_period());
            }

            m_trainer->start_multi_train();
        }
        break;

        default:
            INTER_CHECK(false, "unknown job type: %d", nn_cfg.job_type());
        }
    }

    if (m_trainer != NULL) {
        while (!m_trainer->is_thread_exit()) {
            usleep(100000);
        }
    }

    if (predictor != NULL) {
        while (!predictor->is_thread_exit()) {
            usleep(100000);
        }
    }

    GFLAGS_NAMESPACE::ShutDownCommandLineFlags();
    houyi::train::wind_shutdown();

    if (trainer) {
        delete trainer;
        trainer = NULL;
    }

    if (m_trainer) {
        delete m_trainer;
        m_trainer = NULL;
    }

    if (predictor) {
        delete predictor;
        predictor = NULL;
    }

    if (discriminator) {
        delete discriminator;
        discriminator = NULL;
    }

    INTER_LOG("train platform exit normally");

    return 0;
}
