/**
 * Author: wangkai (wangkai35@baidu.com)
 * Created on: 2018-08
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <omp.h>
#include <math.h>   
#include <mkl_lapacke.h>
#include <mkl_trans.h>
#include "wind/wind.h"
#include "low_bit_quant.h"

namespace houyi {
namespace train {

template <typename T>
static void inc_sort_with_idx(std::vector<T>& out, std::vector<size_t>& idx, const std::vector<T> &in) {
    idx.resize(in.size());
    out.resize(in.size());
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(), [&in](size_t i1, size_t i2) {return in[i1] < in[i2];});
    for (size_t i = 0; i < in.size(); i++) {
        out[i] = in[idx[i]];
    }
}

template <typename T>
static T tensor_diff_norm(Tensor<T>& in1, Tensor<T>& in2) {
    CHECK2(in1.get_size() == in2.get_size());
    const T* in1_ptr = in1.get_ptr();
    const T* in2_ptr = in2.get_ptr();
    size_t len = in1.get_element_count();
    T diff = 0;
    for (size_t i = 0; i < len; i++) {
        diff += fabs(in1_ptr[i] - in2_ptr[i]) * fabs(in1_ptr[i] - in2_ptr[i]); 
    }
    return sqrt(diff);
}

static void tensor_sign(Tensor<DType>& out, const Tensor<DType>& in) 
{
    CHECK2(out.is_contiguous());
    CHECK2(in.is_contiguous());
    BCHECK(out.get_size() == in.get_size());
    size_t len = out.get_element_count();
    DType* out_ptr = out.get_ptr();
    const DType* in_ptr = in.get_ptr();
    for (size_t i = 0; i < len; i++) {
        if (in_ptr[i] > 0.0f) {
            out_ptr[i] = 1.0f;
        } else {
            out_ptr[i] = -1.0f;
        }
    }
}

static void tensor_sign_avx(Tensor<DType>& out, const Tensor<DType>& in)
{
    CHECK2(out.is_contiguous());
    CHECK2(in.is_contiguous());
    BCHECK(out.get_size() == in.get_size());
    __m256 inv;
    __m256 zero;
    __m256 cmpv;
    __m256 one;
    __m256  minone;
    size_t idx = 0;
    size_t len = out.get_element_count();
    DType* out_ptr = out.get_ptr();
    const DType* in_ptr = in.get_ptr();
    if (((size_t)out_ptr & 0x1f) || ((size_t)in_ptr & 0x1f)) {
        tensor_sign(out, in); 
        return;
    }

    zero = _mm256_set1_ps(0.0f);
    one = _mm256_set1_ps(1.0f);
    minone = _mm256_set1_ps(-1.0f);
    for (idx = 0; idx < len; idx += 8) {
        inv = _mm256_load_ps(in_ptr + idx);
        cmpv = _mm256_cmp_ps(inv, zero, _CMP_LT_OS);
        cmpv = _mm256_blendv_ps(one, minone, cmpv);
        _mm256_store_ps(out_ptr + idx, cmpv);
    }

    for (size_t i = ((len >> 3) << 3); i < len; i++) {
        if (in_ptr[i] > 0.0f) {
            out_ptr[i] = 1.0f;
        } else {
            out_ptr[i] = -1.0f;
        }
    }
}

static void transpose_tensor(Tensor<DType>& out, const Tensor<DType>& in)
{
    CHECK2(in.is_contiguous());
    CHECK2(out.is_contiguous());
    size_t rows = out.get_height();
    size_t cols = out.get_width();
    DType* in_ptr = in.get_ptr();
    DType* out_ptr = out.get_ptr();
    mkl_somatcopy('R', 'T', cols, rows, 1.0f, in_ptr, rows, out_ptr, cols); 
}

void LowBitQuant::init(size_t nbit)
{
    const int rows = 1024;
    const int cols = 1024;

    for (size_t b = 1; b <= nbit; b++) {
        size_t layer_nbit = b;
        Tensor<DType> beta(Dim(1<<layer_nbit, layer_nbit), cpu_device());
        for (size_t i = 0; i < (size_t)(1<<layer_nbit); i++) {
            for (size_t j = 0; j < layer_nbit; j++) {
                if (i & (1<<j)) {
                    beta.set_element(Dim(i,j), 1);
                } else {
                    beta.set_element(Dim(i,j), -1);
                }
            }
        }
        _beta_template_map.insert(std::make_pair(layer_nbit, beta));
    }

    _greedy_in_copy.set_device(cpu_device());
    _greedy_tmp.set_device(cpu_device());
    _error.set_device(cpu_device());
    _lsm_buffer1.set_device(cpu_device());
    _lsm_buffer2.set_device(cpu_device());
    _transpose.set_device(cpu_device());
    _transpose_quant.set_device(cpu_device());
    
    if (_alpha.is_init() == false) {
        _alpha.set_device(wind::cpu_device());
    }

    _alpha.resize(Dim(rows, nbit));
    _beta_vec.resize(nbit);
    for (size_t i = 0; i < nbit; i++) {
        if (_beta_vec[i].is_init() == false) {
            _beta_vec[i].set_device(wind::cpu_device());
        }
        _beta_vec[i].resize(Dim(rows, cols));
    }
}

void LowBitQuant::quant_whole(bool transpose, size_t nbit, Tensor<DType>& out, Tensor<DType>& in, std::string prefix, bool logging)
{
    Dim org = in.get_size();

    if (can_quantize(org) == false) {
        out.copy_from(in);
        return;
    }

    if (org.get_axis() == 4) {
        size_t new_h = org.get_size(0);
        size_t new_w = org.product() / new_h;
        in.reshape(Dim(new_h, new_w));
        out.reshape(Dim(new_h, new_w));
    }

    if (transpose) {
        _transpose.resize(Dim(in.get_width(), in.get_height()));
        _transpose_quant.resize(_transpose.get_size());
        transpose_tensor(_transpose, in);
        quant_internal(nbit, _transpose_quant, _transpose, _alpha, _beta_vec);
        transpose_tensor(out, _transpose_quant);
    } else {
        quant_internal(nbit, out, in, _alpha, _beta_vec);
    }

    if (org.get_axis() == 4) {
        in.reshape(org);
        out.reshape(org);
    }
    
    if (logging) {
        float error_norm2 = tensor_diff_norm(out, in);
        float base_norm2 = in.norm2();
        INTER_LOG("Quant %s error = %.2f%% (%f/%f,%f/%f)", prefix.c_str(), 
            100.0f * error_norm2 / base_norm2, out.norm2(), base_norm2, out.max(), in.max());
    }
}

void LowBitQuant::row_mul(Tensor<DType>& out, const Tensor<DType>& alpha, size_t alpha_idx, const Tensor<DType>& beta)
{
    size_t cols = beta.get_width(); 
    size_t rows = beta.get_height();
    
    CHECK(alpha.get_height() == beta.get_height(), "Internal error");
    CHECK(out.get_size() == beta.get_size(), "Internal error");


    if (cols % 8) {
        for (size_t r = 0; r < rows; r++) {
            const DType* beta_ptr = beta.get_ptr() + r * cols;
            DType* out_ptr = out.get_ptr() + r * cols;
            DType alpha1 = alpha.get_ptr()[r * alpha.get_width() + alpha_idx];
            for (size_t c = 0; c < cols; c++) {
                out_ptr[c] = alpha1 * beta_ptr[c]; 
            }
        }
    } else {
        __m256 valpha;
        __m256 vbeta;
        __m256 vout;
        for (size_t r = 0; r < rows; r++) {
            const DType* beta_ptr = beta.get_ptr() + r * cols;
            DType* out_ptr = out.get_ptr() + r * cols;
            valpha = _mm256_broadcast_ss(alpha.get_ptr() + r * alpha.get_width() + alpha_idx);
            for (size_t c = 0; c < cols; c += 8) {
                vbeta = _mm256_load_ps(beta_ptr + c); 
                vout = _mm256_mul_ps(valpha, vbeta);
                _mm256_store_ps(out_ptr + c, vout); 
            }
        }
    }
}

void LowBitQuant::row_least_squares(Tensor<DType>& ten_out, const std::vector<Tensor<DType>>& beta, const Tensor<DType>& in, int total_bit, int cur_bit) 
{
    size_t cols = in.get_width(); 
    size_t rows = in.get_height();
    DType* out = ten_out.get_ptr();

    int bits = cur_bit + 1;

    _lsm_buffer1.resize(Dim(threads * bits * cols));
    _lsm_buffer2.resize(Dim(threads * cols));

    DType* all_tmp1 = _lsm_buffer1.get_ptr();
    DType* all_tmp2 = _lsm_buffer2.get_ptr();
   
    #pragma omp parallel for num_threads(threads) 
    for (size_t r = 0; r < rows; r++) {
        DType* tmp1 = all_tmp1 + omp_get_thread_num() * bits * cols;
        DType* tmp2 = all_tmp2 + omp_get_thread_num() * cols;
        for (int c = 0; c < bits; c++) {
            memcpy(tmp1 + c * cols, beta[c].get_ptr() + r * cols, sizeof(DType) * cols);
        }
        memcpy(tmp2, in.get_ptr() + r * cols, sizeof(DType) * cols);

        LAPACKE_sgels(LAPACK_COL_MAJOR, 'N', cols, bits, 1, tmp1, cols, tmp2, cols); 

        for (int b = 0; b < bits; b++) {
            out[r * total_bit + b] = tmp2[b];
            //CHECK2(tmp2[b] < 100.0f);
        }
    }        
}

void LowBitQuant::greedy_lsm_approximation(size_t nbit, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec) 
{
    _greedy_in_copy.resize(in.get_size());
    _greedy_tmp.resize(in.get_size());
    alpha.resize(Dim(in.get_height(), nbit));
    for (size_t i = 0; i < nbit; i++) {
        beta_vec[i].resize(in.get_size());
    }
    
    _greedy_in_copy.copy_from(in);
    for (size_t i = 0; i < nbit; i++) {
        tensor_sign_avx(beta_vec[i], _greedy_in_copy);

        _greedy_in_copy.copy_from(in);
        row_least_squares(alpha, beta_vec, _greedy_in_copy, nbit, i);

        for (size_t j = 0; j <= i; j++) {
            row_mul(_greedy_tmp, alpha, j, beta_vec[j]);
            _greedy_in_copy.add(_greedy_in_copy, _greedy_tmp, 1.0f, -1.0f);
        }
    }
}

void LowBitQuant::alt_lsm_approximation(size_t nbit, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec) 
{
    _greedy_in_copy.resize(in.get_size());
    _greedy_tmp.resize(in.get_size());
    alpha.resize(Dim(in.get_height(), nbit));
    for (size_t i = 0; i < nbit; i++) {
        beta_vec[i].resize(in.get_size());
    }
    
    greedy_lsm_approximation(nbit, in, alpha, beta_vec); 

    for (size_t iter = 0; iter < 2; iter++) {
        _greedy_in_copy.copy_from(in);
        finetune_beta(beta_vec, _greedy_in_copy, alpha);
        row_least_squares(alpha, beta_vec, _greedy_in_copy, nbit, nbit - 1);
    }
}

void LowBitQuant::finetune_beta(std::vector<Tensor<DType>>& beta_vec, const Tensor<DType>& in, const Tensor<DType>& alpha)
{
    size_t nbit = beta_vec.size();
    size_t rows = in.get_height();
    size_t cols = in.get_width();

    const DType* in_ptr = in.get_ptr();

    auto beta_t = _beta_template_map[nbit];

    #pragma omp parallel for num_threads(threads)
    for (size_t r = 0; r < rows; r++) {
        std::vector<DType> vmap(1<<nbit, 0);
        std::vector<DType> vmap_inc(1<<nbit, 0);
        std::vector<size_t> vmap_idx(1<<nbit, 0);
        quant_map(vmap, beta_t, alpha, r);
        inc_sort_with_idx(vmap_inc, vmap_idx, vmap);
        const DType* beta_ptr = beta_t.get_ptr();
        const size_t beta_width = beta_t.get_width();
        
        for (size_t c = 0; c < cols; c++) {
            int idx = binary_search_tree(vmap_inc, in_ptr[r * cols + c]);
            for (size_t i = 0; i < nbit; i++) {
                beta_vec[i].get_ptr()[r * cols + c] = beta_ptr[vmap_idx[idx] * beta_width + i];
            }
        }
    }
}

void LowBitQuant::quant_map(std::vector<DType>& vmap, const Tensor<DType>& mat, const Tensor<DType>& alpha, size_t row_idx)
{
    CHECK2(alpha.get_width() == mat.get_width());
    
    size_t width = mat.get_width();
    const DType* alpha_ptr = alpha.get_ptr();
    const DType* mat_ptr = mat.get_ptr();
    for (size_t h = 0; h < mat.get_height(); h++) {
        DType sum = 0;
        for (size_t b = 0; b < width; b++) {
            sum += mat_ptr[h * width + b] * alpha_ptr[row_idx * width + b];
        }
        vmap[h] = sum;
    }
}

inline int LowBitQuant::binary_search_tree(const std::vector<DType>& vec, DType flag)
{
    size_t len = vec.size();
    if (flag > vec[len - 1]) {
        return len - 1;
    } 
    if (flag <= vec[0]) {
        return 0;
    }

    for (size_t i = 1; i < len; i++) {
        if (flag <= vec[i]) {
            DType lower1 = vec[i - 1];
            DType upper1 = vec[i];
            if (flag < (lower1 + upper1) / 2.0f) {
                return i - 1;
            } else {
                return i;
            }
        } 
    }
    CHECK2(false);
    return -1;
}

void LowBitQuant::quant_internal(size_t nbit, Tensor<DType>& out, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec)
{
    const DType* in_ptr = in.get_ptr();
    DType* out_ptr = out.get_ptr();

    greedy_lsm_approximation(nbit, in, alpha, beta_vec);
    //alt_lsm_approximation(nbit, in, alpha, beta_vec);
    
    auto beta_t = _beta_template_map[nbit];

    // row-by-row
    #pragma omp parallel for num_threads(threads)
    for (size_t r = 0; r < in.get_height(); r++) {
        std::vector<DType> vmap(1<<nbit, 0);
        quant_map(vmap, beta_t, alpha, r);
        std::sort(vmap.begin(), vmap.end(), std::less<DType>());

        for (size_t c = 0; c < in.get_width(); c++) {
            size_t w = r * in.get_width() + c;
            int idx = binary_search_tree(vmap, in_ptr[w]);
            out_ptr[w] = vmap[idx];
            CHECK2(fabs(out_ptr[w]) < 100.f) ;
        }
    } 
}

bool LowBitQuant::can_quantize(Dim& size)
{
    if ((size.get_axis() == 2) && (size.get_size(0) < 4)) {
        return false;

    } else if (size.get_axis() == 4 && (size.get_size(0) < 4)) {
        return false;

    } else if (size.get_axis() == 3) {
        return false;
    }

    return true;
}



}
}

