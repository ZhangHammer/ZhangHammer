/**
 * Author: wangkai (wangkai35@baidu.com)
 * Created on: 2018-08
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <omp.h>
#include <math.h>   
#include <mkl_lapacke.h>
#include <mkl_trans.h>
#include "wind/wind.h"
#include "sparse.h"

namespace houyi {
namespace train {

static void tensor_fabs(Tensor<DType>& out, const Tensor<DType>& in)
{
    CHECK2(in.get_size() == out.get_size());
    DType* out_ptr = out.get_data();
    const DType* in_ptr = in.get_data();
    size_t len = out.get_element_count();
    for (size_t i = 0; i < len; i++) {
        out_ptr[i] = fabs(in_ptr[i]);
    }
}

static void tensor_sparse(Tensor<DType>& inout, DType threshold)
{
    CHECK2(inout.is_contiguous());
    DType* ptr = inout.get_data();
    size_t len = inout.get_element_count();
    for (size_t i = 0; i < len; i++) {
        if (fabs(ptr[i]) < threshold) {
            ptr[i] = 0;
        }
    }
}

void Sparse::sparsify(Tensor<DType>& inout) {
    _sort.resize(inout.get_size());
    tensor_fabs(_sort, inout);
    
    DType* ptr = _sort.get_data();
    size_t len = _sort.get_element_count();
    sort(ptr, ptr + len, std::less<DType>());
    tensor_sparse(inout, ptr[int(len * _sparse_ratio)]);
}

void Sparse::sparsify(Tensor<DType>& out, const Tensor<DType>& in) {
    CHECK2(out.get_size() == in.get_size());

    _sort.resize(in.get_size());
    tensor_fabs(_sort, in);
    
    DType* ptr = _sort.get_data();
    size_t len = _sort.get_element_count();
    sort(ptr, ptr + len, std::less<DType>());
    tensor_sparse(out, ptr[int(len * _sparse_ratio)]);
}

}
}
