/**
 * parse_string.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-12-23
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "parse_string.h"
#include "text_utils.h"
#include "util.h"

namespace houyi {
namespace train {

void remove_white_space_comment(std::string& str) {
    char temp[2048];
    const char* p = str.c_str();
    int i = 0;

    while (*p) { //remove whitespace
        if (*p == '#') {
            break;
        }

        if (!isspace(*p) && *p != '\t') {
            temp[i++] = *p;
        }

        ++p;
    }

    temp[i] = '\0';

    str.erase(str.begin(), str.end());
    str.append(temp);
    //strcpy(str, temp);
}

void remove_white_space_comment(char* str) {
    char temp[2048];
    char* p = str;
    int i = 0;

    while (*p) { //remove whitespace
        if (!isspace(*p) && *p != '\t') {
            temp[i++] = *p;
        }

        ++p;
    }

    temp[i] = '\0';

    //remove the comment after '#'
    if ((p = strchr(temp, '#')) != NULL) {
        *p = '\0';
    }

    strcpy(str, temp);
}

void stream_to_string(std::ifstream& input,
                      const std::string& end_str, std::string& rslt_str) {
    std::string line;

    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }

        remove_white_space_comment(line);

        if (line.size() == 0) {
            continue;
        }

        if (line == end_str) {
            break;
        }

        rslt_str.append("\t");
        rslt_str.append(line);
    }
}

bool parse_from_string(const std::string& name, std::string* string,
                       int* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();
    int default_value = *param;

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            if (!convert_string_to_integer(split_string[i].substr(len), param)) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    *param = default_value;
    return false;
}

bool parse_from_string(const std::string& name, std::string* string,
                       size_t* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            if (!convert_string_to_integer(split_string[i].substr(len), param)) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}

bool parse_from_string(const std::string& name, std::string* string,
                       bool* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();
    bool default_value = *param;

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            std::string b = split_string[i].substr(len);

            if (b.empty()) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            if (b[0] == 'f' || b[0] == 'F') {
                *param = false;
            } else if (b[0] == 't' || b[0] == 'T') {
                *param = true;
            } else {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    *param = default_value;
    return false;
}


bool parse_from_string(const std::string& name, std::string* string,
                       float* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true, &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            if (!convert_string_to_real(split_string[i].substr(len), param)) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}


bool parse_from_string(const std::string& name, std::string* string,
                       std::string* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true, &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            *param = split_string[i].substr(len);

            // Set "string" to all the pieces but the one we used.
            *string = "";

            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}


bool parse_from_string(const std::string& name, std::string* string,
                       std::vector<int>* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            if (!split_string_to_integers(split_string[i].substr(len), ":", false, param)) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}

bool parse_from_string(const std::string& name, std::string* string,
                       std::vector<float>* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            if (!split_string_to_floats(split_string[i].substr(len), ":", false, param)) {
                INTER_CHECK(false, "Bad option %s", split_string[i].c_str());
            }

            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string += "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}


bool parse_from_string(const std::string& name, std::string* string,
                       std::vector<std::string>* param) {
    std::vector<std::string> split_string;
    split_string_to_vector(*string, " \t", true,
                           &split_string);
    std::string name_equals = name + "="; // the name and then the equals sign.
    size_t len = name_equals.length();

    for (size_t i = 0; i < split_string.size(); i++) {
        if (split_string[i].compare(0, len, name_equals) == 0) {
            split_string_to_vector(split_string[i].substr(len), ":", false, param);
            *string = "";

            // Set "string" to all the pieces but the one we used.
            for (size_t j = 0; j < split_string.size(); j++) {
                if (j != i) {
                    if (!string->empty()) {
                        *string +=  "\t";
                    }

                    *string += split_string[j];
                }
            }

            return true;
        }
    }

    return false;
}

bool parse_tuple_from_string(const std::string& name, std::string* str,
                             std::string* param) {
    const std::string head = "<" + name + ">";
    const std::string tail = "</" + name + ">";
    std::size_t found1 = str->find(head);
    std::size_t found2 = str->find(tail);

    if (found1 == std::string::npos || found2 == std::string::npos) {
        return false;
    }

    //head tail 之间的字符串，不包括head tail
    std::string sub_lines = str->substr(found1 + head.size(), found2 - found1 - head.size());

    //获取剩下的字符串
    std::string remain = str->substr(0, found1) +
                         str->substr(found2 + tail.size(), str->size() - found2 - tail.size());
    *str = remain;
    *param = sub_lines;

    return true;
}

bool split_string(std::vector<std::string>& out, const std::string& s, char seperator)
{
    out.clear();

    std::string::size_type prev_pos = 0;
    std::string::size_type pos = 0;
    while ((pos = s.find(seperator, pos)) != std::string::npos) {
        std::string substring( s.substr(prev_pos, pos-prev_pos) );
        out.push_back(substring);
        prev_pos = ++pos;
    }

    out.push_back(s.substr(prev_pos, pos-prev_pos)); // Last word

    return true;
}

size_t count_file_lines(std::string path) {
    size_t lines = 0;
    char str[1024];
    std::ifstream dataFile(path.c_str());
    CHECK(dataFile.is_open(), "File could not found: %s", path.c_str());
    while (! dataFile.eof()) {
        dataFile.getline(str, 1024);
        if (!strlen(str)) {
            break;
        }
        lines++;
    }
    return lines;
}

}
}

