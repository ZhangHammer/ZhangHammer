// by zhxfl 2017.11.29
#include "io_package.h"

namespace houyi {
namespace train {

void IOPackage::resize(const Dim& size, const Device& device) {
    if (_mask != NULL) {
        CHECK((_ten_is_own && _mask_is_own), "tensor and mask must be own");
        CHECK(device == _mask->get_device(), "device not equal");
        _mask->resize(Dim(size[0]));
        _mask->set_element(1);
    } else {
        _mask = new Tensor<int>(Dim(size[0]), device);
        _mask->set_element(1);
    }

    if (_ten != NULL) {
        CHECK(_ten_is_own && _mask_is_own, "tensor and mask must be own");
        _ten->resize(size);
    }
    else {
        _ten = new Tensor<DType>(size, device);
    }
}

void IOPackage::resize(const Dim& ten_size, Tensor<int>* mask, const Device& device) {
    if (_mask != NULL && _mask_is_own == true) {
        delete _mask;
    } 
    _mask = mask;
    _mask_is_own = false;

    if (_ten != NULL) {
        _ten->resize(ten_size);
    }
    else {
        _ten = new Tensor<DType>(ten_size, device);
    }
}

void IOPackage::zero() {
    _ten->zero();
    _mask->set_element(1);
}

void IOPackage::copy_to(Tensor<DType>* ten) const {
    ten->copy_from(*_ten);
}

void IOPackage::copy_from(const Tensor<DType>* ten) {
    _ten->copy_from(*ten);
}

void IOPackage::copy_from(const IOPackage& src) {
    _ten->copy_from(*(src._ten));
    //src.copy_to(_ten);
    _mask->copy_from(*(src._mask));
}

}
} //namespace houyi
