#include "prof.h"
thread_local int thread_id = -1;
std::atomic<int> thread_count(0);
