// by zzxfl 2016.08.13
// reference : http://docs.opencv.org/2.4/modules/core/doc/basic_structures.html
#include "image_utils.h"
#include "wind/wind.h"
#include "util.h"
#include "base_batch_sample.h"

namespace houyi {
namespace train {

#ifdef __WITH_OPENCV__
using namespace cv;

void tensor_to_mat(Tensor<DType>& src, cv::Mat& sink) {
    size_t width = src.get_w();
    size_t height = src.get_h();
    size_t channel = src.get_c();
    CHECK2((int)height == sink.rows);
    CHECK2((int)width == sink.cols);
    CHECK2((int)channel == sink.channels());
    CHECK2((channel == 1 || channel == 3));
    CHECK2(sizeof(DType) == 4); // support float only
    CHECK2(sink.type() == CV_32FC1 || sink.type() == CV_32FC3
           || sink.type() == CV_8UC1 || sink.type() == CV_8UC3);

    if (channel == 3) {
        for (size_t i = 0; i < height; i++) {
            DType* b = src.get_data(Dim(0, i, 0));
            DType* g = src.get_data(Dim(1, i, 0));
            DType* r = src.get_data(Dim(2, i, 0));

            if (sink.type() == CV_32FC1 || sink.type() == CV_32FC3) {
                for (size_t j = 0; j < width; j++) {
                    sink.at<Vec3f>(i, j) =
                        Vec3f(b[j], g[j], r[j]);
                }
            } else {
                for (size_t j = 0; j < width; j++) {
                    sink.at<Vec3b>(i, j) =
                        Vec3b((uchar)(b[j]), (uchar)(g[j]), (uchar)(r[j]));
                }
            }
        }
    } else if (channel == 1) {
        if (sink.type() == CV_32FC1 || sink.type() == CV_32FC3) {
            for (size_t i = 0; i < height; i++) {
                DType* s = src.get_data(Dim(0, i, 0));
                DType* t = (DType*)sink.ptr(i);
                memcpy(t, s, sizeof(float) * width);
            }
        } else {
            for (size_t i = 0; i < height; i++) {
                DType* s = src.get_data(Dim(0, i, 0));
                uchar* t = (uchar*)sink.ptr(i);

                for (size_t j = 0; j < width; j++) {
                    t[j] = (uchar)s[j];
                }
            }
        }
    } else {
        CHECK2(false);
    }
}

void mat_to_tensor(cv::Mat& src, Tensor<DType>& sink) {
    size_t width = sink.get_w();
    size_t height = sink.get_h();
    size_t channel = sink.get_c();
    CHECK2((int)width == src.cols);
    CHECK2((int)channel == src.channels());
    CHECK2((channel == 1 || channel == 3));
    CHECK2(src.type() == CV_32FC3 || src.type() == CV_8UC3 || src.type() == CV_32FC1
           || src.type() == CV_8UC1);
    CHECK2(sizeof(DType) == 4); // only support float

    if (src.type() == CV_32FC3) {
        for (size_t i = 0; i < height; i++) {
            DType* b = sink.get_data(Dim(0, i, 0));
            DType* g = sink.get_data(Dim(1, i, 0));
            DType* r = sink.get_data(Dim(2, i, 0));

            for (size_t j = 0; j < width; j++) {
                Vec3f v3 = src.at<Vec3f>(i, j);
                b[j] = v3.val[0];
                g[j] = v3.val[1];
                r[j] = v3.val[2];
            }
        }
    } else if (src.type() == CV_32FC1) {
        for (size_t i = 0; i < height; i++) {
            DType* s = (DType*)src.ptr(i);
            DType* t = sink.get_data(Dim(0, i, 0));
            memcpy(t, s, sizeof(float) * width);
        }
    } else if (src.type() == CV_8UC3) {
        for (size_t i = 0; i < height; i++) {
            DType* b = sink.get_data(Dim(0, i, 0));
            DType* g = sink.get_data(Dim(1, i, 0));
            DType* r = sink.get_data(Dim(2, i, 0));

            for (size_t j = 0; j < width; j++) {
                Vec3b v3 = src.at<Vec3b>(i, j);
                b[j] = v3.val[0];
                g[j] = v3.val[1];
                r[j] = v3.val[2];
            }
        }
    } else if (src.type() == CV_8UC1) {
        for (size_t i = 0; i < height; i++) {
            uchar* s = (uchar*)src.ptr(i);
            DType* t = sink.get_data(Dim(0, i, 0));

            for (size_t j = 0; j < width; j++) {
                t[j] = (DType)s[j];
            }
        }
    } else {
        CHECK2(false);
    }
}

void save_batch_sample(BaseBatchSample& bat) {
    for (auto conf : bat.get_features()) {
        std::string key = conf.first;
        Tensor<DType>* tensor = &bat.get_feature_tensor(key);
        size_t width = tensor->get_w();
        size_t height = tensor->get_h();
        size_t channel = tensor->get_c();
        size_t batch_size = tensor->get_n();

        for (size_t b = 0; b < batch_size; b++) {
            static int id = 0;
            char ch[1024];
            sprintf(ch, "%s-%d.jpg", key.c_str(), id++);
            Mat* src = new Mat(height, width, channel == 1 ? CV_32FC1 : CV_32FC3);

            for (size_t i = 0; i < height; i++) {
                for (size_t j = 0; j < width; j++) {
                    if (channel == 1) {
                        Dim coor(b, 0, i, j);
                        DType value =  tensor->get_element(coor);
                        src->at<float>(i, j) = value;
                    } else {
                        Dim coor1(b, 0, i, j);
                        Dim coor2(b, 1, i, j);
                        Dim coor3(b, 2, i, j);
                        DType value1 = tensor->get_element(coor1);
                        DType value2 = tensor->get_element(coor2);
                        DType value3 = tensor->get_element(coor3);
                        src->at<Vec3f>(i, j) =
                            Vec3f(value1, value2, value3);
                    }
                }
            }

            cv::imwrite(ch, *src);
            delete src;
        }
    }
}
/*
 * 对tensor做resize操作
 */
void resize_tensor(Tensor<DType>& src, Tensor<DType>& dsc) {
    cv::Mat src_mat(src.get_h(), src.get_w(), src.get_c() == 1 ? CV_32FC1 : CV_32FC3);
    cv::Mat dsc_mat(dsc.get_h(), dsc.get_w(), dsc.get_c() == 1 ? CV_32FC1 : CV_32FC3);

    tensor_to_mat(src, src_mat);
    tensor_to_mat(dsc, dsc_mat);
    resize(src_mat, dsc_mat, dsc_mat.size());
    mat_to_tensor(dsc_mat, dsc);
}
#endif



void random_tensor(Tensor<DType>& ten, float seed, float alpha) {
    Tensor<DType>tmp {ten.get_size(), cpu_device()};
    srand(seed);

    for (size_t i = 0; i < tmp.get_element_count(); i++) {
        tmp.get_data()[i] = alpha * (2.0 * rand() / RAND_MAX - 1.0);
    }

    ten.copy_from(tmp);
}

void write_tensor(Tensor<DType>& ten, char* path, int count) {
#ifdef __WRITE_DIFF__
    if (false) {
    //if (ten.get_dim() == 2) {
        Tensor<DType> tmp {cpu_device()};
        tmp.resize(ten.get_size());
        tmp.copy_from(ten);
        std::ofstream ofs(path);
        
        for (int i = 0; i < (int)tmp.get_size(0); i++) {
            for (int j = 0; j < (int)tmp.get_size(1); j++) {
                ofs << tmp.get_element(Dim(i, j)) << " ";
            }
            ofs << std::endl;
        }

        ofs.close();
    }else {

        count = 10000;
        ten.write_diff(path, count);
    }
#else
    ten.write(path, count);
#endif
}

void write_tensor(Tensor<int>& ten, char* path, int count) {
#ifdef __WRITE_DIFF__
    count = 10000;
    ten.write_diff(path, count);
#else
    ten.write(path, count);
#endif
}

}
}
