/*
 *Filename: train_type.cpp
 *Description:
 *
 *Version: 1.0
 *Created: 2017年05月16日 14时55分21秒
 *Author: lifeng (lifeng20@baidu.com)
 *
 *Copyright: Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "train_type.h"

namespace houyi {
namespace train {

const char* trainTypeName[] = {
    "sync",
    "async",
    "NULL"
};

}
}

