//by zhxfl 2017.12.30
#include "vec_ops.h"
namespace houyi {
namespace train {

void vec_char2float(float* dst, const unsigned char* src, int size) {
//    for (int i = 0; i < size; i++) {
//        dst[i] = (float)src[i];
//    }
//
//    return;
    int len = size & (~15);
    const __m128i zero = _mm_setzero_si128();
    for (int i = 0; i < len; i += 16) {
        __m128i v_src = _mm_load_si128((const __m128i*)(src + i));
        // first 8 short values
        __m128i lower = _mm_unpacklo_epi8(v_src, zero);
        // last 8 short values
        __m128i higher = _mm_unpackhi_epi8(v_src, zero); 

        __m128i vi0 = _mm_cvtepu16_epi32(lower);
        __m128i vi1 = _mm_cvtepu16_epi32(_mm_unpackhi_epi64(lower, lower));
        __m128i vi2 = _mm_cvtepu16_epi32(higher);
        __m128i vi3 = _mm_cvtepu16_epi32(_mm_unpackhi_epi64(higher, lower));

        __m128 vf0 = _mm_cvtepi32_ps(vi0);
        __m128 vf1 = _mm_cvtepi32_ps(vi1);
        __m128 vf2 = _mm_cvtepi32_ps(vi2);
        __m128 vf3 = _mm_cvtepi32_ps(vi3);

        _mm_store_ps(dst + i + 0, vf0);
        _mm_store_ps(dst + i + 4, vf1);
        _mm_store_ps(dst + i + 8, vf2);
        _mm_store_ps(dst + i + 12, vf3);
    }

    for (int i = len; i < size; ++i) {
        dst[i] = static_cast<float>(src[i]);
    }
}

void vec_short2float(float *dst, const short* src, float value, int size) {
    int skip = 8;
    int len = size & (~7);

    __m128 factor = _mm_set1_ps(1.0f / value);

    for (int i = 0; i < len; i += skip) {
        __m128i vi = _mm_load_si128((const __m128i*)(src + i));

        __m128i vi0 = _mm_cvtepu16_epi32(vi);
        __m128i vi1 = _mm_cvtepu16_epi32(_mm_unpackhi_epi64(vi, vi));

        __m128 vf0 = _mm_cvtepi32_ps(vi0);
        __m128 vf1 = _mm_cvtepi32_ps(vi1);

        vf0 = _mm_mul_ps(vf0, factor);
        vf1 = _mm_mul_ps(vf1, factor);

        _mm_store_ps(dst + i + 0, vf0);
        _mm_store_ps(dst + i + 4, vf1);
    }

    for (int i = len; i < size; i++) {
        dst[i] = src[i] / value;
    }
}

void vec_mean_variance_norm(float* src, float* mean, float* var, int size) {
    int len = size & (~3);
    for (int i = 0; i < len; i += 4) {
        __m128 a = _mm_load_ps(src + i);
        __m128 b = _mm_load_ps(mean + i);
        __m128 c = _mm_load_ps(var + i);

        a = _mm_sub_ps(a, b);
        a = _mm_mul_ps(a, c);
        _mm_store_ps(src + i, a);

    }
    for (int i = len; i < size; i++) {
        src[i] = (src[i] - mean[i]) * var[i];
    }
}

void vec_norm(float *dst, int size, float value) {
    int len = size & ( ~3);

    __m128 factor = _mm_set1_ps(1.0f / value);

    for (int i = 0; i < len; i += 4) {
        __m128 a = _mm_load_ps(dst + i); 
        a = _mm_mul_ps(a, factor);
        _mm_store_ps(dst + i, a);
    }

    for (int i = len; i < size; i++) {
        dst[i] /= value;
    }
}


void vec_add(float* desc, float* src, int size) {
    int len = size & (~3);
    __m128  a;  
    __m128  b;  
    __m128  c;  

    for (int i = 0; i < len; i = i + 4) {  
        a = _mm_load_ps(src+ i);  
        b = _mm_load_ps(desc+ i);  
        c = _mm_add_ps(a, b);
        _mm_store_ps(desc + i, c);  
    } 

    for (int i = len; i < size; i++) {
        desc[i] += src[i];
    }
}

} // houyi
} // train
