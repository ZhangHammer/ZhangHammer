/**
 * multi_trainer.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-31
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "multi_trainer.h"
#include "vector"

namespace houyi {
namespace train {

MultiTrainer::MultiTrainer(NNConfig* nn_cfg)
    : Trainer(nn_cfg) {
    _device_indicator_counter = 0;
    // Init threadPool
    //CHECK2(_data_reader && _nn != NULL);
    CHECK2(_nn != NULL);
    _multi_nn = new MultiNeuralNetwork(
        _nn_cfg->layer_cfg_vec().size(), _nn_cfg->thread_num(),
        _nn_cfg->period_cfg().local_sync_period(),
        _nn_cfg->period_cfg().global_sync_period(),
        _nn_cfg->period_cfg().train_type(),
        _nn_cfg->get_global_updater_cfg());

    _multi_nn->set_weight_fixed_transpose(nn_cfg->get_weight_fixed_transpose());
    _multi_nn->set_weight_quant_transpose(nn_cfg->get_weight_quant_transpose());
    _multi_nn->set_layer_quantize(nn_cfg->get_layer_quantize());
    _multi_nn->set_weight_quant_bits(nn_cfg->get_weight_quant_bits(), _nn_cfg->quant_bits());
    _multi_nn->init_weight(_nn, nn_cfg, NULL);
    _multi_nn->set_major_nn(_nn);
    if (nn_cfg->period_cfg().fixed_period() > 0) {
        _multi_nn->set_fixed_period(nn_cfg->period_cfg().fixed_period());
    }

    _tb_writer->write_value("train_num", (float)_nn_cfg->thread_num());
    _tb_writer->flush();
#ifdef __ENABLE_NCCL__
    NcclSingleton::inst(); 
#endif

    // Start train threads
    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        _sub_trainers[i] = new SubTrainer(i, this, NULL);
        pthread_mutex_lock(&_sub_trainers[i]->_load_mutex);
        _sub_trainers[i]->start();
    }

    /* 释放NeuralNetwork中layer的output */
    _nn->free_layer_output();

    _multi_train_thread = new AsyncTrainThread(
        _nn_cfg, _multi_nn, _sub_trainers, const_cast<MultiTrainer*>(this));

    // If need communication with other node
    if (_nn_cfg->period_cfg().global_sync_period() > 0) {
        init_global_buffer();
    } else {
        _kv = NULL;
    }
    _server_model_counter = 0;
}

MultiTrainer::~MultiTrainer() {
    if (_multi_nn) {
        delete _multi_nn;
        _multi_nn = NULL;
    }

    for (int t = 0; t < _nn_cfg->thread_num(); t++) {
        if (_sub_trainers[t]) {
            delete _sub_trainers[t];
            _sub_trainers[t] = NULL;
        }
    }

    if (_multi_train_thread) {
        delete _multi_train_thread;
        _multi_train_thread = NULL;
    }

    for (size_t l = 0; l < _w_buf_vec.size(); l++) {
        WeightsMap& w_vec = _w_buf_vec[l];
        WeightsMap& dw_vec = _dw_accum_vec[l];
        release_weight_map(w_vec);
        release_weight_map(dw_vec);

        w_vec.clear();
        dw_vec.clear();
    }
}

void MultiTrainer::sync_global_weight(
    SubTrainer* sub_trainers[], int num, MultiNeuralNetwork* multi_nn) {
    for (int i = 0; i < num; i++) {
        SubNeuralNetwork* sub_nn = dynamic_cast<SubNeuralNetwork*>(sub_trainers[i]->nn());
        size_t ly_size = sub_nn->layer_size();

        for (size_t j = 0; j < ly_size; j++) {
            WeightsMap& w_vec = multi_nn->w_vec(j);
            sub_nn->layers()[j]->copy_in(w_vec, WEIGHT);
        }
    }
}

size_t  MultiTrainer::serialize_wvec(std::vector<WeightsMap>& wvec) {
    size_t bt = 0;

    for (size_t l = 0; l < wvec.size(); l++) {
        MAP_LOOP(wvec[l]) {
            //string key = iter1->first; // TODO:
            //bt += key.size();

            BaseWeight* w = itr1->second;
            bt += w->serialize();
        }
    }

    return bt;
}

size_t MultiTrainer::deserialize_wvec(std::vector<WeightsMap>& wvec) {
    size_t bt = 0;

    for (size_t l = 0; l < wvec.size(); l++) {
        MAP_LOOP(wvec[l]) {
            BaseWeight* w = itr1->second;
            bt += w->deserialize();
        }
    }

    return bt;
}

size_t MultiTrainer::serialize(SPEECH_NN_W_TYPE type) {
    size_t size = 0;

    if (type == WEIGHT) {
        size = serialize_wvec(_w_buf_vec);

    } else if (type == D_WEIGHT) {
        size = serialize_wvec(_dw_accum_vec);

    } else {
        CHECK2(false);
    }

    return size;
}

size_t MultiTrainer::deserialize(SPEECH_NN_W_TYPE type) {
    size_t size = 0;

    if (type == WEIGHT) {
        size = deserialize_wvec(_w_buf_vec);

    } else if (type == D_WEIGHT) {
        size = deserialize_wvec(_dw_accum_vec);

    } else {
        CHECK2(false);
    }

    return size;
}

void MultiTrainer::init_global_buffer() {
    _total_w_size = 0;
    _w_buf_vec.resize(_nn->layer_size());

    for (size_t l = 0; l < _w_buf_vec.size(); l++) {
        WeightsMap& w_vec = _w_buf_vec[l];
        _total_w_size += _nn->layers()[l]->copy_out(w_vec, WEIGHT);
    }

    for (size_t l = 0; l < _w_buf_vec.size(); l++) {
        int num = 0;
        MAP_LOOP(_w_buf_vec[l]) {
            const DenseWeight* weight = static_cast<DenseWeight*>(itr1->second);
            _kv_key.push_back(l * 100 + num);
            _kv_color.push_back(l);
            _kv_len.push_back(weight->w()->get_element_count());
            _kv_w.push_back(*weight->w());
            num++;
        }
    }

    INTER_LOG("worker gathers %lu keys", _kv_key.size());

    _kv = new hpps::KVWorker();
    _kv->coordinate(_kv_key, _kv_len, _kv_color);
            
    if (_kv->major_worker()) {
        _kv->reset(_kv_key, _kv_w);
    }
    _kv->barrier();
}

void MultiTrainer::start_multi_train() {
    pthread_create(_multi_train_thread->thread_id(), NULL,
                   AsyncTrainThread::run_thread, _multi_train_thread);
}

bool MultiTrainer::is_thread_exit() {
    return _multi_train_thread->is_thread_exit();
}

int MultiTrainer::fill_weight_array(weight_t* array) {
    int num = 0;

    for (size_t i = 0; i < _w_buf_vec.size(); i++) {
        WeightsMap& wvec = _w_buf_vec[i];
        WeightsMap& dwvec = _dw_accum_vec[i];
        int j = 0;
        // Size is const for DenseWeight
        // but is variable for DiscWeight and ExtDenseWeight
        MAP_LOOP(wvec) {
            const std::string& key = itr1->first;
            WeightsMap::iterator itr2 = dwvec.find(key);

            BaseWeight* w = itr1->second;
            BaseWeight* dw = itr2->second;
            array->size = w->serial_bytes();
            array->dw = dw->serial_buf();
            array->w = w->serial_buf();
            array->layer = i;
            array->weight = j;
            strcpy(array->key, key.c_str());

            j++;
            array++;
            num++;
        }
    }

    return num;
}

void MultiTrainer::update_weight_array(SPEECH_NN_W_TYPE t, weight_t* array) {
    if (t == WEIGHT) {
        for (size_t i = 0; i < _w_buf_vec.size(); i++) {
            WeightsMap& vec = _w_buf_vec[i];
            MAP_LOOP(vec) {
                array->size = itr1->second->serial_bytes();
                array++;
            }
        }
    } else if (t == D_WEIGHT) {
        for (size_t i = 0; i < _dw_accum_vec.size(); i++) {
            WeightsMap& vec = _dw_accum_vec[i];
            MAP_LOOP(vec) {
                array->size = itr1->second->serial_bytes();
                array++;
            }
        }
    } else {
        CHECK2(false);
    }
}


void MultiTrainer::check_epoch(int cur_epoch) {
    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->show_global_log();
    }

    if (_multi_nn != NULL) { // copy out the model
        for (int l = 0; l < _nn->layer_size(); l++) {
#ifdef __ENABLE_NCCL__
            _nn->layers()[l]->copy_in(_sub_trainers[0]->nn()->layers()[l]->w_map(), WEIGHT);
#else
            _nn->layers()[l]->copy_in(_multi_nn->w_vec(l), WEIGHT);
#endif

            DType* low = NULL;
            DType* up  = NULL;
            int cnt = _sub_trainers[0]->get_threshold(l, &low, &up);
            _nn->layers()[l]->set_threshold(low, up, cnt);
            free(low);
            free(up);
            low = up = NULL;
        }
    }

    if (_store_model_file) {
        store_model(_store_model_file, cur_epoch, NULL);
    } else {
        if (access("output_model", 0) == -1) {
            mkdir("output_model", S_IRWXU);
        }

        store_model("output_model/model_test", cur_epoch, NULL);
        store_quantization_model("output_model/model_test", cur_epoch);
    }
    for (int i = 0; i < _nn_cfg->thread_num(); ++i) {
        _sub_trainers[i]->store_mean_var();
    }
}

void MultiTrainer::check_log(int device, int cur_epoch, std::vector<BaseUpdater*>& updater_vec,
                             std::vector<WeightsMap>& w_vec) {
    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        if (device == _sub_trainers[i]->device_id()) {
            for (size_t j = 0; j < _stat_indicator.size(); j++) {
                _stat_indicator[j]->increase_values(_sub_trainers[i]->get_indicator(_cost_layer_name[j]));
                _sub_trainers[i]->get_indicator(_cost_layer_name[j])->zero();
            }
            break;
        }
    }

#ifdef __ENABLE_NCCL__
    int sub_trainer_id = -1;
    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        if (device == _sub_trainers[i]->device_id()) {
            sub_trainer_id = i;
            break;
        }
    }
#endif

    // current log
    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->show_current_log(_cost_layer_name[i], updater_vec, w_vec,
                _sub_trainers[0]->nn());
    }

    // latest log
    bool show = false;

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        show = _stat_indicator[i]->show_latest_log(_cost_layer_name[i]);
    }

    if (show) {

        if (_multi_nn != NULL) {// copy out the model
            for (int l = 0; l < _nn->layer_size(); l++) {
#ifdef __ENABLE_NCCL__
                _nn->layers()[l]->copy_in(_sub_trainers[sub_trainer_id]->nn()->layers()[l]->w_map(), WEIGHT);
#else
                _nn->layers()[l]->copy_in(_multi_nn->w_vec(l), WEIGHT);
#endif

                DType* low = NULL;
                DType* up  = NULL;
                int cnt = _sub_trainers[0]->get_threshold(l, &low, &up);
                _nn->layers()[l]->set_threshold(low, up, cnt);
                free(low);
                free(up);
                low = up = NULL;
            }
        }

        if (access("output_tmp_model", 0) == -1) {
            mkdir("output_tmp_model", S_IRWXU);
        }

        store_model("output_tmp_model/tmp_model", cur_epoch, NULL);
        store_quantization_model("output_tmp_model/tmp_model", cur_epoch);
        for (int i = 0; i < _nn_cfg->thread_num(); ++i) {
            _sub_trainers[i]->store_mean_var();
        }
    }

    bool predict = _stat_indicator[0]->is_time_predict();

    if (predict && _model_predict_queue != NULL) {
        if (_multi_nn != NULL) {// copy out the model
            for (int l = 0; l < _nn->layer_size(); l++) {
                _nn->layers()[l]->copy_in(_multi_nn->w_vec(l), WEIGHT);

                DType* low = NULL;
                DType* up  = NULL;
                int cnt = _sub_trainers[0]->get_threshold(l, &low, &up);
                _nn->layers()[l]->set_threshold(low, up, cnt);
                free(low);
                free(up);
                low = up = NULL;
            }
        }

        // store the mode
        if (access("output_predict_model", 0) == -1) {
            mkdir("output_predict_model", S_IRWXU);
        }

        char model_name[1024];
        store_model("output_predict_model/tmp_model", cur_epoch, model_name);
        for (int i = 0; i < _nn_cfg->thread_num(); ++i) {
            _sub_trainers[i]->store_mean_var();
        }

        _model_predict_queue->push(new std::string(model_name));
    }

    bool update = _stat_indicator[0]->is_time_disc_update();

    if (update && _disc_update_queue != NULL) {
        if (_multi_nn != NULL) {// copy out the model
            for (int l = 0; l < _nn->layer_size(); l++) {
                _nn->layers()[l]->copy_in(_multi_nn->w_vec(l), WEIGHT);

                DType* low = NULL;
                DType* up  = NULL;
                int cnt = _sub_trainers[0]->get_threshold(l, &low, &up);
                _nn->layers()[l]->set_threshold(low, up, cnt);
                free(low);
                free(up);
                low = up = NULL;
            }
        }

        // store the mode
        if (access("output_disc_model", 0) == -1) {
            mkdir("output_disc_model", S_IRWXU);
        }

        char model_name[1024];
        store_model("output_disc_model/tmp_model", cur_epoch, model_name);
        for (int i = 0; i < _nn_cfg->thread_num(); ++i) {
            _sub_trainers[i]->store_mean_var();
        }

        _disc_update_queue->push(new std::string(model_name));
    }

    adjust_lr(_stat_indicator[0]->_total_iter_counter);
    adjust_batch_size(_stat_indicator[0]->_total_iter_counter);
}

void MultiTrainer::adjust_lr(size_t iter_cnt) {
    _multi_nn->adjust_lr(iter_cnt);

    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        _sub_trainers[i]->adjust_lr(iter_cnt);
    }
}

void MultiTrainer::adjust_batch_size(size_t iter_cnt) {
    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        _sub_trainers[i]->adjust_batch_size(iter_cnt);
    }
}

void MultiTrainer::update_global_weight()
{
    if (_kv_dw.size() == 0) {
        // register accumulated dw tensor
        if (_kv->need_delta_weight()) {
            _multi_nn->register_dw_buf(_dw_accum_vec);
        }

        for (size_t l = 0; l < _w_buf_vec.size(); l++) {
            if (_kv->need_weight()) {
                MAP_LOOP(_w_buf_vec[l]) {
                    WeightsMap::iterator itr2 = _multi_nn->w_vec()[l].find(itr1->first);
                    const DenseWeight* weight = static_cast<DenseWeight*>(itr2->second);
                    _kv_dw.push_back(*weight->w());
                }

            } else if (_kv->need_delta_weight()) {
                MAP_LOOP(_w_buf_vec[l]) {
                    WeightsMap::iterator itr2 = _dw_accum_vec[l].find(itr1->first);
                    CHECK2(itr2 != _dw_accum_vec[l].end());
                    const DenseWeight* weight = static_cast<DenseWeight*>(itr2->second);
                    _kv_dw.push_back(*weight->w());
                }
            }
        }
    }

    _kv->update(_kv_key, _kv_dw, _kv_w); 
}

void MultiTrainer::store_global_weight()
{
    if (_w_buf_vec.size() == 0) {
        return;
    }
    _kv->pull(_kv_key, _kv_w); 
    _nn->reset_weight(_w_buf_vec);

    if (access("output_model", 0) == -1) {
        mkdir("output_model", S_IRWXU);
    }

    pid_t pid;
    pid = getpid();
    char datetime[20];
    get_datetime(datetime);
    char hname[256];
    bzero(hname, sizeof(hname));
    gethostname(hname, sizeof(hname));
    snprintf(hname + strlen(hname), 200, ".%u.%s", pid, datetime);

    // build name
    char local_model_name[256] = {0};
    snprintf(local_model_name, 256, "output_model/server_model.%s.%lu", hname, _server_model_counter++);

    // store
    _nn->store_model(local_model_name, WEIGHT);
    INTER_LOG("store server model to %s", local_model_name);
}

void MultiTrainer::store_quantization_model(const char* prefix_name, int cur_epoch)
{
    size_t cnt = _stat_indicator[0]->_sample_counter ?
                 _stat_indicator[0]->_sample_counter : _stat_indicator[0]->_frame_counter;
    _multi_nn->store_quantization_weight(prefix_name, cur_epoch, cnt);
}
}
}

