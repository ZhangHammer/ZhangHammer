/**
 * multi_discriminator.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-14
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "multi_discriminator.h"
#include "vector"

namespace houyi {
namespace train {

MultiDiscriminator::MultiDiscriminator(DiscNNConfig* nn_cfg)
    : Trainer(nn_cfg) {
    // Init threadPool
    CHECK2(_data_reader && _nn != NULL);
    _multi_nn = new MultiNeuralNetwork(
        nn_cfg->layer_cfg_vec().size(), nn_cfg->disc_score_thread_num(),
        nn_cfg->disc_period_cfg().local_sync_period(),
        _nn_cfg->period_cfg().global_sync_period(),
        _nn_cfg->period_cfg().train_type(),
        nn_cfg->get_global_updater_cfg());

    _model_update_period = nn_cfg->disc_period_cfg().model_update_period();

    _multi_nn->init_weight(_nn, nn_cfg, NULL);
    _multi_nn->set_major_nn(_nn);

    _model_predict_queue = new MessageQueue<std::string*>();
    _model_predict_queue->set_max_length(2);
    std::string model_file = nn_cfg->model_init_cfg().model_name();

    if (model_file.size() != 0) {
        _model_predict_queue->push(new std::string(model_file));
    }

    //new decoder
    std::vector<LossConfig*> loss_cfg_vec = nn_cfg->loss_layer_cfg();
    DType alpha = 0.0f;

    for (size_t i = 0; i < loss_cfg_vec.size(); i++) {
        if (loss_cfg_vec[i]->type() == LOSS_TRIPLET) {
            alpha = dynamic_cast<LossConfig*>(loss_cfg_vec[i])->get_alpha();
            break;
        }
    }

    nn_cfg->decoder_cfg().set_alpha(alpha);
    _decoder_cfg = nn_cfg->decoder_cfg();
    _decoder = creat_decoder(_decoder_cfg);
    _decoder->start();

    // Start train threads
    for (int i = 0; i < nn_cfg->disc_score_thread_num(); i++) {
        _sub_disc[i] = new SubDiscriminator(i, this, _decoder->get_decode_data_queue());
        pthread_mutex_lock(&_sub_disc[i]->_load_mutex);
        pthread_mutex_lock(&_sub_disc[i]->_start_score_mutex);
        _sub_disc[i]->start();
    }

    _multi_train_thread = new DiscTrainThread(
        nn_cfg, _multi_nn, _sub_disc, const_cast<MultiDiscriminator*>(this));
}

MultiDiscriminator::~MultiDiscriminator() {
    if (_multi_nn) {
        delete _multi_nn;
        _multi_nn = NULL;
    }

    for (int t = 0; t < dynamic_cast<DiscNNConfig*>(_nn_cfg)->disc_score_thread_num(); t++) {
        if (_sub_disc[t]) {
            delete _sub_disc[t];
            _sub_disc[t] = NULL;
        }
    }

    if (_multi_train_thread) {
        delete _multi_train_thread;
        _multi_train_thread = NULL;
    }

    if (_model_predict_queue != NULL) {
        _model_predict_queue->clean();
        _model_predict_queue = NULL;
    }

    if (_decoder != NULL) {
        delete _decoder;
    }
}

void MultiDiscriminator::start_disc() {
    pthread_create(_multi_train_thread->thread_id(), NULL,
                   DiscTrainThread::run_thread, _multi_train_thread);
}

}
}

