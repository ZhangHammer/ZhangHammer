/**
 * file: stat_indicator.cpp
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年11月05日 11时46分57秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#include <stat_indicator.h>
#include <chrono>
namespace houyi {
namespace train {

StatIndicator* creat_indicator(const PeriodConfig& cfg, const LossType type, 
            const std::string& layer_name) {
    switch (type) {
    case LOSS_TYPE_CE:
    case LOSS_TYPE_MSE:
    case LOSS_TYPE_SMOOTH_L1:
    case LOSS_TYPE_SMOOTH_OHEM_L1:
    case LOSS_TYPE_FOCAL:
    case LOSS_TYPE_LR:
        return new StatIndicator(cfg, type, layer_name);
        break;
    case LOSS_TYPE_MIX_LR:
        return new MixLrStatIndicator(cfg, type, layer_name);
        break;
    case LOSS_TYPE_CTC:
        return new CtcStatIndicator(cfg, type, layer_name);
        break;

    case LOSS_TYPE_TRIPLET:
        return new TripletStatIndicator(cfg, type, layer_name);
        break;

    default:
        CHECK(false, "unsupport loss type");
    }

    return NULL;
}

int StatIndicator::increase_sentframe_num(BaseBatchSample* bat) {
    int frame_cnt = 0;
    int sample_num = bat->get_batch_size();
    std::string feature_key = bat->get_feature_keys()[0];
    Tensor<DType>& data_tensor = bat->get_feature_tensor(feature_key);
    std::string label_key = bat->get_label_keys()[0];
    Tensor<int>& label_mask = bat->get_label_mask(label_key);

    _cpu_label_mask.resize_like(label_mask);
    _cpu_label_mask.copy_from(label_mask);
    for (size_t i = 0; i < _cpu_label_mask.get_size(0); i++) {
        if (_cpu_label_mask.get_element(Dim(i)) > 0) {
            frame_cnt++;
        }
    }

    //for image
    if (!bat->is_speech()) {
        _frame_counter += data_tensor.get_n();
        _sample_counter += data_tensor.get_n();
        _cur_frame_counter += data_tensor.get_n();
        _cur_sample_counter += data_tensor.get_n();
    } else {
        _frame_counter += frame_cnt;
        _sample_counter += sample_num;
        _cur_frame_counter += frame_cnt;
        _cur_sample_counter += sample_num;
    }

    //INTER_LOG("cur batch sample_num: %d frame_num: %d", sample_num, frame_cnt);
    return sample_num;
}

void StatIndicator::sample_num_norm(DType norm) {
    _frame_counter /= norm;
    _sample_counter /= norm;
    _cur_frame_counter /= norm;
    _cur_sample_counter /= norm;
}

void StatIndicator::cal_loss(Loss& cost) {
    *_train_cost += cost;
    *_cur_train_cost += cost;
}

bool StatIndicator::is_time_log() {
    if (_sample_counter >= _log_item * _log_period
            || (_sample_counter == 0 && _frame_counter
                > _log_item * 300 * _log_period)) {
        return true;
    } else {
        return false;
    }
}

bool StatIndicator::is_time_model() {
    if (_sample_counter >= _model_item * _model_period || (
                _sample_counter == 0 &&
                _frame_counter >= _model_item * _model_period * 300)) {
        return true;
    } else {
        return false;
    }
}

bool StatIndicator::is_time_predict() {
    if (_sample_counter >= _predict_item * _predict_period
            || (_sample_counter == 0 && _frame_counter
                > _predict_item * 300 * _predict_period)) {
        _predict_item++;
        return true;
    } else {
        return false;
    }
}

bool StatIndicator::is_time_disc_update() {
    if (_sample_counter >= _disc_update_item * _disc_update_period
            || (_sample_counter == 0 && _frame_counter
                > _disc_update_item * 300 * _disc_update_period)) {
        _disc_update_item++;
        return true;
    } else {
        return false;
    }
}

void StatIndicator::update_values(Loss& cost) {
    *_train_cost = cost;
    *_cur_train_cost = cost;
}

void StatIndicator::increase_values(const StatIndicator* ref) {
    _total_iter_counter += ref->_total_iter_counter;
    _sample_counter += ref->_sample_counter;
    _frame_counter += ref->_frame_counter;
    _cur_frame_counter += ref->_cur_frame_counter;
    _cur_sample_counter += ref->_cur_sample_counter;
    *_train_cost += *(ref->_train_cost);
    *_cur_train_cost += *(ref->_cur_train_cost);
}

void StatIndicator::show_current_log(std::string& prefix) {
    if (is_time_log()) {
        std::chrono::high_resolution_clock::time_point cur_clock =
            std::chrono::high_resolution_clock::now();
        double cur_second = std::chrono::duration < double,
               std::micro > (cur_clock - _cur_clock).count() /
               1000 / 1000;

        // tensorboard
        _writer->write_value(prefix + "/sample_finish",
                             static_cast<float>(_sample_counter),
                             _step);
        _writer->write_value(prefix + "/" + _train_cost->get_name(),
                             _train_cost->get_loss() / _train_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + _cur_train_cost->get_name(),
                             _cur_train_cost->get_loss() / _cur_train_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/sample_num_per_second",
                             _cur_sample_counter / cur_second,
                             _step);

        INTER_LOG(
            "\n\t%s %lu samples finish"
            "\t%s: %f = %.3f:%lu"
            "\t%s: %f = %.3f:%lu\n"
            "\tsample_num/sec : %.3f = %lu:%.3f",
            prefix.c_str(),
            _sample_counter,
            _train_cost->get_name().c_str(),
            _train_cost->get_loss() / _train_cost->get_frame_counter(),
            _train_cost->get_loss(), _train_cost->get_frame_counter(),
            _cur_train_cost->get_name().c_str(),
            _cur_train_cost->get_loss() / _cur_train_cost->get_frame_counter(),
            _cur_train_cost->get_loss(), _cur_train_cost->get_frame_counter(),
            _cur_sample_counter / cur_second,
            _cur_sample_counter, cur_second);
        _cur_frame_counter = 0;
        _cur_sample_counter = 0;
        _cur_clock = cur_clock;
        _cur_train_cost->clear();
    }
}

void StatIndicator::show_current_log(std::string& prefix, std::vector<BaseUpdater*>& updater_vec,
                                     std::vector<WeightsMap>& w_vec, NeuralNetwork* nn) {
    show_current_log(prefix);

    if (is_time_log()) {
        CHECK(nn != NULL, "nn is null");

        CHECK2(w_vec.size() == updater_vec.size());
        CHECK2(w_vec.size() == nn->layers().size());
        for (size_t i = 0; i < w_vec.size(); i++) {
            const std::string& layer_name = std::to_string(i) + "_" + nn->layers()[i]->name();
            _writer->write_value("learn_rate/" + layer_name,
                    nn->layers()[i]->updater()->learn_rate(), _step);
            std::map<std::string, BaseWeight*>::iterator it0;
            std::map<std::string, BaseWeight*>::iterator it1;
            WeightsMap& md_weights = updater_vec[i]->md_weights();

            for (it0 = w_vec[i].begin(); it0 != w_vec[i].end(); ++it0) {
                std::string name = layer_name + "/" + it0->first;
                Tensor<DType>* weight = dynamic_cast<DenseWeight*>(it0->second)->w();
                _writer->write_histogram(name, *weight, _step);
            }

            for (it1 = md_weights.begin(); it1 != md_weights.end(); ++it1) {
                std::string name = layer_name + "/" + it1->first + "_gradient";
                Tensor<DType>* dweight = dynamic_cast<DenseWeight*>(it1->second)->w();
                _writer->write_histogram(name, *dweight, _step);
            }

        }
        ++_step;
        _writer->flush();
#ifdef __TRAIN_OUTPUT_WDW__
        CHECK(nn != NULL, "nn is null");
        CHECK2(w_vec.size() == updater_vec.size());
        INTER_LOG("****************************w*mdw****************************");

        for (size_t i = 0; i < w_vec.size(); i++) {
            std::map<std::string, BaseWeight*>::iterator it0;
            std::map<std::string, BaseWeight*>::iterator it1;
            WeightsMap& md_weights = updater_vec[i]->md_weights();

            for (it0 = w_vec[i].begin(), it1 = md_weights.begin();
                    it0 != w_vec[i].end(), it1 != md_weights.end(); it0++, it1++) {
                char name[128];
                //输出w的norm1，max，min
                snprintf(name, 128, "%s_%s",
                         nn->layers()[i]->name().c_str(), it0->first.c_str());
                DType max_w = dynamic_cast<DenseWeight* >(it0->second)->w()->max();
                DType min_w = dynamic_cast<DenseWeight* >(it0->second)->w()->min();
                DType norm_w = dynamic_cast<DenseWeight* >(it0->second)->w()->norm1();
                size_t elem_cnt = dynamic_cast<DenseWeight* >(it0->second)->w()->
                                  get_element_count();
                INTER_LOG("w%s_[norm1:%10.3e max:%10.3e min:%10.3e]", name,
                          norm_w / elem_cnt, max_w, min_w);

                //输出mdw的norm1，max，min
                snprintf(name, 128, "layer_%d_%s",
                         (int)i, it1->first.c_str());
                DType max_dw = dynamic_cast<DenseWeight* >(it1->second)->w()->max();
                DType min_dw = dynamic_cast<DenseWeight* >(it1->second)->w()->min();
                DType norm_dw = dynamic_cast<DenseWeight* >(it1->second)->w()->norm1();
                INTER_LOG("dw%s_[norm1:%10.3e max:%10.3e min:%10.3e]", name,
                          norm_dw / elem_cnt, max_dw, min_dw);
            }
        }

        INTER_LOG("*************************************************************");
#endif
        _log_item++;
    }

}

bool StatIndicator::show_latest_log(std::string& prefix) {
    if (is_time_model()) {
        _last_frame_counter = _frame_counter - _last_frame_counter;
        _last_sample_counter = _sample_counter - _last_sample_counter;
        *_last_cost = *_train_cost - *_last_cost;

        // tensorboard lastest
        _writer->write_value(prefix + "/" + _last_cost->get_name(),
                             _last_cost->get_loss() / _last_cost->get_frame_counter(),
                             _step);

        INTER_LOG("\n\t***%lu finish %s layer loss: %lu samples %s is %f = %.3f:%lu",
                  _sample_counter,
                  prefix.c_str(),
                  _last_sample_counter,
                  _last_cost->get_name().c_str(),
                  _last_cost->get_loss() / _last_cost->get_frame_counter(),
                  _last_cost->get_loss(), _last_cost->get_frame_counter());
        *_last_cost = *_train_cost;
        _last_frame_counter = _frame_counter;
        _last_sample_counter = _sample_counter;

        _model_item++;
        return true;
    }

    return false;
}

void StatIndicator::show_global_log(std::string& prefix) {
    INTER_LOG(
        "\n\t***%lu samples finish %s layer loss:"
        "\t%s: %f = %.3f:%lu",
        _sample_counter,
        prefix.c_str(),
        _train_cost->get_name().c_str(),
        _train_cost->get_loss() / _train_cost->get_frame_counter(), 
        _train_cost->get_loss(), _train_cost->get_frame_counter());
}

void StatIndicator::show_model_loss(std::string& model_name) {
    INTER_LOG(
        "\n\t%s"
        "\tpredict-cost: %f",
        model_name.c_str(),
        _train_cost->get_loss() / _train_cost->get_frame_counter());
}

void StatIndicator::store_model_loss(std::string& loss_file_name, std::string& model_name) {
    std::ofstream out;

    out.open(loss_file_name.c_str(), std::ios::out | std::ios::app);

    out << model_name.c_str() << "\tpredict-cost: " << _train_cost->get_loss()
        / _train_cost->get_frame_counter() << std::endl;

    out.close();
}

void CtcStatIndicator::update_values(Loss& cost) {
    *(dynamic_cast<CtcLoss*>(_train_cost)) = *(dynamic_cast<CtcLoss*>(&cost));
    *(dynamic_cast<CtcLoss*>(_cur_train_cost)) = *(dynamic_cast<CtcLoss*>(&cost));
}

void CtcStatIndicator::increase_values(const StatIndicator* ref) {
    _total_iter_counter += ref->_total_iter_counter;
    _sample_counter += ref->_sample_counter;
    _frame_counter += ref->_frame_counter;
    _cur_frame_counter += ref->_cur_frame_counter;
    _cur_sample_counter += ref->_cur_sample_counter;
    *(dynamic_cast<CtcLoss*>(_train_cost)) +=
        *(dynamic_cast<CtcLoss*>(ref->_train_cost));
    *(dynamic_cast<CtcLoss*>(_cur_train_cost)) +=
        *(dynamic_cast<CtcLoss*>(ref->_train_cost));
}

void CtcStatIndicator::cal_loss(Loss& cost) {
    *(dynamic_cast<CtcLoss*>(_train_cost)) += *(dynamic_cast<CtcLoss*>(&cost));
    *(dynamic_cast<CtcLoss*>(_cur_train_cost)) += *(dynamic_cast<CtcLoss*>(&cost));
}

void CtcStatIndicator::show_current_log(std::string& prefix) {
    if (is_time_log()) {
        CtcLoss* ctc_cur_cost = dynamic_cast<CtcLoss*>(_cur_train_cost);
        CtcLoss* ctc_cost = dynamic_cast<CtcLoss*>(_train_cost);
        std::chrono::high_resolution_clock::time_point cur_clock =
            std::chrono::high_resolution_clock::now();
        double cur_second = std::chrono::duration < double,
               std::micro > (cur_clock - _cur_clock).count() /
               1000 / 1000;

        // tensorboard current global
        _writer->write_value(prefix + "/sample_finish",
                             static_cast<float>(_sample_counter),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_likely_hood",
                             _cur_train_cost->get_loss() / _cur_train_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_ctc_loglike",
                             ctc_cur_cost->get_log_lh() / _cur_train_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_log_pzx",
                             ctc_cur_cost->get_log_pzx() * 1.0f / 
                             ctc_cur_cost->get_sample_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_ctc_wer",
                             ctc_cur_cost->get_wer_len() * 1.0f / ctc_cur_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_ctc_sub",
                             ctc_cur_cost->get_sub_len() * 1.0f / ctc_cur_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_ctc_del",
                             ctc_cur_cost->get_del_len() * 1.0f / ctc_cur_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cur_cost->get_name() + "_ctc_ins",
                             ctc_cur_cost->get_ins_len() * 1.0f / ctc_cur_cost->get_ref_len(),
                             _step);

        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_likely_hood",
                             ctc_cost->get_loss() / ctc_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_ctc_loglike",
                             ctc_cost->get_log_lh() / ctc_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_log_pzx",
                             ctc_cost->get_log_pzx() * 1.0f / _sample_counter,
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_ctc_wer",
                             ctc_cost->get_wer_len() * 1.0f / ctc_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_ctc_sub",
                             ctc_cost->get_sub_len() * 1.0f / ctc_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_ctc_del",
                             ctc_cost->get_del_len() * 1.0f / ctc_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_cost->get_name() + "_ctc_ins",
                             ctc_cost->get_ins_len() * 1.0f / ctc_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/sample_num_per_second",
                             _cur_sample_counter / cur_second,
                             _step);

        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s likely_hood: %f\n"
            "\t%s ctc_loglike: %f\n"
            "\t%s blank_rate: %f\n"
            "\t%s local_rate: %f\n"
            "\t%s log_pzx: %f\n"
            "\t%s ctc_wer: %f\tsub(%.4f)\tdel(%.4f)\tins(%.4f)\n"
            "\t%s likely_hood: %f\n"
            "\t%s ctc_loglike: %f\n"
            "\t%s blank_rate: %f\n"
            "\t%s local_rate: %f\n"
            "\t%s log_pzx: %f\n"
            "\t%s ctc_wer: %f\tsub(%.4f)\tdel(%.4f)\tins(%.4f)\n"
            "\tsample_num/sec : %.3f = %lu:%.3f",
            _sample_counter, _frame_counter,
            prefix.c_str(),
            ctc_cur_cost->get_name().c_str(), _cur_train_cost->get_loss() /
            ctc_cur_cost->get_frame_counter(),
            ctc_cur_cost->get_name().c_str(), ctc_cur_cost->get_log_lh() /
            ctc_cur_cost->get_frame_counter(),
            ctc_cur_cost->get_name().c_str(), ctc_cur_cost->get_blank_rate() * 1.0f /
            ctc_cur_cost->get_frame_counter(),
            ctc_cur_cost->get_name().c_str(), ctc_cur_cost->get_local_rate() * 1.0f /
            ctc_cur_cost->get_sample_counter(),
            ctc_cur_cost->get_name().c_str(), ctc_cur_cost->get_log_pzx() * 1.0f /
            ctc_cur_cost->get_sample_counter(),
            ctc_cur_cost->get_name().c_str(), ctc_cur_cost->get_wer_len() * 1.0f /
            ctc_cur_cost->get_ref_len(),
            ctc_cur_cost->get_sub_len() * 1.0f / ctc_cur_cost->get_ref_len(),
            ctc_cur_cost->get_del_len() * 1.0f / ctc_cur_cost->get_ref_len(),
            ctc_cur_cost->get_ins_len() * 1.0f / ctc_cur_cost->get_ref_len(),
            ctc_cost->get_name().c_str(), ctc_cost->get_loss() / 
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_log_lh() / 
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_blank_rate() * 1.0f /
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_local_rate() * 1.0f /
            ctc_cost->get_sample_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_log_pzx() * 1.0f /
            ctc_cost->get_sample_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_wer_len() * 1.0f /
            ctc_cost->get_ref_len(),
            ctc_cost->get_sub_len() * 1.0f / ctc_cost->get_ref_len(),
            ctc_cost->get_del_len() * 1.0f / ctc_cost->get_ref_len(),
            ctc_cost->get_ins_len() * 1.0f / ctc_cost->get_ref_len(),
            _cur_sample_counter / cur_second,
            _cur_sample_counter, cur_second
        );

        _cur_frame_counter = 0;
        _cur_sample_counter = 0;
        _cur_clock = cur_clock;
        _cur_train_cost->clear();
    }
}

bool CtcStatIndicator::show_latest_log(std::string& prefix) {
    if (is_time_model()) {
        CtcLoss* ctc_last_cost = dynamic_cast<CtcLoss*>(_last_cost);
        CtcLoss* ctc_cost = dynamic_cast<CtcLoss*>(_train_cost);

        _last_frame_counter = _frame_counter - _last_frame_counter;
        _last_sample_counter = _sample_counter - _last_sample_counter;
        *ctc_last_cost = *ctc_cost - *ctc_last_cost;

        // tensorboard lastest
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_likely_hood",
                             ctc_last_cost->get_loss() / ctc_last_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_ctc_loglike",
                             ctc_last_cost->get_log_lh() / ctc_last_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_log_pzx",
                             ctc_last_cost->get_log_pzx() * 1.0f / 
                             ctc_last_cost->get_sample_counter(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_ctc_wer",
                             ctc_last_cost->get_wer_len() * 1.0f / ctc_last_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_ctc_sub",
                             ctc_last_cost->get_sub_len() * 1.0f / ctc_last_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_ctc_del",
                             ctc_last_cost->get_del_len() * 1.0f / ctc_last_cost->get_ref_len(),
                             _step);
        _writer->write_value(prefix + "/" + ctc_last_cost->get_name() + "_ctc_ins",
                             ctc_last_cost->get_ins_len() * 1.0f / ctc_last_cost->get_ref_len(),
                             _step);

        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s likely_hood: %f\n"
            "\t%s ctc_loglike: %f\n"
            "\t%s blank_rate: %f\n"
            "\t%s local_rate: %f\n"
            "\t%s log_pzx: %f\n"
            "\t%s ctc_wer: %f\tsub(%.4f)\tdel(%.4f)\tins(%.4f)\n"
            "\t%s likely_hood: %f\n"
            "\t%s ctc_loglike: %f\n"
            "\t%s blank_rate: %f\n"
            "\t%s local_rate: %f\n"
            "\t%s log_pzx: %f\n"
            "\t%s ctc_wer: %f\tsub(%.4f)\tdel(%.4f)\tins(%.4f)",
            _sample_counter, _frame_counter, prefix.c_str(),
            ctc_last_cost->get_name().c_str(), ctc_last_cost->get_loss() /
            ctc_last_cost->get_frame_counter(),
            ctc_last_cost->get_name().c_str(), ctc_last_cost->get_log_lh() /
            ctc_last_cost->get_frame_counter(),
            ctc_last_cost->get_name().c_str(), ctc_last_cost->get_blank_rate() * 1.0f /
            ctc_last_cost->get_frame_counter(),
            ctc_last_cost->get_name().c_str(), ctc_last_cost->get_local_rate() * 1.0f /
            ctc_last_cost->get_sample_counter(),
            ctc_last_cost->get_name().c_str(), ctc_last_cost->get_log_pzx() * 1.0f /
            ctc_last_cost->get_sample_counter(),
            ctc_last_cost->get_name().c_str(),
            ctc_last_cost->get_wer_len() * 1.0f / ctc_last_cost->get_ref_len(),
            ctc_last_cost->get_sub_len() * 1.0f / ctc_last_cost->get_ref_len(),
            ctc_last_cost->get_del_len() * 1.0f / ctc_last_cost->get_ref_len(),
            ctc_last_cost->get_ins_len() * 1.0f / ctc_last_cost->get_ref_len(),
            ctc_cost->get_name().c_str(), ctc_cost->get_loss() /
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_log_lh() / 
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_blank_rate() * 1.0f /
            ctc_cost->get_frame_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_local_rate() * 1.0f /
            ctc_cost->get_sample_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_log_pzx() * 1.0f /
            ctc_cost->get_sample_counter(),
            ctc_cost->get_name().c_str(), ctc_cost->get_wer_len() * 1.0f /
            ctc_cost->get_ref_len(),
            ctc_cost->get_sub_len() * 1.0f / ctc_cost->get_ref_len(),
            ctc_cost->get_del_len() * 1.0f / ctc_cost->get_ref_len(),
            ctc_cost->get_ins_len() * 1.0f / ctc_cost->get_ref_len()
        );
        *ctc_last_cost = *ctc_cost;
        _last_frame_counter = _frame_counter;
        _last_sample_counter = _sample_counter;

        _model_item++;
        return true;
    }

    return false;
}

void CtcStatIndicator::show_global_log(std::string& prefix) {
    CtcLoss* ctc_cost = dynamic_cast<CtcLoss*>(_train_cost);
    INTER_LOG(
        "\n\t%lu samples %lu frames finish %s layer loss:\n"
        "\t%s likely_hood: %f\n"
        "\t%s ctc_loglike: %f\n"
        "\t%s blank_rate: %f\n"
        "\t%s local_rate: %f\n"
        "\t%s log_pzx: %f\n"
        "\t%s ctc_wer: %f\tsub(%.4f)\tdel(%.4f)\tins(%.4f)",
        _sample_counter, _frame_counter, prefix.c_str(),
        ctc_cost->get_name().c_str(), ctc_cost->get_loss() / 
        ctc_cost->get_frame_counter(),
        ctc_cost->get_name().c_str(), ctc_cost->get_log_lh() / 
        ctc_cost->get_frame_counter(),
        ctc_cost->get_name().c_str(), ctc_cost->get_blank_rate() * 1.0f /
        ctc_cost->get_frame_counter(),
        ctc_cost->get_name().c_str(), ctc_cost->get_local_rate() * 1.0f /
        ctc_cost->get_sample_counter(),
        ctc_cost->get_name().c_str(), ctc_cost->get_log_pzx() * 1.0f /
        ctc_cost->get_sample_counter(),
        ctc_cost->get_name().c_str(), ctc_cost->get_wer_len() * 1.0f /
        ctc_cost->get_ref_len(),
        ctc_cost->get_sub_len() * 1.0f / ctc_cost->get_ref_len(),
        ctc_cost->get_del_len() * 1.0f / ctc_cost->get_ref_len(),
        ctc_cost->get_ins_len() * 1.0f / ctc_cost->get_ref_len()
    );
}

void TripletStatIndicator::update_values(Loss& cost) {
    *(dynamic_cast<TripletLoss*>(_train_cost)) =
        *(dynamic_cast<TripletLoss*>(&cost));
    *(dynamic_cast<TripletLoss*>(_cur_train_cost)) =
        *(dynamic_cast<TripletLoss*>(&cost));
}

void TripletStatIndicator::increase_values(const StatIndicator* ref) {
    _total_iter_counter += ref->_total_iter_counter;
    _sample_counter += ref->_sample_counter;
    _frame_counter += ref->_frame_counter;
    _cur_frame_counter += ref->_cur_frame_counter;
    *(dynamic_cast<TripletLoss*>(_train_cost)) +=
        *(dynamic_cast<TripletLoss*>(ref->_train_cost));
    *(dynamic_cast<TripletLoss*>(_cur_train_cost)) +=
        *(dynamic_cast<TripletLoss*>(ref->_train_cost));
}

void TripletStatIndicator::cal_loss(Loss& cost) {
    *(dynamic_cast<TripletLoss*>(_train_cost)) +=
        *(dynamic_cast<TripletLoss*>(&cost));
    *(dynamic_cast<TripletLoss*>(_cur_train_cost)) +=
        *(dynamic_cast<TripletLoss*>(&cost));
}

void TripletStatIndicator::show_current_log(std::string& prefix) {
    if (is_time_log()) {
        TripletLoss* cur_cost = dynamic_cast<TripletLoss*>(_cur_train_cost);
        TripletLoss* cost = dynamic_cast<TripletLoss*>(_train_cost);
        std::chrono::high_resolution_clock::time_point cur_clock =
            std::chrono::high_resolution_clock::now();
        double cur_second = std::chrono::duration < double,
               std::micro > (cur_clock - _cur_clock).count() /
               1000 / 1000;

        // tensorboard current global
        _writer->write_value(prefix + "/sample_finish",
                             static_cast<float>(_sample_counter),
                             _step);
        _writer->write_value(prefix + "/" + cur_cost->get_name() + "_loss",
                             cur_cost->get_loss() / cur_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cur_cost->get_name() + "_positive_apn",
                             cur_cost->get_positive_apn() * 1.0f / cur_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cur_cost->get_name() + "_ap_distance",
                             cur_cost->get_ap_distance() / cur_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cur_cost->get_name() + "_an_distance",
                             cur_cost->get_an_distance() / cur_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cost->get_name() + "_loss",
                             cost->get_loss() / cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cost->get_name() + "_positive_apn",
                             cost->get_positive_apn() * 1.0f / cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cost->get_name() + "_ap_distance",
                             cost->get_ap_distance() / cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + cost->get_name() + "_an_distance",
                             cost->get_an_distance() / cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/sample_num_per_second",
                             _cur_sample_counter / cur_second,
                             _step);

        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s loss: %f\n"
            "\t%s positive_apn: %f\n"
            "\t%s ap_distance: %f\n"
            "\t%s an_distance: %f\n"
            "\t%s loss: %f\n"
            "\t%s positive_apn: %f\n"
            "\t%s ap_distance: %f\n"
            "\t%s an_distance: %f\n"
            "\tsample_num/sec : %.3f = %lu:%.3f",
            _sample_counter, _frame_counter,
            prefix.c_str(),
            cur_cost->get_name().c_str(), cur_cost->get_loss() /
            cur_cost->get_frame_counter(),
            cur_cost->get_name().c_str(), cur_cost->get_positive_apn() * 1.0f /
            cur_cost->get_frame_counter(),
            cur_cost->get_name().c_str(), cur_cost->get_ap_distance() /
            cur_cost->get_frame_counter(),
            cur_cost->get_name().c_str(), cur_cost->get_an_distance() /
            cur_cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_loss() / 
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_positive_apn() * 1.0f / 
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_ap_distance() / 
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_an_distance() / 
            cost->get_frame_counter(),
            _cur_sample_counter / cur_second,
            _cur_sample_counter, cur_second
        );

        _cur_frame_counter = 0;
        _cur_sample_counter = 0;
        _cur_clock = cur_clock;
        _cur_train_cost->clear();
    }
}

bool TripletStatIndicator::show_latest_log(std::string& prefix) {
    if (is_time_model()) {
        TripletLoss* last_cost = dynamic_cast<TripletLoss*>(_last_cost);
        TripletLoss* cost = dynamic_cast<TripletLoss*>(_train_cost);

        _last_frame_counter = _frame_counter - _last_frame_counter;
        _last_sample_counter = _sample_counter - _last_sample_counter;
        *last_cost = *cost - *last_cost;

        // tensorboard lastest
        _writer->write_value(prefix + "/" + last_cost->get_name() + "_loss",
                             last_cost->get_loss() / last_cost->get_frame_counter(), _step);
        _writer->write_value(prefix + "/" + last_cost->get_name() + "_positive_apn",
                             last_cost->get_positive_apn() * 1.0f / last_cost->get_frame_counter(),
                             _step);
        _writer->write_value(prefix + "/" + last_cost->get_name() + "_ap_distance",
                             last_cost->get_ap_distance() / last_cost->get_frame_counter(), _step);
        _writer->write_value(prefix + "/" + last_cost->get_name() + "_an_distance",
                             last_cost->get_an_distance() / last_cost->get_frame_counter(), _step);

        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s loss: %f\n"
            "\t%s positive_apn: %f\n"
            "\t%s ap_distance: %f\n"
            "\t%s an_distance: %f\n"
            "\t%s loss: %f\n"
            "\t%s positive_apn: %f\n"
            "\t%s ap_distance: %f\n"
            "\t%s an_distance: %f",
            _sample_counter, _frame_counter, prefix.c_str(),
            last_cost->get_name().c_str(), last_cost->get_loss() / 
            last_cost->get_frame_counter(),
            last_cost->get_name().c_str(), last_cost->get_positive_apn() * 1.0f /
            last_cost->get_frame_counter(),
            last_cost->get_name().c_str(), last_cost->get_ap_distance() /
            last_cost->get_frame_counter(),
            last_cost->get_name().c_str(), last_cost->get_an_distance() /
            last_cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_loss() / 
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_positive_apn() * 1.0f /
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_ap_distance() / 
            cost->get_frame_counter(),
            cost->get_name().c_str(), cost->get_an_distance() / 
            cost->get_frame_counter()
        );
        *last_cost = *cost;
        _last_frame_counter = _frame_counter;
        _last_sample_counter = _sample_counter;

        _model_item++;
        return true;
    }

    return false;
}

void TripletStatIndicator::show_global_log(std::string& prefix) {
    TripletLoss* cost = dynamic_cast<TripletLoss*>(_train_cost);
    INTER_LOG(
        "\n\t%lu samples %lu frames finish %s layer loss:\n"
        "\t%s loss: %f\n"
        "\t%s positive_apn: %f\n"
        "\t%s ap_distance: %f\n"
        "\t%s an_distance: %f",
        _sample_counter, _frame_counter, prefix.c_str(),
        cost->get_name().c_str(), cost->get_loss() / 
        cost->get_frame_counter(),
        cost->get_name().c_str(), cost->get_positive_apn() * 1.0f /
        cost->get_frame_counter(),
        cost->get_name().c_str(), cost->get_ap_distance() /
        cost->get_positive_apn(),
        cost->get_name().c_str(), cost->get_an_distance() /
        cost->get_positive_apn()
    );
}

void MixLrStatIndicator::update_values(Loss& cost) {
    *(dynamic_cast<MixLrLoss*>(_train_cost)) =
        *(dynamic_cast<MixLrLoss*>(&cost));
    *(dynamic_cast<MixLrLoss*>(_cur_train_cost)) =
        *(dynamic_cast<MixLrLoss*>(&cost));
}

void MixLrStatIndicator::increase_values(const StatIndicator* ref) {
    _total_iter_counter += ref->_total_iter_counter;
    _sample_counter += ref->_sample_counter;
    _frame_counter += ref->_frame_counter;
    _cur_frame_counter += ref->_cur_frame_counter;
    _cur_sample_counter += ref->_cur_sample_counter;
    *(dynamic_cast<MixLrLoss*>(_train_cost)) +=
        *(dynamic_cast<MixLrLoss*>(ref->_train_cost));
    *(dynamic_cast<MixLrLoss*>(_cur_train_cost)) +=
        *(dynamic_cast<MixLrLoss*>(ref->_train_cost));
}

void MixLrStatIndicator::cal_loss(Loss& cost) {
    *(dynamic_cast<MixLrLoss*>(_train_cost)) +=
        *(dynamic_cast<MixLrLoss*>(&cost));
    *(dynamic_cast<MixLrLoss*>(_cur_train_cost)) +=
        *(dynamic_cast<MixLrLoss*>(&cost));
}

void MixLrStatIndicator::show_current_log(std::string& prefix) {
    if (is_time_log()) {
        MixLrLoss* cur_cost = dynamic_cast<MixLrLoss*>(_cur_train_cost);
        MixLrLoss* cost = dynamic_cast<MixLrLoss*>(_train_cost);
        std::chrono::high_resolution_clock::time_point cur_clock =
            std::chrono::high_resolution_clock::now();
        double cur_second = std::chrono::duration < double,
               std::micro > (cur_clock - _cur_clock).count() /
               1000 / 1000;

        // tensorboard current global
        //_writer->write_value(prefix + "/sample_finish",
        //                     static_cast<float>(_sample_counter),
        //                     _step);
        //_writer->write_value(prefix + "/" + cur_cost->get_name() + "_loss",
        //                     cur_cost->get_loss() / cur_cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cur_cost->get_name() + "_positive_apn",
        //                     cur_cost->get_positive_apn() * 1.0f / cur_cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cur_cost->get_name() + "_ap_distance",
        //                     cur_cost->get_ap_distance() / cur_cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cur_cost->get_name() + "_an_distance",
        //                     cur_cost->get_an_distance() / cur_cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cost->get_name() + "_loss",
        //                     cost->get_loss() / cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cost->get_name() + "_positive_apn",
        //                     cost->get_positive_apn() * 1.0f / cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cost->get_name() + "_ap_distance",
        //                     cost->get_ap_distance() / cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + cost->get_name() + "_an_distance",
        //                     cost->get_an_distance() / cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/sample_num_per_second",
        //                     _cur_sample_counter / cur_second,
        //                     _step);

        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s loss: %f\n"
            "\t%s one_sigmoid_loss: %f\n"
            "\t%s one_ln_loss: %f\n"
            "\t%s zero_sigmoid_loss: %f\n"
            "\t%s zero_ln_loss: %f\n"
            "\t%s one_sigmoid_loss: %f\n"
            "\t%s one_ln_loss: %f\n"
            "\t%s zero_sigmoid_loss: %f\n"
            "\t%s zero_ln_loss: %f\n"
            "\tsample_num/sec : %.3f = %lu:%.3f",
            _sample_counter, _frame_counter,
            prefix.c_str(),
            cur_cost->get_name().c_str(), cur_cost->get_loss() /
            cur_cost->get_frame_counter(),
            cur_cost->get_name().c_str(), cur_cost->get_loss_vec()[0] /
            cur_cost->get_loss_vec()[4],
            cur_cost->get_name().c_str(), cur_cost->get_loss_vec()[1] /
            cur_cost->get_loss_vec()[5],
            cur_cost->get_name().c_str(), cur_cost->get_loss_vec()[2] /
            cur_cost->get_loss_vec()[6],
            cur_cost->get_name().c_str(), cur_cost->get_loss_vec()[3] /
            cur_cost->get_loss_vec()[7],
            cost->get_name().c_str(), cost->get_loss_vec()[0] / 
            cost->get_loss_vec()[4],
            cost->get_name().c_str(), cost->get_loss_vec()[1] / 
            cost->get_loss_vec()[5],
            cost->get_name().c_str(), cost->get_loss_vec()[2] / 
            cost->get_loss_vec()[6],
            cost->get_name().c_str(), cost->get_loss_vec()[3] / 
            cost->get_loss_vec()[7],
            _cur_sample_counter / cur_second,
            _cur_sample_counter, cur_second
        );

        _cur_frame_counter = 0;
        _cur_sample_counter = 0;
        _cur_clock = cur_clock;
        _cur_train_cost->clear();
    }
}

bool MixLrStatIndicator::show_latest_log(std::string& prefix) {
    if (is_time_model()) {
        MixLrLoss* last_cost = dynamic_cast<MixLrLoss*>(_last_cost);
        MixLrLoss* cost = dynamic_cast<MixLrLoss*>(_train_cost);

        _last_frame_counter = _frame_counter - _last_frame_counter;
        _last_sample_counter = _sample_counter - _last_sample_counter;
        *last_cost = *cost - *last_cost;

        // tensorboard lastest
        //_writer->write_value(prefix + "/" + last_cost->get_name() + "_loss",
        //                     last_cost->get_loss() / last_cost->get_frame_counter(), _step);
        //_writer->write_value(prefix + "/" + last_cost->get_name() + "_positive_apn",
        //                     last_cost->get_positive_apn() * 1.0f / last_cost->get_frame_counter(),
        //                     _step);
        //_writer->write_value(prefix + "/" + last_cost->get_name() + "_ap_distance",
        //                     last_cost->get_ap_distance() / last_cost->get_frame_counter(), _step);
        //_writer->write_value(prefix + "/" + last_cost->get_name() + "_an_distance",
        //                     last_cost->get_an_distance() / last_cost->get_frame_counter(), _step);

        //INTER_LOG(
        //    "\n\t%lu samples %lu frames finish %s layer loss:\n"
        //    "\t%s loss: %f\n"
        //    "\t%s positive_apn: %f\n"
        //    "\t%s ap_distance: %f\n"
        //    "\t%s an_distance: %f\n"
        //    "\t%s loss: %f\n"
        //    "\t%s positive_apn: %f\n"
        //    "\t%s ap_distance: %f\n"
        //    "\t%s an_distance: %f",
        //    _sample_counter, _frame_counter, prefix.c_str(),
        //    last_cost->get_name().c_str(), last_cost->get_loss() / 
        //    last_cost->get_frame_counter(),
        //    last_cost->get_name().c_str(), last_cost->get_positive_apn() * 1.0f /
        //    last_cost->get_frame_counter(),
        //    last_cost->get_name().c_str(), last_cost->get_ap_distance() /
        //    last_cost->get_frame_counter(),
        //    last_cost->get_name().c_str(), last_cost->get_an_distance() /
        //    last_cost->get_frame_counter(),
        //    cost->get_name().c_str(), cost->get_loss() / 
        //    cost->get_frame_counter(),
        //    cost->get_name().c_str(), cost->get_positive_apn() * 1.0f /
        //    cost->get_frame_counter(),
        //    cost->get_name().c_str(), cost->get_ap_distance() / 
        //    cost->get_frame_counter(),
        //    cost->get_name().c_str(), cost->get_an_distance() / 
        //    cost->get_frame_counter()
        //);
        INTER_LOG(
            "\n\t%lu samples %lu frames finish %s layer loss:\n"
            "\t%s loss: %f\n"
            "\t%s one_sigmoid_loss: %f\n"
            "\t%s one_ln_loss: %f\n"
            "\t%s zero_sigmoid_loss: %f\n"
            "\t%s zero_ln_loss: %f\n"
            "\t%s one_sigmoid_loss: %f\n"
            "\t%s one_ln_loss: %f\n"
            "\t%s zero_sigmoid_loss: %f\n"
            "\t%s zero_ln_loss: %f\n",
            _sample_counter, _frame_counter,
            prefix.c_str(),
            last_cost->get_name().c_str(), last_cost->get_loss() /
            last_cost->get_frame_counter(),
            last_cost->get_name().c_str(), last_cost->get_loss_vec()[0] /
            last_cost->get_loss_vec()[4],
            last_cost->get_name().c_str(), last_cost->get_loss_vec()[1] /
            last_cost->get_loss_vec()[5],
            last_cost->get_name().c_str(), last_cost->get_loss_vec()[2] /
            last_cost->get_loss_vec()[6],
            last_cost->get_name().c_str(), last_cost->get_loss_vec()[3] /
            last_cost->get_loss_vec()[7],
            cost->get_name().c_str(), cost->get_loss_vec()[0] / 
            cost->get_loss_vec()[4],
            cost->get_name().c_str(), cost->get_loss_vec()[1] / 
            cost->get_loss_vec()[5],
            cost->get_name().c_str(), cost->get_loss_vec()[2] / 
            cost->get_loss_vec()[6],
            cost->get_name().c_str(), cost->get_loss_vec()[3] / 
            cost->get_loss_vec()[7]
        );
        *last_cost = *cost;
        _last_frame_counter = _frame_counter;
        _last_sample_counter = _sample_counter;

        _model_item++;
        return true;
    }

    return false;
}

void MixLrStatIndicator::show_global_log(std::string& prefix) {
    MixLrLoss* cost = dynamic_cast<MixLrLoss*>(_train_cost);
    INTER_LOG(
        "\n\t%lu samples %lu frames finish %s layer loss:\n"
        "\t%s loss: %f\n"
        "\t%s one_sigmoid_loss: %f\n"
        "\t%s one_ln_loss: %f\n"
        "\t%s zero_sigmoid_loss: %f\n"
        "\t%s zero_ln_loss: %f",
        _sample_counter, _frame_counter, prefix.c_str(),
        cost->get_name().c_str(), cost->get_loss() / 
        cost->get_frame_counter(),
        cost->get_name().c_str(), cost->get_loss_vec()[0] / 
        cost->get_loss_vec()[4],
        cost->get_name().c_str(), cost->get_loss_vec()[1] / 
        cost->get_loss_vec()[5],
        cost->get_name().c_str(), cost->get_loss_vec()[2] / 
        cost->get_loss_vec()[6],
        cost->get_name().c_str(), cost->get_loss_vec()[3] / 
        cost->get_loss_vec()[7]
    );
}

}   /* namespace of houyi */
}   /* namespace of train */
