/**
 * Predictor.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-10-17
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include <sys/stat.h>
#include <sys/types.h>
#include <string>
#include <iomanip>
#include "predictor.h"
#include "util.h"
#include "image_predictor.h"
#include "speech_predictor.h"
#include "image_voter.h"

namespace houyi {
namespace train {

Predictor* creat_predictor(PredictNnConfig& cfg) {
    Predictor* predictor = NULL;

    switch (cfg.job_type()) {
    case PREDICT:
        predictor = new Predictor(&cfg);
        break;

    case SPEECH_PREDICT:
        predictor = new SpeechPredictor(&cfg);
        break;

    case IMAGE_PREDICT:
        predictor = new ImagePredictor(&cfg);
        break;

    case IMAGE_VOTE_PREDICT:
        predictor = new ImageVoter(&cfg);
        break;

    default:
        INTER_CHECK(false, "invalid predict job type: %d", cfg.job_type());
    }

    return predictor;
}

Predictor::Predictor(PredictNnConfig* nn_cfg) {
    _init();
    set_device();
    _nn_cfg = nn_cfg;

    int device_num = _nn_cfg->device_ids().size();
    CHECK(device_num == 1, "now only support one GPU score");
    _device_id = _nn_cfg->device_ids()[_id % device_num];
    pthread_mutex_init(&_load_mutex, NULL);

    int old_id = 0;
    wind_get_gpu_device(&old_id);
    wind_set_gpu_device(_device_id);

    //不需要更新
    bool need_update = false;
    _nn = new NeuralNetwork(*_nn_cfg, need_update);

    if (!_nn_cfg->is_load_by_python()) {
        _data_reader = BaseDataReader::create(*_nn_cfg->data_cfg().get_reader_cfg());
    }

    _out_layer_name = _nn->get_out_layer_name();

    for (size_t i = 0; i < _out_layer_name.size() && i < _nn->get_cost_layer().size(); i++) {
        _stat_indicator.push_back(new StatIndicator(_nn_cfg->period_cfg(),
                    _nn->get_cost_layer()[i]->loss_type(),
                    _nn->get_cost_layer()[i]->name()));
    }

    _model_file_queue = new MessageQueue<std::string*>();
    _model_file_queue->set_max_length(2);

    _model_file = _nn_cfg->in_out_file_cfg().model_file();
    _inq_model_file = _nn_cfg->in_out_file_cfg().inq_model_file(); 

    if (_model_file.size() != 0) {
        _model_file_queue->push(new std::string(_model_file));
        _pre_model_set.insert(_model_file);
        //结束标志
        _model_file_queue->push(NULL);
    }

	if (_inq_model_file.size() != 0) {                       
		_model_file_queue->push(new std::string(_inq_model_file));
		_pre_model_set.insert(_inq_model_file);              
		//结束标志                                           
		_model_file_queue->push(NULL);                       
	}                                                        

    _model_file_list = _nn_cfg->in_out_file_cfg().model_file_list();

    //model list 中有多个模型，读取
    if (_model_file_list.size() != 0) {
        _model_file_queue->set_max_length(100000);
        std::ifstream model_st(_model_file_list);
        CHECK(model_st.is_open(), "File could not found: %s", _model_file_list.c_str());

        char* str = (char*)malloc(1024 * sizeof(char));
        char* model = (char*)malloc(1024 * sizeof(char));
        str[0] = 0;

        while (!model_st.eof()) {
            model_st.getline(str, 1024);
            remove_white_space_comment(str);

            if ('\0' == str[0]) {
                continue;
            }

            sscanf(str, "%s", model);
            _model_file_queue->push(new std::string(model));

#if 0
            std::string model_s(model);
            _pre_model_set.insert(model_s);
#endif
        }

        //结束标志
        _model_file_queue->push(NULL);
    }

    _score_store_dir = _nn_cfg->in_out_file_cfg().score_store_dir();
    _score_store_kaldi_dir = _nn_cfg->in_out_file_cfg().score_store_kaldi_dir();
    _classify_store_dir = _nn_cfg->in_out_file_cfg().classify_store_dir();

    _loss_file = _nn_cfg->in_out_file_cfg().loss_file();

    _predict_period = _nn_cfg->period_cfg().predict_period();

    _call_before_predict = _nn_cfg->call_before_predict();
    _call_after_predict = _nn_cfg->call_after_predict();

    wind_set_gpu_device(old_id);
}

Predictor::~Predictor() {
    if (_nn) {
        delete _nn;
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        if (_stat_indicator[i]) {
            delete _stat_indicator[i];
        }
    }

    _stat_indicator.clear();

    if (_reset_mark) {
        delete _reset_mark;
    }

    if (_data_reader) {
        delete _data_reader;
    }

    if (_data_proccer) {
        delete _data_proccer;
    }

    if (_data_repos) {
        delete _data_repos;
    }

    if (_work_thread) {
        delete _work_thread;
    }

    if (_model_file_queue) {
        _model_file_queue->clean();
        delete _model_file_queue;
    }

    _init();
}

void Predictor::reset() {
    if (_data_reader) {
        _data_reader->reset();
    }

    if (_data_proccer) {
        _data_proccer->reset();
    }

    if (_data_repos) {
        _data_repos->reset();
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        if (_stat_indicator[i]) {
            _stat_indicator[i]->reset();
        }
    }

    //if (_model_file_queue) {
    //    _model_file_queue->clean();
    //}
}

std::pair<BaseBatchSample*, DeviceBatchSample*> Predictor::load_data() {
    CHECK2(_data_reader);

    if (_data_proccer == NULL) {
        _data_proccer = BaseProcesser::create(
                            _data_reader, *(_nn_cfg->data_cfg().get_proc_cfg()));
        _data_proccer->start_async_load();
    }

    if (_data_repos == NULL) {
        _data_repos = BaseRepository::create(
                          _data_proccer, _nn_cfg->data_cfg(), _device_id);
        _data_repos->set_device_id(_device_id);
    }

    std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = 
        _data_repos->get_device_batch_from_repos();

    return bat_pair;
}

void Predictor::start() {
    if (_work_thread) {
        if (_work_thread->is_alive()) {
            return;
        }
    }

    if (_work_thread == NULL) {
        _work_thread = new Thread();
    }

    _work_thread->start(Predictor::run_thread, (void*) this);
}

void* Predictor::run_thread(void* data) {
    ThreadContext* ctx = static_cast<ThreadContext*>(data);
    Predictor* tt = static_cast<Predictor*>(ctx->get_param());
    bool* global_alive_mark = ctx->get_alive();
    *global_alive_mark = true;
    sem_post(&ctx->_create_finish_sem);

    wind_init(tt->_device_id);
    wind_set_gpu_device(tt->_device_id);
    tt->run();
    *global_alive_mark = false;
    return NULL;
}

void Predictor::run() {
    CHECK(false, "Default predictor nothing to do.");
}

void Predictor::store_score(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
            std::string& model_name, int batch_count, BaseBatchSample* bat) {
    char score_name[1024] = {0};

    if (access(dir.c_str(), 0) == -1) {
        mkdir(dir.c_str(), S_IRWXU);
    }

    size_t batch_size = bat->get_batch_size();
    const std::vector<std::string> filenames = bat->get_default_file_name();
    CHECK2(filenames.size() == batch_size);
    size_t frame_num = score.get_size(0) / batch_size;
    
    for (size_t i = 0; i < batch_size; ++i) {
        if (filenames[i].size()) {
            snprintf(score_name, 1024, "%s/%s", dir.c_str(), filenames[i].c_str());
        } else {
            snprintf(score_name, 1024, "%s/score_%d_%d", dir.c_str(), (int)batch_count, (int)i);
        }

        //sprintf(score_name, "%s/%04d.score", dir.c_str(), batch_count);
        //sprintf(score_name, "%s/%s_%04d.score", dir.c_str(), model_name.c_str(), batch_count);

        size_t frame_len = 0;
        size_t j = 0;
        for (j = 0; j < frame_num; j++) {
            if (mask.get_element(Dim(j * batch_size + i)) <= 0) {
                break;
            }
        }
        frame_len = j;

        std::ofstream out_score;
        out_score.open(score_name);
        score.write_score(out_score, (int)i, (int) batch_size, frame_len);
        out_score.close();
    }
}

void Predictor::store_kaldi_score(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
            std::string& model_name, int batch_count, BaseBatchSample* bat) {
    std::ofstream out_file;
    out_file.open(dir, std::ofstream::out | std::ofstream::app);

    if (access(dir.c_str(), 0) == -1) {
        mkdir(dir.c_str(), S_IRWXU);
    }

    size_t batch_size = bat->get_batch_size();
    const std::vector<std::string> filenames = bat->get_default_file_name();
    CHECK2(filenames.size() == batch_size);

    size_t frame_num = score.get_size(0) / batch_size;
    size_t frame_dim = score.get_size(1);

    Tensor<DType> cpu_score{cpu_device()};
    cpu_score.resize(score.get_size());
    cpu_score.copy_from(score);

    Tensor<int> cpu_mask{cpu_device()};
    cpu_mask.resize(mask.get_size());
    cpu_mask.copy_from(mask);

    for (size_t i = 0; i < batch_size; ++i) {
        if (filenames[i].size() == 0) {
            continue;
        }
        out_file << filenames[i] << " [" << std::endl;

        size_t j = 0;
        for (j = 0; j < frame_num; j++) {
            if (cpu_mask.get_data()[j * batch_size + i] == 0) {
                continue;
            }
            for (size_t k = 0; k < frame_dim; k++) {
                out_file << cpu_score.get_element(Dim(j * batch_size + i, k)) << " ";
            }
            out_file << std::endl;
        }
        out_file << " ]" << std::endl;
    }
    out_file.close();
}

void Predictor::store_classify(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
            std::string& model_name, int batch_count, BaseBatchSample* bat) {
    char score_name[1024] = {0};

    if (access(dir.c_str(), 0) == -1) {
        mkdir(dir.c_str(), S_IRWXU);
    }

    std::vector<std::string>label_keys = bat->get_label_keys(); 
    CHECK2(label_keys.size() == 1);
    Tensor<DType>& label_tensor = bat->get_label_tensor(label_keys[0]);

    Tensor<DType>cpu_score(score.get_size(), cpu_device());
    cpu_score.copy_from(score);

    size_t batch_size = bat->get_batch_size();
    const std::vector<std::string> filenames = bat->get_default_file_name();
    CHECK2(filenames.size() == batch_size);
    
    std::ofstream out_file;
    char file_name[1024];
    snprintf(file_name, 1024, "%s/%s", dir.c_str(), model_name.c_str());
    out_file.open(file_name, std::ios_base::app);

    size_t batch_frame_len = cpu_score.get_size(0) / batch_size;
    
    for (size_t i = 0; i < batch_size; ++i) {
        if (i < filenames.size() && filenames[i].size()) {
            snprintf(score_name, 1024, "%s", filenames[i].c_str());
        } else {
            snprintf(score_name, 1024, "score_%d_%d", (int)batch_count, (int)i);
        }
        //获取帧数
        size_t j = 0;
        for (j = 0; j < batch_frame_len; j++) {
            if (mask.get_element(Dim(j * batch_size + i, 0)) <= 0) {
                break;
            }
        }
        size_t frame_len = j;
        CHECK2(frame_len <= batch_frame_len);

        out_file << score_name;
        for (size_t f = 0; f < frame_len; f++) {
            size_t max_id = -1;
            DType max_value = 0; 
            DType* ptr = cpu_score.get_data(Dim(f * batch_size + i, 0));
            for (size_t j = 0; j < cpu_score.get_size(1); j++) {
                DType value = ptr[j];
                if (max_value < value) {
                    max_value = value;
                    max_id = j;
                }
            }

            out_file << std::setw(6) << max_id;
        }
        out_file << std::endl;
        // 原始标签
        out_file << score_name;
        for (size_t f = 0; f < frame_len; f++) {
            out_file << std::setw(6) << label_tensor.get_element(Dim(f * batch_size + i, 0));
        }
        out_file << std::endl << std::endl;

    }
    out_file.close();
}

void Predictor::show_current_log() {
    // current log
    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->show_current_log();
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->show_latest_log();
    }
}

void Predictor::show_model_loss(std::string& model_name) {

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->show_model_loss(model_name);
    }
}

void Predictor::store_model_loss(std::string& loss_file_name, std::string& model_name) {
    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        _stat_indicator[i]->store_model_loss(loss_file_name, model_name);
    }
}

void Predictor::copy_batch(Argument& dest, BaseBatchSample& src, DeviceBatchSample& device_batch) {
    std::vector<std::string> feat_key = src.get_feature_keys();
    std::vector<std::string> label_key = src.get_label_keys();
    
    _feat_pack = device_batch.get_io_package(feat_key);
    _label_pack = device_batch.get_io_package(label_key);
    
    dest.set_sample_num(src.get_batch_size());
    dest.insert_train_pack(feat_key, _feat_pack, label_key, _label_pack, *src.get_batch_desc());
}

}
}
