/**
 * Trainer.cpp
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-25
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include <sys/stat.h>
#include <sys/types.h>
#include "trainer.h"
#include "util.h"
#include "tools.h"
#include "speech_batch_sample.h"
#include "device_batch_sample.h"

namespace houyi {
namespace train {

Trainer::Trainer(NNConfig* nn_cfg) {
    _init();
    _nn_cfg = nn_cfg;
    //_store_model_file = nn_cfg->store_model_file();
    //_store_md_model_file = nn_cfg->md_store_file();

    /* nn */
    bool need_update = (_nn_cfg->device_ids().size() > 1) ? false : true;
    //bool need_update = (_nn_cfg->device_ids().size() >= 1) ? false : true;
    _nn = new NeuralNetwork(*_nn_cfg, need_update);

    _tb_writer = new TensorBoardWriter(_nn_cfg->get_name(), _nn);

    /* data-reader */
    if (!nn_cfg->is_load_by_python()) {
        _data_reader = BaseDataReader::create(*_nn_cfg->data_cfg().get_reader_cfg());
    } else {
        _data_reader = NULL;
    }

    /* Statistical indicators */
    _cost_layer_name = _nn->get_cost_layer_name();
    _out_layer_name = _nn->get_out_layer_name();

    if (_stat_indicator.size() != 0) {
        for (size_t i = 0; i < _stat_indicator.size(); i++) {
            delete _stat_indicator[i];
        }

        _stat_indicator.clear();
    }

    for (size_t i = 0; i < _cost_layer_name.size(); i++) {
        StatIndicator* stat_indicator =
                    creat_indicator(_nn_cfg->period_cfg(),
                    _nn->get_cost_layer()[i]->loss_type(),
                    _nn->get_cost_layer()[i]->name());
        stat_indicator->set_tb_writer(_tb_writer);
        _stat_indicator.push_back(stat_indicator);
    }
}

Trainer::~Trainer() {
    if (_nn) {
        delete _nn;
        _nn = NULL;
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        if (_stat_indicator[i]) {
            delete _stat_indicator[i];
            _stat_indicator[i] = NULL;
        }
    }

    _stat_indicator.clear();

    if (_data_reader) {
        delete _data_reader;
        _data_reader = NULL;
    }

    if (_data_proccer) {
        //delete _data_proccer;
        //_data_proccer = NULL;
        _data_proccer->clear();
    }

    if (_data_repos) {
        delete _data_repos;
        _data_repos = NULL;
    }

    if (_tb_writer) {
        delete _tb_writer;
        _tb_writer = NULL;
    }

    _init();
}

void Trainer::reset() {
    if (_data_reader) {
        _data_reader->reset();
    }

    if (_data_proccer) {
        _data_proccer->reset();
    }

    if (_data_repos) {
        _data_repos->reset();
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        if (_stat_indicator[i]) {
            _stat_indicator[i]->reset();
        }
    }
}

std::pair<BaseBatchSample*, DeviceBatchSample*> Trainer::load_data() {
    CHECK2(_data_reader);

    if (_data_proccer == NULL) {
        _data_proccer = BaseProcesser::create(
                            _data_reader, *(_nn_cfg->data_cfg().get_proc_cfg()));
        _data_proccer->start_async_load();
    }

    if (_data_repos == NULL) {
        _data_repos = BaseRepository::create(
                          _data_proccer, _nn_cfg->data_cfg(), _device_id);
        _data_repos->set_device_id(_device_id);
    }

    std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = 
        _data_repos->get_device_batch_from_repos();

    return bat_pair;
}

void Trainer::copy_batch(Argument& dest, BaseBatchSample& src, DeviceBatchSample& device_batch) {
    std::vector<std::string> feat_key = src.get_feature_keys();
    std::vector<std::string> label_key = src.get_label_keys();

    _feat_pack = device_batch.get_io_package(feat_key);
    _label_pack = device_batch.get_io_package(label_key);

    dest.reset();
    dest.set_sample_num(src.get_batch_size());
    dest.insert_train_pack(feat_key, _feat_pack, label_key, _label_pack, *src.get_batch_desc());
}

void Trainer::store_model(const char* prefix_name, int cur_epoch, char* model_name) {
    // get localhost name&thread_id
    pid_t tid;
    pid_t pid;
    pid = getpid();
    char datetime[20];
    get_datetime(datetime);
    char hname[256];
    bzero(hname, sizeof(hname));
    gethostname(hname, sizeof(hname));
    tid = syscall(SYS_gettid);
    snprintf(hname + strlen(hname), 200, "-%u-%u-%s", tid, pid, datetime);

    // build name
    char local_model_name[256] = {0};
    size_t cnt = _stat_indicator[0]->_sample_counter ?
                 _stat_indicator[0]->_sample_counter : _stat_indicator[0]->_frame_counter;
    snprintf(local_model_name, 256,
             "%s_epoch_%d_%lu.model.%s", prefix_name, cur_epoch, cnt, hname);

    // store
    _nn->store_model(local_model_name, WEIGHT);
    INTER_LOG("store model to %s", local_model_name);

    // mark
    snprintf(_last_model_name, 128, "%s", local_model_name);

    if (model_name != NULL) {
        snprintf(model_name, 128, "%s", local_model_name);
    }
}
}
}
