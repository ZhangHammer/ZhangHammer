/**
 * decoder.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "multi_discriminator.h"
#include "decoder.h"
#include "triplet_decoder.h"
#include "select_decoder.h"
#include "util.h"

namespace houyi {
namespace train {

Decoder* creat_decoder(DecoderConfig& cfg) {
    Decoder* decoder = NULL;

    switch (cfg.get_type()) {
    case DECODER:
        decoder = new Decoder(cfg);
        break;

    case TRIPLET_DECODER:
        decoder = new TripletDecoder(cfg);
        break;

    case SELECT_DECODER:
        decoder = new SelectDecoder(cfg);
        break;

    default:
        CHECK(false, "unknown decoder type");
    }

    return decoder;
}

Decoder::Decoder(DecoderConfig& cfg) {
    init();
    set_device();

    _type = cfg.get_type();
    _epoch = cfg.get_epoch();
    _score_thread_num = cfg.get_score_thread_num();
    _decoder_period = cfg.get_decode_period();
    _decode_data_queue = new MessageQueue<DecodeData*>();
    _decode_data_queue->set_max_length(10);
}

Decoder::~Decoder() {
    if (_decode_data_queue != NULL) {
        _decode_data_queue->clean();
        delete _decode_data_queue;
        _decode_data_queue = NULL;
    }

    if (_work_thread != NULL) {
        delete _work_thread;
        _work_thread = NULL;
    }
}

void Decoder::reset() {
    if (_decode_data_queue != NULL) {
        _decode_data_queue->clean();
    }
}

void Decoder::start() {
    if (_work_thread) {
        if (_work_thread->is_alive()) {
            return;
        }
    }

    if (_work_thread == NULL) {
        _work_thread = new Thread();
    }

    _work_thread->start(Decoder::run_thread, (void*) this);

    if (_decode_data_queue != NULL) {
        _decode_data_queue->clean();
    }
}

void* Decoder::run_thread(void* data) {
    ThreadContext* ctx = static_cast<ThreadContext*>(data);
    Decoder* tt = static_cast<Decoder*>(ctx->get_param());
    bool* global_alive_mark = ctx->get_alive();
    *global_alive_mark = true;
    sem_post(&ctx->_create_finish_sem);

    tt->run();
    *global_alive_mark = false;
    return NULL;
}

void Decoder::run() {
    DecodeData* data = _decode_data_queue->pop();

    Tensor<DType>* feat = data->_feat.get_ten();
    Tensor<DType>* label = data->_label.get_ten();
    Tensor<DType>* score = &data->_score;
    size_t batch_size = score->get_h();
    size_t score_dim = score->get_w();
    CHECK(batch_size == feat->get_size(0), "param error");
    CHECK(batch_size == label->get_size(0), "param error");

    _score.resize(Dim(batch_size, score_dim));
    _feat.resize(Dim(batch_size, feat->get_size(1), feat->get_size(2), feat->get_size(3)));
    _label.resize(Dim(batch_size, label->get_size(1)));

    //copy score feature label
    _score.copy_from(*score);
    _feat.copy_from(*feat);
    _label.copy_from(*label);

    delete data;
    data = NULL;

    size_t cur_epoch = 0;
    size_t cur_stop_thread_num = 0;

    while (cur_epoch < _epoch) {
        data = _decode_data_queue->pop();

        if (data == NULL) {
            cur_stop_thread_num ++;

            if (cur_stop_thread_num >= _score_thread_num) {
                _data_reader->push_batch_to_reader(NULL, NULL);
                cur_stop_thread_num = 0;
                cur_epoch ++;

                if (cur_epoch >= _epoch) {
                    break;
                }
            }

            continue;
        }

        feat = data->_feat.get_ten();
        label = data->_label.get_ten();
        score = &data->_score;

        //copy score feature label
        _score.copy_from(*score);
        _feat.copy_from(*feat);
        _label.copy_from(*label);

        _data_reader->push_batch_to_reader(&_feat, &_label);
        delete data;
        data = NULL;
    }

    reset();
}

}
}
