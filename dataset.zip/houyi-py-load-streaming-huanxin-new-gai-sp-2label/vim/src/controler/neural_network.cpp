/**
 * neural_network.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include <typeinfo>
#include <string>
#include <map>
#include <vector>
#include <pthread.h>
#include <signal.h>
#include <algorithm>
#include "nn_config.h"
#include "neural_network.h"
#include "bat_norm_layer.h"
#include "conv_layer.h"
#include "fast_lstm.h"
#include "full_layer.h"
#include "linear_layer.h"
#include "image_conv_layer.h"
#include "image_pooling_layer.h"
#include "drop_out_layer.h"
#include "image_bat_norm_layer.h"
#include "ctc_loss_layer.h"
#include "norm_softmax_layer.h"
#include "softmax_with_loss.h"
#include "norm2_layer.h"
#include "triplet_loss_layer.h"
#include "roi_pool_layer.h"
#include "ps_roi_pool_layer.h"
#include "reshape_layer.h"
#include "redim_layer.h"
#include "smooth_l1_loss_layer.h"
#include "smooth_l1_loss_ohem_layer.h"
#include "faster_rcnn_acu_layer.h"
#include "rfcn_acu_layer.h"
#include "transpose_layer.h"
#include "expand_layer.h"
#include "skip_layer.h"
#include "box_annotator_ohem_layer.h"
#include "gru_layer.h"
#include "fast_gru_layer.h"
#ifdef __BUILD_PYTHON__
#include "python_layer.h"
#include <boost/python.hpp>
#endif
#include "bat_renorm_layer.h"
#include "split_layer.h"
#include "audio_conv_layer.h"
#include "audio_bat_norm_layer.h"
#include "focal_loss_layer.h"
#include "audio_delta.h"
#include "audio_splice.h"
#include "bit_quant.h"
#include "audio_roi_pool_layer.h"
#include "image_conv_quant_layer.h"
#include "global_cmvn_layer.h"

DEFINE_bool(enable_new_layer, false, "use new conv layer, bn layer");

namespace houyi {
namespace train {
NeuralNetwork::NeuralNetwork(NNConfig& nn_cfg, bool need_update) {
    _init();

    _nn_config = &nn_cfg;

#ifdef __BUILD_PYTHON__
    Py_Initialize();
    bp::object module = bp::import("sys");
    bp::object python_path = module.attr("path");
    bp::object temp = python_path.attr("append")("./python/");

    if (!nn_cfg.get_python_path().empty()) {
        bp::object temp = python_path.attr("append")(nn_cfg.get_python_path().c_str());
    }

#endif

    std::vector<LayerConfig*>& configs = nn_cfg.layer_cfg_vec();
    //OutputConfig& mapCfg = nn_cfg.out_map();
    _batch_size = nn_cfg.batch_size();
    _feature_key = nn_cfg.get_feature_keys();
    std::vector<std::string> ss = nn_cfg.data_cfg().get_dim_string();

    _feature_key.insert(_feature_key.begin(), ss.begin(), ss.end());
    sort(_feature_key.begin(),_feature_key.end());
    _feature_key.erase(unique(_feature_key.begin(), _feature_key.end()), _feature_key.end());

    _label_key = nn_cfg.get_label_keys();

    for (size_t i = 0; i < configs.size(); i++) {
        LayerType layer_type = configs[i]->type();
        // May save a lot of memory space
        configs[i]->set_update(need_update);
        // create a new layer
        Layer* new_ly = create_layer(*configs[i], _cost_layer_name, _cost_layer);
        _layers.push_back(new_ly);

        if (layer_type == LSTM) {
            _lstm_skip_num = dynamic_cast<LstmConfig*>(configs[i])->skip_num();

        }

        configs[i]->set_update(true);
    }

    gen_his_clear_vec();

    const std::vector<LossConfig*>& loss_cfg = nn_cfg.loss_layer_cfg();
    Tensor<DType>* prior = NULL;
    if (loss_cfg.size() != 0) {
        prior = loss_cfg[0]->prior();
    }

    common_set(prior);
    build_out_layer();
    /* 推测每一层的大小 */
    layer_set(_layers, nn_cfg.get_batch_size());

    init_weight(nn_cfg.model_init_cfg());
}

NeuralNetwork::NeuralNetwork(NeuralNetwork& nn) {
    _init();

    for (int i = 0; i < nn.layer_size(); i++) {
        _layers.push_back(nn.layers()[i]->clone());
    }

    _cnt_flag         = nn.get_cnt_flag();
    _lstm_skip_num    = nn.get_lstm_skip_num();
    _batch_size       = nn.get_batch_size();
    _batch_clear_prob = nn.get_batch_clear_prob();
    _batch_clear_num  = nn.get_batch_clear_num();
    _odd_his_vec      = nn.get_odd_his_vec();
    _even_his_vec     = nn.get_even_his_vec();

    common_set(nn.get_prior());

    std::vector<std::string>& cost_layer_name = nn.get_cost_layer_name();
    std::vector<std::string>& out_layer_name = nn.get_out_layer_name();

    for (size_t i = 0; i < cost_layer_name.size(); i++) {
        _cost_layer_name.push_back(cost_layer_name[i]);

        for (size_t j = 0; j < _layers.size(); j++) {
            if (_layers[j]->name() == cost_layer_name[i]) {
                _cost_layer.push_back(dynamic_cast<LossLayer*>(_layers[j]));
                break;
            }
        }
    }

    for (size_t i = 0; i < out_layer_name.size(); i++) {
        _out_layer_name.push_back(out_layer_name[i]);

        for (size_t j = 0; j < _layers.size(); j++) {
            if (_layers[j]->name() == out_layer_name[i]) {
                _out_layer.push_back(dynamic_cast<Layer*>(_layers[j]));
                break;
            }
        }
    }
}

void NeuralNetwork::common_set(Tensor<DType>* prior) {
    // collect the output buffer of each layer
    register_argument();

    // update the start&end layer-ids that need updated in the network
    check_update_limit();

    // for ctc-training or predict-testing
    if (prior) {
        _out_args.insert_prior(prior);
    }
}

NeuralNetwork::~NeuralNetwork() {
    for (size_t i = 0; i < _layers.size(); i++) {
        if (_layers[i]) {
            delete _layers[i];
            _layers[i] = NULL;
        }
    }

    _layers.clear();

    _nn_config = NULL;

    for (size_t i = 0; i < _input_io_vec.size(); i++) {
        delete _input_io_vec[i];
    }
}

void NeuralNetwork::set_workspace(Tensor<unsigned char>* workspace) {
    for (auto it : _layers) {
        it->set_workspace(workspace);
    }
}

int NeuralNetwork::is_echo_finish() {
#ifdef __BUILD_PYTHON__
    PythonLayer* pl = static_cast<PythonLayer*>(_layers[0]);
    return pl->is_echo_finish();
#else
    return 0;
#endif
}

Layer* NeuralNetwork::create_layer(LayerConfig& cfg, std::vector<std::string>& cost_layer_name,
                                   std::vector<LossLayer*>& cost_layer) {
    Layer* new_layer = NULL;
    LayerType layer_type = cfg.type();

    switch (layer_type) {
    case LSTM: {
        LstmConfig* lstm_cfg = static_cast<LstmConfig*>(&cfg);
        new_layer = new FastLstmLayer(*lstm_cfg);
    }
    break;

    case FULL: {
        FullConfig* full_cfg = static_cast<FullConfig*>(&cfg);
        new_layer = new FullLayer(*full_cfg);
    }
    break;

    case CONV: {
        ConvConfig* conv_cfg = static_cast<ConvConfig*>(&cfg);
        if (FLAGS_enable_new_layer) {
            new_layer = new AudioConvLayer(*conv_cfg);
        } else {
            new_layer = new ConvLayer(*conv_cfg);
        }
    }
    break;

    case BAT_NORM: {
        BatNormConfig* bat_cfg = static_cast<BatNormConfig*>(&cfg);
        if (FLAGS_enable_new_layer) {
            new_layer = new AudioBatNormalLayer(*bat_cfg);
        } else {
            new_layer = new BatNormalLayer(*bat_cfg);
        }
    }
    break;

    case LINEAR: {
        LinearConfig* ln_cfg = static_cast<LinearConfig*>(&cfg);
        new_layer = new LinearLayer(*ln_cfg);
    }
    break;

    case IMAGE_CONV: {
        ImageConvConfig* new_cfg = static_cast<ImageConvConfig*>(&cfg);
        new_layer = new ImageConvLayer(*new_cfg);
    }
    break;

    case IMAGE_POOL: {
        ImagePoolingConfig* new_cfg = static_cast<ImagePoolingConfig*>(&cfg);
        new_layer = new PoolingLayer(*new_cfg);
    }
    break;

    case SOFTMAX_WITH_LOSS: {
        SoftmaxWithLossConfig* new_cfg = static_cast<SoftmaxWithLossConfig* >(&cfg);
        new_layer = new SoftmaxWithLossLayer(*new_cfg);
    }
    break;

    case SOFTMAX_NORM: {
        NormSoftmaxConfig* new_cfg = static_cast<NormSoftmaxConfig*>(&cfg);
        new_layer = new NormSoftmaxLayer(*new_cfg);
    }
    break;

    case LOSS_CE: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        CrossEntryLossLayer* new_cost_layer = new CrossEntryLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case LOSS_MSE: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        MSELossLayer* new_cost_layer = new MSELossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case LOSS_CTC: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        CtcLossLayer* new_cost_layer = new CtcLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case LOSS_TRIPLET: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        TripletLossLayer* new_cost_layer = new TripletLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case DROP_OUT: {
        DropOutConfig* drop_cfg = static_cast<DropOutConfig*>(&cfg);
        new_layer = new DropOutLayer(*drop_cfg);
    }
    break;

    case IMAGE_BAT_NORM: {
        ImageBatNormConfig* bat_cfg = static_cast<ImageBatNormConfig*>(&cfg);
        new_layer = new ImageBatNormalLayer(*bat_cfg);
    }
    break;

    case NORM2: {
        Norm2Config* norm_cfg = static_cast<Norm2Config*>(&cfg);
        new_layer = new Norm2Layer(*norm_cfg);
    }
    break;

    case ROI_POOL: {
        ROIPoolConfig* roi_cfg = static_cast<ROIPoolConfig*>(&cfg);
        new_layer = new ROIPoolLayer(*roi_cfg);
    }
    break;

    case PS_ROI_POOL: {
        PSROIPoolConfig* roi_cfg = static_cast<PSROIPoolConfig*>(&cfg);
        new_layer = new PSROIPoolLayer(*roi_cfg);
    }
    break;
#ifdef __BUILD_PYTHON__

    case PYTHON: {
        new_layer = get_python_layer(dynamic_cast<PythonConfig&>(cfg));
        PythonConfig* py_cfg = dynamic_cast<PythonConfig*>(&cfg);

        if (is_loss_layer(py_cfg->get_python_layer_type())) {
            CHECK(false, "python loass layer is not supported now");
            //_cost_layer.push_back(new_layer);
            //_cost_layer_name.push_back(new_layer->name());
        }
    }
    break;
#endif

    case RESHAPE: {
        ReshapeConfig* local_cfg = static_cast<ReshapeConfig*>(&cfg);
        new_layer = new ReshapeLayer(*local_cfg);
    }
    break;

    case REDIM: {
        RedimConfig* local_cfg = static_cast<RedimConfig*>(&cfg);
        new_layer = new RedimLayer(*local_cfg);
    }
    break;

    case TRANSPOSE: {
        TransposeConfig* local_cfg = static_cast<TransposeConfig*>(&cfg);
        new_layer = new TransposeLayer(*local_cfg);
    }
    break;

    case LOSS_SMOOTH_L1: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        SmoothL1LossLayer* new_cost_layer = new SmoothL1LossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case LOSS_SMOOTH_OHEM_L1: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        SmoothL1LossOHEMLayer* new_cost_layer = new SmoothL1LossOHEMLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;

    case FASTER_RCNN_ACU: {
        FasterRCNNACUConfig* local_cfg = static_cast<FasterRCNNACUConfig*>(&cfg);
        new_layer = new FasterRCNNACULayer(*local_cfg);
    }
    break;

    case RFCN_ACU: {
        RfcnAcuConfig* local_cfg = static_cast<RfcnAcuConfig*>(&cfg);
        new_layer = new RfcnAcuLayer(*local_cfg);
    }
    break;

    case EXPAND: {
        ExpandConfig* local_cfg = static_cast<ExpandConfig*>(&cfg);
        new_layer = new ExpandLayer(*local_cfg);
    }
    break;

    case SKIP: {
        SkipConfig* local_cfg = static_cast<SkipConfig*>(&cfg);
        new_layer = new SkipLayer(*local_cfg);
    }
    break;

    case BOX_ANNOTATOR_OHEM: {
        BoxAnnotatorOHEMConfig* local_cfg = static_cast<BoxAnnotatorOHEMConfig*>(&cfg);
        new_layer = new BoxAnnotatorOHEMLayer(*local_cfg);
    }
    break;

    case BAT_RENORM: {
        BatRenormConfig* bat_cfg = static_cast<BatRenormConfig*>(&cfg);
        new_layer = new BatRenormalLayer(*bat_cfg);
    }
    break;

    case SPLIT: {
        SplitConfig* split_cfg = static_cast<SplitConfig*>(&cfg);
        new_layer = new SplitLayer(*split_cfg);
    }
    break;

    case GRU: {
        GruConfig* gru_cfg = static_cast<GruConfig*>(&cfg);
        new_layer = new GruLayer(*gru_cfg);
    }
    break;
    
    case FAST_GRU: {
        FastGruConfig* fast_gru_cfg = static_cast<FastGruConfig*>(&cfg);
        new_layer = new FastGruLayer(*fast_gru_cfg);
    }
    break;
    case LOSS_FOCAL: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        FocalLossLayer* new_cost_layer = new FocalLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
        break;
    }
    case LOSS_LR: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        LRLossLayer* new_cost_layer = new LRLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;
    case AUDIO_DELTA: {
        AudioDeltaConfig* audio_delta_cfg = static_cast<AudioDeltaConfig*>(&cfg);
        new_layer = new AudioDelta(*audio_delta_cfg);
    }
    break;
    case AUDIO_SPLICE: {
        AudioSpliceConfig* audio_delta_cfg = static_cast<AudioSpliceConfig*>(&cfg);
        new_layer = new AudioSplice(*audio_delta_cfg);
    }
    break;
    case BIT_QUANT: {
        BitQuantConfig* bit_quant_cfg = static_cast<BitQuantConfig*>(&cfg);
        new_layer = new BitQuant(*bit_quant_cfg);
    }
    break;
    case GLOBAL_CMVN: {
        GlobalCmvnConfig* global_cmvn_cfg = static_cast<GlobalCmvnConfig*>(&cfg);
        new_layer = new GlobalCmvnLayer(*global_cmvn_cfg);
        break;
    }
    case AUDIO_ROI_POOL: {
        AudioROIPoolConfig* audio_roi_pool_cfg = static_cast<AudioROIPoolConfig*>(&cfg);
        new_layer = new AudioROIPoolLayer(*audio_roi_pool_cfg);
        break;
    }
    case LOSS_MIX_LR: {
        LossConfig* new_cfg = static_cast<LossConfig*>(&cfg);
        MixLRLossLayer* new_cost_layer = new MixLRLossLayer(*new_cfg);
        new_layer = new_cost_layer;
        cost_layer.push_back(new_cost_layer);
        cost_layer_name.push_back(new_layer->name());
    }
    break;
    case IMAGE_CONV_QUANT: {
        ImageConvQuantConfig* image_conv_quant_config = static_cast<ImageConvQuantConfig*>(&cfg);
        new_layer = new ImageConvQuantLayer(*image_conv_quant_config);
    }
    break;

    default:
        INTER_CHECK(false, "unknown layer-type: %d\n", layer_type);
    }

    return new_layer;
}

void NeuralNetwork::check_update_limit() {
    for (int i = 0; i < (int)_layers.size(); i++) {
        if (_layers[i]->need_update() && _start_up_id < 0) {
            _start_up_id = i;
            _end_up_id   = layer_size() - 1; // the last layer
            _up_num      = _end_up_id - _start_up_id + 1;
            INTER_LOG("start_up_id:%d, end_up_id:%d, up_num:%d",
                      _start_up_id, _end_up_id, _up_num);
            break;
        }
    }
}

void NeuralNetwork::register_argument() {
    for (int i = 0; i < (int)_layers.size(); i++) {
        // collect the output buffer of each layer
        _layers[i]->register_args(_out_args, _diff_args);
    }
}

void NeuralNetwork::zero_grad() {
    //CHECK2(_layers.size() == _out_args.size());

    for (size_t l = 0; l < _layers.size(); l++) {
        _layers[l]->clean_delta_w();                // weight-gradients
        //_layers[l]->zero_out_pack();
        _layers[l]->zero_diff_pack();
    }
}

void NeuralNetwork::zero_buf(SPEECH_NN_W_TYPE t) {
    for (size_t l = 0; l < _layers.size(); l++) {
        _layers[l]->zero_buf(t);
    }
}

void NeuralNetwork::set_drop_flag(bool drop_flag) {
    for (size_t l = 0; l < _layers.size(); l++) {
        _layers[l]->set_drop_flag(drop_flag);
    }
}

void NeuralNetwork::set_train_data(Argument& train_data_args) {
    /* first, clear the buffer */
    zero_grad();

    /* append the tarin-data to nn-args-buffer */
    _out_args.append_train_data(train_data_args);
}

void NeuralNetwork::clear_train_data(Argument& train_data_args) {
    /* remove the tarin-data from nn-args-buffer */
    _out_args.remove_train_data(train_data_args);
}

void NeuralNetwork::forward() {
    CHECK2(_layers.size() <= _out_args.size());

    /* Heuristic clear history of RNN for CTC */
    std::vector<int> his_vec;

    for (size_t i = 0; i < _cost_layer.size(); i++) {
        if (_cost_layer[i]->loss_type() == LOSS_TYPE_CTC) {
            his_vec = _odd_his_vec;

            if (rand() % 2 == 0) {
                his_vec = _even_his_vec;
            }

            if (rand() % _batch_clear_prob == 0 || ++_cnt_flag % _batch_clear_num == 0) {
                memset(his_vec.data(), 1, sizeof(int)*his_vec.size());
            }

            break;
        } else {
            his_vec.resize(_odd_his_vec.size(), 1);
        }
    }

    for (size_t l = 0; l < _layers.size(); l++) {
        if (_layers[l]->type() == LSTM) {
            FastLstmLayer* lstm_layer = dynamic_cast<FastLstmLayer*>(_layers[l]);
            lstm_layer->heuristic_clear_history(his_vec);
        }
    }

    /* forward layer by layer */
    for (size_t l = 0; l < _layers.size(); l++) {
        _layers[l]->weight_flag(true);
        _layers[l]->forward(_out_args);
    }
}

void NeuralNetwork::backward() {
    for (auto it = _layers.rbegin(); it != _layers.rend(); ++it) {
        (*it)->backward(_out_args, _diff_args);
    }
}

bool NeuralNetwork::update() {
    bool weight_flag = true;

    for (auto layer : _layers) {
        if (!layer->weight_flag()) {
            weight_flag = false;
            INTER_LOG("nnet do not update!");
        }
    }

    if (!weight_flag) {
        for (auto layer : _layers) {
            layer->zero_buf(MD_WEIGHT);
        }

        return false;
    } else {
        for (auto layer : _layers) {
            layer->update();
        }
    }

    return weight_flag;
}

void NeuralNetwork::reset_weight(std::vector<WeightsMap>& src) {
    CHECK2(src.size() == (size_t)layer_size());

    for (size_t l = 0; l < src.size(); l++) {
        _layers[l]->copy_in(src[l], WEIGHT);
    }
}

void NeuralNetwork::reset_momentum(std::vector<WeightsMap>& src) {
    CHECK2(src.size() == (size_t)layer_size());

    for (size_t l = 0; l < src.size(); l++) {
        _layers[l]->copy_in(src[l], MD_WEIGHT);
    }
}

void NeuralNetwork::read_prior(const char* prior_name) {
    if (NULL == prior_name) {
        return;
    }

    Tensor<DType> cpu_prior;
    cpu_prior.set_device(cpu_device());
    int state = 0;
    int i = 0;

    FILE* f = fopen(prior_name, "rt");
    CHECK(f != NULL, "can not open file %s", prior_name);

    fscanf(f, "%d\n", &state);
    cpu_prior.resize(Dim(state));

    DType* data = cpu_prior.get_data();

    for (i = 0; i < state && !feof(f); ++i) {
        fscanf(f, "%e\n", &(data[i]));
    }

    fclose(f);

    CHECK(0 != state && i == state, "the priorlist %s is wrong format.", prior_name);
    /*
       if (_prior == NULL) {
       _prior = new FTensor();
       }

       _prior->resize(1, state);
       _prior->copy_from(cpu_prior);
       */
    _out_args.insert_prior(&cpu_prior);
}

void NeuralNetwork::store_model(
    const char* file_name, SPEECH_NN_W_TYPE t) {
    std::ofstream output(file_name, std::ios::binary);

    if (output.fail()) {
        perror(file_name);
        exit(1);
    }

    for (size_t i = 0; i < _layers.size(); i++) {
        _layers[i]->store_model(output, t);
    }

    output.close();
}

void NeuralNetwork::read_model_no_bn(
    const char* file_name, SPEECH_NN_W_TYPE t,
    int start_layer, int end_layer) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_model(input, t);
        }
    }

    input.close();
}

void NeuralNetwork::read_model(
    const char* file_name, SPEECH_NN_W_TYPE t,
    int start_layer, int end_layer) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_model(input, t);
            _layers[i]->read_initial_mean_var();
        }
    }

    input.close();
}

void NeuralNetwork::read_model(
    const char* file_name, SPEECH_NN_W_TYPE t,
    int start_layer, int end_layer, std::string bn_file_prefix) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_model(input, t);
            _layers[i]->read_initial_mean_var(bn_file_prefix);
        }
    }

    input.close();
}

void NeuralNetwork::read_inq_model(
        const char* file_name, SPEECH_NN_W_TYPE t,
        int start_layer, int end_layer) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_inq_model(input, t);
            _layers[i]->read_initial_mean_var();
        }
    }

    input.close();
}

void NeuralNetwork::read_inq_model(
        const char* file_name, SPEECH_NN_W_TYPE t,
        int start_layer, int end_layer, std::string bn_file_prefix) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_inq_model(input, t);
            _layers[i]->read_initial_mean_var(bn_file_prefix);
        }
    }

    input.close();
}

void NeuralNetwork::read_heter_model(const char* file_name, int start_layer, int end_layer) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end = (size_t)(end_layer >= 0 ? end_layer : _layers.size() - 1);

    for (size_t i = (size_t)start_layer; i < end; i++) {
        if (_layers[i]->type() == FULL || _layers[i]->type() == CONV) {
            if (_layers[i]->need_read()) {
                _layers[i]->read_heter_model(input);
            }
        }
    }

    input.close();
}

void NeuralNetwork::read_hfnn_model(
    const char* file_name, SPEECH_NN_W_TYPE t,
    int start_layer, int end_layer) {
    std::ifstream input(file_name, std::ios::binary);

    if (input.fail()) {
        perror(file_name);
        exit(1);
    }

    size_t end   = (size_t)(end_layer >= 0 ? end_layer : _layers.size());
    size_t start = start_layer;

    for (size_t i = start; i < end; i++) {
        if (_layers[i]->need_read()) {
            _layers[i]->read_hfnn_model(input, t);
        }
    }

    input.close();
}

void NeuralNetwork::init_weight(const ModelInitConfig& cfg) {
#ifdef __CLOSE_RANDOM__
    wind_set_seed(1024);
#else
    wind_set_seed(100);
#endif
    //todo: remove
    /* 类型没有设置，走旧的逻辑 */
    if (cfg.weight_init_type() == MODEL_INIT_TYPE_UNKNOWN) {
        DType mean = cfg.init_mean();
        DType stdv = cfg.init_stdv();
        gauss_init_weight(mean, stdv);

        if (cfg.model_name().size()) {
            read_model_no_bn(cfg.model_name().c_str(), WEIGHT,
                             cfg.model_start(), cfg.model_end());
        }

        if (cfg.md_model_name().size()) {
            read_model_no_bn(cfg.md_model_name().c_str(), MD_WEIGHT,
                             cfg.model_start(), cfg.model_end());
        }

        if (cfg.heter_name().size()) {
            read_heter_model(cfg.heter_name().c_str(),
                             cfg.heter_start(), cfg.heter_end());
        }

        if (cfg.hfnn_name().size()) {
            read_hfnn_model(cfg.hfnn_name().c_str(), WEIGHT,
                            cfg.hfnn_start(), cfg.hfnn_end());
        }
    } else {
        NNConfig nn_cfg;
        std::vector<Layer*> layers;

        /* 需要预先读取模型 */
        if (cfg.weight_init_type() == MODEL_INIT) {
            std::vector<std::string> cost_layer_name;
            std::vector<LossLayer*> cost_layer;

            CHECK2(cfg.weight_init_type() == MODEL_INIT);
            nn_cfg.read_config(cfg.model_cfg().c_str());
            std::vector<LayerConfig*>& configs = nn_cfg.layer_cfg_vec();

            for (size_t i = 0; i < configs.size(); i++) {
                Layer* new_ly = create_layer(*configs[i], cost_layer_name, cost_layer);
                layers.push_back(new_ly);
            }
            layer_set(layers, 1);

            /* read model */
            if (cfg.model_name().size()) {
                std::ifstream input(cfg.model_name().c_str(), std::ios::binary);
                CHECK(!input.fail(), "model name error");

                for (size_t i = 0; i < layers.size(); i++) {
                    if (layers[i]->need_read()) {
                        layers[i]->read_model(input, WEIGHT);
                    }
                }

                input.close();
            } else if (cfg.md_model_name().size()) {
                std::ifstream input(cfg.md_model_name().c_str(), std::ios::binary);
                CHECK(!input.fail(), "model name error");

                for (size_t i = 0; i < layers.size(); i++) {
                    if (layers[i]->need_read()) {
                        layers[i]->read_model(input, MD_WEIGHT);
                    }
                }
                input.close();
            }
            else if (cfg.inq_model_name().size()) {
                std::ifstream input(cfg.inq_model_name().c_str(), std::ios::binary);
                CHECK(!input.fail(), "model name error");
                for (size_t i = 0; i < layers.size(); i++) {
                    if (layers[i]->need_read()) {
                        layers[i]->read_inq_model(input, WEIGHT);
                    }
                }
                input.close();
            }
            else if (cfg.hfnn_name().size()) {
                std::ifstream input(cfg.hfnn_name().c_str(), std::ios::binary);
                CHECK(!input.fail(), "model name error");

                for (size_t i = 0; i < layers.size(); i++) {
                    if (layers[i]->need_read()) {
                        layers[i]->read_hfnn_model(input, WEIGHT);
                    }
                }

                input.close();
            } else {
                CHECK(false, "unsupported model type");
            }

            for (size_t i = 0; i < _layers.size(); i++) {
                _layers[i]->init_weight(cfg, layers);
            }
        } else {
            for (size_t i = 0; i < _layers.size(); i++) {
                _layers[i]->init_weight(cfg);
            }
        }

    }
}

void NeuralNetwork::gauss_init_weight(DType mean, DType stdv) {
#ifdef __CLOSE_RANDOM__
    wind_set_seed(1024);
#else
    wind_set_seed(100);
#endif

    for (size_t i = 0; i < _layers.size(); i++) {
        _layers[i]->gauss_init(mean, stdv);
    }
}

void NeuralNetwork::resize_out() {
    for (size_t i = 0; i < _layers.size(); i++) {
        std::vector<IOPackage*> io_vec;

        for (auto j : _layers[i]->input_keys()) {
            IOPackage* io = _out_args.get_pack(j);
            if (io == NULL && _layers[i]->get_feature_share_input()) {
                continue;                            
            }                                        
            CHECK(io != NULL, "layer %s input key %s error",
                  _layers[i]->name().c_str(), j.c_str());
            io_vec.push_back(_out_args.get_pack(j));
        }

        /* put label to vector */
        for (auto j : _layers[i]->get_label_key()) {
            IOPackage* io = _out_args.get_pack(j);
            if (io == NULL && _layers[i]->get_feature_share_input()) {
                continue;                            
            }                                        
            CHECK(io != NULL, "layer %s label key error", _layers[i]->name().c_str());
            io_vec.push_back(io);
        }

        IOPackage desc;
        /* put desc to vector */
        if (_layers[i]->get_feat_desc_key().size() > 0) {
            std::vector<std::string> feat_desc_keys = _layers[i]->get_feat_desc_key();
            CHECK(feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
            int desc_num = _out_args.get_feat_desc()->get_origin_height(feat_desc_keys[0]).size();
            desc.resize(Dim(desc_num, 3), GPU);

            for (auto j = 0; j < desc_num; j++) {
                desc.get_ten()->set_element(Dim(j, 0),
                        _out_args.get_feat_desc()->get_origin_height(feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 1),
                        _out_args.get_feat_desc()->get_origin_width(feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 2),
                        _out_args.get_feat_desc()->get_scale(feat_desc_keys[0])[j]);
            }
            io_vec.push_back(&desc);
        }

        _layers[i]->resize_out(io_vec, _out_args.get_sample_num());
    }
}

void  NeuralNetwork::clear_history(int bat_idx) {
    for (size_t i = 0; i < _layers.size(); i++) {
        _layers[i]->clear_history(bat_idx);
    }
}

void  NeuralNetwork::clear_history() {
    for (size_t i = 0; i < _layers.size(); i++) {
        _layers[i]->clear_history();
    }
}

void  NeuralNetwork::store_history() {
    for (size_t i = 0; i < _layers.size(); i++) {
        _layers[i]->store_history();
    }
}

Loss& NeuralNetwork::cal_cost(std::string& cost_name) {
    for (size_t i = 0; i < _cost_layer_name.size(); i++) {
        if (_cost_layer_name[i] == cost_name) {
            return _cost_layer[i]->get_cost_value();
        }
    }

    CHECK(false, "cal_cost fail");
    return _cost_layer[0]->get_cost_value();
}

void NeuralNetwork::build_out_layer() {
    std::map<std::string, Layer*> layer_name_map;
    std::map<std::string, Layer*> layer_output_key_map;

    for (auto layer : _layers) {
        layer_name_map[layer->name()] = layer;
        layer_output_key_map[layer->output_keys()[0]] = layer;
    }

    /* 网络中有loss层，loss层的上一层是输出层 */
    if (_cost_layer_name.size() != 0) {
        for (auto layer_name : _cost_layer_name) {
            Layer* cost_layer = layer_name_map[layer_name];
            std::vector<std::string>& input_keys = cost_layer->input_keys();


            _out_layer_name.push_back(layer_output_key_map[input_keys[0]]->name());
            _out_layer.push_back(layer_output_key_map[input_keys[0]]);
        }
    }
    /* 网络中无loss层，叶子节点是输出层 */
    else {
        for (auto layer : _layers) {
            std::vector<std::string>& input_keys = layer->input_keys();

            for (auto input_key : input_keys) {
                if (layer_output_key_map.find(input_key) != layer_output_key_map.end()) {
                    layer_name_map.erase(layer_output_key_map[input_key]->name());
                }
            }
        }

        for (auto layer : layer_name_map) {
            _out_layer_name.push_back(layer.first);
            _out_layer.push_back(layer.second);
        }
    }
}

void NeuralNetwork::layer_set(std::vector<Layer*>& layers, int sample_num) {
    INTER_LOG("\n==============================================layer set==============================================");
    for (size_t i = 0; i < layers.size(); i++) {
        std::vector<IOPackage*> io_vec;
        int feature_key_count = 0;
        bool feature_share_input = layers[i]->get_feature_share_input();

        for (auto j : layers[i]->input_keys()) {
            /* input layer */
            if (is_feature_key(j)) {
                if (feature_share_input == false || 
                            (feature_share_input == true && feature_key_count == 0)) {
                    /* 从数据加载获取维度 */
                    Dim dim = _nn_config->data_cfg().get_dim(j);
                    for (int i = 0; i < dim.get_size(); i++) {
                        if (dim[i] == -1) {
                            dim[i] = 4;
                        }
                    }
                    IOPackage* io = new IOPackage(dim, GPU);
                    io_vec.push_back(io);
                    _input_io_vec.push_back(io);
                    feature_key_count++;
                }
            }
            else if (is_label_key(j)) {
                /* 从数据加载获取维度 */
                Dim dim = _nn_config->data_cfg().get_dim(j);
                IOPackage* io = new IOPackage(dim, GPU);
                io_vec.push_back(io);
                _input_io_vec.push_back(io);
            } else {
                Layer* input_layer = get_layer_by_out_key(j);
                CHECK(input_layer != NULL, "input layer is NULL");
                io_vec.push_back(&input_layer->output(j));
            }
        }

        /* put label to vector */
        for (auto j : layers[i]->get_label_key()) {
            /* input layer */
            IOPackage* io = NULL;
            if (is_label_key(j)) {
                // 暂时写成Dim(256, 1)
                io = new IOPackage(Dim(256,1), GPU);
            }
            else {
                io = _out_args.get_pack(j);
                CHECK(io != NULL, "layer %s label key error", layers[i]->name().c_str());
            }
            io_vec.push_back(io);
        }

        IOPackage desc;
        /* put desc to vector */
        if (layers[i]->get_feat_desc_key().size() > 0) {
            std::vector<std::string> feat_desc_keys = layers[i]->get_feat_desc_key();
            CHECK(feat_desc_keys.size() <= 1, "feature desc key size must <= 1");
            int desc_num = _out_args.get_feat_desc()->get_origin_height(feat_desc_keys[0]).size();
            desc.resize(Dim(desc_num, 3), GPU);

            for (auto j = 0; j < desc_num; j++) {
                desc.get_ten()->set_element(Dim(j, 0),
                        _out_args.get_feat_desc()->get_origin_height(feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 1),
                        _out_args.get_feat_desc()->get_origin_width(feat_desc_keys[0])[j]);
                desc.get_ten()->set_element(Dim(j, 2),
                        _out_args.get_feat_desc()->get_scale(feat_desc_keys[0])[j]);
            }
            io_vec.push_back(&desc);
        }

        layers[i]->layer_set(io_vec, sample_num);
    }
    INTER_LOG("\n======================================end of layer set==============================================");
}

bool NeuralNetwork::is_feature_key(std::string key) {
    for (auto i : _feature_key) {
        if (i == key) {
            return true;
        }
    }

    return false;
}

bool NeuralNetwork::is_label_key(std::string key) {
    for (auto i : _label_key) {
        if (i == key) {
            return true;
        }
    }

    return false;
}

/* 通过layer output key查找layer config */
Layer* NeuralNetwork::get_layer_by_out_key(std::string& key) {
    for (size_t i = 0; i < _layers.size(); i++) {
        for (auto j = 0; j < _layers[i]->output_num(); j++) {
            if (_layers[i]->output_key(j) == key) {
                return _layers[i];
            }
        }
    }

    return NULL;
}

/* 通过layer input key查找layer config */
Layer* NeuralNetwork::get_layer_by_input_key(std::string& key) {
    for (auto it : _layers) {
        for (auto input_key : it->input_keys()) {
            if (input_key == key) {
                return it;
            }
        }
        for (auto tmp_label_key : it->get_label_key()) {
            if (tmp_label_key == key) {
                return it;
            }
        }
    }

    return NULL;
}

Layer* NeuralNetwork::get_layer_by_name(std::string& name) {
    for (size_t i = 0; i < _layers.size(); i++) {
        if (_layers[i]->name() == name) {
            return _layers[i];
        }
    }

    return NULL;
}
void NeuralNetwork::gen_his_clear_vec() {
    const std::vector<LossConfig*>& loss_cfg = _nn_config->loss_layer_cfg();

    for (size_t i = 0; i < loss_cfg.size(); i++) {
        if (loss_cfg[i]->loss_type() == LOSS_TYPE_CTC) {
            _batch_clear_prob = loss_cfg[i]->get_batch_clear_prob();
            _batch_clear_num = loss_cfg[i]->get_batch_clear_num();
            _odd_his_vec.resize(_lstm_skip_num * _batch_size, 0);
            _even_his_vec.resize(_lstm_skip_num * _batch_size, 0);

            for (int jj = 0; jj < _lstm_skip_num; jj++) {
                for (int ii = 0; ii < _batch_size; ii++) {
                    if (jj % 2 == 1) {
                        _odd_his_vec[jj * _batch_size + ii] = 1;
                        continue;
                    }

                    _even_his_vec[jj * _batch_size + ii] = 1;
                }
            }

            break;
        }
        else {
            _odd_his_vec.resize(_lstm_skip_num * _batch_size * 32, 1);
            _even_his_vec.resize(_lstm_skip_num * _batch_size * 32, 1);
        }
    }
}

}
}
