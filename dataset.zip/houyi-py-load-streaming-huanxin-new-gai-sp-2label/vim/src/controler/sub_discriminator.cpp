/**
 * sub_discrimininator.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-16
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "wind/wind.h"
#include "multi_trainer.h"
#include "sub_neural_network.h"
#include "stat_indicator.h"
#include "sub_discriminator.h"

namespace houyi {
namespace train {
SubDiscriminator::SubDiscriminator(int id, const MultiDiscriminator* parent_in,
                                   MessageQueue<DecodeData*>* decode_queue) : Trainer() {
    _id = id;
    _parent = const_cast<MultiDiscriminator*>(parent_in);
    _data_reader = _parent->data_reader();
    _nn_cfg = _parent->nn_config();
    DiscNNConfig* nn_cfg = dynamic_cast<DiscNNConfig*>(_parent->nn_config());

    _data_proccer = NULL;
    _data_repos = NULL;
    _work_thread = NULL;
    _exit_flag = false;
    _epoch_finish = false;
    _score_finish = false;
    _decode_data_queue = decode_queue;

    int device_num = nn_cfg->device_ids().size();
    _device_id = nn_cfg->device_ids()[_id % device_num];
    pthread_mutex_init(&_load_mutex, NULL);
    pthread_mutex_init(&_start_score_mutex, NULL);
    pthread_mutex_init(&_w_update_mutex, NULL);

    int old_id = 0;
    wind_get_gpu_device(&old_id);
    wind_set_gpu_device(_device_id);

    // _nn
    int async_period = nn_cfg->disc_period_cfg().local_sync_period();
    TrainType train_type = _nn_cfg->period_cfg().train_type();

    CHECK2(async_period >= 1);
    int msg_queue_id = train_type == ASYNC_TRAIN ? id : 0;
    _nn = new SubNeuralNetwork(_parent->ref_nn(),
                               _parent->multi_nn()->dw_mesg_queue(msg_queue_id),
                               async_period, train_type);
    INTER_LOG("id:= %d, msg_queue_id:= %d", id, msg_queue_id);
    _reset_mark = (int*)malloc(sizeof(int) * nn_cfg->batch_size());
    memset(_reset_mark, 0, sizeof(int) * nn_cfg->batch_size());

    wind_set_gpu_device(old_id);
}

SubDiscriminator::~SubDiscriminator() {
    pthread_mutex_destroy(&_load_mutex);

    if (_nn != NULL) {
        delete _nn;
        _nn = NULL;
    }

    _parent = NULL;
    _data_reader = NULL;

    if (_data_proccer) {
        delete _data_proccer;
        _data_proccer = NULL;
    }

    if (_data_repos) {
        delete _data_repos;
        _data_repos = NULL;
    }

    free(_reset_mark);
    _reset_mark = NULL;
}

void SubDiscriminator::reset() {
    if (_data_proccer) {
        _data_proccer->reset();
    }

    if (_data_repos) {
        _data_repos->reset();
    }
}

void SubDiscriminator::start() {
    if (_work_thread) {
        if (_work_thread->is_alive()) {
            return;
        }
    }

    if (_work_thread == NULL) {
        _work_thread = new Thread();
    }

    _work_thread->start(SubDiscriminator::run_thread, (void*) this);
}

void* SubDiscriminator::run_thread(void* data) {
    ThreadContext* ctx = static_cast<ThreadContext*>(data);
    SubDiscriminator* tt = static_cast<SubDiscriminator*>(ctx->get_param());
    bool* global_alive_mark = ctx->get_alive();
    *global_alive_mark = true;
    sem_post(&ctx->_create_finish_sem);

    wind_init(tt->_device_id);
    wind_set_gpu_device(tt->_device_id);
    tt->run();
    *global_alive_mark = false;
    return NULL;
}

void SubDiscriminator::run() {
    SubNeuralNetwork* sub_nn = dynamic_cast<SubNeuralNetwork*>(_nn);

    while (true) {
        pthread_mutex_lock(&_load_mutex);

        if (_parent == NULL) {
            return;
        }

        do {
            pthread_mutex_lock(&_start_score_mutex);
            std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = load_data();
            BaseBatchSample* bat = bat_pair.first;
            DeviceBatchSample* device_bat = bat_pair.second;

            if (bat == NULL) {
                _epoch_finish = true;
                _decode_data_queue->push(NULL);
                break;
            }

            copy_batch(_bat_data, *bat, *device_bat);
            delete bat;
            bat = NULL;
            sub_nn->set_train_data(_bat_data);
            sub_nn->resize_out();

            // forward
            pthread_mutex_lock(&_w_update_mutex);
            sub_nn->forward(); //cout<<"device_id: "<< device_id() <<" forward"<<endl;
            pthread_mutex_unlock(&_w_update_mutex);

            _score_finish = true;

            //push score to decoder
            Tensor<DType>& score = *sub_nn->get_output(sub_nn->get_out_layer_name()[0]);
            DecodeData* data = new DecodeData();
            data->_score.set_device(CPU);
            data->_score.resize(score.get_size());
            data->_score.copy_from(score);
            data->_feat.resize(_feat_pack[0]->get_size(), _feat_pack[0]->get_device());
            data->_feat.copy_from(*_feat_pack[0]);
            data->_label.resize(_label_pack[0]->get_size(), _label_pack[0]->get_device());
            data->_label.copy_from(*_label_pack[0]);
            _decode_data_queue->push(data);

            sub_nn->clear_train_data(_bat_data);
        } while (true);
    }
}

}
}
