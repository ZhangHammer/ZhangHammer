#include <sys/stat.h>
#include <sys/types.h>
#include <string>
#include "util.h"
#include "speech_predictor.h"
#include "object_factory.h"

namespace houyi {
namespace train {

void SpeechPredictor::run() {
    int model_count = 0;

    if (_nn_cfg->disc_cfg().prior_name().size() != 0) {
        _nn->read_prior(_nn_cfg->disc_cfg().prior_name().c_str());
    }

    while (_thread_exit == false) {
        Argument in_feat_args;

        /* 从模型队列中获取模型 */
        std::string* model = _model_file_queue->pop();

        /* 遇到结束符，线程结束 */
        if (model == NULL) {
            _thread_exit = true;
            break;
        }
        /* 重新启动predictor，包括数据加载线程 */
        else {
            this->reset();
        }

        /* 调用脚本做预处理, 生成bn */
        if ("" != _call_before_predict
                && _pre_model_set.end() == _pre_model_set.find(*model)) {
            size_t pos = (*model).find_last_of("/\\");
            pos = (pos == std::string::npos) ? 0 : pos + 1;
            std::string model_name = (*model).substr(pos);
            std::string _bn_path_prefix = "tmp_bn/" + model_name + "/";
            int ret = system(("sh " + _call_before_predict + " " +
                              *model + " " + _bn_path_prefix).c_str());
            CHECK(0 == ret, "_call_before_predict failed");
            if (_nn_cfg->inq()) {
                _nn->read_inq_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end(),
                            _bn_path_prefix);
            }
            else {
                _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end(),
                            _bn_path_prefix);
            }
        } else {
            if (_nn_cfg->inq()) {
                _nn->read_inq_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end());
            }
            else {
                _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end());
            }
        }

        size_t position = model->rfind('/', model->size() - 2);
        position = (position != std::string::npos) ? position + 1 : 0;
        std::string model_real_name(*model, position);

        int batch_count = 0;

        // 初始化 10 M 空间作为 workspace
        _worksapce = new Tensor<unsigned char>(Dim(10 * 1024 * 1024), gpu_device());
        _nn->set_workspace(_worksapce);

        do {
            std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = load_data();
            BaseBatchSample* bat = bat_pair.first;
            DeviceBatchSample* device_bat = bat_pair.second;

            if (bat == NULL) {
                break;
            }

            copy_batch(in_feat_args, *bat, *device_bat);
            _nn->set_train_data(in_feat_args);
            _nn->resize_out();

            // forward
            _nn->forward();
            for (size_t i = 0; i < _stat_indicator.size(); i++) {
                _stat_indicator[i]->increase_sentframe_num(bat);
                _stat_indicator[i]->sample_num_norm(_nn_cfg->get_sample_statis_norm());
            }

            // get the value of indicators
            std::vector<std::string>& cost_layer_name = _nn->get_cost_layer_name();
            std::vector<std::string>& out_layer_name = _nn->get_out_layer_name();

            for (size_t i = 0; i < cost_layer_name.size(); i++) {
                _stat_indicator[i]->cal_loss(_nn->cal_cost(
                                                 cost_layer_name[i]
                                             ));
            }

            for (size_t i = 0; i < out_layer_name.size(); i++) {
                Tensor<DType>& score = *_nn->get_output(out_layer_name[i]);
                Tensor<int>& mask = *_nn->get_output_mask(out_layer_name[i]);

                if (_nn->get_prior() != NULL) {
                    score.log_sub_prior(*_nn->get_prior());
                }

                if (_score_store_dir.size() != 0) {
                    store_score(score, mask, _score_store_dir, model_real_name,
                                batch_count, bat);
                }

                if (_score_store_kaldi_dir.size() != 0) {
                    store_kaldi_score(score, mask, _score_store_kaldi_dir, model_real_name,
                                batch_count, bat);
                }

                if (_classify_store_dir.size() != 0) {
                    store_classify(score, mask, 
                            _classify_store_dir, 
                            model_real_name, 
                            batch_count,
                            bat); 
                }
            }

            batch_count++;
            if (bat) {
                ObjectFactory<BaseBatchSample>::instance()->delete_object(bat);
            }
            if (device_bat) {
                _data_repos->recycle_device_batch_sample(device_bat);
            }
            bat = NULL;
            device_bat = NULL;
            INTER_LOG("batch_count %d", batch_count);
            _nn->clear_train_data(in_feat_args);
            // show_current_log();
        } while (true);

        show_model_loss(model_real_name);

        if (_loss_file.size() != 0) {
            store_model_loss(_loss_file, model_real_name);
        }

        /* 调用脚本做后处理, 统计 WER */
        if ("" != _call_after_predict) {
            int ret = system(("sh " + _call_after_predict + " " + *model).c_str());
            CHECK(0 == ret, "_call_after_predict failed");
        }

        delete model;
        model_count++;

    }
}

}   // namespace train
}   // namespace houyi
