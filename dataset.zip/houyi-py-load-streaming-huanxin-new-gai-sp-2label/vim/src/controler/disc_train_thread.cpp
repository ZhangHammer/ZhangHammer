/**
 * disc_train_thread.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-16
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "disc_train_thread.h"
#include "multi_trainer.h"

namespace houyi {
namespace train {
DiscTrainThread::DiscTrainThread(
    DiscNNConfig* cfg, MultiNeuralNetwork* muti_nn,
    SubDiscriminator* sub_disc[], MultiDiscriminator* disc) {
    _nn_cfg = cfg;
    _local_disc = disc;
    _local_multi_nn = muti_nn;
    _sub_disc  = sub_disc;
    _exit_flag = NULL;
    _is_wait = false;
    _thread_exit = false;

    _device_id = cfg->device_id(0);

    _model_file = cfg->model_init_cfg().model_name();
    _call_before_predict = cfg->call_before_predict();
    _call_after_predict = cfg->call_after_predict();

    srand(time(NULL));
    int tmp_id = rand();
    _bn_path_prefix = "tmp_bn/" + std::to_string(tmp_id) + "/";
}

void* DiscTrainThread::run_thread(void* self) {
    DiscTrainThread* tt = static_cast<DiscTrainThread*>(self);
    wind_init(tt->device_id());
    wind_set_gpu_device(tt->device_id());
    tt->run();
    return NULL;
}

void DiscTrainThread::run() {
    int cur_epoch = 0;
    int cur_epoch_finish_trainer = 0;

    while (cur_epoch < _nn_cfg->disc_period_cfg().epoch()) {
        cur_epoch_finish_trainer = 0;

        // unlock all the trainThreads
        for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
            pthread_mutex_unlock(&_sub_disc[i]->_load_mutex);
        }

        for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
            pthread_mutex_unlock(&_sub_disc[i]->_start_score_mutex);
        }

        while (true) {
            if (_local_disc->get_model_predict_queue()->size() > 0) {
                /* 从模型队列中获取模型 */
                std::string* model = _local_disc->get_model_predict_queue()->pop();

                /* 遇到结束符，线程结束 */
                if (model == NULL) {
                    break;
                }

                /* 调用脚本做预处理, 生成bn */
                if ("" != _call_before_predict && _model_file != *model) {
                    int ret = system(("sh " + _call_before_predict + " " + *model +
                                      " " + _bn_path_prefix).c_str());
                    CHECK(0 == ret, "_call_before_predict failed");

                    for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
                        pthread_mutex_lock(&_sub_disc[i]->_w_update_mutex);
                        int old_device = 0;
                        wind_get_gpu_device(&old_device);
                        wind_set_gpu_device(_sub_disc[i]->device_id());
                        _sub_disc[i]->nn()->read_model(model->c_str(), WEIGHT,
                                                       _nn_cfg->model_init_cfg().model_start(),
                                                       _nn_cfg->model_init_cfg().model_end(),
                                                       _bn_path_prefix);
                        wind_set_gpu_device(old_device);
                        pthread_mutex_unlock(&_sub_disc[i]->_w_update_mutex);
                    }
                } else {
                    for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
                        pthread_mutex_lock(&_sub_disc[i]->_w_update_mutex);
                        int old_device = 0;
                        wind_get_gpu_device(&old_device);
                        wind_set_gpu_device(_sub_disc[i]->device_id());
                        _sub_disc[i]->nn()->read_model(model->c_str(), WEIGHT,
                                                       _nn_cfg->model_init_cfg().model_start(),
                                                       _nn_cfg->model_init_cfg().model_end());
                        wind_set_gpu_device(old_device);
                        pthread_mutex_unlock(&_sub_disc[i]->_w_update_mutex);
                    }
                }

                delete model;
            }

            for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
                if (_sub_disc[i]->_score_finish == true) {
                    _sub_disc[i]->_score_finish = false;
                    pthread_mutex_unlock(&_sub_disc[i]->_start_score_mutex);
                }

                if (_sub_disc[i]->_epoch_finish == true) {
                    cur_epoch_finish_trainer++;
                    _sub_disc[i]->_epoch_finish = false;

                    if (cur_epoch_finish_trainer >= _nn_cfg->disc_score_thread_num()) {
                        break;
                    }
                }
            }

            if (cur_epoch_finish_trainer >= _nn_cfg->disc_score_thread_num()) {
                break;
            }

        }

        cur_epoch++;

        // reset for next epoch
        if (cur_epoch < _nn_cfg->disc_period_cfg().epoch()) {
            _local_disc->reset();

            for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
                _sub_disc[i]->reset();
            }
        }
    }

    // Notice the subNeuralNetworks to exit
    for (int i = 0; i < _nn_cfg->disc_score_thread_num(); i++) {
        _sub_disc[i]->parent(NULL);
        pthread_mutex_unlock(&_sub_disc[i]->_load_mutex);
    }

    _thread_exit = true;
    pthread_exit(0);
}

}
}
