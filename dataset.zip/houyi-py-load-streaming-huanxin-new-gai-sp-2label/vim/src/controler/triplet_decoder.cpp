/**
 * triplet_decoder.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "multi_discriminator.h"
#include "triplet_decoder.h"
#include "util.h"
#include <utility>

namespace houyi {
namespace train {

TripletDecoder::TripletDecoder(DecoderConfig& cfg) : Decoder(cfg) {
    init();
    set_device();
    _alpha = cfg.get_alpha();
    _triplet_select_type = cfg.get_triplet_select_type();
}

void TripletDecoder::run() {
    DecodeData* data = _decode_data_queue->pop();

    Tensor<DType>* feat = data->_feat.get_ten();
    Tensor<DType>* label = data->_label.get_ten();
    Tensor<DType>* score = &data->_score;
    size_t batch_size = score->get_h();
    size_t score_dim = score->get_w();
    size_t align_score_num = ALIGNED(_decoder_period, batch_size);
    CHECK(batch_size % 2 == 0, "param error");
    CHECK(batch_size == feat->get_size(0), "param error");
    CHECK(batch_size == label->get_size(0), "param error");

    _score.resize(Dim(align_score_num, score_dim));
    _trans_score.resize(Dim(score_dim, align_score_num));
    _an_loss.resize(Dim(align_score_num, align_score_num));
    _feat.resize(Dim(align_score_num, feat->get_size(1), feat->get_size(2), feat->get_size(3)));
    _label.resize(Dim(align_score_num, label->get_size(1)));

    //copy score feature label
    size_t cur_score_num = 0;
    _score.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*score);
    Dim feat_start_dim(cur_score_num, 0, 0, 0);
    Dim feat_end_dim(cur_score_num + batch_size, feat->get_size(1), feat->get_size(2),
                     feat->get_size(3));
    _feat.get_block(feat_start_dim, feat_end_dim).copy_from(*feat);
    _label.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*label);

    cur_score_num += batch_size;
    delete data;
    data = NULL;

    size_t cur_epoch = 0;
    size_t cur_stop_thread_num = 0;

    while (cur_epoch < _epoch) {
        //收集各个卡传输的数据
        while (cur_score_num < align_score_num) {
            data = _decode_data_queue->pop();

            if (data == NULL) {
                cur_stop_thread_num++;

                if (cur_stop_thread_num >= _score_thread_num) {
                    break;
                }

                continue;
            }

            feat = data->_feat.get_ten();
            label = data->_label.get_ten();
            score = &data->_score;

            //copy score feature label
            _score.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*score);
            Dim feat_start_dim(cur_score_num, 0, 0, 0);
            Dim feat_end_dim(cur_score_num + batch_size, feat->get_size(1), feat->get_size(2),
                             feat->get_size(3));
            _feat.get_block(feat_start_dim, feat_end_dim).copy_from(*feat);
            _label.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*label);
            cur_score_num += batch_size;

            delete data;
        }

        //构造新的训练数据
        if (cur_score_num != 0) {
            //找到的n的数量
            size_t n_idx_num = 0;
            Tensor<int> n_idx_vec(Dim(cur_score_num), CPU);
            select_n_idx(_triplet_select_type, cur_score_num, _score, _label, n_idx_vec, n_idx_num);

            _new_feat.resize(Dim(n_idx_num * 3, _feat.get_size(1), _feat.get_size(2),
                                 _feat.get_size(3)));
            _new_label.resize(Dim(n_idx_num * 3, _label.get_size(1)));

            //拼接数据
            size_t j = 0;

            for (size_t i = 0; i < cur_score_num / 2; i++) {
                int select_idx = n_idx_vec.get_element(Dim(i * 2));

                //没有找到符合条件的n
                if (select_idx < 0) {
                    continue;
                }

                Dim ap_feat_start_dim(i * 2, 0, 0, 0);
                Dim ap_feat_end_dim(i * 2 + 2, _feat.get_size(1),
                                    _feat.get_size(2), _feat.get_size(3));
                Dim ap_new_feat_start_dim(j * 3, 0, 0, 0);
                Dim ap_new_feat_end_dim(j * 3 + 2, _feat.get_size(1),
                                        _feat.get_size(2), _feat.get_size(3));
                _new_feat.get_block(ap_new_feat_start_dim,
                                    ap_new_feat_end_dim).copy_from(
                                        _feat.get_block(ap_feat_start_dim,
                                                        ap_feat_end_dim));
                _new_label.range_row(j * 3, j * 3 + 2).copy_from(
                    _label.range_row(i * 2, i * 2 + 2));

                Dim n_feat_start_dim(select_idx, 0, 0, 0);
                Dim n_feat_end_dim(select_idx + 1, _feat.get_size(1),
                                   _feat.get_size(2), _feat.get_size(3));
                Dim n_new_feat_start_dim(j * 3 + 2, 0, 0, 0);
                Dim n_new_feat_end_dim(j * 3 + 3, _feat.get_size(1),
                                       _feat.get_size(2), _feat.get_size(3));
                _new_feat.get_block(n_new_feat_start_dim, n_new_feat_end_dim)
                .copy_from(_feat.get_block(n_feat_start_dim,
                                           n_feat_end_dim));
                _new_label.range_row(j * 3 + 2, j * 3 + 3).copy_from(
                    _label.range_row(select_idx, select_idx + 1));
                j++;
            }

            for (size_t i = 0; i < _new_label.get_h(); i += 3) {
                CHECK(_new_label.get_element(Dim(i, 0)) == _new_label.get_element(Dim(i + 1, 0)),
                      "label error, a p label is not same");
                CHECK(_new_label.get_element(Dim(i, 0)) != _new_label.get_element(Dim(i + 2, 0)),
                      "label error, a n label is same");
            }

            _data_reader->push_batch_to_reader(&_new_feat, &_new_label);
        }

        if (cur_stop_thread_num >= _score_thread_num) {
            _data_reader->push_batch_to_reader(NULL, NULL);
            cur_stop_thread_num = 0;
            cur_epoch++;

            if (cur_epoch >= _epoch) {
                break;
            }
        }

        cur_score_num = 0;
    }

    //reset();
}

void TripletDecoder::select_n_idx(TripletSelectType select_type, size_t sample_num,
                                  Tensor<DType>& score,
                                  Tensor<DType>& label, Tensor<int>& select_idx, size_t& n_idx_num) {
    CHECK(sample_num % 2 == 0, "sample number error");

    //计算loss
    _trans_score.transpose(score);
    _an_loss.mul(_score, _trans_score);

    switch (select_type) {
    case RANDOM_HARD_TRIP_SEL_TYPE:
        select_random_hard(sample_num, _an_loss, label, select_idx, n_idx_num);
        break;

    case SEMI_HARD_TRIP_SEL_TYPE:
        select_semi_hard(sample_num, _an_loss, label, select_idx, n_idx_num);
        break;

    case MOST_HARD_TRIP_SEL_TYPE:
        n_idx_num = sample_num / 2;
        row_max_diff_label(sample_num, _an_loss, label, select_idx);
        break;

    default:
        CHECK(false, "error tripet select type");
    }
}

void TripletDecoder::select_semi_hard(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                                      Tensor<int>& select_idx, size_t& n_idx_num) {
    CHECK(sample_num % 2 == 0, "sample number error");
    CHECK(loss.get_w() == loss.get_h(), "loss dim error");
    std::vector<int> effective_sample;

#ifdef __CLOSE_RANDOM__
    srand(256);
#else
    time_t seed = time(NULL);
    srand(seed);
#endif

    /* 从norm2(a - p) - norme2(a - n) < 0的样本中随机选一个 */
    /* 通过变换过后即从矩阵乘法的结果中挑选an < ap的样本 */
    n_idx_num = 0;

    for (size_t i = 0; i < sample_num; i += 2) {
        DType* data_p = loss.get_data();
        DType ap = data_p[i * sample_num + 1];
        DType* label_p = label.get_data();

        for (size_t j = 0; j < sample_num; j++) {
            DType data = data_p[i * sample_num + j];

            if (data < ap && label_p[j] != label_p[i]) {
                effective_sample.push_back(j);
            }
        }

        int idx = -1;
        size_t effective_sample_num = effective_sample.size();

        if (effective_sample_num > 0) {
            size_t rand_idx = rand() % effective_sample_num;
            idx = effective_sample[rand_idx];
            n_idx_num++;
        } else {
            idx = -1;
            //INTER_LOG("not find right sample");
        }

        //INTER_LOG("indx i: %ld, idx: %d dim: %ld", i, idx, select_idx.get_size(0));
        select_idx.set_element(Dim(i), idx);

        effective_sample.clear();
    }
}

void TripletDecoder::select_random_hard(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                                        Tensor<int>& select_idx, size_t& n_idx_num) {
    CHECK(sample_num % 2 == 0, "sample number error");
    CHECK(loss.get_h() == loss.get_w(), "loss dim error");
    std::vector<int> effective_sample;

#ifdef __CLOSE_RANDOM__
    srand(256);
#else
    time_t seed = time(NULL);
    srand(seed);
#endif
    /* 从norm2(a - p) - norme2(a - n) + appha > 0的样本中随机选一个 */
    /* 通过变换过后即从矩阵乘法的结果中挑选an > ap - alpha / 2的样本 */
    DType half_alpha = _alpha / 2.0f;
    n_idx_num = 0;

    for (size_t i = 0; i < sample_num; i += 2) {
        DType* data_p = loss.get_data();
        DType ap = data_p[i * sample_num * 1] - half_alpha;
        DType* label_p = label.get_data();

        for (size_t j = 0; j < sample_num; j++) {
            DType data = data_p[i * sample_num + j];

            if (data > ap && label_p[j] != label_p[i]) {
                effective_sample.push_back(j);
            }
        }

        int idx = -1;
        size_t effective_sample_num = effective_sample.size();

        if (effective_sample_num > 0) {
            size_t rand_idx = rand() % effective_sample_num;
            idx = effective_sample[rand_idx];
            n_idx_num++;
        } else {
            idx = -1;
            INTER_LOG("not find right sample");
        }

        select_idx.set_element(Dim(i), idx);

        effective_sample.clear();
    }

}

void TripletDecoder::row_max_diff_label(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                                        Tensor<int>& max_id) {
    CHECK(sample_num % 2 == 0, "sample number error");
    CHECK(loss.get_h() == loss.get_w(), "loss dim error");

    for (size_t i = 0; i < sample_num; i += 2) {
        DType max = -std::numeric_limits<DType>::infinity();
        size_t max_idx = 0;
        DType* data_p = loss.get_data();
        DType* label_p = label.get_data();

        for (size_t j = 0; j < sample_num; j++) {
            DType data = data_p[i * sample_num + j];

            if (data > max && label_p[j] != label_p[i]) {
                max = data;
                max_idx = j;
            }
        }

        max_id.set_element(Dim(i), max_idx);
    }
}

}
}
