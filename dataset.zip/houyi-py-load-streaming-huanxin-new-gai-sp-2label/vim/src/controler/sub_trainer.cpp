#include "multi_trainer.h"
#include "sub_neural_network.h"
#include "stat_indicator.h"
#include "object_factory.h"

namespace houyi {
namespace train {
SubTrainer::SubTrainer(int id, const MultiTrainer* parent_in,
                       SyncCls* sync_cls) : Trainer() {
    _id = id;
    _parent = const_cast<MultiTrainer*>(parent_in);
    _data_reader = _parent->data_reader();
    _nn_cfg = _parent->nn_config();

    _batch_size = _nn_cfg->data_cfg().get_batch_size();
    _base_batch_size = _batch_size;
    _cur_step = 0;
    _worksapce = NULL;

    _queue_id = -1;
    _data_proccer = NULL;
    _data_repos = NULL;
    _work_thread = NULL;

    int device_num = _nn_cfg->device_ids().size();
    _device_id = _nn_cfg->device_ids()[_id % device_num];
    pthread_mutex_init(&_load_mutex, NULL);

    int old_id = 0;
    wind_get_gpu_device(&old_id);
    wind_set_gpu_device(_device_id);

    int async_period = _nn_cfg->period_cfg().local_sync_period();
    TrainType train_type = _nn_cfg->period_cfg().train_type();

    CHECK2(async_period >= 1);
    int msg_queue_id =  train_type == ASYNC_TRAIN ? id : 0;
    _nn = new SubNeuralNetwork(_parent->ref_nn(),
                               _parent->multi_nn()->dw_mesg_queue(msg_queue_id),
                               async_period, train_type);

    ///* Statistical indicators */
    if (_stat_indicator.size() != 0) {
        for (size_t i = 0; i < _stat_indicator.size(); i++) {
            delete _stat_indicator[i];
        }

        _stat_indicator.clear();
    }

    for (size_t i = 0; i < _nn->get_cost_layer().size(); i++) {
        StatIndicator* stat_indicator =
                    creat_indicator(_nn_cfg->period_cfg(),
                    _nn->get_cost_layer()[i]->loss_type(),
                    _nn->get_cost_layer()[i]->name());
        stat_indicator->set_tb_writer(_parent->get_tb_writer());
        _stat_indicator.push_back(stat_indicator);
    }

    _cost_layer_name = _nn->get_cost_layer_name();
    _out_layer_name = _nn->get_out_layer_name();

    _reset_mark = (int*)malloc(sizeof(int) * _nn_cfg->batch_size());
    memset(_reset_mark, 0, sizeof(int) * _nn_cfg->batch_size());

    wind_set_gpu_device(old_id);
}

SubTrainer::~SubTrainer() {
    pthread_mutex_destroy(&_load_mutex);

    if (_nn != NULL) {
        delete _nn;
        _nn = NULL;
    }

    _parent = NULL;
    _data_reader = NULL;

    if (_data_proccer) {
        //delete _data_proccer;
        //_data_proccer = NULL;
        _data_proccer->clear();
    }

    if (_data_repos) {
        delete _data_repos;
        _data_repos = NULL;
    }

    if (_worksapce) {
        delete _worksapce;
        _worksapce = NULL;
    }

    free(_reset_mark);
    _reset_mark = NULL;
    _sync_cls = NULL;
}

void SubTrainer::reset() {
    if (_data_proccer) {
        _data_proccer->reset();
    }

    if (_data_repos) {
        _data_repos->reset();
    }

    for (size_t i = 0; i < _stat_indicator.size(); i++) {
        if (_stat_indicator[i]) {
            _stat_indicator[i]->reset();
        }
    }
}

void SubTrainer::start() {
    if (_work_thread) {
        if (_work_thread->is_alive()) {
            return;
        }
    }

    if (_work_thread == NULL) {
        _work_thread = new Thread();
    }

    _work_thread->start(SubTrainer::run_thread, (void*) this);
}

void* SubTrainer::run_thread(void* data) {
    ThreadContext* ctx = static_cast<ThreadContext*>(data);
    SubTrainer* tt = static_cast<SubTrainer*>(ctx->get_param());
    bool* global_alive_mark = ctx->get_alive();
    *global_alive_mark = true;
    sem_post(&ctx->_create_finish_sem);

    wind_init(tt->_device_id);
    wind_set_gpu_device(tt->_device_id);

    tt->run();
    *global_alive_mark = false;
    return NULL;
}

void SubTrainer::run() {
    set_train_rank(_id);

#ifdef __TRAIN_OUTPUT_RESULT__
    int device = 0;
    wind_get_gpu_device(&device);
#endif
    SubNeuralNetwork* sub_nn = dynamic_cast<SubNeuralNetwork*>(_nn);

#ifdef __ENABLE_NCCL__
    auto it = std::find(_nn_cfg->device_ids().begin(), 
            _nn_cfg->device_ids().end(), _device_id);
    CHECK2(it != _nn_cfg->device_ids().end());
    int cur_idx = it - _nn_cfg->device_ids().begin();

    INTER_LOG("Device %d init nccl", cur_idx);
    _intra_node_comm = std::shared_ptr<Nccl>(new Nccl(NcclSingleton::inst(), 
        _nn_cfg->thread_num(),  cur_idx));
    sub_nn->set_intra_node_comm(_intra_node_comm);
#endif

    // 初始化 10 M 空间作为 workspace
    _worksapce = new Tensor<unsigned char>(Dim(10 * 1024 * 1024), gpu_device());
    sub_nn->set_workspace(_worksapce);

    while (true) {
        // Block before we load data
        pthread_mutex_lock(&_load_mutex);
        BaseBatchSample* bat = NULL;
        DeviceBatchSample* device_bat = NULL;

        if (_parent == NULL) {
            return;
        }
        do {
            if (_nn_cfg->is_load_by_python()) {
                //判断echo是否结束
                if (sub_nn->is_echo_finish()) {
                    break;
                }

                //set feature pack and label pack
                std::vector<std::string>vec_feature;
                std::vector<std::string>vec_label;
                vec_feature.push_back(_nn_cfg->get_python_input_feature_key());
                vec_label.push_back(_nn_cfg->get_python_input_label_key());
                int batch_size = _nn_cfg->get_python_input_batch_size();
                sub_nn->get_out_args().set_feat_key(vec_feature);
                sub_nn->get_out_args().set_label_key(vec_label);
                sub_nn->get_out_args().set_sample_num(batch_size);
                sub_nn->resize_out();
            } else {
                std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = load_data();
                bat = bat_pair.first;
                device_bat = bat_pair.second;

                if (bat == NULL || device_bat == NULL) {
                    break;
                }
                copy_batch(_bat_data, *bat, *device_bat);
                sub_nn->set_train_data(_bat_data);
                sub_nn->resize_out();
            }

#ifdef __TRAIN_OUTPUT_RESULT__
            g_thread_batch_cnt[device]++;
#endif

            // forward
#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("%d device forward", _device_id);
#endif
            sub_nn->forward();
            if (_nn_cfg->is_load_by_python()) {
                // TODO 只支持图像训练
                int batch_size = _nn_cfg->get_python_input_batch_size();
                for (size_t i = 0; i < _stat_indicator.size(); i++) {
                    _stat_indicator[i]->increase_sample_num(batch_size);
                }
            }
            else{
                for (size_t i = 0; i < _stat_indicator.size(); i++) {
                    _stat_indicator[i]->increase_sentframe_num(bat);
                    _stat_indicator[i]->sample_num_norm(_nn_cfg->get_sample_statis_norm());
                }
            }

            // backward
#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("%d device backward", _device_id);
#endif
            sub_nn->gen_bp_flag();
            sub_nn->backward();

            // get the value of indicators
            std::vector<std::string> cost_layer_name = sub_nn->get_cost_layer_name();

            for (size_t i = 0; i < _stat_indicator.size(); i++) {
                Layer *layer = sub_nn->get_layer_by_name(_stat_indicator[i]->get_layer_name());
                std::string &label_key = layer->get_label_key()[0];
                for (size_t j = 0; j < sub_nn->get_out_args().label_key().size(); ++j) {
                    if (label_key == sub_nn->get_out_args().label_key()[j] 
                            || sub_nn->get_layer_by_out_key(label_key)) {
                        _stat_indicator[i]->cal_loss(sub_nn->cal_cost(cost_layer_name[i]));
                        break;
                    }
                }
            }

#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("%d device send loss ready message", _device_id);
#endif
            sub_nn->loss_ready_message();

            // update
#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("%d device update", _device_id);
#endif

            sub_nn->update();

            for (size_t i = 0; i < _stat_indicator.size(); i++) {
                _stat_indicator[i]->increase_iter(sub_nn->done_iter_num());
            }

            if (!_nn_cfg->is_load_by_python()) {
                if (bat) {
                    ObjectFactory<BaseBatchSample>::instance()->delete_object(bat);
                }
                if (device_bat) {
                    _data_repos->recycle_device_batch_sample(device_bat);
                }
                bat = NULL;
                device_bat = NULL;
                sub_nn->clear_train_data(_bat_data);
            }

        } while (true);

        INTER_LOG("%d device send done message", _device_id);
        sub_nn->done_message();
    }
}

void SubTrainer::adjust_lr(size_t iter_cnt) {
    SubNeuralNetwork* sub_nn = dynamic_cast<SubNeuralNetwork*>(_nn);
    sub_nn->adjust_lr(iter_cnt);
}

void SubTrainer::adjust_batch_size(size_t iter_cnt) {
    int batch_size = 0;
    BatchSizeAdjustCfg& cfg = _nn_cfg->get_batch_size_adjust_cfg();

    if (cfg.get_type() == FIXED_BS) {
        _batch_size = _base_batch_size;
    } else if (cfg.get_type() == STEP_BS) {
        int cur_step = iter_cnt / cfg.get_step();
        batch_size = (int)(_base_batch_size * pow(cfg.get_gamma(), cur_step));

        if (batch_size != _batch_size) {
            INTER_LOG("type: step_bs");
            INTER_LOG("cur batch size %d", batch_size);
        }

        _batch_size = batch_size;
    } else if (cfg.get_type() == MULTI_STEP_BS) {
        if (_cur_step < (int)cfg.get_step_value().size() &&
            (int)iter_cnt >= cfg.get_step_value()[_cur_step]) {
            _cur_step++;
        }

        batch_size = (int)(_base_batch_size * pow(cfg.get_gamma(), _cur_step));

        if (batch_size != _batch_size) {
            INTER_LOG("type: multi_step_bs");
            INTER_LOG("cur batch size %d", batch_size);
        }

        _batch_size = batch_size;
    } else if (cfg.get_type() == LINEAR_BS) {
        int cur_step = iter_cnt / cfg.get_step();
        batch_size = (int)(_base_batch_size + cfg.get_gamma() * cur_step);

        if (batch_size != _batch_size) {
            INTER_LOG("type: step_bs");
            INTER_LOG("cur batch size %d", batch_size);
        }

        _batch_size = batch_size;
    } else if (cfg.get_type() == MULTI_LINEAR_BS) {
        if (_cur_step < (int)cfg.get_step_value().size() &&
            (int)iter_cnt >= cfg.get_step_value()[_cur_step]) {
            _cur_step++;
        }

        batch_size = (int)(_base_batch_size + cfg.get_gamma() * _cur_step);

        if (batch_size != _batch_size) {
            INTER_LOG("type: multi_step_bs");
            INTER_LOG("cur batch size %d", batch_size);
        }

        _batch_size = batch_size;
    } else {
        CHECK(false, "batch size adjust type error");
    }
    if (_data_repos) {
        _data_repos->set_new_batch_size(_batch_size);
    }
}

void SubTrainer::store_mean_var() {
    int old_device = 0;
    SubNeuralNetwork* sub_nn = dynamic_cast<SubNeuralNetwork*>(_nn);
    wind_get_gpu_device(&old_device);
    wind_set_gpu_device(_device_id);
    sub_nn->store_mean_var();
    wind_set_gpu_device(old_device);
}

}
}
