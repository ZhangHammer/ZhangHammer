#include <sys/stat.h>
#include <sys/types.h>
#include <string>
#include <queue>
#include <vector>
#include "util.h"
#include "image_predictor.h"
#include "object_factory.h"

namespace houyi {
namespace train {

// TODO 图像预测逻辑
void ImagePredictor::run() {
    int model_count = 0;

    if (_nn_cfg->disc_cfg().prior_name().size() != 0) {
        _nn->read_prior(_nn_cfg->disc_cfg().prior_name().c_str());
    }

    while (_thread_exit == false) {
        Argument in_feat_args;

        /* 从模型队列中获取模型 */
        std::string* model = _model_file_queue->pop();

        /* 遇到结束符，线程结束 */
        if (model == NULL) {
            _thread_exit = true;
            break;
        }
        /* 重新启动predictor，包括数据加载线程 */
        else {
            this->reset();
        }

        /* 调用脚本做预处理, 生成bn */
        if ("" != _call_before_predict
                && _pre_model_set.end() == _pre_model_set.find(*model)) {
            size_t pos = (*model).find_last_of("/\\");
            pos = (pos == std::string::npos) ? 0 : pos + 1;
            std::string model_name = (*model).substr(pos);
            std::string _bn_path_prefix = "tmp_bn/" + model_name + "/";
            int ret = system(("sh " + _call_before_predict + " "
                              + *model + " " + _bn_path_prefix).c_str());
            CHECK(0 == ret, "_call_before_predict failed");

            if (_nn_cfg->inq()) {
                _nn->read_inq_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end(),
                            _bn_path_prefix);
            } 
            else {
                _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end(),
                            _bn_path_prefix);
            }
        } else {
            if (_nn_cfg->inq()) {
                _nn->read_inq_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end());
            }
            else {
                _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end());
            }
        }

        size_t position = model->rfind('/', model->size() - 2);
        position = (position != std::string::npos) ? position + 1 : 0;
        std::string model_real_name(*model, position);

        int batch_count = 0;
        std::vector<std::string>& out_layer_names = _nn->get_out_layer_name();
        std::vector<std::pair<int, int>> res_count(out_layer_names.size());
        std::vector<std::pair<int, int>> top5_res_count(out_layer_names.size());
        std::vector<Layer*> out_layer = _nn->get_out_layer();
        BaseBatchSample* bat = NULL;
        DeviceBatchSample * device_batch = NULL;

        // 初始化 10 M 空间作为 workspace
        _worksapce = new Tensor<unsigned char>(Dim(10 * 1024 * 1024), gpu_device());
        _nn->set_workspace(_worksapce);

        do {

            if (_nn_cfg->is_load_by_python()) {
                if (_nn->is_echo_finish()) {
                    break;
                }

                //set feature pack and label pack
                std::vector<std::string>vec_feature;
                std::vector<std::string>vec_label;
                vec_feature.push_back(_nn_cfg->get_python_input_feature_key());
                vec_label.push_back(_nn_cfg->get_python_input_label_key());
                int batch_size = _nn_cfg->get_python_input_batch_size();
                _nn->get_out_args().set_feat_key(vec_feature);
                _nn->get_out_args().set_label_key(vec_label);
                _nn->get_out_args().set_sample_num(batch_size);
                _nn->resize_out();
            }else {
                std::pair<BaseBatchSample*, DeviceBatchSample*> bat_pair = load_data();
                bat = bat_pair.first;
                device_batch = bat_pair.second;
                if (bat == NULL) {
                    break;
                }
                copy_batch(in_feat_args, *bat, *device_batch);
                _nn->set_train_data(in_feat_args);
                _nn->resize_out();
            }

            std::vector<std::string>feature_keys = bat->get_feature_keys();
            std::vector<std::string>label_keys = bat->get_label_keys();

            // forward
            _nn->forward();

            if (_nn_cfg->is_load_by_python()) {
                int batch_size = _nn_cfg->get_python_input_batch_size();
                for (size_t i = 0; i < _stat_indicator.size(); i++) {
                    _stat_indicator[i]->increase_sample_num(batch_size);
                }
            }
            else {
                for (size_t i = 0; i < _stat_indicator.size(); i++) {
                    _stat_indicator[i]->increase_sentframe_num(bat);
                    _stat_indicator[i]->sample_num_norm(_nn_cfg->get_sample_statis_norm());
                }
            }

            // get the value of indicators
            std::vector<std::string>& cost_layer_name = _nn->get_cost_layer_name();
            std::vector<std::string>& out_layer_name = _nn->get_out_layer_name();
            
            for (size_t i = 0; i < cost_layer_name.size(); i++) {
                _stat_indicator[i]->cal_loss(_nn->cal_cost(
                                                 cost_layer_name[i]));
            }

            for (size_t i = 0; i < out_layer_name.size(); i++) {
                Tensor<DType>& score = *_nn->get_output(out_layer_name[i]);

                if (_score_store_dir.size() != 0) {
                    store_score(score, _score_store_dir, model_real_name, batch_count, bat);
                }
            }

            _nn->clear_train_data(in_feat_args);
            batch_count++;

            for (int l = 0; l < static_cast<int>(out_layer_names.size()); ++l) {
                if (out_layer[l]->type() == SOFTMAX_WITH_LOSS) {

                    size_t height = _nn->get_output(out_layer_names[l])->get_height();
                    size_t width = _nn->get_output(out_layer_names[l])->get_width();
                    Tensor<DType> tmp_out {cpu_device()};
                    tmp_out.resize(Dim(height, width));

                    tmp_out.copy_from(*_nn->get_output(out_layer_names[l]));
                    Tensor<DType> label(Dim(height, 1), cpu_device());
                    label.copy_from(bat->get_label_tensor(label_keys[l]));

                    //INTER_LOG("height %u width %u\n", height, width);
                    float* label_p = label.get_data();
                    res_count[l].second += height;

                    for (size_t i = 0; i < height; i++) {
                        DType* p = tmp_out.get_data(Dim(i, 0));
                        DType max_p = p[0];
                        int max_label = 0;

                        for (size_t j = 1; j < width; j++) {
                            if (p[j] > max_p) {
                                max_p = p[j];
                                max_label = j;
                            }
                        }

                        if (max_label == static_cast<int>(label_p[i])) {
                            res_count[l].first += 1;
                        }
                    }

                    //top5排序
                    top5_res_count[l].second += height;

                    for (size_t i = 0; i < height; i++) {
                        DType* p = tmp_out.get_data(Dim(i, 0));
                        auto cmp = [](std::pair<float, int>a, std::pair<float, int>b)->bool {return a.first > b.first;};
                        std::priority_queue<std::pair<float, int>, std::vector<std::pair<float, int> >, decltype(cmp) > que(
                            cmp);//小根堆
                        que.push(std::make_pair<float, int>((float)p[0], 0));

                        for (size_t j = 1; j < width; j++) {
                            if (que.size() < 5) {
                                que.push(std::make_pair<float, int>((float)p[j], j));
                            } else {
                                std::pair<float, int> tmp_pair = que.top();

                                if (tmp_pair.first < p[j]) {
                                    que.pop();
                                    que.push(std::make_pair<float, int>((float)p[j], j));
                                }
                            }
                        }

                        //判断top5是否包含标签
                        while (!que.empty()) {
                            std::pair<float, int>tmp_pair = que.top();
                            que.pop();

                            if (tmp_pair.second == label_p[i]) {
                                top5_res_count[l].first += 1;
                            }
                        }
                    }
                }

                if (batch_count % 200 == 0) {
                    INTER_LOG("top1 all image predict correct %f",
                              res_count[l].first / (1.0 * res_count[l].second));
                    INTER_LOG("top1 all image predict correct %d\\%d",  res_count[l].first, res_count[l].second);
                    INTER_LOG("top5 all image predict correct %f",
                              top5_res_count[l].first / (1.0f * top5_res_count[l].second));
                    INTER_LOG("top5 all image predict correct %d\\%d",  top5_res_count[l].first,
                              top5_res_count[l].second);
                }
            }
            batch_count++;
            if (bat) {
                ObjectFactory<BaseBatchSample>::instance()->delete_object(bat);
            }
            if (device_batch) {
                _data_repos->recycle_device_batch_sample(device_batch);
            }
            bat = NULL;
            device_batch = NULL;
            INTER_LOG("batch_count %d", batch_count);
            // show_current_log();
        } while (true);

        show_model_loss(model_real_name);

        if (_loss_file.size() != 0) {
            store_model_loss(_loss_file, model_real_name);
        }

        INTER_LOG("model: %s", model_real_name.c_str());
        std::ofstream out;

        for (int l = 0; l < static_cast<int>(out_layer_names.size())
                && out_layer[l]->type() == SOFTMAX_WITH_LOSS; ++l) {

            INTER_LOG("top1 all image predict correct %f", 1.0 * res_count[l].first / res_count[l].second);
            INTER_LOG("top1 all image predict correct %d\\%d",  res_count[l].first, res_count[l].second);

            INTER_LOG("top5 all image predict correct %f",
                      1.0 * top5_res_count[l].first / top5_res_count[l].second);
            INTER_LOG("top5 all image predict correct %d\\%d",  top5_res_count[l].first,
                      top5_res_count[l].second);

            out.open(_loss_file.c_str(), std::ios::out | std::ios::app);
            out << model_real_name.c_str() << "\ttop1 predict-correct: "
                << res_count[l].first * 1.0f / res_count[l].second << std::endl;
            out << model_real_name.c_str() << "\ttop5 predict-correct: "
                << top5_res_count[l].first * 1.0f / top5_res_count[l].second << std::endl;

        }

        out.close();

        /* 调用脚本做后处理 */
        if ("" != _call_after_predict) {
            int ret = system(("sh " + _call_after_predict).c_str());
            CHECK(0 == ret, "_call_after_predict failed");
        }

        delete model;
        model_count ++;

    }
}

void ImagePredictor::store_score(Tensor<DType>& score, std::string& dir, std::string& model_name,
                                 int batch_count, BaseBatchSample* bat) {
    char score_name[1024] = {0};

    if (access(dir.c_str(), 0) == -1) {
        mkdir(dir.c_str(), S_IRWXU);
    }

    size_t batch_size = bat->get_batch_size();
    const std::vector<std::string> filenames = bat->get_default_file_name();
    CHECK2(filenames.size() == batch_size);

    int frame_len = score.get_h() / batch_size;

    for (size_t i = 0; i < batch_size; ++i) {
        // TODO batch_size 不为 1 时, 一个score 写多个文件
        sprintf(score_name, "%s/%s", dir.c_str(), filenames[i].c_str());
        //sprintf(score_name, "%s/%04d.score", dir.c_str(), batch_count);
        //sprintf(score_name, "%s/%s_%04d.score", dir.c_str(), model_name.c_str(), batch_count);

        std::ofstream out_score;
        out_score.open(score_name);
        score.write_score(out_score, (int)i, (int) batch_size, frame_len);
        out_score.close();
    }

}

}   // namespace train
}   // namespace houyi
