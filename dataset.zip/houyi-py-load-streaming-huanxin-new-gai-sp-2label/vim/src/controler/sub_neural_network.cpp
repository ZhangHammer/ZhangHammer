/**
 * sub_neural_network.h
 * Author: lifeng(lifeng20@ainirobo.com)
 * Created on: 2014-09-14
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include <pthread.h>
#include <signal.h>
#include <typeinfo>
#include "sub_neural_network.h"

namespace houyi {
namespace train {

SubNeuralNetwork::SubNeuralNetwork(
    NeuralNetwork* from, MessageQueue<DwMessage*>* dwMsgQ, int async_period_num,
    TrainType train_type)
    : NeuralNetwork(*from) {
    CHECK2(from != NULL);

    for (int i = 0; i < from->layer_size(); i++) {
        _layer_msg_vec.push_back(new DwMessage(this, i));
    }

    _dw_mq = dwMsgQ;

    _async_period_num = async_period_num;
    _train_type = train_type;
    _self_update_counter = 0;
    _done_iter_num = 0;
}

SubNeuralNetwork::~SubNeuralNetwork() {
    _dw_mq = NULL;

    for (size_t i = 0; i < _layer_msg_vec.size(); i++) {
        if (_layer_msg_vec[i]) {
            delete _layer_msg_vec[i];
            _layer_msg_vec[i] = NULL;
        }
    }

    _layer_msg_vec.clear();
}

void SubNeuralNetwork::backward() {
    /* Synchronous update strategy */
    if (_train_type == SYNC_TRAIN && _async_period_num == 1) {
        for (int l = end_id(); l >= 0 && l >= start_id(); l--) {
            _layers[l]->backward(_out_args, _diff_args);
#ifdef __ENABLE_NCCL__
            WeightsMap& dw_map = _layers[l]->dw_map();
            for (const auto& dw : dw_map) {
                _intra_node_comm.get()->all_reduce_sum(*dw.second->w());
            }
#else
            _layer_msg_vec[l]->copy_out(D_WEIGHT);
            _dw_mq->push(_layer_msg_vec[l]);
#endif 
        }
    }
    else if (_train_type == ASYNC_TRAIN) {
        if (_async_period_num > _self_update_counter) {
            for (int l = end_id(); l >= 0 && l >= start_id(); l--) {
                _layers[l]->backward(_out_args, _diff_args);
                _layers[l]->update();
                _layer_msg_vec[l]->accum_grad(1.0f, 1.0f);

                if (l == end_id()) {
                    _done_iter_num = 0;
                    _self_update_counter++;
                }
                if (_async_period_num <= _self_update_counter) {
                    _layer_msg_vec[l]->copy_out(D_WEIGHT);
#ifdef __MULTI_GPU_DEBUG__
                    INTER_LOG("subNN push a message to queue_%lu", (unsigned long)_dw_mq);
#endif
                    _dw_mq->push(_layer_msg_vec[l]);
                }
            }
        }
    }
    else {
        for (int l = end_id(); l >= 0 && l >= start_id(); l--) {
            _layers[l]->backward(_out_args, _diff_args);
        }
    }
}

void SubNeuralNetwork::update() {
    /* Synchronous */
    if (_train_type == SYNC_TRAIN) {  // || _async_period_num <= _self_update_counter) {
        if (_async_period_num == 1) {
#ifdef __ENABLE_NCCL__
            _intra_node_comm->wait();
            for (int i = end_id(); i >= 0 && i >= start_id(); i--) {
                _layers[i]->update();
            }
#else
            for (int i = end_id(); i >= 0 && i >= start_id(); i--) {
#ifdef __MULTI_GPU_DEBUG__
                INTER_LOG("%d device wait w message, layer id: %d", _layer_msg_vec[i]->device_id(), i);
#endif
                _layer_msg_vec[i]->sync_update();
            }
#endif

            _done_iter_num = 1;
        } else if (_async_period_num > 1) {
            /* update weights with major trainer */
            if (_async_period_num > _self_update_counter) {
                for (int l = end_id(); l >= 0 && l >= start_id(); l--) {
                    _layers[l]->updater()->copy_from(_layers[l]->dw_map());
                    _layer_msg_vec[l]->accum_grad(1.0f, 1.0f);
                }

                _done_iter_num = 0;
                _self_update_counter++;
            }

            if (_async_period_num <= _self_update_counter) {
                for (int l = end_id(); l >= 0 && l >= start_id(); l--) {
                    _layer_msg_vec[l]->copy_out(D_WEIGHT);
#ifdef __MULTI_GPU_DEBUG__
                    INTER_LOG("subNN push a message to queue_%lu", (unsigned long)_dw_mq);
#endif
                    _dw_mq->push(_layer_msg_vec[l]);
                }

                for (int i = end_id(); i >= 0 && i >= start_id(); i--) {
                    _layer_msg_vec[i]->sync_update();
                    _layer_msg_vec[i]->zero_accum_grad();
                }

#ifdef __MULTI_GPU_DEBUG__
                INTER_LOG("update a period");
#endif
                _done_iter_num = 1;
                _self_update_counter = 0;
            }
        } else {
            CHECK(false, "update error");
        }

        /* Asynchronous */
    } else {
        if (_async_period_num <= _self_update_counter) {

            for (int i = end_id(); i >= 0 && i >= start_id(); i--) {
                _layer_msg_vec[i]->sync_update();
                _layer_msg_vec[i]->zero_accum_grad();
            }

#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("update a period");
#endif
            _done_iter_num = 1;
            _self_update_counter = 0;
        }
    }
}

void SubNeuralNetwork::done_message() {
    _dw_mq->push(new DwMessage(this, _layers.size()));
}

void SubNeuralNetwork::loss_ready_message() {
    _dw_mq->push(new DwMessage(this, _layers.size() + 1));
}

void SubNeuralNetwork::send_message(int id) {
    _dw_mq->push(new DwMessage(this, id));
}
void SubNeuralNetwork::adjust_lr(size_t iter_cnt) {
    for (auto layer : _layers) {
        layer->updater()->adjust_lr(iter_cnt);
    }
}
void SubNeuralNetwork::gen_bp_flag() {
    for (std::vector<Layer*>::reverse_iterator it = _layers.rbegin(); 
                it != _layers.rend(); it++) {
        std::vector<bool> output_bp_vec;
        for (auto output_key : (*it)->output_keys()) {
            Layer* next_layer = get_layer_by_input_key(output_key);
            //叶子节点，找不到下一层
            if (next_layer == NULL) {
                output_bp_vec.push_back(true);
            }
            else {
                output_bp_vec.push_back(next_layer->get_bp_down(output_key) & 
                            next_layer->get_enable_bp());
            }
        }
        std::vector<bool> label_bp_vec;
        for (auto label_key : (*it)->get_label_key()) { 
            IOPackage* io = _out_args.get_pack(label_key);
            if (io == NULL && (*it)->get_feature_share_input()) {    
                label_bp_vec.push_back(false);
            }                                            
            else if (io != NULL){
                label_bp_vec.push_back(true);
            }
        }                                                

        bool output_bp_flag = std::find(output_bp_vec.begin(), output_bp_vec.end(), true) 
                    != output_bp_vec.end();
        bool label_bp_flag = std::find(label_bp_vec.begin(), label_bp_vec.end(), false) 
                    == label_bp_vec.end();
        if ((output_bp_flag & label_bp_flag) == false) {
            (*it)->set_enable_bp(false);
        }
        else {
            (*it)->set_enable_bp(true);
        }
        (*it)->set_diff_ready(output_bp_vec);
    }
}

void SubNeuralNetwork::store_mean_var() {
    for (auto it : _layers) {
        it->store_mean_var();
    }
}

void SyncCls::copy_models(NeuralNetwork* Gen_nn) {
    for (int l = 0; l < Gen_nn->layer_size(); l++) {
        _train_nn->layers()[l]->copy_out(_w_vec[l], WEIGHT);
        Gen_nn->layers()[l]->copy_in(_w_vec[l], WEIGHT);
    }
}

DwMessage::DwMessage(SubNeuralNetwork* n, int l, bool init_gpu)
    : _nn(n), _layer_id(l) {
    // clone the dwSize from layer
    _dw_vec.clear();
    _gpu_dw_vec.clear();

    if (_layer_id < _nn->layer_size()) {
        _learn_rate = _nn->layers()[_layer_id]->updater()->learn_rate();
    }

    wind_get_gpu_device(&_device_id);

    sem_init(&_updated, 0, 0);

    _cp_out_stream = WIND_STREAM_1;
    _cp_in_stream  = WIND_STREAM_2;

    wind_create_event(&_cp_out_event);
    wind_create_event(&_cp_in_event);

    _init_gpu = init_gpu;
    _gpu_dw_vec.clear();
}

DwMessage::~DwMessage() {
    _nn = NULL;

    //for (size_t i = 0; i < _dw_vec.size(); i++) {
    //    release_weight_map(_dw_vec[i]);
    //}
    release_weight_map(_dw_vec);

    _dw_vec.clear();

    //for (size_t i = 0; i < _gpu_dw_vec.size(); i++) {
    //    if (_gpu_dw_vec[i]) {
    //        delete _gpu_dw_vec[i];
    //        _gpu_dw_vec[i] = NULL;
    //    }
    //}
    release_weight_map(_gpu_dw_vec);

    _gpu_dw_vec.clear();

    sem_destroy(&_updated);

    if (_cp_out_event) {
        wind_destroy_event(_cp_out_event);
        _cp_out_event = NULL;
    }

    if (_cp_in_event) {
        wind_destroy_event(_cp_in_event);
        _cp_in_event = NULL;
    }
}

void DwMessage::set_device_info(WindStream oStream, WindStream iStream) {
    _cp_out_stream = oStream;
    _cp_in_stream = iStream;

    if (!_cp_out_event) {
        wind_create_event(&_cp_out_event);
    }

    if (!_cp_in_event) {
        wind_create_event(&_cp_in_event);
    }
}

void DwMessage::accum_grad(DType alpha, DType beta) {
    _nn->layers()[_layer_id]->accum_grad(_gpu_dw_vec, alpha, beta);
}

void DwMessage::zero_accum_grad() {
    MAP_LOOP(_gpu_dw_vec) {
        itr1->second->zero();
    }
}

void DwMessage::copy_out(SPEECH_NN_W_TYPE t) {
    /*
     * if the gpuMatrix-vector has been initialized,
     * we should copy gradients from the _gpu_dw_vec
     * and, before copy, must make sure the _dw_vec is intialized
     */
    int old_device = 0;
    wind_get_gpu_device(&old_device);
    wind_set_gpu_device(_device_id);

    if (_gpu_dw_vec.size()) {
        if (0 == _dw_vec.size()) {
#if 0

            /* TODO: DiscreteLayer-specific, ugly */
            if (_nn->layers()[_layer_id]->type() == DISCRETE) {
                _nn->layers()[_layer_id]->copy_out_async(_dw_vec, t, _cp_out_stream);

            } else {
                //for (size_t i = 0; i < _gpu_dw_vec.size(); i++) {
                //    _dw_vec.push_back(_gpu_dw_vec[i]->clone(false));
                //}
#endif
                //init_weight_map(_dw_vec, _gpu_dw_vec, cpu_device());
                init_weight_map(_dw_vec, _gpu_dw_vec, cpu_pinned_device());
#if 0
            }

#endif
        }

        //for (size_t i = 0; i < _dw_vec.size(); i++) {
        //    _dw_vec[i]->copy_from(_gpu_dw_vec[i], _cp_out_stream);
        //}
        copy_weight_map(_dw_vec, _gpu_dw_vec, _cp_out_stream);

        wind_stream_record_event(_cp_out_stream, _cp_out_event);
        /*
         * if the gpuMatrix-vector has NOT been initialized,
         * we should copy gradients from the network-layer
         */
    } else {
        _nn->layers()[_layer_id]->copy_out_async(_dw_vec, t, _cp_out_stream);
        wind_stream_record_event(_cp_out_stream, _cp_out_event);
    }

    wind_set_gpu_device(old_device);
}

void DwMessage::sync_copy_out() {
    wind_event_synchronize(_cp_out_event);
}

void DwMessage::update(WeightsMap& w_vec) {
    if (w_vec.size()) {
        int old_device = 0;
        wind_get_gpu_device(&old_device);
        wind_set_gpu_device(_device_id);
        _nn->layers()[_layer_id]->update(w_vec, _cp_in_stream);
        wind_stream_record_event(_cp_in_stream, _cp_in_event);
        //sem_post(&_updated);
        wind_set_gpu_device(old_device);
    }

    sem_post(&_updated);
}

void DwMessage::sync_update() {
    sem_wait(&_updated);
    wind_event_synchronize(_cp_in_event);
}
}
}
