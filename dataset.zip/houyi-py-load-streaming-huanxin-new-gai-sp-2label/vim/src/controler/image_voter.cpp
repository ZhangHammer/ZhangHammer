#include <sys/stat.h>
#include <sys/types.h>
#include <string>
#include "util.h"
#include "image_voter.h"

namespace houyi {
namespace train {

// TODO 图像预测逻辑
void ImageVoter::run() {
    int model_count = 0;

    if (_nn_cfg->disc_cfg().prior_name().size() != 0) {
        _nn->read_prior(_nn_cfg->disc_cfg().prior_name().c_str());
    }

    while (_thread_exit == false) {
        Argument in_feat_args;

        /* 从模型队列中获取模型 */
        std::string* model = _model_file_queue->pop();

        /* 遇到结束符，线程结束 */
        if (model == NULL) {
            _thread_exit = true;
            break;
        }
        /* 重新启动predictor，包括数据加载线程 */
        else {
            this->reset();
        }

        /* 调用脚本做预处理, 生成bn */
        if ("" != _call_before_predict
                && _pre_model_set.end() == _pre_model_set.find(*model)) {
            size_t pos = (*model).find_last_of("/\\");
            pos = (pos == std::string::npos) ? 0 : pos + 1;
            std::string model_name = (*model).substr(pos);
            std::string _bn_path_prefix = "tmp_bn/" + model_name + "/";
            int ret = system(("sh " + _call_before_predict + " " +
                              *model + " " + _bn_path_prefix).c_str());
            CHECK(0 == ret, "_call_before_predict failed");

            _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end(), _bn_path_prefix);
        } else {
            _nn->read_model(model->c_str(), WEIGHT,
                            _nn_cfg->in_out_file_cfg().model_start(),
                            _nn_cfg->in_out_file_cfg().model_end());
        }

        size_t position = model->rfind('/', model->size() - 2);
        position = (position != std::string::npos) ? position + 1 : 0;
        std::string model_real_name(*model, position);

        int batch_count = 0;
        std::vector<std::string>& out_layer_names = _nn->get_out_layer_name();
        std::vector<std::pair<int, int>> res_count(out_layer_names.size());
        std::vector<std::pair<int, int>> top5_res_count(out_layer_names.size());
        std::vector<Layer*> out_layer = _nn->get_out_layer();

        do {
            std::pair<BaseBatchSample*, DeviceBatchSample*> pair_bat = load_data();

            BaseBatchSample* bat = pair_bat.first;
            DeviceBatchSample * device_batch = pair_bat.second;

            if (bat == NULL) {
                break;
            }

            std::vector<std::string>feature_keys = bat->get_feature_keys();
            std::vector<std::string>label_keys = bat->get_label_keys();

            copy_batch(in_feat_args, *bat, *device_batch);
            _nn->set_train_data(in_feat_args);
            _nn->resize_out();

            // forward
            _nn->forward();

            // get the value of indicators
            std::vector<std::string>& cost_layer_name = _nn->get_cost_layer_name();

            for (size_t i = 0; i < cost_layer_name.size(); i++) {
                _stat_indicator[i]->cal_loss(_nn->cal_cost(
                                                 cost_layer_name[i]));
            }

#if 0
            Tensor<DType>& score = *_nn->get_output();

            if (_nn->get_prior() != NULL) {
                /*
                score.log();
                score.add(*_nn->get_prior(), 1.0f, -1.0f);
                */
                score.log_sub_prior(*_nn->get_prior());
            }

            if (_score_store_dir.size() != 0) {
                store_score(score, _score_store_dir, model_real_name, batch_count, bat);
            }

#endif

            _nn->clear_train_data(in_feat_args);
            batch_count++;

            for (int l = 0; l < static_cast<int>(out_layer_names.size())
                    && out_layer[l]->type() == SOFTMAX_WITH_LOSS; ++l) {

                size_t height = _nn->get_output(out_layer_names[l])->get_height();
                size_t width = _nn->get_output(out_layer_names[l])->get_width();
                Tensor<DType> tmp_out {cpu_device()};
                tmp_out.resize(Dim(height, width));

                tmp_out.copy_from(*_nn->get_output(out_layer_names[l]));
                Tensor<DType> label(Dim(height, 1), cpu_device());
                label.copy_from(bat->get_label_tensor(label_keys[l]));

                // all of the label is equal

                for (size_t i = 1; i < height; i++) {
                    CHECK2(label.get_data()[i] == label.get_data()[i - 1]);
                }

                // the sum tensor probability
                Tensor<DType> sum_probability(Dim(1, width), cpu_device());
                sum_probability.zero();

                res_count[l].second += 1;

                //for (size_t i = 0; i < 1; i++) {
                for (size_t i = 0; i < height; i++) {
                    DType* p = tmp_out.get_data(Dim(i, 0));

                    for (size_t j = 0; j < width; j++) {
                        sum_probability.get_data()[j] += p[j];
                    }
                }

                // check label
                DType max_p = sum_probability.get_data()[0];
                int max_label = 0;

                for (size_t j = 1; j < width; j++) {
                    if (sum_probability.get_data()[j] > max_p) {
                        max_p = sum_probability.get_data()[j];
                        max_label = j;
                    }
                }

                if (max_label == static_cast<int>(label.get_data()[0])) {
                    res_count[l].first += 1;
                }

                // top5
                top5_res_count[l].second += 1;
                auto cmp = [](std::pair<float, int>a, std::pair<float, int>b)->bool
                {return a.first > b.first;};
                std::priority_queue < std::pair<float, int>,
                    std::vector<std::pair<float, int> >, decltype(cmp) > que(
                        cmp);//小根堆
                que.push(std::make_pair<float, int>
                         ((float)sum_probability.get_data()[0], 0));

                for (size_t j = 1; j < width; j++) {
                    if (que.size() < 5) {
                        que.push(std::make_pair<float, int>
                                 ((float)sum_probability.get_data()[j], j));
                    } else {
                        std::pair<float, int>tmp_pair = que.top();

                        if (tmp_pair.first < sum_probability.get_data()[j]) {
                            que.pop();
                            que.push(std::make_pair<float, int>
                                     ((float)sum_probability.get_data()[j], j));
                        }
                    }
                }

                //判断top5是否包含标签
                while (!que.empty()) {
                    std::pair<float, int>tmp_pair = que.top();
                    que.pop();

                    if (tmp_pair.second == static_cast<int>(label.get_data()[0])) {
                        top5_res_count[l].first += 1;
                    }
                }

                if (batch_count % 50 == 0) {
                    INTER_LOG("top1 all image predict correct %f",
                              1.0 * res_count[l].first / res_count[l].second);
                    INTER_LOG("top1 all image predict correct %d\\%d",
                              res_count[l].first, res_count[l].second);
                    INTER_LOG("top5 all image predict correct %f",
                              1.0 * top5_res_count[l].first / top5_res_count[l].second);
                    INTER_LOG("top5 all image predict correct %d\\%d",
                              top5_res_count[l].first, top5_res_count[l].second);
                }
            }

            delete bat;
            bat = NULL;  // TODO:
            // show_current_log();
        } while (true);

        show_model_loss(model_real_name);

        if (_loss_file.size() != 0) {
            store_model_loss(_loss_file, model_real_name);
        }

        INTER_LOG("model: %s", model_real_name.c_str());
        std::ofstream out;

        for (int l = 0; l < static_cast<int>(out_layer_names.size())
                && out_layer[l]->type() == SOFTMAX_WITH_LOSS; ++l) {

            INTER_LOG("top1 all image predict correct %f", 1.0 * res_count[l].first /
                      res_count[l].second);
            INTER_LOG("top1 all image predict correct %d\\%d",  res_count[l].first,
                      res_count[l].second);

            INTER_LOG("top5 all image predict correct %f",
                      1.0 * top5_res_count[l].first / top5_res_count[l].second);
            INTER_LOG("top5 all image predict correct %d\\%d",  top5_res_count[l].first,
                      top5_res_count[l].second);

            out.open(_loss_file.c_str(), std::ios::out | std::ios::app);
            out << model_real_name.c_str() << "\ttop1 predict-correct: "
                << res_count[l].first * 1.0f / res_count[l].second << std::endl;
            out << model_real_name.c_str() << "\ttop5 predict-correct: "
                << top5_res_count[l].first * 1.0f / top5_res_count[l].second << std::endl;

        }

        out.close();

        delete model;
        model_count++;

    }
}

}   // namespace train
}   // namespace houyi
