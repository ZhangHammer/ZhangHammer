/**
 * select_decoder.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-12-6
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include "multi_discriminator.h"
#include "select_decoder.h"
#include "util.h"
#include <utility>
#include <algorithm>
#include <tuple>

namespace houyi {
namespace train {

SelectDecoder::SelectDecoder(DecoderConfig& cfg) : Decoder(cfg) {
    init();
    set_device();
    _recall = cfg.get_recall();
    _select_ratio = cfg.get_select_ratio();
    _pos_neg_ratio = cfg.get_pos_neg_ratio();
    _score_threshold = cfg.get_score_threshold();
}

void SelectDecoder::run() {
    DecodeData* data = _decode_data_queue->pop();

    Tensor<DType>* feat = data->_feat.get_ten();
    Tensor<DType>* label = data->_label.get_ten();
    Tensor<DType>* score = &data->_score;
    size_t batch_size = score->get_h();
    size_t score_dim = score->get_w();
    size_t align_score_num = ALIGNED(_decoder_period, batch_size);
    CHECK(batch_size % 2 == 0, "param error");
    CHECK(batch_size == feat->get_size(0), "param error");
    CHECK(batch_size == label->get_size(0), "param error");

    _score.resize(Dim(align_score_num, score_dim));
    _feat.resize(Dim(align_score_num, feat->get_size(1), feat->get_size(2), feat->get_size(3)));
    _label.resize(Dim(align_score_num, label->get_size(1)));

    //copy score feature label
    size_t cur_score_num = 0;
    _score.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*score);
    Dim feat_start_dim(cur_score_num, 0, 0, 0);
    Dim feat_end_dim(cur_score_num + batch_size, feat->get_size(1), feat->get_size(2),
                     feat->get_size(3));
    _feat.get_block(feat_start_dim, feat_end_dim).copy_from(*feat);
    _label.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*label);

    cur_score_num += batch_size;
    delete data;
    data = NULL;

    size_t cur_epoch = 0;
    size_t cur_stop_thread_num = 0;

    while (cur_epoch < _epoch) {
        //收集各个卡传输的数据
        while (cur_score_num < align_score_num) {
            data = _decode_data_queue->pop();

            if (data == NULL) {
                cur_stop_thread_num++;

                if (cur_stop_thread_num >= _score_thread_num) {
                    break;
                }

                continue;
            }

            feat = data->_feat.get_ten();
            label = data->_label.get_ten();
            score = &data->_score;

            //copy score feature label
            _score.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*score);
            Dim feat_start_dim(cur_score_num, 0, 0, 0);
            Dim feat_end_dim(cur_score_num + batch_size, feat->get_size(1), feat->get_size(2),
                             feat->get_size(3));
            _feat.get_block(feat_start_dim, feat_end_dim).copy_from(*feat);
            _label.range_row(cur_score_num, cur_score_num + batch_size).copy_from(*label);
            cur_score_num += batch_size;

            delete data;
        }

        //构造新的训练数据
        if (cur_score_num != 0) {
            size_t idx_num = 0;
            Tensor<int> idx_vec(Dim(cur_score_num), CPU);

            if (_pos_neg_ratio > 0) {
                get_idx_pos_neg_ratio(cur_score_num, _score, _label, idx_vec, idx_num);
            } else if (_score_threshold > 0) {
                get_idx_score_threshold(cur_score_num, _score, _label, idx_vec, idx_num);
            } else {
                CHECK(false, "ratio error");
            }

            _new_feat.resize(Dim(idx_num, _feat.get_size(1), _feat.get_size(2),
                                 _feat.get_size(3)));
            _new_label.resize(Dim(idx_num, _label.get_size(1)));

            //拼接数据
            for (size_t i = 0; i < idx_num; i++) {
                int select_idx = idx_vec.get_element(Dim(i));

                Dim ap_feat_start_dim(select_idx, 0, 0, 0);
                Dim ap_feat_end_dim(select_idx + 1, _feat.get_size(1),
                                    _feat.get_size(2), _feat.get_size(3));
                Dim ap_new_feat_start_dim(i, 0, 0, 0);
                Dim ap_new_feat_end_dim(i + 1, _feat.get_size(1),
                                        _feat.get_size(2), _feat.get_size(3));
                _new_feat.get_block(ap_new_feat_start_dim, ap_new_feat_end_dim).
                copy_from(_feat.get_block(ap_feat_start_dim,
                                          ap_feat_end_dim));
                _new_label.range_row(i, i + 1).copy_from(
                    _label.range_row(select_idx, select_idx + 1));
            }

            _data_reader->push_batch_to_reader(&_new_feat, &_new_label);
        }

        if (cur_stop_thread_num >= _score_thread_num) {
            _data_reader->push_batch_to_reader(NULL, NULL);
            cur_stop_thread_num = 0;
            cur_epoch++;

            if (cur_epoch >= _epoch) {
                break;
            }
        }

        cur_score_num = 0;
    }

    reset();
}

bool pos_neg_cmp(const std::tuple<DType, int>& a,
                 const std::tuple<DType, int>& b) {
    if (get<0>(a) > get<0>(b)) {
        return true;
    }

    return false;
}

void SelectDecoder::get_idx_pos_neg_ratio(size_t cur_score_num,
        Tensor<DType>& score,
        Tensor<DType>& label, Tensor<int>& idx_vec, size_t& idx_num) {
    std::vector<std::tuple<DType, int>> neg;
    CHECK2(score.get_size(0) == label.get_size(0));
    std::vector<int> pos_idx;

    for (int i = 0; i < (int)cur_score_num; i++) {
        int label_value = (int)label.get_element(Dim(i, 0));

        if (label_value > 0) {
            pos_idx.push_back(i);
        } else {
            neg.push_back(std::make_tuple(score.get_element(Dim(i, label_value)), i));
        }
    }

    sort(neg.begin(), neg.end(), pos_neg_cmp);

    size_t pos_num = pos_idx.size();
    size_t neg_num = (pos_num / _pos_neg_ratio) > neg.size() ?
                     neg.size() : pos_num / _pos_neg_ratio;

    idx_num = pos_num + neg_num;

    for (size_t i = 0; i < pos_num; i++) {
        idx_vec.set_element(Dim(i), pos_idx[i]);
    }

    for (size_t i = pos_num, j = 0; i < pos_num + neg_num; i++, j++) {
        idx_vec.set_element(Dim(i), get<1>(neg[j]));
    }
}

void SelectDecoder::get_idx_score_threshold(size_t cur_score_num,
        Tensor<DType>& score,
        Tensor<DType>& label,
        Tensor<int>& idx_vec,
        size_t& idx_num) {
    std::vector<std::tuple<DType, int>> sample_score;
    CHECK2(score.get_size(0) == label.get_size(0));
    std::vector<int> pos_idx;

    idx_num = 0;

    for (int i = 0; i < (int)cur_score_num; i++) {
        int label_value = (int)label.get_element(Dim(i, 0));
        DType score_value = score.get_element(Dim(i, label_value));

        if (score_value <= _score_threshold) {
            idx_vec.set_element(Dim(idx_num), i);
            idx_num++;
        }
    }

    INTER_LOG("%ld samples are select from %ld samples", idx_num, cur_score_num);
}

}
}
