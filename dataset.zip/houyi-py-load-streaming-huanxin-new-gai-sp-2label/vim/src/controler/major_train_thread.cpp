#include "major_train_thread.h"
#include "multi_trainer.h"

namespace houyi {
namespace train {
AsyncTrainThread::AsyncTrainThread(
    NNConfig* cfg, MultiNeuralNetwork* muti_nn,
    SubTrainer* sub_traners[], MultiTrainer* major_trainer) {
    _nn_cfg = cfg;
    _local_trainer = major_trainer;
    _local_multi_nn = muti_nn;
    _sub_traners  = sub_traners;
    _thread_exit = false;

    _device_id = cfg->device_id(0);

    if (_nn_cfg->period_cfg().global_sync_period() > 0) {
        _multi_node_training = true;
    } else {
        _multi_node_training = false;
    }
}

void AsyncTrainThread::sync_train(int cur_epoch) {
    int batch_counter = 0;
    bool is_do_update = false;
    // get the total layer number that need to be updated
    int cur_up_num = _sub_traners[0]->nn()->update_layer_num();
    int start_up_id = _sub_traners[0]->nn()->start_id();
    int thread_num = _nn_cfg->thread_num();
    int up_layers[cur_up_num];

    for (int i = 0; i < cur_up_num; i++) {
        up_layers[i] = 0;
    }

    if (_multi_node_training) {
        /* For cluster training, do update in sync_with_server function */
        is_do_update = false;
    } else {
        /* For single node training, do update immediately */
        is_do_update = true;
    }

    while (_local_multi_nn->up_number()) {
        int up_num = cur_up_num;

        // if the training is on a cluster
        if (_multi_node_training) {
            bool res = sync_with_server(&batch_counter, 0, cur_up_num);

            /* If do NOT synchronize with server, then perform update for train thread */
            if (!res) {
                _local_multi_nn->update_all_msg();
            }
        }

        int cnt = 0;

        while (cnt < up_num) {
            DwMessage* msg = _local_multi_nn->dw_mesg_queue()->pop();
            int id = msg->layer_id();
            int device = msg->device_id();

            /* loss ready */
            if (id == _sub_traners[0]->nn()->layer_size() + 1) {
                _local_trainer->check_log(device, cur_epoch, _local_multi_nn->updater_vec(),
                                          _local_multi_nn->w_vec());
#ifdef __MULTI_GPU_DEBUG__
                INTER_LOG("major thread get a loss ready message, \
                            batch: %d device: %d layer id: %d", batch_counter, device, id);
#endif
                continue;
            }

            DwMessage* ret_msg = _local_multi_nn->update_from_msg(msg, is_do_update);

            if (ret_msg) {
#ifdef __MULTI_GPU_DEBUG__
                INTER_LOG("major thread get a message, batch: %d device: %d layer id: %d",
                          batch_counter, device, id);
#endif
                up_layers[id - start_up_id]++;

                if (up_layers[id - start_up_id] == thread_num) {
                    cnt++;
                    up_layers[id - start_up_id] = 0;
                }
            } else {
                // Receive a done message
#ifdef __MULTI_GPU_DEBUG__
                INTER_LOG("major thread get a done message, batch: %d device: %d", batch_counter, device);
#endif
                thread_num--;

                /* A done message from one thread is interleaved with messages from another */
                for (int i = 0; i < cur_up_num; i++) {
                    if (up_layers[i] == thread_num) {
                        up_layers[i] = 0;
                        cnt++;
                    }
                }

                /* Unconditional jump out when thread_num being zero */
                if (thread_num == 0) {
                    for (int i = 0; i < cur_up_num; i++) {
                        up_layers[i] = 0;
                    }

                    break;
                }
            }
        }

        batch_counter++;
    }
}

bool AsyncTrainThread::sync_with_server(int* cur_up_couter, int cur_thread_id, int need_up_num) {
    if (_multi_node_training && *cur_up_couter >= _nn_cfg->period_cfg().global_sync_period()) {
        _local_trainer->update_global_weight();
        _local_trainer->reset_weight();
        _local_multi_nn->update_all_msg();
        *cur_up_couter = 0;
        return true;
    } else {
        return false;
    }
}

void AsyncTrainThread::async_train(int cur_epoch) {
    int cur_thread_id = 0;
    int batch_counter = 0;
    int is_do_update = false;

    if (_multi_node_training) {
        /* For cluster training, do update in sync_with_server function */
        is_do_update = false;
    } else {
        /* For single node training, do update immediately */
        is_do_update = true;
    }

    _local_multi_nn->clear_finish_flag();

    while (_local_multi_nn->up_number() - 1 + _nn_cfg->thread_num()) {
        // get the total layer number that need to be updated
        int cur_up_num = _sub_traners[cur_thread_id]->nn()->update_layer_num();

        // if the training is on a cluster
        if (_multi_node_training) {
            bool res = sync_with_server(&batch_counter, cur_thread_id, cur_up_num);

            // If do NOT synchronize with other node,
            // then perform update for train thread
            if (!res) {
                _local_multi_nn->update_all_msg();
            }
        }

        DwMessage* msg = NULL;
        DwMessage* ret_msg = NULL;

        for (int i = 0; i < cur_up_num + _local_multi_nn->get_async_period_num(); i++) {
            msg = _local_multi_nn->dw_mesg_queue(cur_thread_id)->pop();

            int id = msg->layer_id();
            //统计w和dw的mean，max，min
            int device = msg->device_id();

            /* loss ready */
            if (id == _sub_traners[0]->nn()->layer_size() + 1) {
                _local_trainer->check_log(device, cur_epoch, _local_multi_nn->updater_vec(),
                                          _local_multi_nn->w_vec());
                continue;
            }

#ifdef __MULTI_GPU_DEBUG__
            INTER_LOG("major_nn get a message form thread_%d_queue_%p",
                      cur_thread_id, _local_multi_nn->dw_mesg_queue(cur_thread_id));
#endif
            ret_msg = _local_multi_nn->update_from_msg(msg, is_do_update);

            if (ret_msg == NULL) {
                _local_multi_nn->mark_finish(cur_thread_id);
                break;
            }
        }

        cur_thread_id = _local_multi_nn->poolling(cur_thread_id); // select a train-thread

        batch_counter++;
    }
}

void* AsyncTrainThread::run_thread(void* self) {
    AsyncTrainThread* tt = static_cast<AsyncTrainThread*>(self);
    wind_init(tt->device_id());
    wind_set_gpu_device(tt->device_id());
    tt->run();
    return NULL;
}

void AsyncTrainThread::run() {
    int cur_epoch = 0;
    int update_num = _nn_cfg->thread_num();

    if (_nn_cfg->period_cfg().train_type() == ASYNC_TRAIN) {
        update_num = 1;
    }

    // training
    while (cur_epoch < _nn_cfg->period_cfg().epoch()) {
        // dispatch global weight to subNNs
        MultiTrainer* l_trainer = static_cast<MultiTrainer*>(_local_trainer);
        l_trainer->sync_global_weight(
            _sub_traners, _nn_cfg->thread_num(), _local_multi_nn);

        _local_multi_nn->clear_msg_group();
        _local_multi_nn->set_up_number(update_num);

        // unlock all the trainThreads
        for (int i = 0; i < _nn_cfg->thread_num(); i++) {
            pthread_mutex_unlock(&_sub_traners[i]->_load_mutex);
        }

        if (_nn_cfg->period_cfg().train_type() == ASYNC_TRAIN) {
            async_train(cur_epoch);
        } else {
            sync_train(cur_epoch);
        }

        // copy out the model
        _local_trainer->check_epoch(cur_epoch);
        cur_epoch++;

        // reset for next epoch
        if (cur_epoch < _nn_cfg->period_cfg().epoch()) {
            _local_trainer->reset();

            for (int i = 0; i < _nn_cfg->thread_num(); i++) {
                _sub_traners[i]->reset();
            }
        }
    }

    _local_trainer->store_global_weight();
    _local_trainer->stop_kvstore();

    // Notice the subNeuralNetworks to exit
    for (int i = 0; i < _nn_cfg->thread_num(); i++) {
        _sub_traners[i]->parent(NULL);
        pthread_mutex_unlock(&_sub_traners[i]->_load_mutex);
    }

    _thread_exit = true;

    if (_local_trainer->get_model_predict_queue() != NULL) {
        _local_trainer->get_model_predict_queue()->push(NULL);
    }

    if (_local_trainer->get_disc_update_queue() != NULL) {
        _local_trainer->get_disc_update_queue()->push(NULL);
    }

    pthread_exit(0);
}

}
}
