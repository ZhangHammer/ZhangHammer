/**
 * multi_neural_network.h
 * Author: madongpeng (madongpeng@baidu.com)
 * Created on: 2014-09-14
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#include <pthread.h>
#include <signal.h>
#include <typeinfo>
#include "multi_neural_network.h"
#include "train_type.h"

namespace houyi {
namespace train {

MultiNeuralNetwork::MultiNeuralNetwork(
    int layer_size, int thread_num, int async_period_num,
    int global_sync_period, TrainType train_type,
    GlobalUpdaterCfg& global_updater_cfg) {
    /*
     * clear buffer
     */
    init();

    _mdw_vec.resize(layer_size);
    _w_vec.resize(layer_size);
    _w_quant_vec.resize(layer_size);
    _msg_group.resize(layer_size);
    _up_number = thread_num;
    _train_thread_num = thread_num;

    _layer_num = layer_size;

    if (train_type == SYNC_TRAIN) {
        _dw_mq = new class MessageQueue<DwMessage*>[1];
    } else {
        _dw_mq = new class MessageQueue<DwMessage*>[_train_thread_num];
        //_up_number = 1;
    }

    _async_period_num = async_period_num;
    _train_type = train_type;
    _global_sync_period = global_sync_period;
    _global_updater_cfg = global_updater_cfg;
    _weight_fixed_buffer.set_device(cpu_device());
}

MultiNeuralNetwork::~MultiNeuralNetwork() {
    if (_dw_mq) {
        delete []_dw_mq;
        _dw_mq = NULL;
    }

    _msg_group.clear();

    _major_nn = NULL; // this pointer is set by caller

    for (int l = 0; l < _layer_num; l++) {
        release_weight_map(_mdw_vec[l]);
        release_weight_map(_w_vec[l]);
        release_weight_map(_w_quant_vec[l]);
    }
}

void MultiNeuralNetwork::init_weight(
    NeuralNetwork* nn, NNConfig* nn_cfg,
    const char* md_model_file) {
    for (size_t i = 0; i < _w_vec.size(); i++) {
        //float lr = nn->layers()[i]->learnRate();
        //if (lr != 0.0f) {
        WeightsMap& mdw_vec = _mdw_vec[i];
        WeightsMap& w_vec = _w_vec[i];
        WeightsMap& w_quant_vec = _w_quant_vec[i];
        nn->layers()[i]->copy_out(w_vec, WEIGHT);
        nn->layers()[i]->copy_out(w_quant_vec, WEIGHT);
        init_weight_map(mdw_vec, w_vec, cpu_pinned_device());
    }

    if (nn_cfg->model_init_cfg().md_model_name().size()) {
        //use weight to store md_weight
        nn->read_model_no_bn(nn_cfg->model_init_cfg().md_model_name().c_str(), WEIGHT,
                             nn_cfg->model_init_cfg().model_start(), nn_cfg->model_init_cfg().model_end());

        for (size_t i = 0; i < _w_vec.size(); i++) {
            nn->layers()[i]->copy_out(_mdw_vec[i], WEIGHT);
        }
    }

    /*
    if (md_model_file) {
        nn->read_model(md_model_file, WEIGHT,
                nn_cfg->model_init_cfg().model_start(), nn_cfg->model_init_cfg().model_end());
        for (size_t i = 0; i < _w_vec.size(); i++) {
            nn->layers()[i]->copy_out(_mdw_vec[i], WEIGHT);
        }
    }
    */
}

void MultiNeuralNetwork::do_update(int layer_id) {
    /* update subNN weights */
    for (size_t i = 0; i < _msg_group[layer_id].size(); i++) {
        if (_mdw_vec.size()
                && _msg_group[layer_id][i]->nn()->layers()[layer_id]->weight_flag() == false) {
            MAP_LOOP(_mdw_vec[layer_id]) {
                itr1->second->zero();
            }
        }

        if (_layer_quantize.size() && _layer_quantize[layer_id]) {
            _msg_group[layer_id][i]->update(_w_quant_vec[layer_id]);
        } else {
            _msg_group[layer_id][i]->update(_w_vec[layer_id]);
        }
    }

    /* clear message */
    _msg_group[layer_id].clear();
}

void MultiNeuralNetwork::if_do_update(int l, bool notice) {
    // for sync-train or async-train
    // if async-training, we update the global-weights immediately
    //INTER_LOG("msg group: %d size: %d up_number: %d", l, _msg_group[l].size(), _up_number);
    if (((int)_msg_group[l].size() == _up_number && _train_type == SYNC_TRAIN)
            || _train_type == ASYNC_TRAIN) {

        _updater_vec[l]->update(_w_vec[l]); // update local weights

        // fixed-model
        if (_fixed_period > 0) {
            if (_fixed_batch_count == _fixed_period) {
                MAP_LOOP(_w_vec[l]) {
                    std::string key = itr1->first;
                    BaseWeight* w = itr1->second;
                    if (key.find("bias") == key.npos) {
                        Dim size = w->get_size();
                        CHECK2(size.get_axis() == 2);
                        if (_weight_fixed_transpose[l] == true) {
                            _weight_fixed_buffer.resize(Dim(size.get_size(1), size.get_size(0)));
                            _weight_fixed_buffer.transpose(*w->w());
                            _weight_fixed_buffer.fixed_loss();
                            w->w()->transpose(_weight_fixed_buffer);
                        } else {
                            w->fixed_loss();
                        }
                    }
                }     
                if (l == 0) {
                    _fixed_batch_count = 0;
                }
            } else if (l == 0) {
                _fixed_batch_count++;
            }
        }

        if (l == (int)_w_vec.size() - 1) {
            _enable_statis = false;
            if (rand() % 100 == 0) {
                _enable_statis = true;
            }
        }

        if (_layer_quantize.size() && _layer_quantize[l]) {
            size_t layer_nbit = _weight_quant_bits[l];
            MAP_LOOP(_w_vec[l]) {
                std::string key = itr1->first;
                BaseWeight* w = itr1->second;
                BaseWeight* w_quant = _w_quant_vec[l].at(key);
                std::string prefix = std::string("layer") + std::to_string(l) + std::string(" ") + key;
                
                _lbq.quant_whole(_weight_quant_transpose[l], layer_nbit, *w_quant->w(), *w->w(), prefix, _enable_statis);
                
            }
        }

        if (notice) { // notice sub_NN
            do_update(l);
        }
    }
}

DwMessage* MultiNeuralNetwork::collect_msg(DwMessage* msg) {
    int layer_id = msg->layer_id();

    if (layer_id == _layer_num) {
        INTER_LOG("a done message from GPU%d !!!", msg->device_id());
        _up_number--;
        delete msg;

        if (_up_number > 0) {
            /* done message 发送不及时，其它卡已经开始等待更新w */
            for (int l = (int)_w_vec.size() - 1; l >= 0; l--) {
                if_do_update(l, true);
            }
        }

        return NULL;
    }

    msg->sync_copy_out();
    _msg_group[layer_id].push_back(msg);

    return msg;
}

DwMessage* MultiNeuralNetwork::update_from_msg(
    DwMessage* in_msg, bool is_do_update) {

    int layer_id = in_msg->layer_id();
    DwMessage* msg = collect_msg(in_msg);

    if (msg == NULL) {
        return NULL;
    }

    WeightsMap& subDWVec = msg->dw_vec();

    // collect gradient
    _updater_vec[layer_id]->collect(subDWVec, _w_vec[layer_id], 1);

    // check if need to update local or global model
    if_do_update(layer_id, is_do_update);

    return msg;
}

void MultiNeuralNetwork::update_all_msg() {
    for (size_t l = 0; l < _msg_group.size(); l++) {
        do_update(l);
    }
}

void MultiNeuralNetwork::reset(int threadNum) {
    _up_number = threadNum;

    for (size_t i = 0; i < _msg_group.size(); i++) {
        CHECK2(_msg_group[i].size() == 0);
    }

    clear_finish_flag();
}

void MultiNeuralNetwork::reset_weight(std::vector<WeightsMap>& src) {
    CHECK2(src.size() == _w_vec.size());

    for (size_t l = 0; l < src.size(); l++) {
        copy_weight_map(_w_vec[l], src[l]);
    }
}

void MultiNeuralNetwork::reset_momentum(std::vector<WeightsMap>& src) {
    CHECK2(src.size() == _mdw_vec.size());

    for (size_t l = 0; l < src.size(); l++) {
        copy_weight_map(_mdw_vec[l], src[l]);
    }
}

void MultiNeuralNetwork::register_dw_buf(std::vector<WeightsMap>& dw_buf) {
    dw_buf.resize(_updater_vec.size());
    for (size_t l = 0; l < dw_buf.size(); l++) {
        _updater_vec[l]->clone_to(dw_buf[l]);
    }
}

void MultiNeuralNetwork::copy_weight(std::vector<WeightsMap>& dest) {
    CHECK2(dest.size() == _w_vec.size());

    for (size_t l = 0; l < dest.size(); l++) {
        copy_weight_map(dest[l], _w_vec[l]);
    }
}

void MultiNeuralNetwork::copy_momentum(std::vector<WeightsMap>& dest) {
    CHECK2(dest.size() == _mdw_vec.size());

    for (size_t l = 0; l < dest.size(); l++) {
        copy_weight_map(dest[l], _mdw_vec[l]);
    }
}

void MultiNeuralNetwork::adjust_lr(size_t iter_cnt) {
    for (auto update : _updater_vec) {
        update->adjust_lr(iter_cnt);
    }
}

void MultiNeuralNetwork::store_quantization_weight(const char* prefix_name, int cur_epoch, size_t cnt)
{
    if (*std::max_element(_weight_quant_bits.begin(), _weight_quant_bits.end()) == 0) {
        return;
    }

    pid_t tid;
    pid_t pid;
    pid = getpid();
    char datetime[20];
    get_datetime(datetime);
    char hname[256];
    bzero(hname, sizeof(hname));
    gethostname(hname, sizeof(hname));
    tid = syscall(SYS_gettid);
    snprintf(hname + strlen(hname), 200, "-%u-%u-%s", tid, pid, datetime);

    // build name
    char local_model_name[256] = {0};
    snprintf(local_model_name, 256,
             "%s_epoch_%d_%lu.quantization_model.%s", prefix_name, cur_epoch, cnt, hname);

    for (size_t l = 0; l < _w_vec.size(); l++) {
        if (_layer_quantize.size() && _layer_quantize[l]) {
            size_t layer_nbit = _weight_quant_bits[l];
            MAP_LOOP(_w_vec[l]) {
                std::string key = itr1->first;
                BaseWeight* w = itr1->second;
                BaseWeight* w_quant = _w_quant_vec[l].at(key);
            
                _lbq.quant_whole(_weight_quant_transpose[l], layer_nbit, *w_quant->w(), *w->w(), std::string(""), false);
            }
        } else {
            copy_weight_map(_w_quant_vec[l], _w_vec[l]);
        }
    }

    _major_nn->reset_weight(_w_quant_vec);

    // store
    _major_nn->store_model(local_model_name, WEIGHT);
    INTER_LOG("store server model to %s", local_model_name);

    // restore weight
    _major_nn->reset_weight(_w_vec);
}

}
}
