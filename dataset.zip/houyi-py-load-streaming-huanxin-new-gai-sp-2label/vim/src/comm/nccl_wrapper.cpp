/**
 * nccl_wrapper.cpp
 *
 * Author: wangkai35 (wangkai35@baidu.com)
 * Created on: 2018-07-19
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <math.h>   
#include "wind/wind.h"
#include "nccl_wrapper.h"

#ifdef __ENABLE_NCCL__

namespace houyi {
namespace train {

void Nccl::all_reduce_sum(Tensor<DType>& inout) {
    CHECK2(inout.is_contiguous());

    size_t len = inout.get_element_count();
    DType* ptr = inout.get_data();

    ncclAllReduce(ptr, ptr, len, ncclFloat, ncclSum, _comm, _stream); 
}

void Nccl::all_reduce_sum(Tensor<DType>& out, const Tensor<DType>& in) {
    CHECK2(out.is_contiguous());
    CHECK2(in.is_contiguous());
    CHECK2(out.get_size() == in.get_size());

    size_t len = out.get_element_count();
    DType* dst_ptr = out.get_data();
    const DType* src_ptr = in.get_data();

    ncclAllReduce(src_ptr, dst_ptr, len, ncclFloat, ncclSum, _comm, _stream); 
}

std::shared_ptr<NcclSingleton> NcclSingleton::get_shared_ref() {
    static std::shared_ptr<NcclSingleton> sptr(new NcclSingleton());
    return sptr;
}

NcclSingleton* NcclSingleton::inst() {
    static NcclSingleton* inst = get_shared_ref().get();
    return inst;
}
    
} //namesapce train
} //namespace houyi

#endif 


