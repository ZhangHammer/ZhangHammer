#include <string.h>
#include <climits>
#include <sys/stat.h>
#include <errno.h>
#include <dirent.h>

#include <string>
#include <iomanip>
#include <vector>
#ifdef __WITH_OPENCV__
#include <opencv2/opencv.hpp>
#endif

#include "tb_writer.h"
#include "./tensorboard.pb.h"

DEFINE_bool(enable_tensorboard, false, "enable tensorboard record");

namespace houyi {
namespace train {

namespace util {

uint32_t crc_table[] = {
    0x00000000, 0xf26b8303, 0xe13b70f7, 0x1350f3f4,
    0xc79a971f, 0x35f1141c, 0x26a1e7e8, 0xd4ca64eb,
    0x8ad958cf, 0x78b2dbcc, 0x6be22838, 0x9989ab3b,
    0x4d43cfd0, 0xbf284cd3, 0xac78bf27, 0x5e133c24,
    0x105ec76f, 0xe235446c, 0xf165b798, 0x030e349b,
    0xd7c45070, 0x25afd373, 0x36ff2087, 0xc494a384,
    0x9a879fa0, 0x68ec1ca3, 0x7bbcef57, 0x89d76c54,
    0x5d1d08bf, 0xaf768bbc, 0xbc267848, 0x4e4dfb4b,
    0x20bd8ede, 0xd2d60ddd, 0xc186fe29, 0x33ed7d2a,
    0xe72719c1, 0x154c9ac2, 0x061c6936, 0xf477ea35,
    0xaa64d611, 0x580f5512, 0x4b5fa6e6, 0xb93425e5,
    0x6dfe410e, 0x9f95c20d, 0x8cc531f9, 0x7eaeb2fa,
    0x30e349b1, 0xc288cab2, 0xd1d83946, 0x23b3ba45,
    0xf779deae, 0x05125dad, 0x1642ae59, 0xe4292d5a,
    0xba3a117e, 0x4851927d, 0x5b016189, 0xa96ae28a,
    0x7da08661, 0x8fcb0562, 0x9c9bf696, 0x6ef07595,
    0x417b1dbc, 0xb3109ebf, 0xa0406d4b, 0x522bee48,
    0x86e18aa3, 0x748a09a0, 0x67dafa54, 0x95b17957,
    0xcba24573, 0x39c9c670, 0x2a993584, 0xd8f2b687,
    0x0c38d26c, 0xfe53516f, 0xed03a29b, 0x1f682198,
    0x5125dad3, 0xa34e59d0, 0xb01eaa24, 0x42752927,
    0x96bf4dcc, 0x64d4cecf, 0x77843d3b, 0x85efbe38,
    0xdbfc821c, 0x2997011f, 0x3ac7f2eb, 0xc8ac71e8,
    0x1c661503, 0xee0d9600, 0xfd5d65f4, 0x0f36e6f7,
    0x61c69362, 0x93ad1061, 0x80fde395, 0x72966096,
    0xa65c047d, 0x5437877e, 0x4767748a, 0xb50cf789,
    0xeb1fcbad, 0x197448ae, 0x0a24bb5a, 0xf84f3859,
    0x2c855cb2, 0xdeeedfb1, 0xcdbe2c45, 0x3fd5af46,
    0x7198540d, 0x83f3d70e, 0x90a324fa, 0x62c8a7f9,
    0xb602c312, 0x44694011, 0x5739b3e5, 0xa55230e6,
    0xfb410cc2, 0x092a8fc1, 0x1a7a7c35, 0xe811ff36,
    0x3cdb9bdd, 0xceb018de, 0xdde0eb2a, 0x2f8b6829,
    0x82f63b78, 0x709db87b, 0x63cd4b8f, 0x91a6c88c,
    0x456cac67, 0xb7072f64, 0xa457dc90, 0x563c5f93,
    0x082f63b7, 0xfa44e0b4, 0xe9141340, 0x1b7f9043,
    0xcfb5f4a8, 0x3dde77ab, 0x2e8e845f, 0xdce5075c,
    0x92a8fc17, 0x60c37f14, 0x73938ce0, 0x81f80fe3,
    0x55326b08, 0xa759e80b, 0xb4091bff, 0x466298fc,
    0x1871a4d8, 0xea1a27db, 0xf94ad42f, 0x0b21572c,
    0xdfeb33c7, 0x2d80b0c4, 0x3ed04330, 0xccbbc033,
    0xa24bb5a6, 0x502036a5, 0x4370c551, 0xb11b4652,
    0x65d122b9, 0x97baa1ba, 0x84ea524e, 0x7681d14d,
    0x2892ed69, 0xdaf96e6a, 0xc9a99d9e, 0x3bc21e9d,
    0xef087a76, 0x1d63f975, 0x0e330a81, 0xfc588982,
    0xb21572c9, 0x407ef1ca, 0x532e023e, 0xa145813d,
    0x758fe5d6, 0x87e466d5, 0x94b49521, 0x66df1622,
    0x38cc2a06, 0xcaa7a905, 0xd9f75af1, 0x2b9cd9f2,
    0xff56bd19, 0x0d3d3e1a, 0x1e6dcdee, 0xec064eed,
    0xc38d26c4, 0x31e6a5c7, 0x22b65633, 0xd0ddd530,
    0x0417b1db, 0xf67c32d8, 0xe52cc12c, 0x1747422f,
    0x49547e0b, 0xbb3ffd08, 0xa86f0efc, 0x5a048dff,
    0x8ecee914, 0x7ca56a17, 0x6ff599e3, 0x9d9e1ae0,
    0xd3d3e1ab, 0x21b862a8, 0x32e8915c, 0xc083125f,
    0x144976b4, 0xe622f5b7, 0xf5720643, 0x07198540,
    0x590ab964, 0xab613a67, 0xb831c993, 0x4a5a4a90,
    0x9e902e7b, 0x6cfbad78, 0x7fab5e8c, 0x8dc0dd8f,
    0xe330a81a, 0x115b2b19, 0x020bd8ed, 0xf0605bee,
    0x24aa3f05, 0xd6c1bc06, 0xc5914ff2, 0x37faccf1,
    0x69e9f0d5, 0x9b8273d6, 0x88d28022, 0x7ab90321,
    0xae7367ca, 0x5c18e4c9, 0x4f48173d, 0xbd23943e,
    0xf36e6f75, 0x0105ec76, 0x12551f82, 0xe03e9c81,
    0x34f4f86a, 0xc69f7b69, 0xd5cf889d, 0x27a40b9e,
    0x79b737ba, 0x8bdcb4b9, 0x988c474d, 0x6ae7c44e,
    0xbe2da0a5, 0x4c4623a6, 0x5f16d052, 0xad7d5351,
};

static uint32_t crc_mask = 0xFFFFFFFF;

class GetHostName : public std::string {
public:
    GetHostName() {
        static std::string hostname;
        if (hostname.empty()) {
            char hostnamebuf[1024];
            strcpy(hostnamebuf, "localhost");
            ::gethostname(hostnamebuf, sizeof(hostnamebuf));
            hostname = hostnamebuf;
        }
        assign(hostname);
    }
};

static std::string get_new_file_path(const std::string path,
                                     time_t time) {
    std::stringstream filename;
    if (!path.empty()) {
        filename << path << "/";
    }
    filename << "events.out.tfevents."
        << std::setfill('0') << std::setw(10) << time
        << "." << GetHostName();
    return filename.str();
}

template<typename T>
static void encode_data(char* buf, T value) {
    memcpy(buf, &value, sizeof(value));
}

static uint32_t mask_crc(const char* data, size_t n) {
    uint32_t crc = 0ul;
    crc ^= crc_mask;
    const uint8_t* buf = (const uint8_t *)data;
    for (size_t i = 0; i < n; ++i) {
        size_t table_index = (crc ^ buf[i]) & 0xff;
        crc = (crc_table[table_index] ^ (crc >> 8)) & crc_mask;
    }
    crc ^= crc_mask;
    return ((crc >> 15) | (crc << 17)) + 0xa282ead8ul;
}

static void fwrite_or_die(const void* ptr, size_t size, size_t count, FILE* f) {
    size_t n = fwrite(ptr, size, count, f);
    CHECK(n == count, "error writing to file (ptr=0x%08lx, size=%zu, count=%zu, writing %zu: %s",
                      (unsigned long) (size_t) ptr, size, count, n, strerror(errno));
}

static int mkdir_p(const char *path) {
    const size_t len = strlen(path);
    char _path[PATH_MAX];
    char *p = nullptr;
    errno = 0;

    if (len > sizeof(_path)-1) {
        errno = ENAMETOOLONG;
        return -1;
    }
    strcpy(_path, path);

    for (p = _path + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(_path, S_IRWXU) != 0) {
                if (errno != EEXIST) {
                    return -1;
                }
            }
            *p = '/';
        }
    }

    if (mkdir(_path, S_IRWXU) != 0) {
        if (errno != EEXIST)
            return -1;
    }

    return 0;
}

#ifdef __WITH_OPENCV__
static void write_image_to_buffer(float* image_data, int height, int width,
        int data_type, std::vector<uchar>& buffer) {
    cv::Mat source(height, width, data_type, (void*)image_data);
    std::vector<int> parameters = std::vector<int>(2);
    parameters[0] = CV_IMWRITE_PNG_COMPRESSION;
    parameters[1] = 3;
    if (!cv::imencode(".png", source, buffer, parameters)) {
        INTER_LOG("TensorBoardWriter: PNG encoding failed.");
    }
}
#endif

static std::string serialize(const tensorflow::Event& event) {
    std::string record;
    event.AppendToString(&record);
    return record;
}

static void create_graph(NeuralNetwork* model, tensorflow::GraphDef& dst) {
    std::unordered_map<std::string, tensorflow::NodeDef*> io_nodes;
    std::unordered_map<std::string, std::string> io_map;

    std::string scope = "";
    for (Layer* layer : model->layers()) {
        // 添加 Layer 属性
        tensorflow::NodeDef* op_node = dst.add_node();
        op_node->set_name(layer->name());
        op_node->set_op(layer->type_str());

        // 添加 Layer 的输入节点
        std::vector<std::string>& inputs = layer->input_keys();
        for (const auto& in : inputs) {
            std::string name = in;
            if (io_map.find(in) != io_map.end()) {
                name = io_map[in] + "/" + in;
            }
            op_node->add_input(name);
            if (io_nodes.find(name) == io_nodes.end()) {
                tensorflow::NodeDef* io_node = dst.add_node();
                io_node->set_name(name);
                io_node->set_op("in_out");
                io_nodes[name] = io_node;
            }
        }

        // 添加 Layer 的输出节点
        std::vector<std::string>& outputs = layer->output_keys();
        for (const auto& out : outputs) {
            CHECK(io_map.find(out) == io_map.end(), "config error");
            io_map[out] = layer->name();
            std::string name = layer->name() + "/" + out;
            tensorflow::NodeDef* io_node = nullptr;
            if (io_nodes.find(name) == io_nodes.end()) {
                io_node = dst.add_node();
                io_node->set_name(name);
                io_node->set_op("in_out");
                io_nodes[name] = io_node;
            } else {
                io_node = io_nodes[name];
            }
            io_node->add_input(layer->name());
        }

        // 添加 Layer 的输入节点
        WeightsMap w_map = layer->w_map();
        for (const auto& w : w_map) {
            tensorflow::NodeDef* w_node = dst.add_node();
            std::string name = layer->name() + "/" + w.first;
            w_node->set_name(name);
            w_node->set_op("weight");
            op_node->add_input(name);
        }
    }
}

}   // namespace util

TensorBoardWriter::TensorBoardWriter(const std::string& dir, NeuralNetwork* model)
    : _model(model),
      _dir(dir),
      _file_name(),
      _fp(nullptr),
      _base_step(0u) {
    if (false == FLAGS_enable_tensorboard) {
        return;
    }
    init();
}

void TensorBoardWriter::init() {
    std::string path = "tb_log/" + _dir;
    bool found = false;
    if (!access(path.c_str(), F_OK)) {
        // 如果文件夹存在, 表明为继续训练，则继续写
        DIR* dir = NULL;
        struct dirent* ent = NULL;
        if ((dir = opendir(path.c_str())) != NULL) {
            while ((ent = readdir(dir)) != NULL) {
                if (strncmp(ent->d_name, "events.out.tfevents", 19) == 0) {
                    found = true;
                    break;
                }
            }
            if (found) {
                std::string file_path = path + "/" + ent->d_name;
                INTER_LOG("found event file: %s", file_path.c_str());
                char* data = NULL;
                size_t ret = 0u;
                uint64_t size = 0u;
                uint32_t crc = 0u;
                FILE* fp = fopen(file_path.c_str(), "rb");
                CHECK(fp != nullptr, "failed to open file %s", file_path.c_str());
                while (!feof(fp)) {
                    ret = fread(&size, sizeof(uint64_t), 1u, fp);
                    if (ret == 0) {
                        break;
                    }
                    ret = fread(&crc, sizeof(uint32_t), 1u, fp);
                    CHECK(ret == 1u, "read event file failed");
                    if (util::mask_crc((char*)(&size), sizeof(uint64_t)) != crc) {
                        CHECK(false, "event file %s is invalid, please rm it first",
                                file_path.c_str());
                    }
                    if (data) {
                        free(data);
                    }
                    data = (char*)malloc(size);
                    ret = fread(data, sizeof(char), size, fp);
                    CHECK(ret == size, "read event file failed");
                    ret = fread(&crc, sizeof(uint32_t), 1u, fp);
                    CHECK(ret == 1u, "read event file failed");

                    if (util::mask_crc(data, size) != crc) {
                        CHECK(false, "event file %s is invalid, please rm it first",
                                file_path.c_str());
                    }
                }
                fclose(fp);
                CHECK(data != NULL, "read event file failed");

                tensorflow::Event event;
                bool parse_ok = event.ParseFromArray(data, size);
                CHECK(parse_ok, "read event file failed");
                _base_step = event.step();
                INTER_LOG("tensorboard base_step = %zu", _base_step);
                free(data);
                _fp = fopen(file_path.c_str(), "ab");
                CHECK(_fp != nullptr, "failed to open file %s", file_path.c_str());
            }
            closedir(dir);
        }
    }
    if (!found) {
        // 如果文件夹不存在或文件不存在, 表明为重新训练，则重新写
        int ret = util::mkdir_p(path.c_str());
        CHECK(ret == 0, "failed to create path %s", _dir.c_str());
        time_t time_now = std::time(0);
        std::string file_path = util::get_new_file_path(path, time_now);
        _fp = fopen(file_path.c_str(), "wb");
        CHECK(_fp != nullptr, "failed to open file %s", file_path.c_str());
        _file_name = file_path;
        write_version(time_now);

        if (_model) {
            write_model();
        }
        flush();
    }
}

void TensorBoardWriter::write_text(
        const std::string& name,
        const std::string& value,
        uint64_t step) {
    if (false == FLAGS_enable_tensorboard) {
        return;
    }
    tensorflow::Event event;
    event.set_step(step + _base_step);
    event.set_wall_time(static_cast<double>(std::time(0)));

    tensorflow::Summary* summary = event.mutable_summary();
    tensorflow::Summary::Value* summary_val = summary->add_value();
    summary_val->set_tag(name);
    tensorflow::SummaryMetadata* summary_meta = summary_val->mutable_metadata();
    tensorflow::SummaryMetadata::PluginData* summary_meta_data =
        summary_meta->add_plugin_data();
    summary_meta_data->set_plugin_name("text");
    tensorflow::TensorProto* tensor = summary_val->mutable_tensor();
    tensor->set_dtype(tensorflow::DT_STRING);
    tensor->add_string_val(value);
    tensorflow::TensorShapeProto* tensor_shape = tensor->mutable_tensor_shape();
    tensorflow::TensorShapeProto::Dim* dim = tensor_shape->add_dim();
    dim->set_size(1);
    write_record(util::serialize(event));
}

void TensorBoardWriter::write_value(
        const std::string& name,
        float value,
        uint64_t step) {
    if (false == FLAGS_enable_tensorboard) {
        return;
    }
    tensorflow::Event event;
    event.set_step(step + _base_step);
    event.set_wall_time(static_cast<double>(std::time(0)));

    tensorflow::Summary* summary = event.mutable_summary();
    tensorflow::Summary::Value* summary_val = summary->add_value();
    summary_val->set_tag(name);
    summary_val->set_simple_value(value);
    write_record(util::serialize(event));
}

void TensorBoardWriter::write_model() {
    CHECK(_model != nullptr, "model is empty");
    // convert model to tensorflow graphdef first
    tensorflow::GraphDef graph;
    util::create_graph(_model, graph);

    std::string graph_str;
    graph.AppendToString(&graph_str);

    tensorflow::Event event;
    event.set_wall_time(static_cast<double>(std::time(0)));
    event.set_graph_def(graph_str);

    write_record(util::serialize(event));
}

void TensorBoardWriter::write_record(const std::string& data) {
    CHECK(_fp != nullptr, "tb_writer fp is null");
    // 头信息: 长度(uint64_t) + 长度的crc(uint32_t)
    char header[sizeof(uint64_t) + sizeof(uint32_t)];
    util::encode_data(header, static_cast<uint64_t>(data.size()));
    util::encode_data(header + sizeof(uint64_t), util::mask_crc(header, sizeof(uint64_t)));

    // 尾信息: 数据的 crc
    char footer[sizeof(uint32_t)];
    util::encode_data(footer, util::mask_crc(data.data(), data.size()));

    util::fwrite_or_die(header, sizeof(header[0]), sizeof(header), _fp);
    util::fwrite_or_die(data.data(), sizeof(data[0]), data.size(), _fp);
    util::fwrite_or_die(footer, sizeof(footer[0]), sizeof(footer), _fp);
}

void TensorBoardWriter::write_image(
        const std::string& name,
        const Tensor<DType>& image_data,
        uint64_t step) {
#ifdef __WITH_OPENCV__
    if (false == FLAGS_enable_tensorboard) {
        return;
    }
    tensorflow::Event event;
    event.set_wall_time(static_cast<double>(std::time(0)));
    tensorflow::Summary* summary = event.mutable_summary();

    Dim dim = image_data.get_size();
    CHECK(dim.get_axis() == 4, "image_data must be 4D vs %dD", dim.get_axis());
    CHECK(image_data.get_device() == CPU, "TensorBoardWriter: image_data must be cpu tensor");

    const size_t batch_size = dim[0];
    const size_t depth = dim[1];
    const size_t height = dim[2];
    const size_t width = dim[3];

    Dim image_shape(depth, width, height);
    for (size_t i = 0; i < batch_size; ++i) {
        tensorflow::Summary::Value* summary_val = summary->add_value();
        summary_val->set_tag(name + "/image/" + std::to_string(i));

        tensorflow::Summary::Image* summary_image = summary_val->mutable_image();
        summary_image->set_height(height);
        summary_image->set_width(width);
        summary_image->set_colorspace(depth);
        Tensor<DType> image = image_data.slice(i, i + 1);
        std::vector<uchar> buffer;
        util::write_image_to_buffer(image.get_ptr(), height, width, CV_32FC(depth), buffer);

        std::string str(buffer.begin(), buffer.end());
        summary_image->set_encoded_image_string(str);
    }
    write_record(util::serialize(event));
#endif 
}

void TensorBoardWriter::write_histogram(
        const std::string& name,
        const Tensor<DType>& tensor,
        uint64_t step) {
    if (false == FLAGS_enable_tensorboard) {
        return;
    }
    CHECK(is_cpu_device(tensor.get_device()), "write_histogram must be cpu tensor");
    tensorflow::Event event;
    event.set_wall_time(static_cast<double>(std::time(0)));
    event.set_step(step + _base_step);
    tensorflow::Summary* summary = event.mutable_summary();

    tensorflow::Summary::Value* summary_val = summary->add_value();
    summary_val->set_tag(name);

    tensorflow::HistogramProto* summary_histo = summary_val->mutable_histo();
    constexpr int bins = 10;
    float max = tensor.max();
    float min = tensor.min();
    float norm2 = tensor.norm2();
    size_t count = tensor.get_element_count();

    summary_histo->set_min(min);
    summary_histo->set_max(max);
    summary_histo->set_num(count);
    summary_histo->set_sum(tensor.sum());
    summary_histo->set_sum_squares(norm2 * norm2);

    float offset = max > min ? (max - min) / 1e4 : 1e-6;
    float range = (max - min + offset) / bins;
    float* ptr = tensor.get_ptr();
    double backet[bins] = {0};
    for (size_t i = 0; i < count; ++i) {
        ++backet[static_cast<int>((ptr[i] - min) / range)];
    }
    for (size_t i = 0; i < bins; ++i) {
        summary_histo->add_bucket_limit(min + i * range + 0.5 * range);
        summary_histo->add_bucket(backet[i]);
    }

    write_record(util::serialize(event));
}

void TensorBoardWriter::write_version(time_t time) {
    tensorflow::Event event;
    event.set_wall_time(static_cast<double>(time));
    event.set_file_version("brain.Event:2");
    write_record(util::serialize(event));
}

bool TensorBoardWriter::flush() {
    if (false == FLAGS_enable_tensorboard) {
        return true;
    }
    if (_fp == nullptr) {
        return false;
    }
    if (fflush(_fp)) {
        INTER_LOG("TensorBoardWriter: Error flushing the event file(%s).", _file_name.c_str());
        return false;
    }
    return true;
}

bool TensorBoardWriter::close() {
    if (false == FLAGS_enable_tensorboard) {
        return true;
    }
    if (_fp == nullptr) {
        return false;
    }
    bool success = this->flush();
    if (fclose(_fp)) {
        INTER_LOG("TensorBoardWriter: Error closing the previous event file(%s).", _file_name.c_str());
        success = false;
    }

    _fp = nullptr;
    _file_name.clear();
    return success;
}

}   // namespace train
}   // namespace houyi
