/**
 * base_processer_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-12
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "base_processer_config.h"
namespace houyi {
namespace train {

BaseProcConfig* BaseProcConfig::read(std::ifstream &input) {
    std::string param_lines;

    stream_to_string(input, "</Processer>", param_lines);
    BaseProcConfig* cfg = new BaseProcConfig(); 
    cfg->parse_params(param_lines);
    return cfg;
}

void BaseProcConfig::parse_params(std::string &config_line) {
    parse_from_string("type", &config_line, &_type);
    INTER_LOG("type %s", _type.c_str());
    
    // parse_from_string("numDevices", &config_line, &_num_devices);
    // INTER_LOG("numDevices %d", _num_devices);
    
    parse_from_string("asyncLoad", &config_line, &_is_async);
    INTER_LOG("asyncLoad %d", _is_async);

    parse_from_string("maxBufferNum", &config_line, &_max_buf_num);
    INTER_LOG("maxBufferNum %d", (int)_max_buf_num);
    parse_from_string("threadPoolNum", &config_line, &_thread_pool_num);
    INTER_LOG("threadPoolNum %d", (int)_thread_pool_num);
    std::string line;

    size_t start_pos = config_line.find("<Transform>");
    while (start_pos != std::string::npos) {
        std::string remain = config_line.substr(0, start_pos);

        size_t end_pos = config_line.find("</Transform>");
        CHECK(end_pos != std::string::npos, "can not find transform end");

        size_t len = end_pos - start_pos - 11;
        std::string trans_line = config_line.substr(start_pos + 11, len);
        remain += config_line.substr(end_pos + 12);
        _trans_lines.push_back(trans_line);
        INTER_LOG("%s", trans_line.c_str());
        config_line = remain;
        start_pos = config_line.find("<Transform>");
    }
}

}
}
