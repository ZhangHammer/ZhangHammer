// by zzxfl 2016.10.28
#include "trans_delay.h"
#include "base_transformation.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
int TransDelay::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    for (auto key : sent->get_label_keys()) {
        if (!has_key(key))continue;
        SpeechOneLabel *label = static_cast<SpeechOneLabel*>(&sent->get_label(key));
        int nframe = sent->get_frame_num(key);
        if (nframe <= _time) {
            INTER_LOG("nframe <= _time %d %d", nframe, _time);
            return 0;
        }
        Tensor<DType> &label_data = label->get_label();

        //copy label_data
        //向后移动_time位
        Tensor<DType>& label_tmp = _label_tmp;
        //Tensor<int>label_tmp {cpu_device()};
        label_tmp.resize(label_data.get_size());
        label_tmp.copy_from(label_data);
        label_data.range_row(_time, nframe).copy_from(label_tmp.range_row(0, nframe - _time));
        //前面的标签用第一个标签补齐
        for (int i = 0; i < _time; i++) {
            label_data.range_row(i, i + 1).copy_from(label_tmp.range_row(0, 1));
        }
    }
    return 0;
}

void TransDelay::read_data(std::string &config_line) {
    parse_from_string("Time", &config_line, &_time);
    INTER_LOG("TransDelay: Time %d", _time);
    CHECK2(config_line.size() == 0);
}
}
}

