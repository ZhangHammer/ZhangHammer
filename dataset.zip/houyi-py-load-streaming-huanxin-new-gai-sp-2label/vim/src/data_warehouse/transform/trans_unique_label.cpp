/**
 * trans_unique_label.cpp
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-07-02
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#include "trans_unique_label.h"
#include "speech_one_sentence.h"
#include "parse_string.h"
//#include "util.h"

namespace houyi {
namespace train {

int TransUniqueLabel::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    CHECK2(sent->get_label_keys().size() == 1);
    std::string label_key = sent->get_label_keys()[0];
    Tensor<DType>& label_data = sent->get_label_tensor(label_key);
    // convert to unique sequence
    int label_num = sent->get_frame_num();
    int label_dim = sent->get_label_dim(label_key);
    CHECK2(label_dim == 1);
    std::vector<int> label_vec(label_num);
    
    for (int ii = 0; ii < label_num; ii++) {
        label_vec[ii] = (int)label_data.get_element(Dim(ii, 0));
    }

    std::vector<int> unique_ids;
    unique_ids.clear();
    for (size_t idx = 1; idx < label_vec.size() - 1; ++idx) {
        if (label_vec[idx] == _blank_id && (label_vec[idx+1] != _blank_id || (label_vec[idx-1] != _blank_id && label_vec[idx+1] == _blank_id))) {
            unique_ids.push_back(label_vec[idx-1]);
        }   
    }   
    unique_ids.push_back(label_vec[label_vec.size() -1]);
    
    _label_data.resize(Dim(unique_ids.size(), 1));
    for (int ii = 0; ii < (int)unique_ids.size(); ii++) {
        _label_data.get_data()[ii] = (float)unique_ids[ii];
    }
    label_data.resize(_label_data.get_size());
    label_data.copy_from(_label_data);
    sent->set_frame_num(label_key, label_data.get_size(0));


/*
    std::vector<int>::iterator it = std::unique(label_vec.begin(), label_vec.end());
    label_vec.erase(it, label_vec.end());
    //
    int unique_label_num = (int)label_vec.size();
    _label_data.resize(Dim(unique_label_num, 1));
    for (int ii = 0; ii < unique_label_num; ii++) {
        _label_data.get_data()[ii] = (float)label_vec[ii];
    }
    label_data.resize(_label_data.get_size());
    label_data.copy_from(_label_data);
    sent->set_frame_num(label_key, label_data.get_size(0));
    // // insert new label
    // SpeechOneLabel* speech_one_label = new SpeechOneLabel(INT_LABEL_TYPE, unique_label_num, 1);
    // speech_one_label->set_label(_label_data);
    // sent->insert_label(_new_label_name, *speech_one_label);
*/


    return 0;
}

void TransUniqueLabel::read_data(std::string &config_line) {
    // parse_from_string("newLabelName", &config_line, &_new_label_name);
    // INTER_LOG("newLabelName: %s", _new_label_name.c_str());
    parse_from_string("blank_id", &config_line, &_blank_id);

    CHECK2(config_line.size() == 0);
}

}
}

