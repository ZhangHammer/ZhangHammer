//by zzxfl 2016.12.23
#include "trans_wakeup_crop.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransWakeupCrop::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;

        Tensor<DType>*image = &sample->get_feature_tensor(key);

        int width = image->get_w();
        int height = image->get_h();
        int channel = image->get_c();
        int crop_width = _crop_width;
#ifndef __CLOSE_RANDOM__
        int crop_height = _crop_height[0] + 1.0 * rand() / RAND_MAX * (_crop_height[1] - _crop_height[0]);
#else
        int crop_height = _crop_height[0];
#endif
        if (width <= crop_width && height <= crop_height)
            continue;

        CHECK2(channel == 1 || channel == 3);
        CHECK2(crop_width > 0);
        CHECK2(crop_height > 0);

        Tensor<DType>target = Tensor<DType>(Dim(channel, crop_height, crop_width), cpu_device());

        size_t skip_w_max = width - crop_width;
        size_t skip_h_max = height - crop_height;

        size_t skip_w = 0;
        size_t skip_h = 0;
        if (_predict) {
            skip_w = skip_w_max / 2;
            skip_h = skip_h_max / 2;
        } else {
            skip_w = 1.0 * rand() / RAND_MAX * skip_w_max + 0.1;
            skip_h = 1.0 * rand() / RAND_MAX * skip_h_max + 0.1;
        }

        for (int k = 0; k < channel; k++) {
            for (int j = 0; j < crop_height; j++) {
                DType* ptr1 = image->get_data(Dim(k, j + skip_h, skip_w));
                DType* ptr2 = target.get_data(Dim(k, j, 0));
                memcpy(ptr2, ptr1, sizeof(DType) * crop_width);
            }
        }

        sample->set_feature_tensor(key, target);
    }
    return 0;
}

void TransWakeupCrop::read_data(std::string &config_line) {
    parse_from_string("cropWidth", &config_line, &_crop_width);
    parse_from_string("cropHeight", &config_line, &_crop_height);
    parse_from_string("predict", &config_line, &_predict);
    CHECK2(_crop_height.size() == 2);
    INTER_LOG("TransWakeupCrop: cropWidth %d, cropHeight %d:%d predict %d",
              (int)_crop_width, _crop_height[0], _crop_height[1], (int)_predict);
}

}
}
