// by zzxfl 2016.10.28
#include "trans_add_deltas.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

void regress(
    float* data_in, float* data_out, int size, int n, int step)
{
    CHECK2(data_in != NULL && data_out != NULL);

    float sigma_t2 = 0.0;
    int delta_window = 2;

    for (int t = 1; t <= delta_window; t++) {
        sigma_t2 += t * t;
    }

    sigma_t2 *= 2.0;

    for (int i = 0; i < n; i++) {
        float* fp1 = data_in;
        float* fp2 = data_out;

        for (int j = 0; j < size; j++) {
            float* back = fp1;
            float* forw = fp1;
            float sum = 0.0;

            for (int t = 1; t <= delta_window; t++) {
                back -= step;
                forw += step;
                sum  += t * (*forw - *back);
            }

            *fp2 = sum / sigma_t2;
            ++fp1;
            ++fp2;
        }

        data_in  += step;
        data_out += step;
    }
}

int TransAddDeltas::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key))continue;
        int frame_dim = sent->get_frame_dim(key);
        int d_frame_dim = frame_dim * 3;
        //CHECK2(frame_dim == 40);
        Tensor<DType>& mat = _mat;
        Tensor<DType>&src = sent->get_feature_tensor(key);
        CHECK2(src.get_dim() == 2);
        const int head_filled = 5;
        const int tail_filled = 5;
        mat.resize(Dim(src.get_size()[0] + tail_filled + head_filled, d_frame_dim), true);
        //前面补left_context帧
        Tensor<DType>& head = sent->get_split_head();
        if (head.is_init()) {
            CHECK2(head.get_height() == 5);
            for (int i = 0; i < head_filled; i++) {
                mat.copy_row(head, i, i);
            }
        } else {
            for (int i = 0; i < head_filled; i++) {
                mat.copy_row(src, 0, i);
            }
        }

        for (int i = 0; i < (int)src.get_size(0); i++) {
            mat.copy_row(src, i, i + head_filled);
        }
        //后面补right_context帧
        Tensor<DType>& tail = sent->get_split_tail();
        if (tail.is_init()) {
            CHECK2(tail.get_height() == 5);
            for (int i = 0; i < tail_filled; i++) {
                mat.copy_row(tail, i, i + src.get_size()[0] + head_filled);
            }
        } else {
            for (int i = head_filled + src.get_size()[0]; i < (int)mat.get_size(0); i++) {
                mat.copy_row(src, src.get_size()[0] - 1, i);
            }
        }

        int nframe = sent->get_frame_num(key);
        int start = head_filled;
        float *temp = mat.get_data();
        regress(temp + start * d_frame_dim,
                temp + start * d_frame_dim + frame_dim, frame_dim, nframe, d_frame_dim);
        regress(temp + start * d_frame_dim + frame_dim,
                temp + start * d_frame_dim + 2 * frame_dim, frame_dim, nframe, d_frame_dim);
        //不需要保留补好的帧
        if (!_keep_additional) {
            src.resize(Dim(src.get_size(0), d_frame_dim), false);
            src.copy_from(
                mat.get_block(Dim(head_filled, 0),
                              Dim(head_filled + src.get_size(0), src.get_size(1))));
            sent->set_frame_dim(key, d_frame_dim);
            sent->set_frame_num(key, nframe);
        }
        //保留补好的帧
        else {
            src.resize(Dim(mat.get_size(0), d_frame_dim), false);
            src.copy_from(mat);
            sent->set_frame_dim(key, d_frame_dim);
            sent->set_frame_num(key, nframe + tail_filled + head_filled);
        }
    }
    return 0;
}

void TransAddDeltas::read_data(std::string &config_line) {
    parse_from_string("DeltaOrder", &config_line, &_order);
    parse_from_string("DeltaWindow", &config_line, &_window);
    parse_from_string("KeepAdditional", &config_line, &_keep_additional);
    INTER_LOG("AddDeltas: DeltaOrder %d, DeltaWindow %d KeepAdditional %d", _order, _window, _keep_additional);
    CHECK2(config_line.size() == 0);
}

}
}

