//by zzxfl 2016.10.28
#include "trans_crop.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransCrop::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &sample->get_feature_tensor(key);

        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();
        if (width <= _crop_width && height <= _crop_height)
            continue;

        CHECK2(channel == 1 || channel == 3);
        CHECK2(_crop_width > 0);
        CHECK2(_crop_height > 0);

        Tensor<DType>target(Dim(channel, _crop_height, _crop_width), cpu_device());

        size_t skip_w_max = width - _crop_width;
        size_t skip_h_max = height - _crop_height;

        size_t skip_w = 0;
        size_t skip_h = 0;
        if (_predict) {
            skip_w = skip_w_max / 2;
            skip_h = skip_h_max / 2;
        } else {
#ifndef __CLOSE_RANDOM__
            skip_w = 1.0 * rand() / RAND_MAX * skip_w_max + 0.1;
            skip_h = 1.0 * rand() / RAND_MAX * skip_h_max + 0.1;
#else
            skip_w = skip_w_max / 2;
            skip_h = skip_h_max / 2;
#endif
        }

        for (size_t k = 0; k < channel; k++) {
            for (size_t j = 0; j < _crop_height; j++) {
                DType* ptr1 = image->get_data(Dim(k, j + skip_h, skip_w));
                DType* ptr2 = target.get_data(Dim(k, j, 0));
                memcpy(ptr2, ptr1, sizeof(DType) * _crop_width);
            }
        }

        sample->set_feature_tensor(key, target);
    }
    return 0;
}

void TransCrop::read_data(std::string &config_line) {
    parse_from_string("cropWidth", &config_line, &_crop_width);
    parse_from_string("cropHeight", &config_line, &_crop_height);
    parse_from_string("predict", &config_line, &_predict);
    INTER_LOG("TransCrop: cropWidth %d, cropHeight %d predict %d",
              (int)_crop_width, (int)_crop_height, (int)_predict);
}

}
}
