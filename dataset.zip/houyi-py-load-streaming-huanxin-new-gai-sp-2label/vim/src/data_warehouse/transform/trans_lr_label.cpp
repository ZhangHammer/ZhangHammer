// by zzxfl 2018.05.10
#include "trans_lr_label.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransLrLabel::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    for (auto key : sent->get_label_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>& label = sent->get_label_tensor(key);
        
        _label.resize(label.get_size(), false);
        _label.copy_from(label);
        label.resize(Dim(label.get_size(0), _class_num));

        for (int i = 0; i < (int)label.get_size(0); ++i) {
            int position = (int)_label.get_data()[i];
            // position == _class_num 是所有样本的负例
            if (position == _class_num) {
                // nothing to do
            }
            // 是其他样本的负例
            else if (position < _class_num) {
                label.get_data()[i * _class_num + position] = 1.0;
                //处理mask
                for (int j = 0; j < _class_num; ++j) {
                    if (_mask[position][j] == 1) {
                        label.get_data()[i * _class_num + j] = -1.0;
                    }
                }
            }
            // 只有cur_position是负例
            else {
                int cur_position = position - 1;
                CHECK2(cur_position < _class_num);
                for (int j = 0; j < _class_num; ++j) {
                    label.get_data()[i * _class_num + j] = -1.0;
                }
                label.get_data()[i * _class_num + cur_position] = 0.0;
            }
        }
        
        sent->set_label_dim(key, _class_num);
    }
    return 0;
}

void TransLrLabel::read_data(std::string &config_line) {
    std::string file;
    parse_from_string("classNum", &config_line, &_class_num);
    INTER_LOG("TransLrLabel : classNum %d", _class_num);

    parse_from_string("maskFile", &config_line, &file);
    INTER_LOG("TransMixLr: maskFile %s", file.c_str());
    CHECK2(config_line.size() == 0);
    std::ifstream is(file.c_str());
    int row = 0;
    is >> row;
    CHECK2(row == _class_num);
    for (int i = 0; i < row; ++i) {
        std::vector<int>t_v(_class_num, 0);
        _mask.push_back(t_v);
        int col = 0;
        is >> col;
        for (int j = 0; j < col; ++j) {
            int val = 0;
            is >> val;
            CHECK2(val < _class_num);
            _mask[i][val] = 1;
        }
    }
}

}
}

