//by longfei 2017.06.08
#include "trans_image_channel.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include <cmath>

namespace houyi {
namespace train {

int TransImageChannel::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);

    for (auto key : sample->get_feature_keys()) {
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        //const size_t channel = 3;
        //CHECK2(image->get_c() == channel);
        CHECK2(image->get_c() == 3 || image->get_c() == 1);

        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        if (channel == _channel)
            continue;

        Tensor<DType>target(Dim(_channel, height, width), cpu_device());
        if (channel == 1 && _channel == 3) {
            for (int i = 0; i < 3; i++) {
                target.get_block(Dim(i, 0, 0), Dim(i+1, height, width)).copy_from(*image);
            }
        }
        else if (channel == 3 && _channel == 1) {
            float s[3] = {0.299, 0.587, 0.114};
            for (int i = 0; i < 3; i++) {
                Tensor<DType> sub_img= image->get_block(Dim(i, 0, 0), Dim(i + 1, height, width));
                target.elem_add(target, sub_img, 0.0, s[i]);
            }
        }

        sample->set_feature_tensor(key, target);
    }
    return 0;
}

void TransImageChannel::read_data(std::string &config_line) {
    parse_from_string("channel", &config_line, &_channel);
    CHECK2(_channel == 3 || _channel == 1);
}
}
}

