//by zzxfl 2017.03.02
#include "trans_pix_mean_norm.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
;
int TransPixMeanNorm::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        const size_t channel = 3;
        CHECK2(image->get_c() == channel);
        image->add_tensor(_mean);
    }
    return 0;
}

void TransPixMeanNorm::read_data(std::string &config_line) {
    std::vector<float>value;
    parse_from_string("Stats", &config_line, &value);
    CHECK2(value.size() == 3);
    _mean.resize(Dim(value.size(), 1));
    for (size_t i = 0; i < value.size(); i++) {
        _mean.get_data()[i] = -value[i];
    }
}
}
}

