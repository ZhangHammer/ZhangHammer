// by zzxfl 2016.10.28
#include "trans_batch_reshape.h"
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_batch_sample.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

int TransBatchReshape::perform_trans(BaseBatchSample& data_batch) {
    for (auto key : data_batch.get_feature_keys()) {
        Tensor<DType>&feature = data_batch.get_feature_tensor(key);
        if (!has_key(key))continue;
        int num = (int)feature.get_size()[0];
        int all_count = 1;
        for (auto d : _dim) {
            all_count *= d;
        }
        CHECK2(all_count == (int)feature.get_size(1));
        if (_dim.size() == 1) {
            feature.reshape(Dim(num, _dim[0]));
        }
        else if (_dim.size() == 2) {
            feature.reshape(Dim(num, _dim[0], _dim[1]));
        }
        else if (_dim.size() == 3) {
            feature.reshape(Dim(num, _dim[0], _dim[1], _dim[2]));
        }
        else if (_dim.size() == 4) {
            feature.reshape(Dim(num, _dim[0], _dim[1], _dim[2], _dim[3]));
        }
        else {
            CHECK2(false);
        }
    }
    return 0;
}

void TransBatchReshape::read_data(std::string &config_line) {
    parse_from_string("Dim", &config_line, &_dim);
    INTER_LOG("TransBatchReshape: Dim size %d dim[0]%d", (int)_dim.size(), (int)_dim[0]);
    CHECK2(config_line.size() == 0);
}
}
}

