#include "trans_batch_reduce_label.h"
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_batch_sample.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

int TransBatchReduceLabel::perform_trans(BaseBatchSample& data_batch) {
    for (auto key : data_batch.get_label_keys()) {
        if (!has_key(key))continue;

        Tensor<DType>&label = data_batch.get_label_tensor(key);
        int batch_size = static_cast<int>(data_batch.get_batch_size());
        _tmp_label.resize(Dim(batch_size, 1));
        memcpy(_tmp_label.get_ptr(), (void*)(label.get_ptr() + batch_size), sizeof(float) * batch_size);
        label.resize(Dim(batch_size, 1));
        label.copy_from(_tmp_label);

        Tensor<int>&mask = data_batch.get_label_mask(key);
        _tmp_mask.resize(Dim(batch_size));
        memcpy(_tmp_mask.get_ptr(), mask.get_ptr(), sizeof(int) * batch_size);
        mask.resize(Dim(batch_size));
        mask.copy_from(_tmp_mask);
    }
    return 0;
}

void TransBatchReduceLabel::read_data(std::string &config_line) {
    CHECK2(config_line.size() == 0);
}
}
}

