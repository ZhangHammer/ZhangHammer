// by zzxfl 2016.10.28
#include "trans_change_background.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__

void TransChangeBackground::image_with_wave(cv::Mat& input, cv::Mat& output) {
    int height = input.rows;
    int width = input.cols;

    cv::Mat mask(height, width, CV_8UC1, cvScalar(0));
    float angle = (rand() % 100) / 100.f;
    int margin = (rand() % 100) / 100.f * 80 + 20;
    std::vector<int> line_start;
    for (int i = 0 - (height*sqrt(2) - height) / 2;
            i < height + (height*sqrt(2) - height) / 2;
            i = i + margin) {
        line_start.push_back(i);
    }

    std::vector<float> x;
    std::vector<std::vector<float>> y;
    std::vector<std::vector<float>> xx;
    std::vector<std::vector<float>> yy;
    for (int i = 0 - (height*sqrt(2) - height) / 2;
            i < height + (height*sqrt(2) - height) / 2;
            i = i + 1) {
        x.push_back(i);
    }

    float phi1 = (rand() % 10) + 6;
    float phi2 = phi1 / 2 * CV_PI;
    float amp1 = ((rand() % 50) / 100.f + 0.5)*margin;
    float amp2 = rand() % 10;

    float pi1 = (rand() % 100) / 100.f * CV_PI;
    float pi2 = 0;
    float offset1 = 0;
    float offset2 = 0;
    float tmp1 = CV_PI*phi1;
    float tmp2 = CV_PI*phi2;

    for (int i = 0; i < (int)line_start.size(); ++i) {
        offset1 = offset1 + tmp1;
        offset2 = offset2 + tmp2;
        std::vector<float> tmpy;
        std::vector<float> tmpxx;
        std::vector<float> tmpyy;
        for (size_t j = 0; j < x.size(); ++j) {
            tmpy.push_back(line_start[i] +
                           amp1*sin((x[j] + offset1) / phi1 + pi1) +
                           amp2*sin((x[j] + offset2) / phi2 + pi2));
            tmpxx.push_back((x[j] - width / 2)*cos(angle) -
                            (tmpy[j] - height / 2)*sin(angle) + width / 2);
            tmpyy.push_back((x[j] - width / 2)*sin(angle) +
                            (tmpy[j] - height / 2)*cos(angle) + height / 2);
        }
        y.push_back(tmpy);
        xx.push_back(tmpxx);
        yy.push_back(tmpyy);
    }

    cv::Point ** pt = new cv::Point*[line_start.size()];
    for (size_t i = 0; i < line_start.size(); ++i) {
        pt[i] = new cv::Point[xx[i].size()];
        for (size_t j = 0; j < xx[i].size(); ++j) {
            pt[i][j] = cv::Point(xx[i][j], yy[i][j]);
        }
    }
    int* arr = new int[line_start.size()];
    for (size_t i = 0; i < line_start.size(); ++i) {
        arr[i] = x.size();
    }
    int thick = std::max(2, rand() % 4);
    cv::polylines(mask, (const cv::Point **)pt, arr,
                  line_start.size(), 0, CV_RGB(255, 255, 255), thick);

    uchar value = rand() % 100 + 20;
    for (int i = 0; i<input.rows*input.cols; ++i) {
        if (mask.data[i]>0) {
            output.data[i * 3 + 0] = input.data[i * 3 + 0] * 0.5 + value;
            output.data[i * 3 + 1] = input.data[i * 3 + 1] * 0.5 + value;
            output.data[i * 3 + 2] = input.data[i * 3 + 2] * 0.5 + value;
        }
        else {
            output.data[i * 3 + 0] = input.data[i * 3 + 0];
            output.data[i * 3 + 1] = input.data[i * 3 + 1];
            output.data[i * 3 + 2] = input.data[i * 3 + 2];
        }
    }

    delete arr;
    for (size_t i = 0; i < line_start.size(); i++) {
        delete [](pt[i]);
    }
}

bool TransChangeBackground::change_background(cv::Mat& src, std::vector<cv::Mat>&bgimg, cv::Mat& sink) {
    //load claw3d2cm
    cv::Mat claw = _claw;
    cv::Mat channel[4];
    split(claw, channel);
    cv::Mat alpha_mask = channel[3];

    cv::Mat hsv;
    cvtColor(src, hsv, cv::COLOR_BGR2HSV);

    cv::Scalar lower_color1 = cv::Scalar(150, 20, 20);
    cv::Scalar upper_color1 = cv::Scalar(180, 255, 255);
    cv::Scalar lower_color2 = cv::Scalar(0, 20, 20);
    cv::Scalar upper_color2 = cv::Scalar(10, 255, 255);

    cv::Mat mask1;
    cv::Mat mask2;
    cv::Mat mask;
    cv::Mat maskclaw;
    cv::inRange(hsv, lower_color1, upper_color1, mask1);
    cv::inRange(hsv, lower_color2, upper_color2, mask2);
    cv::bitwise_or(mask1, mask2, mask);

    //腐蚀
    cv::erode(mask, mask, cv::Mat(10, 10, CV_8U), cv::Point(-1, -1), 1);
    int area = 0;
    for (int k = 0; k < mask.rows; k++) {
        for (int l = 0; l < mask.cols; l++) {
            float value = mask.at<uchar>(k, l);
            if (value > 0.0f) {
                area++;
            }
        }
    }

    if (area < mask.rows*mask.cols*0.0025) {
        return 0;
    }

    cv::dilate(mask, mask, cv::Mat(30, 30, CV_8U), cv::Point(-1, -1), 1);

    cv::bitwise_or(alpha_mask, mask, mask);

    std::vector<cv::Mat> channels;
    cv::split(src, channels);
    cv::bitwise_and(mask, channels[0], channels[0]);
    cv::bitwise_and(mask, channels[1], channels[1]);
    cv::bitwise_and(mask, channels[2], channels[2]);
    cv::Mat img_mask;

    cv::merge(channels, img_mask);
    for (int j = 0; j < 5; j++) {
        cv::Mat img_wave(_height, _width, CV_8UC3, cvScalar(0));
        image_with_wave(src, img_wave);

        for (int k = 0; k < mask.rows; k++) {
            for (int l = 0; l < mask.cols; l++) {
                float value = mask.at<uchar>(k, l);
                if (value > 0.0f) {
                    img_wave.at<cv::Vec3b>(k, l) = src.at<cv::Vec3b>(k, l);
                }
            }
        }
    }

    int j = rand() % bgimg.size();
    cv::Mat img_merge(_height, _width, CV_8UC3, cvScalar(0));

    for (int k = 0; k < mask.rows; k++) {
        for (int l = 0; l < mask.cols; l++) {
            float value = mask.at<uchar>(k, l);
            if (value > 0.0f) {
                img_merge.at<cv::Vec3b>(k, l) = src.at<cv::Vec3b>(k, l);
            }
            else {
                img_merge.at<cv::Vec3b>(k, l) = bgimg[j].at<cv::Vec3b>(k, l);
            }
        }
    }
    sink = img_merge;
    return true;
}

void TransChangeBackground::load_bg() {
    int width = _width;
    int height = _height;
    std::ifstream in(_bg_path.c_str());

    //Size dsize = Size(width, height);
    char buffer[1024];
    std::string pre_path = "";
    int idx = 0;
    for (int i = _bg_path.size() - 1; i >= 0; i--) {
        if (_bg_path[i] == '/') {
            idx = i;
            break;
        }
    }
    pre_path = _bg_path.substr(0, idx + 1);

    while (in.getline(buffer, 1024)) {
        std::string path = pre_path + std::string(buffer);
        cv::Mat read_mat = cv::imread(path.c_str());
        cv::Size dsize = cv::Size(width, height);
        cv::Mat img_r;
        resize(read_mat, img_r, dsize);
        _bg_img.push_back(img_r);
    }
    in.close();
}

void TransChangeBackground::read_data(std::string &config_line) {
    parse_from_string("claw_path", &config_line, &_claw_path);
    parse_from_string("bg_path", &config_line, &_bg_path);
    _claw = cv::imread(_claw_path.c_str(), CV_LOAD_IMAGE_UNCHANGED);
    load_bg();
}

int TransChangeBackground::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_8UC1: CV_8UC3);
        cv::Mat to(height, width, channel == 1 ? CV_8UC1: CV_8UC3);
        tensor_to_mat(*image, sink);
        /*更换背景成功*/
        if (change_background(sink, _bg_img, to)) {
            mat_to_tensor(to, *image);
        }
        else {
            INTER_LOG("change_background fail");
        }
    }
    return 0;
}
#endif

}
}
