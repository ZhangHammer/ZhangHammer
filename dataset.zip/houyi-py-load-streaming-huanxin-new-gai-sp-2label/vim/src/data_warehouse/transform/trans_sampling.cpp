// by zzxfl 2016.10.28
#include "trans_sampling.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
void TransSampling::read_data(std::string &config_line) {
    parse_from_string("Step", &config_line, &_step);
    parse_from_string("Start", &config_line, &_start);
    INTER_LOG("TransSampling: step %d start %d", _step, _start);
    CHECK2(config_line.size() == 0);
}

int TransSampling::perform_trans(BaseOneSample & data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    int start = _start;
    int check_frame_num = -1;

    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key))continue;
        int frame_num = sent->get_frame_num(key);
        int split_frame_num = (frame_num + _step - 1)/ _step;
        int cur_frame_num =
            start + (split_frame_num - 1) * _step >= frame_num ?
            (split_frame_num - 1) : split_frame_num;
        CHECK2((check_frame_num == -1) || (check_frame_num != -1 && check_frame_num == cur_frame_num));
        check_frame_num = cur_frame_num;
        if (cur_frame_num > 0) {
            Tensor<DType>& sent_mat = sent->get_feature_tensor(key);
            Tensor<DType>& mat = _mat;
            mat.resize(Dim(cur_frame_num, sent->get_frame_dim(key)), false);
            for (int sidx = 0; sidx < cur_frame_num; sidx ++) {
                int idx = start + sidx * _step;
                mat.copy_row(sent_mat, idx, sidx);
            }
            sent_mat.resize(mat.get_size(), false);
            sent_mat.copy_from(mat);
            sent->set_frame_num(key, cur_frame_num);
        } else {
            INTER_LOG("the split-sentence length is %d, will be ignored", cur_frame_num);
        }
    }

    for (auto key : sent->get_label_keys()) {
        if (!has_key(key)) {
            continue;
        }
        int frame_num = sent->get_frame_num(key);
        int split_frame_num = (frame_num + _step - 1)/ _step;
        int cur_frame_num =
            start + (split_frame_num - 1) * _step >= frame_num ?
            (split_frame_num - 1) : split_frame_num;
        CHECK2((check_frame_num == -1) || (check_frame_num != -1 && check_frame_num == cur_frame_num));
        check_frame_num = cur_frame_num;
        if (cur_frame_num > 0) {
            Tensor<DType>&sent_label = sent->get_label_tensor(key);
            Tensor<DType>&label = _label;
            label.resize(Dim(cur_frame_num, sent_label.get_size(1)), false);
            for (int sidx = 0; sidx < cur_frame_num; sidx ++) {
                int idx = start + sidx * _step;
                label.copy_row(sent_label, idx, sidx);
            }
            sent_label.resize(label.get_size(), false);
            sent_label.copy_from(label);
            sent->set_frame_num(key, cur_frame_num);
        }
    }
    _start = (_start + 1) % _step;
    return 0;
}
}
}
