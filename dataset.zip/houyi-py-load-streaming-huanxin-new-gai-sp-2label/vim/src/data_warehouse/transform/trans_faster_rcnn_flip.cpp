//by zzxfl 2017.03.20
#include "trans_faster_rcnn_flip.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
;

void TransFasterRcnnFlip::read_data(std::string &config_line) {
    config_line = config_line;
}

int TransFasterRcnnFlip::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample *sample = dynamic_cast<ImageOneSample*>(&data_pack);
#ifndef __CLOSE_RANDOM__
    if (rand() % 2 == 0)return 0;
#else
    return 0;
#endif

    CHECK2(sample->get_feature_keys().size() == 1);
    CHECK2(sample->get_label_keys().size() == 1);

    size_t width = 0;
    size_t height = 0;
    size_t channel = 0;

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))
            continue;
        Tensor<DType> *image = &sample->get_feature_tensor(key);
        width = image->get_w();
        height = image->get_h();
        channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);
        for (size_t k = 0; k < channel; k++) {
            for (size_t i = 0; i < height; i++) {
                Dim start(k, i, 0);
                DType* ptr = image->get_data(start);
                for (size_t j = 0; j < width >> 1; j++) {
                    std::swap(ptr[j], ptr[width - 1 -j]);
                }
            }
        }
    }

    for (auto key : sample->get_label_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>&label = sample->get_label_tensor(key);
        int num = label.get_element_count() / 5;
        //label前四个是坐标(xmin, ymin, xmax, ymax)，第五个是对应的物体类别
        for (int i = 0; i < num; i++) {
            float* label_ptr = label.get_data(Dim(i * 5));
            float xmin = label_ptr[0];
            float ymin = label_ptr[1];
            float xmax = label_ptr[2];
            float ymax = label_ptr[3];

            label_ptr[0] = float(width) - xmax;
            label_ptr[1] = ymin;
            label_ptr[2] = float(width) - xmin;
            label_ptr[3] = ymax;
        }
    }
    return 0;
}

}
}

