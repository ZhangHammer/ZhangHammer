// by zzxfl 2017.04.10
#include "trans_batch_transpose.h"
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_batch_sample.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

int TransBatchTranspose::perform_trans(BaseBatchSample& data_batch) {
    CHECK2(_reshape.size() == 4);
    CHECK2(_transpose.size() == 4);
    for (auto key : data_batch.get_feature_keys()) {
        if (!has_key(key))continue;

        Tensor<DType>&feature = data_batch.get_feature_tensor(key);
        std::vector<int>reshape;
        for (size_t i = 0; i < _reshape.size(); i++) {
            if (_reshape[i] == 0) {
                reshape.push_back(feature.get_size()[i]);
            }
            else if (_reshape[i] == -1)
                reshape.push_back(-1);
            else
                reshape.push_back(_reshape[i]);
        }

        size_t count = 1;
        int zero_count =0;
        int zero_idx = -1;
        for (size_t i = 0; i < reshape.size(); i++) {
            if (reshape[i] > 0) {
                count*=reshape[i];
            }
            else {
                zero_count++;
                zero_idx = i;
            }
        }
        CHECK2(zero_count <=1);
        if (zero_count == 1) {
            reshape[zero_idx] = feature.get_element_count() / count;
        }
        if (zero_count == 0)
            CHECK2(feature.get_element_count() == count);
        else {
            CHECK2(feature.get_element_count() == count * reshape[zero_idx]);
        }

        if (!has_key(key))continue;

        feature.reshape(Dim(reshape[0], reshape[1], reshape[2], reshape[3]));
        _tmp.resize(Dim(reshape[_transpose[0]], reshape[_transpose[1]], reshape[_transpose[2]], reshape[_transpose[3]]), false);

        for (int i = 0; i < feature.get_size()[0]; i ++) {
            for (int j1 = 0; j1 < feature.get_size()[1]; j1++) {
                for (int j2 = 0; j2 < feature.get_size()[2]; j2++) {
                    DType *data = feature.get_data(Dim(i, j1, j2, 0));
                    if (_transpose[3] != 3) {
                        for (int j3 = 0; j3 < feature.get_size()[3]; j3++) {
                            std::vector<int>idx = {i, j1, j2, j3};
                            _tmp.set_element(
                                Dim(idx[_transpose[0]],
                                    idx[_transpose[1]],
                                    idx[_transpose[2]],
                                    idx[_transpose[3]]),
                                data[j3]);
                        }
                    }
                    else {
                        std::vector<int>idx = {i, j1, j2};
                        DType* data1 = _tmp.get_data(Dim(idx[_transpose[0]], idx[_transpose[1]], idx[_transpose[2]], 0));
                        memcpy((void*)data1, (void*)data, sizeof(DType) * feature.get_size()[3]);
                    }
                }
            }
        }
        feature.reshape(_tmp.get_size());
        feature.copy_from(_tmp);
    }
    return 0;
}

void TransBatchTranspose::read_data(std::string &config_line) {
    parse_from_string("reshape", &config_line, &_reshape);
    parse_from_string("transpose", &config_line, &_transpose);

    INTER_LOG("TransBatchTranspose: Reshape size %d reshape[0]%d", (int)_reshape.size(), (int)_reshape[0]);
    INTER_LOG("TransBatchTranspose: Transpose size %d transpose[0]%d", (int)_transpose.size(), (int)_transpose[0]);

    CHECK2(config_line.size() == 0);
}
}
}

