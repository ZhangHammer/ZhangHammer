#include "trans_flip.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

void TransFlip::read_data(std::string &config_line) {
    config_line = config_line;
}

int TransFlip::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample *sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType> *image = &sample->get_feature_tensor(key);
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();
        CHECK2(channel == 1 || channel == 3);
#ifndef __CLOSE_RANDOM__
        if (rand() % 2 == 0) {
#else
        if (false) {
#endif
            for (size_t k = 0; k < channel; k++) {
                for (size_t i = 0; i < height; i++) {
                    Dim start(k, i, 0);
                    DType* ptr = image->get_data(start);
                    for (size_t j = 0; j < width >> 1; j++) {
                        std::swap(ptr[j], ptr[width - 1 -j]);
                    }
                }
            }
        }
    }

    return 0;
}

}
}

