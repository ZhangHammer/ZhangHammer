//by zhxfl 2018.05.17
#include "trans_vad_mean_mute.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "vec_ops.h"

namespace houyi {
namespace train {

TransVadMeanMute::TransVadMeanMute() : BaseTransformation() {
    _mute_mean.set_device(cpu_device());
}

int TransVadMeanMute::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence* sample = dynamic_cast<SpeechOneSentence*>(&data_pack);
   
    //CHECK2(sample->get_feature_keys().size() == 1);
    CHECK2(sample->get_label_keys().size() == 1);

    std::string feature_key = sample->get_feature_keys()[0];
    std::string label_key = sample->get_label_keys()[0];

    int frame_num = sample->get_frame_num(feature_key);
    int frame_dim = sample->get_frame_dim(feature_key);
    Tensor<DType>& label_tensor = sample->get_label_tensor(label_key);
    Tensor<DType>& feature_tensor = sample->get_feature_tensor(feature_key);

    _mute_mean.resize(Dim(frame_num, frame_dim));
    int count = 0;
    
    for (int i = 0; i < frame_num; ++i) {
        //开头开始，连续静音求均值
        DType* feature_ptr = feature_tensor.get_data(Dim(i, 0));
        
        if (label_tensor.get_data()[i] == _label_id) {
            if (1.0 * rand() / RAND_MAX <= _ratio) {
                for (int j = 0; j < frame_dim; ++j) {
                    _mute_mean.get_data()[j] += feature_ptr[j];
                }
                ++count;
            }
        }
    }

    if (count) {
        _mute_mean.get_block(Dim(0, 0), Dim(1, frame_dim)).mul(1.0f / count);
    }
    for (int i = 1; i < (int)frame_num; ++i) {
        _mute_mean.copy_row(_mute_mean, 0, i);
    }

    //插入一个新的feature
    SpeechOneFeature* speech_one_feature = 
        new SpeechOneFeature(FBANK_TYPE, frame_num, frame_dim, 0);

    speech_one_feature->set_feature(_mute_mean);
    sample->insert_feature(_feature_name, *speech_one_feature);
    return 0;
}

void TransVadMeanMute::read_data(std::string &config_line) {
    parse_from_string("featureName", &config_line, &_feature_name);
    INTER_LOG("featureName%s", _feature_name.c_str());
    
    parse_from_string("ratio", &config_line, &_ratio);
    INTER_LOG("ratio %f", _ratio);

    parse_from_string("labelId", &config_line, &_label_id);
    INTER_LOG("labelId %d", _label_id);
}

}
}
