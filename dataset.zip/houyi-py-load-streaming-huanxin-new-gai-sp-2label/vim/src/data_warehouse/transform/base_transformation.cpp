//by zzxfl 2016.10.28
#include "base_transformation.h"
#include "text_utils.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "trans_add_deltas.h"
#include "trans_crop.h"
#include "trans_change_background.h"
#include "trans_affine.h"
#include "trans_delay.h"
#include "trans_flip.h"
#include "trans_mean_norm.h"
#include "trans_mean_variance_norm.h"
#include "trans_sampling.h"
#include "trans_splice.h"
#include "trans_wakeup.h"
#include "trans_wakeup_crop.h"
#include "trans_area_aspect_crop.h"
#include "trans_random_resize.h"
#include "trans_image_resize.h"
#include "trans_pix_mean_norm.h"
#include "trans_faster_rcnn_flip.h"
#include "trans_faster_rcnn_resize.h"
#include "trans_shuffle_sentence.h"
#include "trans_pca_lighting.h"
#include "trans_saturation.h"
#include "trans_contrast.h"
#include "trans_brightness.h"
#include "trans_pix_mean_scale_norm.h"
#include "trans_bbox_affine.h"
#include "trans_image_channel.h"
#include "trans_image_lighting.h"
#include "trans_discrete_tts.h"
#include "trans_wakeup_6720.h"
#include "trans_replace_label.h"
#include "trans_lr_label.h"
#include "trans_vad_splice.h"
#include "trans_vad_mean_mute.h"
#include "trans_vad_merge_feature.h"
#include "trans_remove_illegal.h"
#include "trans_vad_mean_variance_norm.h"
#include "trans_unique_label.h"

namespace houyi {
namespace train {
BaseTransformation* BaseTransformation::new_trans_of_type(const std::string &type) {
    BaseTransformation* ans = NULL;
    if (type == "meanNorm") {
        ans = new TransMeanNorm();
    }
    else if (type == "flip") {
        ans = new TransFlip();
    }
    else if (type == "MeanVarianceNorm") {
        ans = new TransMeanVarianceNorm();
    }
    else if (type == "crop") {
        ans = new TransCrop();
    }
    else if (type == "AddDeltas") {
        ans = new TransAddDeltas();
    }
    else if (type == "Delay") {
        ans = new TransDelay();
    }
    else if (type == "Sampling") {
        ans = new TransSampling();
    }
    else if (type == "Splice") {
        ans = new TransSplice();
    }
    else if (type == "wakeup") {
        ans = new TransWakeup();
    }
    else if (type == "wakeupCrop") {
        ans = new TransWakeupCrop();
    }
    else if (type == "areaAspectCrop") {
        ans = new TransAreaAspectCrop();
    }
    else if (type == "pixMeanNorm") {
        ans = new TransPixMeanNorm();
    }
    else if (type == "fasterRcnnFlip") {
        ans = new TransFasterRcnnFlip();
    }
    else if (type == "shuffleSentence") {
        ans = new TransShuffleSentence();
    }
    else if (type == "pcaLighting") {
        ans = new TransPcaLighting();
    }
    else if (type == "saturation") {
        ans = new TransSaturation();
    }
    else if (type == "contrast") {
        ans = new TransContrast();
    }
    else if (type == "brightness") {
        ans = new TransBrightness();
    }
    else if (type == "pixMeanScaleNorm") {
        ans = new TransPixMeanScaleNorm();
    }
    else if (type == "imageChannel") {
        ans = new TransImageChannel();
    }
    else if (type == "discreteTTS") {
        ans = new TransDiscreteTTS();
    }
    else if (type == "trans_wake_up_6720") {
        ans = new TransWakeup6720();
    }
    else if (type == "replaceLabel") {
        ans = new TransReplaceLabel();
    }
    else if (type == "uniqueLabel") {
        ans = new TransUniqueLabel();
    }
    else if (type == "lrLabel") {
        ans = new TransLrLabel();
    }
    else if (type == "vadSplice") {
        ans = new TransVadSplice();
    }
    else if (type == "vadMeanMute") {
        ans = new TransVadMeanMute();
    }
    else if (type == "vadMergeFeature") {
        ans = new TransVadMergeFeature();
    }
    else if (type == "removeIllegal") {
        ans = new TransRemoveIllegal();
    }
    else if (type == "vadMeanVarianceNorm") {
        ans = new TransVadMeanVarianceNorm();
    }
#ifdef __WITH_OPENCV__
    else if (type == "bboxAffine") {
        ans = new TransBboxAffine();
    }
    else if (type == "affine") {
        ans = new TransAffine();
    }
    else if (type == "changeBackground") {
        ans = new TransChangeBackground();
    }
    else if (type == "randomResize") {
        ans = new TransRandomResize();
    }
    else if (type == "imageResize") {
        ans = new TransImageResize();
    }
    else if (type == "fasterRcnnResize") {
        ans = new TransFasterRcnnResize();
    }
    else if (type == "lighting") {
        ans = new TransImageLighting();
    }
#endif
    else {
        INTER_CHECK(false, "Unknown type: %s", type.c_str());
    }
    return ans;
}

void BaseTransformation::read_keys(std::string &config_line) {
    std::vector<std::string>tmp_keys;
    parse_from_string("keys", &config_line, &tmp_keys);
    for (auto key : tmp_keys) {
        _keys.insert(key);
    }
}

BaseTransformation* BaseTransformation::read(std::string &config_line) {
    std::string type;
    std::vector<std::string>tmp_keys;
    parse_from_string("type", &config_line, &type);
    BaseTransformation *trans = new_trans_of_type(type);
    trans->read_keys(config_line);
    trans->read_data(config_line);
    /*检查config_line是否都解析了，如果存残留项，报错提醒*/
    trim(&config_line);
    CHECK(!is_token(config_line),
            "data transform residual term [%s]", 
            config_line.c_str());
    return trans;
}
}
}
