//by zzxfl 2017.05.10
#include "trans_saturation.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include <cmath>

namespace houyi {
namespace train {

void TransSaturation::blend(Tensor<DType>&img1, Tensor<DType>&img2, float alpha) {
    img1.elem_add(img1, img2, alpha,  1.0 - alpha);
}

void TransSaturation::gray_scale(Tensor<DType>&img) {
    CHECK2(img.get_c() == 3);
    _gray.resize(img.get_size());
    _gray.zero();
    float s[3] = {0.299, 0.587, 0.114};
    int h = _gray.get_h();
    int w = _gray.get_w();

    Tensor<DType> sub_gray = _gray.get_block(Dim(0, 0, 0), Dim(1, h, w));
    for (int i = 0; i < 3; i++) {
        Tensor<DType> sub_img = img.get_block(Dim(i, 0, 0), Dim(i + 1, h, w));
        sub_gray.elem_add(sub_gray, sub_img, 0.0, s[i]);
    }

    _gray.get_block(Dim(1, 0, 0), Dim(2, h, w)).copy_from(sub_gray);
    _gray.get_block(Dim(2, 0, 0), Dim(3, h, w)).copy_from(sub_gray);
}

int TransSaturation::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);

    Tensor<DType>alpha {Dim(1), cpu_device()};
    for (int i = 0; i < (int)alpha.get_element_count(); i++) {
#ifndef __CLOSE_RANDOM__
        alpha.get_data()[i] = (rand() / double(RAND_MAX)) * 2.0f  * _saturation - _saturation;
#else
        alpha.get_data()[i] = 0;
#endif
    }


    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        const size_t channel = 3;
        CHECK2(image->get_c() == channel);

        gray_scale(*image);
        blend(*image, _gray, 1.0 + alpha.get_data()[0]);
    }
    return 0;
}

void TransSaturation::read_data(std::string &config_line) {
    parse_from_string("saturation", &config_line, &_saturation);
}
}
}

