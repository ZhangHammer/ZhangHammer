// by zzxfl 2017.04.10
#include "trans_shuffle_sentence.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
int TransShuffleSentence::perform_trans(BaseOneSample &data_pack) {
#ifndef __CLOSE_RANDOM__
    if (rand() % 8 != 0)
        return 0;
#else
    return 0;
#endif

    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    std::string label_key = sent->get_label_keys()[0];
    CHECK2(sent->get_label_keys().size() == 1);
    CHECK2(sent->get_feature_keys().size() == 1);

    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key)) continue;
        int frame_num = sent->get_frame_num(key);
        int frame_dim = sent->get_frame_dim(key);
        int label_dim = sent->get_label_dim(label_key);
        Tensor<DType>& label_tensor = sent->get_label_tensor(label_key);
        Tensor<DType>& feature_tensor = sent->get_feature_tensor(key);

        Tensor<DType>&swap_feature = _swap_feature;
        Tensor<DType>&swap_label = _swap_label;
        swap_feature.resize(feature_tensor.get_size(), false);
        swap_label.resize(label_tensor.get_size(), false);

        std::vector<std::pair<int, int>>idx_vec;
        int start_idx = 0;
        for (int ii = 1; ii < frame_num - 1; ii++) {
            if (label_tensor.get_data()[ii] == _edge_id && label_tensor.get_data()[ii + 1] != _edge_id) {
                idx_vec.push_back(std::make_pair(start_idx, ii));
                start_idx = ii;
            }
        }

        if (start_idx != frame_num) {
            idx_vec.push_back(std::make_pair(start_idx, frame_num));
        }

        if (idx_vec.size() <= 5)return 0;
        //for (int i = 0; i < (int) idx_vec.size() - 1; i++) {
        //    CHECK2(idx_vec[i].second == idx_vec[i + 1].first - 1);
        //}
        //CHECK2(idx_vec.back().second == frame_num - 1);
        std::random_shuffle(idx_vec.begin()+1, idx_vec.end()-1);
        int cur_idx = 0;
        for (int ii = 0; ii < (int) idx_vec.size(); ii++) {
            int start = idx_vec[ii].first;
            int end = idx_vec[ii].second;
            int cur_len = end - start;
            //copy feature
            DType* from = feature_tensor.get_data(Dim(start, 0));
            DType* to = swap_feature.get_data(Dim(cur_idx, 0));
            memcpy(to, from, sizeof(DType) * frame_dim * cur_len);

            //copy label
            DType* from1 = label_tensor.get_data(Dim(start, 0));
            DType* to1 = swap_label.get_data(Dim(cur_idx, 0));
            memcpy(to1, from1, sizeof(int) * label_dim * cur_len);
            cur_idx += cur_len;
        }

        CHECK2(cur_idx == frame_num);

        //copy
        CHECK2(label_tensor.sum() == swap_label.sum());
        //CHECK2(fabs(feature_tensor.sum() - swap_feature.sum()) < 2);
        feature_tensor.copy_from(swap_feature);
        label_tensor.copy_from(swap_label);
    }
    return 0;
}

void TransShuffleSentence::read_data(std::string &config_line) {
    parse_from_string("edgeId", &config_line, &_edge_id);
    INTER_LOG("edgeId %d ", _edge_id);
    INTER_CHECK(_edge_id != -1, "please config edgeId");
    CHECK2(config_line.size() == 0);
}

}
}

