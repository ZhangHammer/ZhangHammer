// by zzxfl 2017.05.18
#include "trans_batch_sampling.h"
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_batch_sample.h"
#include "speech_batch_sample.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
int TransBatchSampling::perform_trans(BaseBatchSample& data_batch) {
    SpeechBatchSample& sent_batch = *(static_cast<SpeechBatchSample*>(&data_batch));

    int check_frame_num = -1;
    //label
    for (auto key : sent_batch.get_label_keys()) {
        if (!has_key(key))continue;

        int batch_size = sent_batch.get_batch_size();
        int frame_num = sent_batch.get_frame_num(key);
        int label_dim = sent_batch.get_label_dim(key);
        int split_frame_num = (frame_num + _step - 1) / _step;

        //[frame_num * batch_size, frame_dim]
        int cur_frame_num =
            _start + (split_frame_num - 1) * _step >= frame_num ?
            (split_frame_num - 1) : split_frame_num;

        CHECK2((check_frame_num == -1) || (check_frame_num != -1 && check_frame_num == cur_frame_num));
        check_frame_num = cur_frame_num;

        if (cur_frame_num > 0) {
            Tensor<DType>&label_tensor = sent_batch.get_label_tensor(key);
            Tensor<int>&label_mask = sent_batch.get_label(key).get_mask();

            CHECK2(batch_size * frame_num == (int)label_tensor.get_size(0));
            CHECK2(label_dim == (int)label_tensor.get_size(1));

            _label.resize(Dim(batch_size * cur_frame_num, 1));
            _mask.resize(Dim(batch_size * cur_frame_num));

            for (int sidx = 0; sidx < cur_frame_num; sidx++) {
                int idx = _start + sidx * _step;
                //label
                Tensor<DType> sub_tensor1 = _label.get_block(Dim(sidx * batch_size, 0), Dim((sidx + 1) * batch_size, label_dim));
                Tensor<DType> sub_tensor2 = label_tensor.get_block(Dim(idx *  batch_size, 0),
                        Dim((idx + 1) * batch_size, label_dim));
                sub_tensor1.copy_from(sub_tensor2);
                //mask
                Tensor<int> sub_mask1 = _mask.get_block(Dim(sidx * batch_size), Dim((sidx + 1) * batch_size));
                Tensor<int> sub_mask2 = label_mask.get_block(Dim(idx * batch_size), Dim((idx + 1) * batch_size));
                sub_mask1.copy_from(sub_mask2);
            }

            label_tensor.resize(_label.get_size());
            label_tensor.copy_from(_label);

            label_mask.resize(_mask.get_size());
            label_mask.copy_from(_mask);

            sent_batch.set_frame_num(key, cur_frame_num);
        }
    }

    for (auto key : sent_batch.get_feature_keys()) {
        if (!has_key(key))continue;
        int batch_size = sent_batch.get_batch_size();
        int frame_num = sent_batch.get_frame_num(key);
        int frame_dim = sent_batch.get_frame_dim(key);
        Tensor<DType>&feature_tensor = data_batch.get_feature_tensor(key);
        Tensor<int>&feature_mask = data_batch.get_feature(key).get_mask();
        CHECK2(frame_num * batch_size == (int)feature_tensor.get_size(0));
        CHECK2(frame_dim == (int)feature_tensor.get_size(1));

        int split_frame_num = (frame_num + _step - 1) / _step;
        int cur_frame_num =
            _start + (split_frame_num - 1) * _step >= frame_num ?
            (split_frame_num - 1) : split_frame_num;

        CHECK2((check_frame_num == -1) || (check_frame_num != -1 && check_frame_num == cur_frame_num));
        check_frame_num = cur_frame_num;

        if (cur_frame_num > 0) {
            _mat.resize(Dim(cur_frame_num * batch_size, frame_dim));
            _mask.resize(Dim(cur_frame_num * batch_size));
            for (int sidx = 0; sidx < cur_frame_num; sidx ++) {
                int idx = _start + sidx * _step;
                //feature
                Tensor<DType>sub_mat1 = _mat.get_block(Dim(sidx * batch_size, 0),
                                                      Dim((sidx + 1) * batch_size, frame_dim));
                Tensor<DType>sub_mat2 = feature_tensor.get_block(Dim(idx * batch_size, 0),
                                        Dim((idx + 1) * batch_size, frame_dim));
                sub_mat1.copy_from(sub_mat2);

                //mask
                Tensor<int> sub_mask1 = _mask.get_block(Dim(sidx * batch_size), Dim((sidx + 1) * batch_size));
                Tensor<int> sub_mask2 = feature_mask.get_block(Dim(idx * batch_size), Dim((idx + 1) * batch_size));
                sub_mask1.copy_from(sub_mask2);
            }
            sent_batch.set_feature_tensor(key, _mat);

            feature_mask.resize(_mask.get_size());
            feature_mask.copy_from(_mask);

            sent_batch.set_frame_num(key, cur_frame_num);
        }
        else {
            INTER_LOG("the split-sentence length is %d, will be ignored", cur_frame_num);
        }
    }
#ifndef __CLOSE_RANDOM__
    _start = (_start + 1) % _step;
#endif
    return 0;
}

void TransBatchSampling::read_data(std::string &config_line) {
    parse_from_string("Start", &config_line, &_start);
    parse_from_string("Step", &config_line, &_step);

    INTER_LOG("TransBatchSampling: start size %d", _start);
    INTER_LOG("TransBatchSampling: step size %d", _step);

    CHECK2(config_line.size() == 0);
}
}
}

