//by zhxfl 2018.05.17
#include "trans_vad_merge_feature.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "vec_ops.h"

namespace houyi {
namespace train {

TransVadMergeFeature::TransVadMergeFeature() : BaseTransformation() {
    _feature.set_device(cpu_device());
}

int TransVadMergeFeature::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence* sample = dynamic_cast<SpeechOneSentence*>(&data_pack);
   
    //CHECK2(sample->get_feature_keys().size() == 1);
    CHECK2(sample->get_label_keys().size() == 1);

    std::vector<std::string>& feature_key = sample->get_feature_keys();

    size_t frame_num = 0;
    size_t frame_dim = 0;

    for (auto& key : feature_key) { 
        if (!has_key(key)) {
            continue;
        }
        frame_dim += sample->get_frame_dim(key);
        if (frame_num) {
            CHECK2((int)frame_num == (int)sample->get_frame_num(key));
        }
        frame_num = sample->get_frame_num(key);
    }

    CHECK2(frame_num);

    // merge feature tensor 
    _feature.resize(Dim(frame_num, frame_dim), false);

    int cur_frame_dim = 0; 
    for (auto& key : feature_key) {
        if (!has_key(key)) {
            continue;
        }
        int frame_num = sample->get_frame_num(key);
        int frame_dim = sample->get_frame_dim(key);
        Tensor<DType>& tmp = sample->get_feature_tensor(key);
        Tensor<DType> tmp1 = _feature.get_block(Dim(0, cur_frame_dim),
                Dim(frame_num, cur_frame_dim + frame_dim));
        tmp1.copy_from(tmp);
        cur_frame_dim += frame_dim;
    }

    //插入一个新的feature
    SpeechOneFeature* speech_one_feature = 
        new SpeechOneFeature(FBANK_TYPE, frame_num, frame_dim, 0);

    speech_one_feature->set_feature(_feature);
    sample->insert_feature(_feature_name, *speech_one_feature);

    return 0;
}

void TransVadMergeFeature::read_data(std::string &config_line) {
    parse_from_string("featureName", &config_line, &_feature_name);
    INTER_LOG("featureName %s", _feature_name.c_str());
}

}
}
