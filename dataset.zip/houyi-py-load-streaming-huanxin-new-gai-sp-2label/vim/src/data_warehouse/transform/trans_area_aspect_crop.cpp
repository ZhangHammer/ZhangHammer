//by zzxfl 2017.01.07
#include "trans_area_aspect_crop.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransAreaAspectCrop::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = static_cast<ImageOneSample*>(&data_pack);
#ifndef __CLOSE_RANDOM__
    float s = _aspect_ratio[0] + 1.0 * rand() / RAND_MAX * (_aspect_ratio[1] - _aspect_ratio[0]);
    float a = _area_ratio[0] + 1.0 * rand() / RAND_MAX * (_area_ratio[1] - _area_ratio[0]);
#else
    float s = (_aspect_ratio[1] - _aspect_ratio[0]) / 2;
    float a = (_area_ratio[1] - _area_ratio[0]) / 2;
#endif

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &sample->get_feature_tensor(key);
        

        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        size_t crop_width = std::sqrt(1.0 * width * height * a * s);
        size_t crop_height = std::sqrt(1.0 * width * height * a / s);
        if (crop_width > width) {
            float tmp = 1.0f * width / crop_width;
            crop_width = width;
            crop_height = height * tmp;
        }
        if (crop_height > height) {
            float tmp = 1.0f * height / crop_height;
            crop_height = height;
            crop_width = tmp * width;
        }
        CHECK2(width >= crop_width);
        CHECK2(height >= crop_height);

       // Tensor<DType>target(Dim(channel, crop_height, crop_width), cpu_device());
        Tensor<DType>&target = _tmp;
        target.resize(Dim(channel, crop_height, crop_width), false);

        size_t skip_w_max = width - crop_width;
        size_t skip_h_max = height - crop_height;

        size_t skip_w = 0;
        size_t skip_h = 0;
#ifndef __CLOSE_RANDOM__
        skip_w = 1.0 * rand() / RAND_MAX * skip_w_max + 0.1;
        skip_h = 1.0 * rand() / RAND_MAX * skip_h_max + 0.1;
#else
        skip_w = 1.0 * skip_w_max / 2 + 0.1;
        skip_h = 1.0 * skip_h_max / 2 + 0.1;
#endif
        for (size_t k = 0; k < channel; k++) {
            for (size_t j = 0; j < crop_height; j++) {
                DType* ptr1 = image->get_data(Dim(k, j + skip_h, skip_w));
                DType* ptr2 = target.get_data(Dim(k, j, 0));
                memcpy(ptr2, ptr1, sizeof(DType) * crop_width);
            }
        }
        sample->set_feature_tensor(key, target);
    }
    return 0;
}

void TransAreaAspectCrop::read_data(std::string &config_line) {
    parse_from_string("aspectRatio", &config_line, &_aspect_ratio);
    parse_from_string("areaRatio", &config_line, &_area_ratio);

    CHECK(_aspect_ratio.size() == 0 || _aspect_ratio.size() == 2, "aspect ratio size must be 2");
    CHECK(_area_ratio.size() == 0 || _area_ratio.size() == 2, "area ratio size must be 2");

    INTER_LOG("aspect_ratio %f %f", _aspect_ratio[0], _aspect_ratio[1]);
    INTER_LOG("area_ratio %f %f", _area_ratio[0], _area_ratio[1]);
}

}
}
