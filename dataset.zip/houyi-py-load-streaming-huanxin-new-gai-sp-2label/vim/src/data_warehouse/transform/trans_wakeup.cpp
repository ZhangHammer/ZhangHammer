//by zzxfl 2016.10.28
#include "trans_wakeup.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransWakeup::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &sample->get_feature_tensor(key);

        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();
        size_t new_height = _threshold;
        size_t skip = (height) / new_height;
        if (height == _threshold)
            continue;
        CHECK2(height >= _threshold);

        CHECK2(channel == 1 || channel == 3);
        CHECK2(skip > 0);

        Tensor<DType>target(Dim(channel, new_height, width), cpu_device());
        target.zero();

        for (size_t c = 0; c < channel; c++) {
            for (size_t j = 0; j < new_height; j++) {
                int curskip = 0;
                DType* ptr2 = target.get_data(Dim(c, j, 0));
                for (size_t f = 0; f < skip; f++) {
                    size_t cur_height = j * skip + f;
                    if (cur_height < image->get_h())
                    {
                        curskip ++;
                        DType* ptr1 = image->get_data(Dim(c, cur_height, 0));
                        for (size_t h = 0; h < target.get_w(); h++) {
                            ptr2[h] += ptr1[h];
                        }
                    }
                }
                //求平均
                for (size_t h = 0; h < target.get_w(); h++) {
                    ptr2[h] /= curskip;
                }
            }
        }
        sample->set_feature_tensor(key, target);
    }
    return 0;
}

void TransWakeup::read_data(std::string &config_line) {
    parse_from_string("threshold", &config_line, &_threshold);
    INTER_LOG("TransWakeup: threshold %d", (int)_threshold);
}

}
}
