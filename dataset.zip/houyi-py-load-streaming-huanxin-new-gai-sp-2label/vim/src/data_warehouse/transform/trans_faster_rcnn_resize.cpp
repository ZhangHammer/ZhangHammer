// by zzxfl 2017.02.17
#include "trans_faster_rcnn_resize.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__

void TransFasterRcnnResize::read_data(std::string &config_line) {
    parse_from_string("minEdge", &config_line, &_min_edge);
    if (_min_edge.size() == 2) {
        CHECK(_min_edge[0] <= _min_edge[1], "_min_edge[0] must <= _min_edge[1]");
    }
    parse_from_string("maxEdge", &config_line, &_max_edge);
    for (auto i : _min_edge) {
        INTER_LOG("TransFasterRcnnResize: minEdge %d", i);
    }
    INTER_LOG("TransFasterRcnnResize: maxEdge %d", _max_edge);
}

int TransFasterRcnnResize::perform_trans(BaseOneSample &data_pack) {
    const int linears[4] = {cv::INTER_NEAREST, cv::INTER_LINEAR, cv::INTER_CUBIC, cv::INTER_AREA} ;

    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    std::map<std::string , float>&scale_map = sample->get_scale();
    CHECK2(sample->get_feature_keys().size() == 1 && sample->get_label_keys().size() == 1);

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_32FC1: CV_32FC3);
        tensor_to_mat(*image, sink);

        int new_width = (int)width;
        int new_height = (int)height;
        int new_channel = (int)channel;

        int min_edge = -1;
        srandom(time(NULL));
        if (_min_edge.size() == 2) {
#ifndef __CLOSE_RANDOM__
            min_edge = random() % (_min_edge[1] - _min_edge[0] + 1) + _min_edge[0];
#else
            min_edge = _min_edge[0];
#endif
        }
        else if (_min_edge.size() == 1) {
            min_edge = _min_edge[0];
        }
        else {
            CHECK(false, "min edge error");
        }
        DType scale1 = 0.0f;
        DType scale2 = 1.0f;
        //height是小边
        if (new_width > new_height) {
            scale1 = (1.0 * min_edge) / new_height;
            new_height = min_edge;
            new_width = min_edge * (width * 1.0f) / height;

            if (new_width > _max_edge) {
                scale2 = (1.0 * _max_edge) / new_width;
                new_width = _max_edge;
                new_height = scale2 * new_height;
            }
        }
        //width是小边
        else {
            scale1 = (1.0 * min_edge)/ new_width;
            new_width = min_edge;
            new_height = min_edge * (1.0f * height) / width;

            if (new_height > _max_edge) {
                scale2 = (1.0 *_max_edge) / new_height;
                new_height = _max_edge;
                new_width = scale2 * new_width;
            }
        }

        CHECK2(new_width <= _max_edge);
        CHECK2(new_height <=  _max_edge);
        scale_map[key] = 1.0 * scale1 * scale2;

        cv::Mat to = cv::Mat(new_height, new_width, new_channel == 1 ? CV_32FC1:CV_32FC3);
        cv::resize(sink, to, to.size(), linears[rand() % 4]);
        image->resize(Dim(new_channel, new_height, new_width));
        sample->set_width(key, new_width);
        sample->set_height(key, new_height);
        sample->set_channel(key, new_channel);

        mat_to_tensor(to, *image);

        //DOTO
        //load data.bin for caffe


        //to do with label
        std::string label_keys = sample->get_label_keys()[0];
        scale_map[label_keys] = 1.0 * scale1 * scale2;
        Tensor<DType>&label_tensor = sample->get_label_tensor(label_keys);
        for (size_t i = 0; i < label_tensor.get_element_count(); i++) {
            if ((i + 1) % 5 == 0) continue;
            label_tensor.get_data()[i] *= 1.0 * scale1 * scale2;
        }
        if (false)
            //if (true)
        {
            FILE* file = fopen("data.bin", "r");
            int num = -1;
            fscanf(file, "%d %d %d %d", &num, &new_channel, &new_height, &new_width);
            image->resize(Dim(new_channel, new_height, new_width));
            sample->set_width(key, new_width);
            sample->set_height(key, new_height);
            sample->set_channel(key, new_channel);
            for (int ff = 0; ff < (int)image->get_element_count(); ff++) {
                fscanf(file, "%f", image->get_data() + ff);
            }
            fclose(file);

            Tensor<DType>&label = sample->get_label_tensor(sample->get_label_keys()[0]);
            sample->set_label_dim(sample->get_label_keys()[0], 5);
            label.resize(Dim(5));
            label.get_data()[0] = 52.7999992371;
            label.get_data()[1] = 16.0000000000;
            label.get_data()[2] = 715.2000122070;
            label.get_data()[3] = 467.2000122070;
            label.get_data()[4] = 20.0000000000;
        }
    }

    return 0;
}
#endif

}
}
