// by zzxfl 2018.05.29
#include "trans_vad_mean_variance_norm.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "vec_ops.h"

namespace houyi {
namespace train {
int TransVadMeanVarianceNorm::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    Tensor<DType>& mean = sent->get_feature_tensor(_feature_name);
    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>&src = sent->get_feature_tensor(key);
        int dim = (int)mean.get_size(1);
        CHECK2(sent->get_frame_dim(key) % dim == 0);
        //int count = (int) src.get_element_count();
        for (size_t i = 0; i < src.get_size(0); ++i) {
            DType* p_src = src.get_data(Dim(i, 0));
            for (size_t j = 0; j < src.get_size(1); ++j) {
                p_src[j] = (p_src[j] - mean.get_data()[j % dim]) * _std_inv_var.get_data()[j % dim];
            }
        }
    }
    return 0;
}

void TransVadMeanVarianceNorm::read_data(std::string &config_line) {
    std::string file_stats;
    parse_from_string("Stats", &config_line, &file_stats);
    std::ifstream fin(file_stats.c_str());
    INTER_CHECK(!fin.fail(), "Open file error %s", file_stats.c_str());
    parse_from_string("featureName", &config_line, &_feature_name);
    INTER_LOG("featureName %s", _feature_name.c_str());

    char str[4096];
    float m = 0.0f;
    float v = 0.0f;
    std::vector<DType> mean;
    std::vector<DType> std_inv_var;

    while (fin.getline(str, 4096)) {
        sscanf (str, "%f %f", &m, &v);
        mean.push_back(m);
        std_inv_var.push_back(v);
    }
    fin.close();

    for (size_t i = 0; i < mean.size(); ++i) {
        std_inv_var[i] = 1.0f / sqrt(std_inv_var[i]);
        if (std_inv_var[i] > 100000.0f) {
            std_inv_var[i] = 100000.0f;
        }
    }

    _mean.resize(Dim(mean.size()));
    _std_inv_var.resize(Dim(std_inv_var.size()));

    memcpy((char*)_mean.get_data(), (char*)&mean[0], sizeof(DType) * mean.size());
    memcpy((char*)_std_inv_var.get_data(), (char*)&std_inv_var[0], sizeof(DType) * std_inv_var.size());
}
}
}
