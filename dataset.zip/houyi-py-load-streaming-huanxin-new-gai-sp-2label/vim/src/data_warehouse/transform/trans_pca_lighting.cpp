//by zzxfl 2017.05.09
#include "trans_pca_lighting.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include <cmath>

namespace houyi {
namespace train {
int TransPcaLighting::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    //随机数,方差为0.1,均值为0
    Tensor<DType>alpha {Dim(1, 3), cpu_device()};

    for (int i =0; i < (int)alpha.get_element_count(); i++) {
#ifndef __CLOSE_RANDOM__
        double number = _distribution(_generator);
        alpha.get_data()[i] = number;
#else
        alpha.get_data()[i] = 0;

#endif
    }

    Tensor<DType>tmp {Dim(3, 3), cpu_device()};
    tmp.copy_from(_eigvec);
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j ++) {
            tmp.get_data()[i * 3 + j] *= alpha.get_data()[j] * _eigval.get_data()[j];
        }
    }

    Tensor<DType>rgb {Dim(3, 1), cpu_device()};
    for (int i = 0; i < 3; i++) {
        rgb.get_data()[i] = tmp.get_data()[i * 3 + 0] +
                            tmp.get_data()[i * 3 + 1] +
                            tmp.get_data()[i * 3 + 2];
        rgb.get_data()[i] *= 256;
        //INTER_LOG("%f %f %f", rgb.get_data()[0], rgb.get_data()[1], rgb.get_data()[2]);
    }

    std::swap(rgb.get_data()[0], rgb.get_data()[2]);

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        const size_t channel = 3;
        CHECK2(image->get_c() == channel);

        image->add_tensor(rgb);

    }
    return 0;
}

void TransPcaLighting::read_data(std::string &config_line) {
    std::vector<float>value;
    parse_from_string("eigval", &config_line, &value);
    CHECK2(value.size() == 3);
    _eigval.resize(Dim(value.size(), 1));
    for (size_t i = 0; i < value.size(); i++) {
        _eigval.get_data()[i] = value[i];
    }

    value.clear();
    parse_from_string("eigvec", &config_line, &value);
    CHECK2(value.size() == 9);
    _eigvec.resize(Dim(3, 3));
    for (size_t i = 0; i < value.size(); i++) {
        _eigvec.get_data()[i] = value[i];
    }
}
}
}

