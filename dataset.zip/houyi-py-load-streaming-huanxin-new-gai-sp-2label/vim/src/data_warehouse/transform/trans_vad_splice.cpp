// by zzxfl 2018.05.10
#include "trans_vad_splice.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransVadSplice::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);

    int label_frame_num = sent->get_frame_num(sent->get_label_keys()[0]);
    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>&mat = _mat;
        Tensor<DType>&src = sent->get_feature_tensor(key);
        int nframe = sent->get_frame_num(key);
        CHECK2(nframe == label_frame_num);
        CHECK2(nframe >= _right_context);

        nframe = nframe - _right_context;
        mat.resize(Dim(src.get_size()[0] + _left_context, src.get_size()[1]), false);

        Tensor<DType>& head = sent->get_split_head();
        
        // 使用头部信息
        if (_use_head && head.is_init()) {
            CHECK2((int)head.get_height() >= _left_context);

            for (int i = 0; i < _left_context; ++i) {
                mat.copy_row(head, (int)head.get_height() - _left_context + i, i);
            }
        }else {
            // 补left_context帧
            for (int i = 0; i < _left_context; ++i) {
                mat.copy_row(src, 0, i);
            }
        }

        //中间数据拷贝
        mat.get_block(Dim(_left_context , 0),
                Dim(_left_context  + src.get_size()[0], src.get_size()[1])).copy_from(src);

        int new_dim = sent->get_frame_dim(key) * (_left_context + _right_context + 1);
        src.resize(Dim(nframe, new_dim), false);
        for (int i = 0; i < nframe; i++) {
            memcpy(src.get_data(Dim(i, 0)), mat.get_data(Dim(i, 0)), new_dim * sizeof(float));
        }
        sent->set_frame_dim(key, new_dim);
        sent->set_frame_num(key, nframe);
    }
    //label去掉头尾数据
    Tensor<DType>& label = sent->get_label_tensor(sent->get_label_keys()[0]);
    label_frame_num = label_frame_num - _right_context;
    _label.resize(label.get_size(), false);
    _label.copy_from(label);
    label.resize(Dim(label_frame_num, label.get_size(1)), false);
    label.copy_from(_label.get_block(
                Dim(0, 0), 
                Dim(label_frame_num, _label.get_size(1))));

    sent->set_frame_num(sent->get_label_keys()[0], label_frame_num);

    return 0;
}

void TransVadSplice::read_data(std::string &config_line) {
    parse_from_string("LeftContext", &config_line, &_left_context);
    parse_from_string("RightContext", &config_line, &_right_context);
    parse_from_string("UseHead", &config_line, &_use_head);
    INTER_LOG("TransVadSplice : LeftContext %d, RightContext %d, UseHead %d",
            _left_context, _right_context, (int)_use_head);
    CHECK2(config_line.size() == 0);
}

} // houyi
} // train
