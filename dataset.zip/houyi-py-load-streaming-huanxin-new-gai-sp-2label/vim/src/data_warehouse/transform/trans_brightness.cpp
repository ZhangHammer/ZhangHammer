//by zzxfl 2017.05.10
#include "trans_brightness.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include <cmath>

namespace houyi {
namespace train {

int TransBrightness::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);

    Tensor<DType>alpha {Dim(1), cpu_device()};
    //alpha.random(-_brightness, _brightness);
    for (int i = 0; i < (int)alpha.get_element_count(); i++) {
#ifndef __CLOSE_RANDOM__
        alpha.get_data()[i] = (rand() / double(RAND_MAX)) * 2.0f  * _brightness - _brightness;
#else
        alpha.get_data()[i] = 0;
#endif
    }

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))
            continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        // const size_t channel = 3;
        // CHECK2(image->get_c() == channel);
        image->mul(1.0 + alpha.get_data()[0]);
    }
    return 0;
}

void TransBrightness::read_data(std::string &config_line) {
    parse_from_string("brightness", &config_line, &_brightness);
}
}
}

