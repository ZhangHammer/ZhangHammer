//by zzxfl 2017.03.11
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "trans_batch_reshape.h"
#include "trans_batch_transpose.h"
#include "trans_batch_sampling.h"
#include "trans_batch_random_sampling.h"
#include "trans_batch_reduce_label.h"
#include "trans_batch_remove_illegal_label.h"

namespace houyi {
namespace train {

BaseBatchTransformation* BaseBatchTransformation::new_trans_of_type(const std::string &type) {
    BaseBatchTransformation* ans = NULL;
    if (type == "TransBatchReshape") {
        return ans = new TransBatchReshape();
    }
    else if (type == "TransBatchTranspose") {
        return ans = new TransBatchTranspose();
    }
    else if (type == "TransBatchSampling") {
        return ans = new TransBatchSampling();
    }
    else if (type == "TransBatchRandomSampling") {
        return ans = new TransBatchRandomSampling();
    }
    else if (type == "TransBatchReduceLabel") {
        return ans = new TransBatchReduceLabel();
    }
    else if (type == "TransBatchRemoveIllegalLabel") {
        return ans = new TransBatchRemoveIllegalLabel();
    }
    else {
        CHECK2(false);
    }
    return ans;
}

void BaseBatchTransformation::read_keys(std::string &config_line) {
    std::vector<std::string>tmp_keys;
    parse_from_string("keys", &config_line, &tmp_keys);
    for (auto key : tmp_keys) {
        _keys.insert(key);
    }
}

BaseBatchTransformation* BaseBatchTransformation::read(std::string &config_line) {
    std::string type;
    std::vector<std::string>tmp_keys;
    parse_from_string("type", &config_line, &type);
    BaseBatchTransformation *trans = new_trans_of_type(type);
    trans->read_keys(config_line);
    trans->read_data(config_line);
    return trans;
}
}
}
