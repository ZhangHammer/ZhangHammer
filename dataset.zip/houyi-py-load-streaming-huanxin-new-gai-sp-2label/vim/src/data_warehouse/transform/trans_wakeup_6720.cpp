//by zhxfl 2017.12.24
#include "trans_wakeup_6720.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"
#include "vec_ops.h"

namespace houyi {
namespace train {

TransWakeup6720::TransWakeup6720() : BaseTransformation() {
    memset(_flag, 0, sizeof(_flag));
    _flag[30] = _flag[31] = _flag[32] = _flag[99] = _flag[100] = _flag[101] = 1;
    _predict.resize(Dim(1, _frame_dim));
    read_key_word_label_map();
}

void TransWakeup6720::read_key_word_label_map() {
    std::ifstream fi_map_id(_key_word_label_map.c_str());
    if (!fi_map_id) {
        INTER_CHECK(false, "Failed to open file: %s", _key_word_label_map.c_str());
    }

    int keyword_id = 0;
    int map_keywor_id = 0;

    while (fi_map_id >> keyword_id >> map_keywor_id) {
        _id_map[keyword_id] = map_keywor_id;
    }
    fi_map_id.close();
}

int TransWakeup6720::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence* sample = dynamic_cast<SpeechOneSentence*>(&data_pack);

    std::string feature_key = sample->get_feature_keys()[0];
    std::string label_key = sample->get_label_keys()[0];

    int wrdid = sample->get_speaker_id(feature_key);
    int frame_num = sample->get_frame_num(feature_key);
    int frame_dim = sample->get_frame_dim(feature_key);
    int speak_id = sample->get_speaker_id(feature_key);
    Tensor<DType>& label_tensor = sample->get_label_tensor(label_key);
    DType* align = label_tensor.get_data();
    DType* feat = sample->get_feature_tensor(feature_key).get_data();
    _predict.zero();
    DType* predictor = _predict.get_data();

    //sample->set_frame_num(label_key, 1);
    //sample->set_frame_num(feature_key, 1);
    //sample->set_frame_dim(feature_key, _frame_dim);
    //sample->set_feature_tensor(feature_key, _predict);
    //label_tensor.resize(Dim(1,1), false);
    //label_tensor.get_data()[0] = 1;
    //return 0;

    if (wrdid == 30 || wrdid == 31 || wrdid == -30 || wrdid == -31) {
        for (int i = 0; i < frame_num; i++) {
            if ((int) align[i] <= 101 && _flag[(int)align[i]]) {
                align[i] = -1;
            }
        }
    }

    _period_mean_tensor.resize(Dim(frame_dim));
    DType* period_mean = _period_mean_tensor.get_data();

    std::vector<int> part_align;
    int prev_state = -1;
    int ii = 0;
    int dur = 0;
    int dur_half = 0;
    int tot_dur = 0;
    for (int t = 0; t < frame_num; t++) {
        int cur_align = (int)align[t];
        if (cur_align < 9) {
            continue;
        }

        if (prev_state == -1) {
            prev_state = cur_align;
        }
        
        if (cur_align != prev_state) {
            dur = part_align.size();
            dur_half = dur >> 1;
            for (int cc = 0; cc < dur_half; cc++) {
                vec_add(predictor + ii * frame_dim,
                        feat + part_align[cc] * frame_dim,
                        frame_dim);
            }
            vec_add(period_mean, predictor + ii * frame_dim,
                frame_dim);
            vec_norm(predictor + ii++ * frame_dim,
                     frame_dim, dur_half);
            for (int cc = dur_half; cc < dur; cc++) {
                vec_add(predictor + ii * frame_dim,
                        feat + part_align[cc] * frame_dim,
                        frame_dim);
            }
            vec_add(period_mean, predictor + ii * frame_dim,
                frame_dim);
            vec_norm(predictor + ii++ * frame_dim,
                     frame_dim, dur - dur_half);
            tot_dur += dur;
            part_align.clear();
            prev_state = (int)align[t];
        }
        part_align.push_back(t);
    }

    // process last state
    dur = part_align.size();
    dur_half = dur >> 1;

    if (dur == 0) {
        return -1;
    }

    for (int cc = 0; cc < dur_half; cc++) {
        vec_add(predictor + ii * frame_dim,
                feat + part_align[cc] * frame_dim,
                frame_dim);
    }
    vec_add(period_mean, predictor + ii * frame_dim,
        frame_dim);
    vec_norm(predictor + ii++ * frame_dim,
             frame_dim, dur_half);
    for (int cc = dur_half; cc < dur; cc++) {
        vec_add(predictor + ii * frame_dim,
                feat + part_align[cc] * frame_dim,
                frame_dim);
    }
    vec_add(period_mean, predictor + ii * frame_dim,
        frame_dim);
    vec_norm(predictor + ii++ * frame_dim, frame_dim, dur - dur_half);
    tot_dur += dur;    

    /// Do keyword period sentence norm
    //vec_norm(period_mean, frame_dim, 1.0 * tot_dur);
    //for (int j = 0; j < ii * frame_dim; j++) {
    //    predictor[j] -= period_mean[j % frame_dim];
    //}

    /// Do feature difference
    int word_num = ii / 12;
    if (word_num == 0) {
        INTER_LOG("abnormal value is found");
        return -1;
    }
    int quarter_dim = ii * frame_dim / word_num;
    for (int d = 0; d < quarter_dim * (word_num - 1); d++) {
        predictor[ii * frame_dim + d] = predictor[quarter_dim + d] - predictor[d];
    }

    label_tensor.resize(Dim(1, 1), false);
    CHECK2(_id_map.find(speak_id) != _id_map.end());
    label_tensor.get_data()[0] = _id_map[speak_id];

    sample->set_feature_tensor(feature_key, _predict);
    sample->set_frame_num(label_key, 1);
    sample->set_frame_num(feature_key, 1);
    sample->set_frame_dim(feature_key, _frame_dim);

    // check abnormal value
    for (int i = 0; i < _frame_dim; i++) {
        if (isnan(predictor[i]) || isinf(predictor[i])) {
            INTER_LOG("abnormal value is found");
            return -1;
        }
    }
    return 0;
}

void TransWakeup6720::read_data(std::string &config_line) {
    parse_from_string("frameDim", &config_line, &_frame_dim);
    INTER_LOG("frameDim %d", _frame_dim);
    parse_from_string("labelMap", &config_line, &_key_word_label_map);
    INTER_LOG("labelMap %s", _key_word_label_map.c_str());
}

}
}
