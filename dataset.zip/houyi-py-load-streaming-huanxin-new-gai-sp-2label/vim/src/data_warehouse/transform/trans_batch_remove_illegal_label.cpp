#include "trans_batch_remove_illegal_label.h"
#include "base_batch_transformation.h"
#include "parse_string.h"
#include "base_batch_sample.h"
#include "wind/wind.h"
#include "speech_batch_sample.h"

namespace houyi {
namespace train {

int TransBatchRemoveIllegalLabel::perform_trans(BaseBatchSample& data_batch) {
    for (auto key : data_batch.get_label_keys()) {
        if (!has_key(key))continue;

        Tensor<DType>& label = data_batch.get_label_tensor(key);
        Tensor<int>& mask = data_batch.get_label_mask(key);

        int batch_size = static_cast<int>(data_batch.get_batch_size());
        int frame_num = static_cast<int>(label.get_size(0)) / batch_size;
        _tmp_label.resize(Dim(batch_size, 1));
        _tmp_mask.resize(Dim(batch_size));

        for (int i = 0; i < batch_size; ++i) {
            DType label_idx = 0;
            for (int j = frame_num - 1; j >= 0; --j) {
                DType cur_value = label.get_data()[j * batch_size + i];
                if (mask.get_data()[j * batch_size + i] == 0) {
                    continue;
                }
                if (cur_value > std::numeric_limits<float>::lowest()) {
                    label_idx = cur_value;
                    _tmp_mask.get_data()[i] = 1;
                    break;
                }
            }
            _tmp_label.get_data()[i] = label_idx;
        }

        label.resize(Dim(batch_size, 1));
        label.copy_from(_tmp_label);

        mask.resize(Dim(batch_size));
        mask.copy_from(_tmp_mask);
        SpeechBatchSample* sample = static_cast<SpeechBatchSample*>(&data_batch);
        sample->set_frame_num(key, 1); 
    }
    return 0;
}

void TransBatchRemoveIllegalLabel::read_data(std::string &config_line) {
    CHECK2(config_line.size() == 0);
}
}
}

