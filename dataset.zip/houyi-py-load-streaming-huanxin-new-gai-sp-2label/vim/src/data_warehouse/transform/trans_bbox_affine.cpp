// by longfei 2017.05.22
#include "trans_bbox_affine.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

#ifdef __WITH_OPENCV__
void TransBboxAffine::read_data(std::string &config_line) {
    parse_from_string("angleRange", &config_line, &_angle_range);
    parse_from_string("marginRatio", &config_line, &_margin_ratio);
    parse_from_string("newSize", &config_line, &_new_size);
    parse_from_string("bboxKey", &config_line, &_bbox_key);
    CHECK2(_angle_range.size() == 2);
    CHECK2(_new_size > 0);
    CHECK2(has_key(_bbox_key));
    INTER_LOG("TransBboxAffine: angleRange %f %f", _angle_range[0], _angle_range[1]);
    INTER_LOG("TransBboxAffine: marginRatio %f", _margin_ratio);
    INTER_LOG("TransBboxAffine: newSize %d", _new_size);
}

int TransBboxAffine::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_32FC1: CV_32FC3);
        tensor_to_mat(*image, sink);

        Tensor<DType>& bbox_tensor = sample->get_label_tensor(_bbox_key);
        int x0 = bbox_tensor.get_data()[0];
        int y0 = bbox_tensor.get_data()[1];
        int x1 = bbox_tensor.get_data()[2];
        int y1 = bbox_tensor.get_data()[3];
        int bboxWidth = x1 - x0 + 1;
        int bboxHeight = y1 - y0 +1;
        int length = std::min(bboxWidth, bboxHeight);//最短边作为长度
        int margin = length * _margin_ratio;//为随机crop做余量

        //新的左上角点，为了去掉额头部分
        x0 = x0 + (bboxWidth - length)/2;
        y0 = y0 + bboxHeight - length;

        //扩充边缘 length + margin
        int widthPad = width + 2*(length + margin);
        int heightPad = height + 2*(length + margin);
        cv::Mat imgboarder = cv::Mat::zeros(heightPad, widthPad, channel == 1 ? CV_32FC1: CV_32FC3);
        cv::Rect sinkRect = cv::Rect(length + margin, length + margin, width, height);
        sink.copyTo(imgboarder(sinkRect));

        //新的bbox：
        //x0 = x0 + length +margin - margin - 0.25*length
        //newsize = int(1.5 * length + 2*margin);
        x0 = int(x0 + length * 0.75);
        y0 = int(y0 + length * 0.75);
        bboxWidth = int(1.5 * length + 2*margin);
        bboxHeight = int(1.5 * length + 2*margin);

        //Rotate
        float angle = (1.0f * rand() / RAND_MAX) * (_angle_range[1] - _angle_range[0])  + _angle_range[0];
        cv::Point center = cv::Point(x0 + bboxWidth/2, y0 + bboxHeight/2);
        cv::Mat rot_mat = cv::getRotationMatrix2D(center, angle, 1.0);

        cv::Mat to;
        cv::warpAffine(imgboarder, to, rot_mat, cv::Size(widthPad, heightPad));

        cv::Rect faceRectMargin = cv::Rect(x0, y0, bboxWidth, bboxHeight);
        cv::Mat faceImage = cv::Mat(to, faceRectMargin);
        cv::resize(faceImage, faceImage, cv::Size(_new_size, _new_size));

        image->resize(Dim(channel, _new_size, _new_size));
        sample->set_width(key, _new_size);
        sample->set_height(key, _new_size);
        sample->set_channel(key, channel);

        mat_to_tensor(faceImage, *image);
    }

    return 0;
}
#endif
}
}
