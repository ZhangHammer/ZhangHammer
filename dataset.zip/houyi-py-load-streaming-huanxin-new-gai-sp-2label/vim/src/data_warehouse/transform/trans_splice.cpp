// by zzxfl 2016.10.28
#include "trans_splice.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransSplice::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    //label_frame_num指句子实际的帧数，由于nframe可能是做了add_detla之后的
    int label_frame_num = sent->get_frame_num(sent->get_label_keys()[0]);
    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>&mat = _mat;
        Tensor<DType>&src = sent->get_feature_tensor(key);
        int nframe = sent->get_frame_num(key);
        //需要补帧
        if (nframe - label_frame_num != _left_context + _right_context) {
            if (_use_head_tail) {
                CHECK2(nframe == label_frame_num);

                int nframe = sent->get_frame_num(key);
                mat.resize(Dim(nframe + _left_context + _right_context, src.get_size()[1]), false);

                // 前面补left_contect帧
                Tensor<DType>& head = sent->get_split_head();
                if (head.is_init()) {
                    CHECK2((int)head.get_height() >= _left_context);
                    for (int i = 0; i < _left_context; ++i) {
                        mat.copy_row(head, head.get_height() - _left_context + i, i);
                    }
                }else {
                    //前面补left_context帧
                    for (int i = 0; i < _left_context; ++i) {
                        mat.copy_row(src, 0, i);
                    }
                }
                //中间数据块拷贝
                mat.get_block(Dim(_left_context , 0),
                        Dim(_left_context  + src.get_size()[0], src.get_size()[1])).copy_from(src);
                Tensor<DType>& tail = sent->get_split_tail();
                    //后面补right_context帧
                if (tail.is_init()) {
                    CHECK2((int)tail.get_height() >= _right_context);
                    for (int i = 0; i < _right_context; ++i) {
                        mat.copy_row(tail, i, i + src.get_size()[0]);
                    }
                }else {
                    for (int i = _left_context + src.get_size()[0]; i < (int)mat.get_size(0); i++) {
                        mat.copy_row(src, src.get_size()[0] - 1, i);
                    }
                }

                int new_dim = sent->get_frame_dim(key) * (_left_context + _right_context + 1);
                src.resize(Dim(label_frame_num, new_dim), false);
                for (int i = 0; i < label_frame_num; i++) {
                    memcpy(src.get_data(Dim(i, 0)), mat.get_data(Dim(i, 0)), new_dim * sizeof(float));
                }

                sent->set_frame_dim(key, new_dim);
                sent->set_frame_num(key, label_frame_num);
            }else {
                //已经左右补好的帧数,必须是对称的
                int already_left = (nframe - label_frame_num) / 2;
                int already_right =  already_left;
                //实际需要补的帧数
                int new_left_context = _left_context - already_left;
                int new_right_context = _right_context - already_right;
                CHECK2(nframe - already_left - already_right == label_frame_num);

                int nframe = sent->get_frame_num(key);
                mat.resize(Dim(nframe + new_left_context + new_right_context, src.get_size()[1]), false);
                //前面补left_context帧
                for (int i = 0; i < new_left_context; i++) {
                    mat.copy_row(src, 0, i);
                }
                //中间数据块拷贝
                mat.get_block(Dim(new_left_context , 0),
                        Dim(new_left_context  + src.get_size()[0], src.get_size()[1])).copy_from(src);
                //后面补right_context帧
                for (int i = new_left_context + src.get_size()[0]; i < (int)mat.get_size(0); i++) {
                    mat.copy_row(src, src.get_size()[0] - 1, i);
                }

                int new_dim = sent->get_frame_dim(key) * (_left_context + _right_context + 1);
                src.resize(Dim(label_frame_num, new_dim), false);
                for (int i = 0; i < label_frame_num; i++) {
                    memcpy(src.get_data(Dim(i, 0)), mat.get_data(Dim(i, 0)), new_dim * sizeof(float));
                }

                sent->set_frame_dim(key, new_dim);
                sent->set_frame_num(key, label_frame_num);
            }
        }
        // 不需要补帧
        else {
            int nframe = sent->get_frame_num(key) - _left_context - _right_context;
            mat.resize(Dim(src.get_size()[0], src.get_size()[1]), false);
            mat.copy_from(src);

            int new_dim = sent->get_frame_dim(key) * (_left_context + _right_context + 1);
            src.resize(Dim(nframe, new_dim), false);
            for (int i = 0; i < nframe; i++) {
                memcpy(src.get_data(Dim(i, 0)), mat.get_data(Dim(i, 0)), new_dim * sizeof(float));
            }
            sent->set_frame_dim(key, new_dim);
            sent->set_frame_num(key, nframe);
        }
    }
    return 0;
}

void TransSplice::read_data(std::string &config_line) {
    parse_from_string("LeftContext", &config_line, &_left_context);
    parse_from_string("RightContext", &config_line, &_right_context);
    parse_from_string("UseHeadTail", &config_line, &_use_head_tail);
    INTER_LOG("TransSplice : LeftContext %d, RightContext %d",
              _left_context, _right_context);
    CHECK2(config_line.size() == 0);
}

}
}

