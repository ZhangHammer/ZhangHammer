//by longfei 2017.05.22
#include "trans_pix_mean_scale_norm.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
int TransPixMeanScaleNorm::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        CHECK2(image->get_c() == _mean.get_size(0));

        image->add_tensor( _mean);
        image->mul(_scale);
    }
    return 0;
}

void TransPixMeanScaleNorm::read_data(std::string &config_line) {
    std::vector<float>value;
    parse_from_string("Stats", &config_line, &value);
    CHECK2(value.size() == 1 || value.size() == 3);
    _mean.resize(Dim(value.size(), 1));
    for (size_t i = 0; i < value.size(); i++) {
        _mean.get_data()[i] = -value[i];
    }
    parse_from_string("Scale", &config_line, &_scale);
}
}
}

