#include "trans_image_lighting.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "image_utils.h"

#include <wind/wind.h>
#include <iostream>

namespace houyi {
namespace train {

#ifdef __WITH_OPENCV__

const float EXPOSURE = 2.2;
const float GAMMA = 2.2;

void TransImageLighting::read_data(std::string& config_line) {

    parse_from_string("numberOfEnvironment", &config_line, &_number_of_env);
    CHECK(_number_of_env > 0, "Invalid numberOfEnvironment %d", _number_of_env);
    parse_from_string("numberOfOffset", &config_line, &_number_of_offset);
    CHECK(_number_of_offset > 0, "Invalid numberOfOffset %d", _number_of_offset);
    std::string weight_file;
    parse_from_string("weightFile", &config_line, &weight_file);
    CHECK(!weight_file.empty(), "Invalid weightFile %s", weight_file.c_str());
    // 从文件加载权重
    std::ifstream ifs(weight_file.c_str(), std::ios::in | std::ios::binary);
    CHECK(ifs.good(), "Cannot open the file %s", weight_file.c_str());
    _weight.set_device(cpu_device());
    _weight.read(ifs);
    CHECK(_weight.get_dim() == 4u, "Weight must be 4D vs %dD", static_cast<int>(_weight.get_dim()));
    CHECK(static_cast<int>(_weight.get_size(0)) == _number_of_env,
          "Weight dim(0) %d must equal to numberOfEnvironment %d",
          static_cast<int>(_weight.get_size(0)), _number_of_env);
    CHECK(static_cast<int>(_weight.get_size(1)) == _number_of_offset,
          "Weight dim(1) %d must equal to numberOfOffset %d",
          static_cast<int>(_weight.get_size(1)), _number_of_offset);
}

int TransImageLighting::perform_trans(BaseOneSample& data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    CHECK2(sample->get_feature_keys().size() == 1 && sample->get_label_keys().size() == 1);

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        CHECK(image->get_c() == 3u,
              "TransImageLighting only support 3 channel image vs %d channel",
              static_cast<int>(image->get_c()));
        cv::Mat sink(image->get_w(), image->get_h(), CV_8UC3);
        tensor_to_mat(*image, sink);

        // 随机方向 和 背景
        int random_offset = rand() % _number_of_offset;
        int random_env_map = rand() % _number_of_env;

        // load_reflectance_field
        cv::Mat reflectance_field;
        cv::Mat image_bgr;
        cv::Mat  mask;
        {
            cv::Mat channels[3];
            cv::Mat rgbd[4];
            cv::split(sink, channels);
            cv::Mat tmp_mask(channels[0].rows, channels[0].cols, CV_8UC1, 255);
            rgbd[0] = channels[0];
            rgbd[1] = channels[1];
            rgbd[2] = channels[2];
            rgbd[3] = tmp_mask;
            cv::merge(rgbd, 3, image_bgr);
            cv::merge(rgbd, 4, sink);
            channels[0] = tmp_mask;
            channels[1] = tmp_mask;
            channels[2] = tmp_mask;
            cv::merge(channels, 3, mask);
        }

        int width = sink.cols;
        int height = sink.rows;
        int width_padding = std::max(width, height) * 2;
        int x = (width_padding - width) / 2;
        int y = (width_padding - height) / 2;
        cv::Rect obj_rect(x, y, width, height);

        reflectance_field = cv::Mat::zeros(width_padding, width_padding, CV_8UC3);
        cv::Mat obj_roi = reflectance_field(obj_rect);
        image_bgr.copyTo(obj_roi);

        cv::Mat object_mask = cv::Mat::zeros(width_padding, width_padding, CV_8UC3);
        cv::Mat mask_roi = object_mask(obj_rect);
        mask.copyTo(mask_roi);

        reflectance_field.convertTo(reflectance_field, CV_32FC3, 1.0 / 255.0);

        cv::Mat relit_result;
        // remove_gamma_reflectance_field
        {
            cv::Mat channel[3];
            cv::Mat channel_without_gamma[3];

            cv::split(reflectance_field, channel);
            channel[0].convertTo(channel[0], CV_32F);
            channel[1].convertTo(channel[1], CV_32F);
            channel[2].convertTo(channel[2], CV_32F);

            cv::pow(channel[0], GAMMA, channel_without_gamma[0]);
            cv::pow(channel[1], GAMMA, channel_without_gamma[1]);
            cv::pow(channel[2], GAMMA, channel_without_gamma[2]);

            cv::merge(channel_without_gamma, 3, reflectance_field);
        }
        // compute_final_relighting_from_single_image
        {
            relit_result = cv::Mat::zeros(reflectance_field.rows, reflectance_field.cols, CV_32FC3);
            cv::Mat channel[3];
            cv::Mat current_image;
            std::vector<int> index;
            for (int i = 0; i < static_cast<int>(_weight.get_size(2)); ++i) {
                index.push_back(i);
            }
            std::random_shuffle(index.begin(), index.end());

            // 随机选取一些灯光
            int num_total = (6 + rand() % 20) * 10; // [60, 250)

            float* weights_ptr = _weight.get_data(Dim(random_env_map, random_offset, 0, 0));
            float total_weight[3] = {0.0f};
            for (int i = 0; i < num_total; ++i) {
                int j = index[i];
                total_weight[0] += weights_ptr[3 * j + 2];
                total_weight[1] += weights_ptr[3 * j + 1];
                total_weight[2] += weights_ptr[3 * j + 0];
            }

            cv::split(reflectance_field, channel);
            channel[0] *= total_weight[0];
            channel[1] *= total_weight[1];
            channel[2] *= total_weight[2];
            cv::merge(channel, 3, current_image);
            relit_result += current_image;
        }

        // change_exposure
        relit_result.convertTo(relit_result, -1, pow(2.0, EXPOSURE));
        // gamma_correction
        {
            cv::Mat channel[3];
            cv::Mat channel_with_gamma[3];
            cv::split(relit_result, channel);
            channel[0].convertTo(channel[0], CV_32F);
            channel[1].convertTo(channel[1], CV_32F);
            channel[2].convertTo(channel[2], CV_32F);
            cv::pow(channel[0], 1.0f / GAMMA, channel_with_gamma[0]);
            cv::pow(channel[1], 1.0f / GAMMA, channel_with_gamma[1]);
            cv::pow(channel[2], 1.0f / GAMMA, channel_with_gamma[2]);
            cv::merge(channel_with_gamma, 3, relit_result);
        }

        // roi
        relit_result *= 255.0f;
        relit_result.convertTo(relit_result, CV_8UC3);
        cv::Mat result_roi = relit_result(obj_rect);
        // cv::Mat channels_obj[4];
        // cv::Mat channels_mask[3];
        // cv::Mat relit_obj;
        // cv::split(result_roi, channels_obj);
        // cv::split(mask_roi, channels_mask);
        // channels_obj[3] = channels_mask[0];
        // cv::merge(channels_obj, 4, relit_obj);

        // convert back to tensor
        mat_to_tensor(result_roi, *image);
    }

    return 0;
}

#endif

}   // namespace train
}   // namespace houyi
