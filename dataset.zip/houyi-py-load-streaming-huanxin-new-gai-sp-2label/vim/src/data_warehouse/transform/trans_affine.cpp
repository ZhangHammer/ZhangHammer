// by zzxfl 2016.10.28
#include "trans_affine.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
void TransAffine::read_data(std::string &config_line) {
    parse_from_string("angleRange", &config_line, &_angle_range);
    parse_from_string("scaleRange", &config_line, &_scale_range);
    CHECK2(_angle_range.size() == 2);
    CHECK2(_scale_range.size() == 2);
    INTER_LOG("TransAffine: angleRange %f %f, fixAngle", _angle_range[0], _angle_range[1]);
    INTER_LOG("TransAffine: scaleRange %f %f, fixScale", _scale_range[0], _scale_range[1]);
}

int TransAffine::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_32FC1: CV_32FC3);
        tensor_to_mat(*image, sink);
        //Rotate
        cv::Point center = cv::Point(sink.rows >> 1, sink.cols >> 1);
#ifndef __CLOSE_RANDOM__
        float angle = (1.0f * rand() / RAND_MAX) * (_angle_range[1] - _angle_range[0])  + _angle_range[0];
        float scale = (1.0f * rand() / RAND_MAX) * (_scale_range[1] - _scale_range[0])  + _scale_range[0];
#else
        float angle = 0.0;
        float scale = 1.0;
#endif

        int new_width = scale * width;
        int new_height = scale * height;
        int new_channel = channel;

        cv::Mat rot_mat = cv::getRotationMatrix2D(center, angle, scale);
        cv::Mat to = cv::Mat(new_height, new_width, new_channel == 1 ? CV_32FC1:CV_32FC3);
        cv::warpAffine(sink, to, rot_mat, to.size());
        image->resize(Dim(new_channel, new_height, new_width));
        sample->set_width(key, new_width);
        sample->set_height(key, new_height);
        sample->set_channel(key, new_channel);

        mat_to_tensor(to, *image);
    }

    return 0;
}
#endif

}
}
