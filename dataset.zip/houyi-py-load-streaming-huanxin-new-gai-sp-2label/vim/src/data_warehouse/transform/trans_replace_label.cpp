// by zzxfl 2018.01.03
#include "trans_replace_label.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
int TransReplaceLabel::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    std::string label_key = sent->get_label_keys()[0];
    CHECK2(sent->get_label_keys().size() == 1);
    CHECK2(sent->get_feature_keys().size() == 1);

    for (auto key : sent->get_feature_keys()) {
        if (!has_key(key)) continue;
        sent->replace_label(_from_label, _to_label);
    }
    return 0;
}

void TransReplaceLabel::read_data(std::string &config_line) {
    parse_from_string("fromLabel", &config_line, &_from_label);
    parse_from_string("toLabel", &config_line, &_to_label);
    INTER_LOG("from %d to %d", _from_label, _to_label);
    CHECK2(config_line.size() == 0);
}

}
}

