// by zzxfl 2017.02.17
#include <map>
#include "trans_image_resize.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
void TransImageResize::read_data(std::string &config_line) {
    parse_from_string("minEdge", &config_line, &_min_edge);
    parse_from_string("maxEdge", &config_line, &_max_edge);
    for (auto i : _min_edge) {
        INTER_LOG("TransImageResize: minEdge %d", i);
    }
    INTER_LOG("TransImageResize: maxEdge %d", _max_edge);
}

int TransImageResize::perform_trans(BaseOneSample &data_pack) {
    const int linears[4] = {cv::INTER_NEAREST, cv::INTER_LINEAR, cv::INTER_CUBIC, cv::INTER_AREA} ;

    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    //std::map<std::string , float> &scale_map = sample->get_scale();
    CHECK2(sample->get_feature_keys().size() == 1 && sample->get_label_keys().size() == 1);

    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_32FC1: CV_32FC3);
        tensor_to_mat(*image, sink);

        int new_width = (int)width;
        int new_height = (int)height;
        int new_channel = (int)channel;

        int min_edge = -1;
        srandom(time(NULL));
        if (_min_edge.size() == 2) {
#ifndef __CLOSE_RANDOM__
            min_edge = random() % (_min_edge[1] - _min_edge[0] + 1) + _min_edge[0];
#else
            min_edge = _min_edge[0];
#endif
        }
        else if (_min_edge.size() == 1) {
            min_edge = _min_edge[0];
        }
        else {
            CHECK(false, "min edge error");
        }

        //height是小边
        if (new_width > new_height) {
            new_height = min_edge;
            new_width = min_edge * (width * 1.0f) / height;

            if (new_width > _max_edge) {
                float scale2 = (1.0 * _max_edge) / new_width;
                new_width = _max_edge;
                new_height = scale2 * new_height;
            }
        }
        //width是小边
        else {
            new_width = min_edge;
            new_height = min_edge * (1.0f * height) / width;

            if (new_height > _max_edge) {
                float scale2 = (1.0 *_max_edge) / new_height;
                new_height = _max_edge;
                new_width = scale2 * new_width;
            }
        }

        CHECK2(new_width <= _max_edge);
        CHECK2(new_height <=  _max_edge);

        cv::Mat to = cv::Mat(new_height, new_width, new_channel == 1 ? CV_32FC1:CV_32FC3);
        cv::resize(sink, to, to.size(), linears[rand() % 4]);
        image->resize(Dim(new_channel, new_height, new_width));
        sample->set_width(key, new_width);
        sample->set_height(key, new_height);
        sample->set_channel(key, new_channel);

        mat_to_tensor(to, *image);
    }

    return 0;
}
#endif

}
}
