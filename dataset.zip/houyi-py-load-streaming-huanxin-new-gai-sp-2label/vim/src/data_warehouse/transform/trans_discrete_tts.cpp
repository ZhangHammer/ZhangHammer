// by zzxfl 2017.09.19
#include "trans_discrete_tts.h"
#include "base_transformation.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
int TransDiscreteTTS::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    //总的维度
    int new_dim = 0;
    //每一个种特征的起始位置
    std::vector<int>start_index;
    for (size_t i = 0; i < _desc.size(); i++) {
        start_index.push_back(new_dim);
        new_dim += _desc[i];
    }

    for (auto key : sent->get_feature_keys() ) {
        if (!has_key(key)) {
            continue;
        }

        Tensor<DType>&feature_tensor = sent->get_feature_tensor(key);
        Tensor<DType>new_feature_tensor(cpu_device());
        new_feature_tensor.resize(Dim(feature_tensor.get_size(0), new_dim));
    
        //拷贝连续特征
        Tensor<DType>block1 = new_feature_tensor.get_block(Dim(0, 0),
                Dim(new_feature_tensor.get_size(0), _desc[0]));
        Tensor<DType>block2 = feature_tensor.get_block(Dim(0, 0),
                Dim(feature_tensor.get_size(0), _desc[0]));
        block1.copy_from(block2);

        //处理离散特征
        int frame_num = sent->get_frame_num(key);
        for (int f = 0; f < frame_num; f++) {
            DType* ptr1 = feature_tensor.get_data(Dim(f, 0));
            DType* ptr2 = new_feature_tensor.get_data(Dim(f, 0));
            for (size_t d = 1; d < _desc.size(); d++) {
                int start = start_index[d];
                int len = _desc[d];
                int index = ptr1[_desc[0] + d - 1];
                CHECK2(index <= len);
                ptr2[start + index] = 1;
            }
        }
        
        //修改句子中的内存 
        feature_tensor.resize(new_feature_tensor.get_size());
        feature_tensor.copy_from(new_feature_tensor); 
        //修改句子的实际维度 
        sent->set_frame_dim(key, (int)(new_dim));
    }

    return 0;
}

void TransDiscreteTTS::read_data(std::string &config_line) {
    parse_from_string("desc", &config_line, &_desc);
    CHECK2(_desc.size());
    for (size_t i = 0; i < _desc.size(); i++) {
        INTER_LOG("desc[%d]:%d", (int)(i), _desc[i]);
    }
    CHECK2(config_line.size() == 0);
}

}//namespace houyi
}//namespace train

