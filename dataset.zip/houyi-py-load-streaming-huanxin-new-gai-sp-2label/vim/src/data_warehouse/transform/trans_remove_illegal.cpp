// by zzxfl 2018.06.07
#include "trans_remove_illegal.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransRemoveIllegal::perform_trans(BaseOneSample &data_pack) {
    SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(&data_pack);
    std::string label_key = sent->get_label_keys()[0];
    std::string feature_key = sent->get_feature_keys()[0];
    CHECK2(sent->get_label_keys().size() == 1);
    CHECK2(sent->get_feature_keys().size() == 1);
   
    Tensor<DType>& label_tensor = sent->get_label_tensor(label_key);
    Tensor<DType>& feature_tensor = sent->get_feature_tensor(feature_key);
    size_t frame_dim = feature_tensor.get_size(1);
    size_t count = 0;
    for (size_t i = 0; i < label_tensor.get_element_count(); ++i) {
        if (label_tensor.get_data()[i] != _label_idx) {
            ++count;
        }
    }

    // 全部合法
    if (count == label_tensor.get_element_count()) {
        return 0;
    }

    //句子全部无效
    if (count == 0) {
        INTER_LOG("sent is illegal");
        return -1;
    }

    _feature.resize(Dim(count, frame_dim), false);
    _label.resize(Dim(count, 1));

    int cur_frame = 0;
    for (size_t i = 0; i < label_tensor.get_element_count(); ++i) {
        if (label_tensor.get_data()[i] != _label_idx) {
            _label.get_data()[cur_frame] = label_tensor.get_data()[i];
            _feature.copy_row(feature_tensor, i, cur_frame);
            ++cur_frame;
        }
    } 

    label_tensor.resize(_label.get_size(), false);
    label_tensor.copy_from(_label);

    feature_tensor.resize(_feature.get_size(), false);
    feature_tensor.copy_from(_feature);

    sent->set_frame_num(label_key, count);
    sent->set_frame_num(feature_key, count);
    return 0;
}

void TransRemoveIllegal::read_data(std::string &config_line) {
    parse_from_string("labelIndex", &config_line, &_label_idx);
    INTER_LOG("label_index %d", _label_idx);
    CHECK2(config_line.size() == 0);
}

} // namespace houyi
} // namespace train

