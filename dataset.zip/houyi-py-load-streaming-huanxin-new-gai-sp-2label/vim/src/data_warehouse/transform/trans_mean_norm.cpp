#include "trans_mean_norm.h"
#include "parse_string.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

int TransMeanNorm::perform_trans(BaseOneSample &data_pack) {
    ImageOneSample* sample = dynamic_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));
        CHECK2(image->get_size() == _mean->get_size());
        image->elem_add(*image, *_mean, 1.0f, -1.0f);
    }
    return 0;
}

void TransMeanNorm::read_data(std::string &config_line) {
    char str[4096];
    std::string file_stats;

    parse_from_string("Stats", &config_line, &file_stats);
    std::ifstream fin(file_stats.c_str());
    CHECK(!fin.fail(), "Open file error %s", file_stats.c_str());

    fin.getline(str, 4096);
    int width =0;
    int height = 0;
    int channel = 0;
    sscanf(str, "%d %d %d", &width, &height, &channel);
    _width = width;
    _height = height;
    _channel = channel;
    if (_mean == NULL)
        _mean = new Tensor<float>(Dim(_channel, _height, _width), cpu_device());

    for (int ch = 0; ch < (int)_channel; ch++) {
        for (int r = 0; r < (int)_height; r++) {
            for (int c = 0; c < (int)_width; c++) {
                float val = 0;
                fin>>val;
                Dim coor(ch, r, c);
                _mean->set_element(coor, val);
            }
        }
    }

    fin.close();
}
}
}

