// by zzxfl 2017.01.07
#include "trans_random_resize.h"
#include "parse_string.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "image_one_sample.h"
#include "image_reader_config.h"
#include "wind/wind.h"
#include "image_utils.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
void TransRandomResize::read_data(std::string &config_line) {
    parse_from_string("resizeWidth", &config_line, &_resize_width);
    parse_from_string("resizeHeight", &config_line, &_resize_height);
    INTER_LOG("TransRandomResize: resizeWidth %d", _resize_width);
    INTER_LOG("TransRandomResize: resizeHeight %d", _resize_height);
}

int TransRandomResize::perform_trans(BaseOneSample &data_pack) {
    const int linears[4] = {cv::INTER_NEAREST, cv::INTER_LINEAR, cv::INTER_CUBIC, cv::INTER_AREA} ;

    ImageOneSample* sample = static_cast<ImageOneSample*>(&data_pack);
    for (auto key : sample->get_feature_keys()) {
        if (!has_key(key))continue;
        Tensor<DType>*image = &(sample->get_feature_tensor(key));

        //Conver BaseTensor to Mat
        size_t width = image->get_w();
        size_t height = image->get_h();
        size_t channel = image->get_c();

        CHECK2(channel == 1 || channel == 3);

        cv::Mat sink(height, width, channel == 1 ? CV_32FC1: CV_32FC3);
        tensor_to_mat(*image, sink);
        int new_width = _resize_width;
        int new_height = _resize_height;
        int new_channel = channel;

        cv::Mat to = cv::Mat(new_height, new_width, new_channel == 1 ? CV_32FC1:CV_32FC3);
#ifndef __CLOSE_RANDOM__
        cv::resize(sink, to, to.size(), linears[rand() % 4]);
#else
        cv::resize(sink, to, to.size(), linears[0]);
#endif
        image->resize(Dim(new_channel, new_height, new_width));
        sample->set_width(key, new_width);
        sample->set_height(key, new_height);
        sample->set_channel(key, new_channel);

        mat_to_tensor(to, *image);
    }

    return 0;
}
#endif
}
}
