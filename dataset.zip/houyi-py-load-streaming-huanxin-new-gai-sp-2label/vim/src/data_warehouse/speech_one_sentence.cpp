// by zzxfl 2016.08.29
#include "speech_one_sentence.h"
#include "wind/wind.h"
#include <malloc.h>

namespace houyi {
namespace train {

SpeechOneSentence::SpeechOneSentence(
    ParamFeatureT features,
    ParamLabelT labels,
    std::map<std::string, std::string>file_name):BaseOneSample(file_name) {
    
    _split_head.set_device(cpu_device());
    _split_tail.set_device(cpu_device());

    //特征的初始化
    for (auto& conf : features) {
        DataType data_type;
        size_t frame_num = 0;
        size_t frame_dim = 0;
        size_t speaker_id = 0;
        std::tie(data_type, frame_num, frame_dim, speaker_id) = conf.second;
        std::string key = conf.first;
        BaseOneFeature* feature =
            new SpeechOneFeature(data_type, frame_num, frame_dim, speaker_id);
        _feature_keys.push_back(key);
        _features[key] = feature;
    }

    //标签的初始化
    for (auto& conf : labels) {
        LabelType label_type;
        int frame_num = 0;
        int label_dim = 0;
        std::tie(label_type, frame_num, label_dim) = conf.second;
        std::string key = conf.first;
        BaseOneLabel* label = new SpeechOneLabel(label_type, frame_num, label_dim);
        _label_keys.push_back(key);
        _labels[key] = label;
    }
}

SpeechOneSentence::SpeechOneSentence(SpeechOneSentence& sentence):
    BaseOneSample(sentence.get_file_name()) {
    _split_head.set_device(cpu_device());
    _split_tail.set_device(cpu_device());

    //特征的初始化
    for (auto key : sentence.get_feature_keys()) {
        SpeechOneFeature* feature = (SpeechOneFeature*)(&sentence.get_feature(key));
        DataType data_type = feature->get_feature_type();
        size_t frame_num = feature->get_frame_num();
        size_t frame_dim = feature->get_frame_dim();
        size_t speaker_id = feature->get_speaker_id();
        _feature_keys.push_back(key);
        _features[key] = 
            new SpeechOneFeature(data_type, frame_num, frame_dim, speaker_id);
        _features[key]->get_feature().copy_from(feature->get_feature());
    }

    //标签的初始化
    for (auto key : sentence.get_label_keys()) {
        SpeechOneLabel* label = (SpeechOneLabel*)(&sentence.get_label(key));
        LabelType label_type = label->get_label_type();
        int frame_num = label->get_frame_num();
        int label_dim = label->get_label_dim();
        _label_keys.push_back(key);
        _labels[key] = 
            new SpeechOneLabel(label_type, frame_num, label_dim);
        _labels[key]->get_label().copy_from(label->get_label());
    }
}

void SpeechOneSentence::copy_from(SpeechOneSentence& sentence) {
    rename(sentence.get_file_name(), 
            sentence.get_feature_keys(), 
            sentence.get_label_keys());

    _split_head.set_device(cpu_device());
    _split_tail.set_device(cpu_device());

    //特征的初始化
    for (auto key : sentence.get_feature_keys()) {
        SpeechOneFeature* feature = (SpeechOneFeature*)(&sentence.get_feature(key));
        DataType data_type = feature->get_feature_type();
        size_t frame_num = feature->get_frame_num();
        size_t frame_dim = feature->get_frame_dim();
        size_t speaker_id = feature->get_speaker_id();
        SpeechOneFeature* new_feature = static_cast<SpeechOneFeature*>(_features[key]);
        new_feature->resize(data_type, frame_num, frame_dim, speaker_id);
        new_feature->get_feature().copy_from(feature->get_feature());
    }

    //标签的初始化
    for (auto key : sentence.get_label_keys()) {
        SpeechOneLabel* label = (SpeechOneLabel*)(&sentence.get_label(key));
        LabelType label_type = label->get_label_type();
        int frame_num = label->get_frame_num();
        int label_dim = label->get_label_dim();
        SpeechOneLabel* new_label = static_cast<SpeechOneLabel*>(_labels[key]);
        new_label->resize(label_type, frame_num, label_dim);
        new_label->get_label().copy_from(label->get_label());
    }
}

void SpeechOneSentence::resize(
        ParamFeatureT features,
        ParamLabelT labels,
        std::map<std::string, std::string> file_name) {
    std::vector<std::string> feature_key;
    std::vector<std::string> label_key;
    
    std::transform(features.begin(), 
            features.end(), 
            std::back_inserter(feature_key),
            [](ParamFeatureT::value_type& kv) { return kv.first;}); 
    std::transform(labels.begin(), labels.end(), 
            std::back_inserter(label_key), 
            [](ParamLabelT::value_type& kv) { return kv.first;}); 
    rename(file_name, feature_key, label_key);

    //删除多余的feature
    
    for (auto& key: _feature_keys) {
        if (features.find(key) == features.end()) {
            delete _features[key];
            _features.erase(key);
        }
    }

    //删除多余的label
    for (auto& key: _label_keys) {
        if (labels.find(key) == labels.end()) {
            delete _labels[key];
            _labels.erase(key);
        }
    }

    //keys更新
    _feature_keys = feature_key;
    _label_keys = label_key;

    //TODO RENAME 
    //特征的初始化
    for (auto& conf : features) {
        DataType data_type;
        size_t frame_num = 0;
        size_t frame_dim = 0;
        size_t speaker_id = 0;
        std::tie(data_type, frame_num, frame_dim, speaker_id) = conf.second;
        std::string key = conf.first;
        SpeechOneFeature* feature = static_cast <SpeechOneFeature*>(_features[key]);
        feature->resize(data_type, frame_num, frame_dim, speaker_id);
    }

    //标签的初始化
    for (auto& conf : labels) {
        LabelType label_type;
        int frame_num = 0;
        int label_dim = 0;
        std::tie(label_type, frame_num, label_dim) = conf.second;
        std::string key = conf.first;
        SpeechOneLabel* label = static_cast<SpeechOneLabel*>(_labels[key]);
        label->resize(label_type, frame_num, label_dim);
    }
}

SpeechOneSentence::~SpeechOneSentence() {
    for (auto d : _features) {
        delete d.second;
    }
    _features.clear();
    for (auto l : _labels) {
        delete l.second;
    }
    _labels.clear();

    _label_keys.clear();
    _feature_keys.clear();
}

void SpeechOneSentence::copy_sent(SpeechBatchSample& bat, int batch_size, int batch_id) {
    for (auto conf: _features) {
        std::string key = conf.first;
        Tensor<DType>& sentence_feature = conf.second->get_feature();
        Tensor<DType>& bat_feature = bat.get_feature_tensor(key);
        Tensor<int>& bat_feature_mask = bat.get_feature(key).get_mask();
        for (int fetch_pos = 0; fetch_pos < (int)sentence_feature.get_size(0); fetch_pos++) {
            int fill_pos = fetch_pos * batch_size + batch_id;
            bat_feature.copy_row(sentence_feature, fetch_pos, fill_pos);
            bat_feature_mask.set_element(Dim(fill_pos), 1);
        }
    }

    for (auto conf : _labels) {
        std::string key = conf.first;
        SpeechOneLabel& label = *(dynamic_cast<SpeechOneLabel*> (conf.second));
        SpeechBatchLabel& dest_label = *(dynamic_cast<SpeechBatchLabel*>(&bat.get_label(key)));
        if (label.get_label_dim() == 1) {
            for (int fetch_pos = 0; fetch_pos < (int)label.get_label().get_size(0); fetch_pos++) {
                int fill_pos = fetch_pos * batch_size + batch_id;
                DType label_value = 
                    label.get_label().get_data()[fetch_pos];
                dest_label.get_label().get_data()[fill_pos] = label_value;

                if (std::numeric_limits<float>::lowest() >= label_value) {
                    dest_label.get_mask().get_data()[fill_pos] = 0;
                    dest_label.get_label().get_data()[fill_pos] = 0;
                }
                else {
                    dest_label.get_mask().get_data()[fill_pos] = 1;
                }
            }
        }
        else {
            for (int fetch_pos = 0; fetch_pos < (int)label.get_label().get_size(0); fetch_pos++) {
                int fill_pos = fetch_pos * batch_size + batch_id;
                dest_label.get_label(fill_pos).copy_from(label.get_label(fetch_pos));
                dest_label.get_mask(fill_pos).set_element(1);
            }
        }
    }
}

int SpeechOneSentence::copy_next_frame(SpeechBatchSample& bat, int fill_pos, int fetch_pos) {// batch_id, frame_id
    int ret = 1;
    for (auto conf: _features) {
        std::string key = conf.first;
        Tensor<DType>& sentence_feature = conf.second->get_feature();
        Tensor<DType>& bat_feature = bat.get_feature_tensor(key);
        Tensor<int>& bat_feature_mask = bat.get_feature(key).get_mask();
        if (fetch_pos < (int) sentence_feature.get_size(0)) {
            bat_feature.copy_row(sentence_feature, fetch_pos, fill_pos);
            bat_feature_mask.set_element(Dim(fill_pos), 1);
            if (fetch_pos == (int)sentence_feature.get_size(0))
                ret = 0;
        }
        else {
            bat_feature.get_block(Dim(fill_pos, 0),
                    Dim(fill_pos + 1, bat_feature.get_size(1))).zero();
            ret = 0;
        }
    }

    for (auto conf : _labels) {
        std::string key = conf.first;
        SpeechOneLabel& label = *(dynamic_cast<SpeechOneLabel*> (conf.second));
        SpeechBatchLabel& dest_label = *(dynamic_cast<SpeechBatchLabel* >(&bat.get_label(key)));
        if (fetch_pos < (int)label.get_label().get_size(0)) {
            dest_label.get_label(fill_pos).copy_from(
                label.get_label(fetch_pos));
            if (label.get_label_dim() == 1) {
                DType label_value = 
                    label.get_label().get_element(Dim(fetch_pos, 0));
                if (std::numeric_limits<float>::lowest() >= label_value) {
                    dest_label.get_mask(fill_pos).set_element(0);
                    CHECK2(false);
                }
                else {
                    dest_label.get_mask(fill_pos).set_element(1);
                }
            }
            else {
                dest_label.get_mask(fill_pos).set_element(1);
            }

            if (fetch_pos == (int)label.get_label().get_size(0) - 1)
                ret = 0;
        } else {
            dest_label.get_label(fill_pos).set_element(0);
            dest_label.get_mask(fill_pos).zero();
            ret = 0;
        }
    }
    return ret;
}

int SpeechOneSentence::copy_spliced_frame(SpeechBatchSample& bat, int fill_pos, int fetch_pos, int left_context, int right_context) {// batch_id, frame_id
    int ret = 1;
    int label_frame_num = get_frame_num(get_label_keys()[0]);
    for (auto conf: _features) {
        std::string key = conf.first;
        // assert no splice has been done yet
        int frame_num = get_frame_num(key);
        CHECK2(label_frame_num == frame_num);

        Tensor<DType>& sentence_feature = conf.second->get_feature();
        Tensor<DType>& bat_feature = bat.get_feature_tensor(key);

        size_t sent_frame_dim = sentence_feature.get_size()[1];
        size_t bat_frame_dim = bat_feature.get_size()[1];
        CHECK2(sent_frame_dim * (1 + left_context + right_context) == bat_frame_dim);

        Tensor<int>& bat_feature_mask = bat.get_feature(key).get_mask();

        auto bat_feat = bat_feature.get_block(Dim(fill_pos, 0), Dim(fill_pos + 1, bat_frame_dim));
        bat_feat.reshape(Dim(1 + left_context + right_context, sent_frame_dim));

        assert(fetch_pos < frame_num);
        if (fetch_pos < left_context) {
            int head_copy = left_context - fetch_pos;
            auto src_head = sentence_feature.get_block(Dim(0, 0), Dim(1, sent_frame_dim));
            for (int n = 0; n < head_copy; ++n) {
                auto dest = bat_feat.get_block(Dim(n, 0), Dim(n + 1, sent_frame_dim));
                dest.copy_from(src_head);
            }   

            auto block_dest = bat_feat.get_block(Dim(head_copy, 0), Dim(left_context + 1, sent_frame_dim));
            auto block_src = sentence_feature.get_block(Dim(0, 0), Dim(fetch_pos + 1, sent_frame_dim));
            block_dest.copy_from(block_src);
        } else {
            auto block_dest = bat_feat.get_block(Dim(0, 0), Dim(left_context + 1, sent_frame_dim));
            auto block_src = sentence_feature.get_block(Dim(fetch_pos - left_context, 0), Dim(fetch_pos + 1, sent_frame_dim));
            block_dest.copy_from(block_src);
        }  
        
        int offset = left_context + 1;
        int remain = frame_num - 1 - fetch_pos;
        if (remain < right_context) {
            if (0 != remain) {
                auto block_dest = bat_feat.get_block(Dim(offset, 0), Dim(offset + remain, sent_frame_dim));
                auto block_src = sentence_feature.get_block(Dim(fetch_pos + 1, 0), Dim(frame_num, sent_frame_dim));
                block_dest.copy_from(block_src);
                offset += remain;
            }       

            int tail_copy = right_context - remain;
            auto src_tail = sentence_feature.get_block(Dim(frame_num - 1, 0), Dim(frame_num, sent_frame_dim));

            for (int n = 0; n < tail_copy; ++n) {
                auto dest = bat_feat.get_block(Dim(offset + n, 0), Dim(offset + n + 1, sent_frame_dim));
                dest.copy_from(src_tail);
            }

        } else {
            auto block_dest = bat_feat.get_block(Dim(offset, 0), Dim(offset + right_context, sent_frame_dim));
            auto block_src = sentence_feature.get_block(Dim(fetch_pos + 1, 0), Dim(fetch_pos + 1 + right_context, sent_frame_dim));
            block_dest.copy_from(block_src);
        }

        bat_feature_mask.set_element(Dim(fill_pos), 1);
    }
    
    for (auto conf : _labels) {
        std::string key = conf.first;
        SpeechOneLabel& label = *(dynamic_cast<SpeechOneLabel*> (conf.second));
        SpeechBatchLabel& dest_label = *(dynamic_cast<SpeechBatchLabel* >(&bat.get_label(key)));
        if (fetch_pos < (int)label.get_label().get_size(0)) {
            dest_label.get_label(fill_pos).copy_from(
                label.get_label(fetch_pos));
            if (label.get_label_dim() == 1) {
                DType label_value =
                    label.get_label().get_element(Dim(fetch_pos, 0));
                CHECK2((int)label_value != -1);
                if (std::numeric_limits<float>::lowest() >= label_value) {
                    dest_label.get_mask(fill_pos).set_element(0);
                    CHECK2(false);
                }
                else {
                    dest_label.get_mask(fill_pos).set_element(1);
                }
            }
            else {
                dest_label.get_mask(fill_pos).set_element(1);
            }

            if (fetch_pos == (int)label.get_label().get_size(0) - 1) {
                ret = 0;
            }
        } else {
            CHECK2(false);
            dest_label.get_label(fill_pos).set_element(0);
            dest_label.get_mask(fill_pos).zero();
            ret = 0;
        }
    }
    return ret;
}

int SpeechOneSentence::read_feature(std::string key, BaseStream& in_stream, size_t st_position_in_byte, size_t size_in_byte) {
    CHECK2(_features.find(key) != _features.end());
    SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
    return feature->read_data(in_stream, st_position_in_byte, size_in_byte);
}

int SpeechOneSentence::read_label(std::string key, BaseStream& in_stream, size_t st_position_in_byte, size_t size_in_byte) {
    CHECK2(_labels.find(key) != _labels.end());
    SpeechOneLabel* label = dynamic_cast<SpeechOneLabel*>(_labels[key]);
    return label->read_label(in_stream, st_position_in_byte, size_in_byte);
}
/*
 *TODO: 对所有特征和标签进行切子句，要求所有特征和标签的对应的帧长都是一样的
 *integrity : 切的时候保证词的完整性
 */
int SpeechOneSentence::split_sentence(std::vector<BaseOneSample*>&sent ,int perturb, int sub_seq_size, int split_sentence_threshold, bool integrity) {
    int remain_frame_num = get_default_feature().get_frame_num();
    //不需要进行切子句
    if (remain_frame_num <= split_sentence_threshold || split_sentence_threshold == -1 || sub_seq_size == -1) {
        return 1;
    }
    int cur_frame_pos = 0;
    int counter =  0;
    do {
        int cur_frame_len = 0;
        if (remain_frame_num > split_sentence_threshold) {
#ifndef __CLOSE_RANDOM__
            cur_frame_len = sub_seq_size + random() % perturb;
#else
            cur_frame_len = sub_seq_size;
#endif
            //保证词的完整性
            if (integrity == true) {
                Tensor<DType>&label_tensor = get_label_tensor(_label_keys[0]);
                for (int i = cur_frame_pos + cur_frame_len; i < get_frame_num(_feature_keys[0]) - 1; i++) {
                    //INTER_LOG("move %d %d", label_tensor.get_data()[i], label_tensor.get_data()[i + 1]);
                    if (label_tensor.get_data()[i] != label_tensor.get_data()[i + 1] || cur_frame_len >= 350) {
                        break;
                    }
                    cur_frame_len++;
                }
            }
            if (cur_frame_len > remain_frame_num)
                cur_frame_len = remain_frame_num;
        }
        else {
            cur_frame_len = remain_frame_num;
        }

        //feature
        SpeechOneSentence::ParamFeatureT features;
        SpeechOneSentence::ParamLabelT labels;
        for (auto feature_key : _feature_keys) {
            features[feature_key] = std::make_tuple(
                                        get_feature(feature_key).get_feature_type(),
                                        cur_frame_len,
                                        get_frame_dim(feature_key),
                                        get_speaker_id(feature_key));
        }

        //label
        for (auto label_key : _label_keys) {
            labels[label_key] = std::make_tuple(
                                    get_label(label_key).get_label_type(),
                                    cur_frame_len,
                                    get_label(label_key).get_label_dim());
        }

        SpeechOneSentence* sentence = NULL;
        sentence = new SpeechOneSentence(features, labels, _file_name);

        //拷贝特征
        for (auto feature_key : _feature_keys) {
            Tensor<DType>&to = sentence->get_feature_tensor(feature_key);
            Tensor<DType>&from = get_feature_tensor(feature_key);
            for (int i = 0; i < cur_frame_len; i++) {
                int fetch_pos = i + cur_frame_pos;
                int fill_pos = i;
                to.copy_row(from, fetch_pos, fill_pos);
            }

            //保留头5帧
            if (cur_frame_pos >= 5) {
                int feat_dim = from.get_width();
                Tensor<DType>& split_head = sentence->get_split_head();
                split_head.resize(Dim(5, feat_dim));
                for (int i=0; i<5; i++) {
                    split_head.copy_row(from, cur_frame_pos - 5 + i, i);
                }
            }
            //保留尾5帧
            if (cur_frame_pos + cur_frame_len + 5 < (int)from.get_height()) {
                int feat_dim = from.get_width();

                Tensor<DType>& split_tail = sentence->get_split_tail();
                split_tail.resize(Dim(5, feat_dim));
                for (int i=0; i<5; i++) {
                    split_tail.copy_row(from, cur_frame_pos+cur_frame_len+i, i);
                }
            }
        }
        //拷贝标签
        for (auto label_key : _label_keys) {
            Tensor<DType>&from = get_label_tensor(label_key);
            Tensor<DType>&to = sentence->get_label_tensor(label_key);
            for (int i = 0; i < cur_frame_len; i++) {
                int fetch_pos = i + cur_frame_pos;
                int fill_pos = i;
                to.copy_row(from, fetch_pos, fill_pos);
            }
        }

        remain_frame_num-= cur_frame_len;
        cur_frame_pos += cur_frame_len;
        sent.push_back(sentence);
        counter ++;
    } while (remain_frame_num > 0);
    return counter;
}

void SpeechOneSentence::replace_label(int old_label, int new_label)
{
    for (auto label_key : _label_keys) {
        Tensor<DType>&label = get_label_tensor(label_key);
        int frame_num = label.get_height();
        for (int ii = 1; ii < frame_num; ii++) {
            if (label.get_data()[ii-1] == old_label && label.get_data()[ii] == old_label) {
                label.get_data()[ii-1] = new_label;
            }
        }
    }
}
}//houyi
}//train
