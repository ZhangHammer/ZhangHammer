//by zhxfl 2017.11.27
#include "device_batch_sample.h"

namespace houyi {
namespace train {
void DeviceBatchSample::copy_from(BaseBatchSample* sample) {
    reset();
    //feature tensor
    for (auto key : sample->get_feature_keys()) {
        Tensor<DType>& from_feature = sample->get_feature_tensor(key);
        Tensor<int>& from_mask = sample->get_feature_mask(key);
        IOPackage& package = get_io_package(key);
        package.resize(from_feature.get_size(), gpu_device());
        package.get_ten()->copy_from(from_feature);
        package.get_mask()->resize(from_mask.get_size());
        package.get_mask()->copy_from(from_mask);
    }

    for (auto key : sample->get_label_keys()) {
        //label tensor
        Tensor<DType>& from_label = sample->get_label_tensor(key);
        Tensor<int>& from_mask = sample->get_label_mask(key);

        IOPackage& package = get_io_package(key);
        package.resize(from_label.get_size(), gpu_device());
        
        package.get_ten()->copy_from(from_label);
        package.get_mask()->copy_from(from_mask);
    }
    //INTER_LOG("iopacksize %d", _io_package.size());
    //CHECK2(_io_package.size() == 2);
}

}// train
}// houyi
