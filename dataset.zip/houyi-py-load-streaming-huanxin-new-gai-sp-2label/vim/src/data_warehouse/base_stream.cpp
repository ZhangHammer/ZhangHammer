#include "base_stream.h"
#include "util.h"
//namespace linux{
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#ifdef __SNAPPY__
#include "snappy.h"
#include "snappy-sinksource.h"
#endif 
//}

namespace houyi {
namespace train {
IfStream::IfStream(const std::string& path) {
    _is = new std::ifstream(path);
}

void IfStream::seekg(std::streamoff off, std::ios_base::seekdir way) {
    _is->seekg(off, way);
}

void IfStream::seekg(std::streampos pos) {
    _is->seekg(pos);
}

std::streampos IfStream::tellg() {
    return _is->tellg();
}

void IfStream::read(char* s, std::streamsize n) {
    _is->read(s, n);
}

void IfStream::close() {
    _is->close();
}

void IfStream::getline(char*s, std::streamsize n) {
    _is->getline(s, n);
}

std::streamsize IfStream::gcount() const {
    return _is->gcount();
}

//========================================//

SnappyStream::SnappyStream(std::string& path) {
    std::ifstream ifs(path);
    ifs.seekg(0, std::ios::end);
    size_t length = ifs.tellg();
    CHECK2(length);
    _buffer = new char[length];
    ifs.seekg(0, std::ios::beg);
    ifs.read(_buffer, length);
    ifs.close();
    std::string out;
#ifdef __SNAPPY__
    snappy::Uncompress(_buffer, length, &out);
#endif
    _is.str(out);
}

void SnappyStream::seekg(std::streamoff off, std::ios_base::seekdir way) {
    _is.seekg(off, way);
}

void SnappyStream::seekg(std::streampos pos) {
    _is.seekg(pos);
}

std::streampos SnappyStream::tellg() {
    return _is.tellg();
}

void SnappyStream::read(char* s, std::streamsize n) {
    _is.read(s, n);
}

void SnappyStream::close() {
    //nothing to do
}

void SnappyStream::getline(char* s, std::streamsize n) {
    _is.getline(s, n);
}

std::streamsize SnappyStream::gcount()const {
    return _is.gcount();
}

SnappyStream::~SnappyStream() {
    delete _buffer;
}

}
}
