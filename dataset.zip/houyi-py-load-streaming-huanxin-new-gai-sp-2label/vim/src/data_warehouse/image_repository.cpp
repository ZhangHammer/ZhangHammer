/**
 * image_repository.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-06
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "image_batch_sample.h"
#include "image_repository.h"
#include "image_utils.h"
#include "wind/wind.h"
#include "object_factory.h"

namespace houyi {
namespace train {

ImageBatchSample::ParamFeatureT ImageRepository::get_features_param(ImageOneSample& sample) {
    ImageBatchSample::ParamFeatureT feature_param;

    std::vector<std::string> feature_key = sample.get_feature_keys();
    for (auto key : feature_key) {
        feature_param[key] = std::make_tuple(
                                 sample.get_data_type(key),
                                 sample.get_channel(key),
                                 sample.get_height(key),
                                 sample.get_width(key));
    }
    return feature_param;
}

ImageBatchSample::ParamLabelT ImageRepository::get_labels_param(ImageOneSample& sample) {
    ImageBatchSample::ParamLabelT label_param;
    std::vector<std::string> label_keys = sample.get_label_keys();
    for (auto key : label_keys) {
        label_param[key] = std::make_tuple(
                               sample.get_label_type(key),
                               sample.get_label_dim(key)
                           );
    }
    return label_param;
}

size_t ImageRepository::inter_get_batch(
    std::vector<BaseBatchSample*> &batches, size_t max_num) {

    _batch_size = _new_batch_size;
    size_t counter = 0;

    for (size_t l = 0; l < max_num; l++) {
        BaseProcesser *image_processer = static_cast<BaseProcesser *>(_data_processer);
        if (_sample_buf.size() < _batch_size) {
            image_processer->get_samples_from_proc(_sample_buf, _batch_size - _sample_buf.size());
            if ((_sample_buf.size() && _sample_buf.back() == NULL)
                    ||(
                        _sample_buf.size() < _batch_size)) {
                for (auto sample : _sample_buf) {
                    if (sample)
                        delete sample;
                }
                _sample_buf.clear();
                return 0;
            }
        }

        ImageBatchSample* bat = NULL;
        bat = static_cast<ImageBatchSample*>(ObjectFactory<BaseBatchSample>::instance()->create_object());
        ImageBatchSample::ParamFeatureT feature_param = get_features_param(*(static_cast<ImageOneSample*>(_sample_buf[0])));
        ImageBatchSample::ParamLabelT label_param = get_labels_param(*(static_cast<ImageOneSample*>(_sample_buf[0])));
        if (bat == NULL) {
            bat = new ImageBatchSample(_batch_size,
                    feature_param,
                    label_param);
            bat->set_is_speech(false);
        }
        bat->resize(_batch_size, feature_param, label_param);
        ImageBatchDesc* batch_desc = static_cast<ImageBatchDesc*>(bat->get_batch_desc());
        std::vector<std::string> label_keys = _sample_buf[0]->get_label_keys();
        std::vector<std::string> feature_keys = _sample_buf[0]->get_feature_keys();

        for (size_t b = 0; b < _batch_size; b++) {
            if (b < _sample_buf.size() &&_sample_buf[b]) {
                ImageOneSample*sample = static_cast<ImageOneSample*>(_sample_buf[b]);

                for (auto key : label_keys) {
                    // copy data&label
                    bat->get_label_tensor_by_index(key, b).copy_from(sample->get_label_tensor(key));
                }
                for (auto key : feature_keys) {
                    //feature
                    Tensor<DType> b_tensor = bat->get_feature_tensor(key, b);
                    b_tensor.copy_from(sample->get_feature_tensor(key));
                    //file_name
                    batch_desc->get_file_name(key).push_back(sample->get_file_name(key));
                    // origin height width
                    batch_desc->get_origin_width(key).push_back(sample->get_width(key));
                    batch_desc->get_origin_height(key).push_back(sample->get_height(key));
                    batch_desc->get_scale(key).push_back(sample->get_scale(key));
                }
                delete sample;
            }
            else {
                for (auto key : label_keys) {
                    bat->get_label_tensor_by_index(key, b).set_element(-1);
                }
                for (auto key : feature_keys) {
                    //feature
                    bat->get_feature_tensor(key, b).zero();
                    //file_name
                    bat->get_file_name(key).push_back("");
                    // origin height width
                    batch_desc->get_origin_width(key).push_back(0);
                    batch_desc->get_origin_height(key).push_back(0);
                    batch_desc->get_scale(key).push_back(1.0);
                }
            }
        }
        _sample_buf.erase(_sample_buf.begin(), _sample_buf.begin() + _batch_size);
        batches.push_back(bat);
        counter++;
    }
    return counter;
}

}
}

