//by zhxfl 2017.12.20
#include <omp.h>
#include <set>
#include <algorithm>
#include "speech_extract_data.h"
#include "object_factory.h"
#include "text_utils.h"

namespace houyi {
namespace train {

void SpeechExtractData::close_stream(
    std::map<std::string,
    std::tuple<bool, BaseStream*, BaseStream*> >& one_block_stream) {
    for (auto conf : one_block_stream) {
        BaseStream* bin_stream = NULL;
        BaseStream* desc_stream = NULL;
        bool is_feature = false;
        std::tie(is_feature, bin_stream, desc_stream) = conf.second;
        bin_stream->close();
        desc_stream->close();
        delete bin_stream;
        delete desc_stream;
    }
}

void SpeechExtractData::read_sample(
    std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
    std::vector<BaseOneSample*>& sample_buffer, int thread_id) {

    if (_intersection) {
        read_sample_intersection(one_block, sample_buffer, thread_id);
    }
    else {
        read_sample_normal(one_block, sample_buffer, thread_id);
    }
}

int SpeechExtractData::get_intersection_name(
    std::map<std::string, std::vector<std::tuple<std::string, int, int, int, int, int>>>& desc_map) {
    std::set<std::string> inter_set;
    int max_data_num = -1;

    // 求交集，保存到inter_set
    for (auto& mm :desc_map) {
        std::set<std::string> cur_set;
        for (auto& v : mm.second) {
            cur_set.insert(std::get<0>(v));
        }
        if (inter_set.size() == 0) {
            cur_set.swap(inter_set);
        } else {
            std::set<std::string> cur_inter_set;
            cur_inter_set.swap(inter_set);
            CHECK2(inter_set.size() == 0);
            std::set_intersection(cur_set.begin(), cur_set.end(),
                                  cur_inter_set.begin(), cur_inter_set.end(), std::inserter(inter_set, inter_set.begin()));
        }
        max_data_num = std::max(max_data_num, (int)mm.second.size());
    }

    // 重新构造desc_map，删除冗余数据
    std::map<std::string, std::vector<std::tuple<std::string, int, int, int, int, int>>> dm;
    dm.swap(desc_map);
    int data_num = -1;
    for (auto& mm : dm) {
        std::vector<std::tuple<std::string, int, int, int, int, int>> vec_tuple;
        for (auto& v : mm.second) {
            std::string name = std::get<0>(v);
            if (inter_set.find(name) != inter_set.end()) {
                vec_tuple.push_back(v);
            }
        }
        desc_map[mm.first] = vec_tuple;
        // 检查每个描述文件的data_num一样
        if (-1 == data_num) {
            data_num = vec_tuple.size();
        } else {
            CHECK2(data_num == (int)vec_tuple.size());
        }
    }
    // data_num 小于等于0属于异常情况
    CHECK2(data_num > 0);
    INTER_LOG("intersection from %d to %d", max_data_num, data_num);
    return data_num;
}

void SpeechExtractData::read_sample_intersection(
    std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
    std::vector<BaseOneSample*>& sample_buffer, int thread_id) {

    std::map<std::string, std::tuple<bool, BaseStream*, BaseStream*> > one_block_stream;

    //打开文件所有描述文件，二进制文件
    for (auto& conf : one_block) {
        std::string key = conf.first;
        bool is_feature = false;
        size_t idx = 0;
        std::string bin_file;
        std::string desc_file;
        std::tie(is_feature, idx, bin_file, desc_file) = conf.second;
        BaseStream* bin_stream = NULL;
        // open the feature file
        bin_stream = new IfStream(bin_file);
        INTER_LOG("read file %s", bin_file.c_str());
        if (bin_stream->fail()) {
            INTER_LOG("warning data load: open file error %s", bin_file.c_str());
            delete bin_stream;
            close_stream(one_block_stream);
            return;
        }
        // open the desc
        // 判断描述文件是否被merge
        std::vector<std::string> desc_vec;
        split_string_to_vector(desc_file, ":", true, &desc_vec);
        if (desc_vec.size() == 1) {
            IfStream* desc_stream = new IfStream(desc_vec[0]);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: open file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
            // 描述文件被合并
        }else if (desc_vec.size() == 3) {
            size_t position = 0;
            sscanf(desc_vec[1].c_str(), "%zu", &position);
            IfStream* desc_stream = new IfStream(desc_vec[0]);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: open file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            desc_stream->seekg(position);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: seekg file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
        } else {
            CHECK2(false);
        }
    }

    //==================================================//
    // 注意 : 读取数据,构造的sample以特征和标签的交集为准
    //==================================================//
    // 读取描述文件头并且进行校验
    std::map<std::string, FeatureDescHead> feature_head;
    std::map<std::string, LabelDescHead> label_head;

    for (auto conf : one_block_stream) {
        // feature desc
        if (std::get<0>(conf.second) == true) {
            FeatureDescHead head;
            BaseStream& file_stream = *std::get<2>(conf.second);
            if (!get_feature_desc_head(file_stream, head)) {
                INTER_LOG("warning data_load get_feature_desc_head fail %s", get<2>(one_block[conf.first]).c_str());
                close_stream(one_block_stream);
                return;
            }
            feature_head[conf.first] = head;
        }
        // label desc
        else if (std::get<0>(conf.second) == false) {
            LabelDescHead head;
            if (!get_label_desc_head(*std::get<2>(conf.second), head)) {
                INTER_LOG("warning data_load : get_label_desc_head fail %s", get<2>(one_block[conf.first]).c_str());
                close_stream(one_block_stream);
                return;
            }
            label_head[conf.first] = head;
        }
    }

    // 读取描述文件，求交集
    // tuple -> file_name, speaker_id, st_position_in_byte, size_in_byte, frame_len, (frame_dim, label_dim)
    std::map<std::string, std::vector<std::tuple<std::string, int, int, int, int, int>>> desc_map;

    for (auto& conf : one_block_stream) {
        char file_name[2048];
        size_t st_position_in_byte = 0;
        size_t size_in_byte = 0;
        size_t frame_len = 0;
        size_t frame_dim = 0;
        int speaker_id = -1;

        bool is_feature = false;
        BaseStream*bin_stream = NULL;
        BaseStream*desc_stream = NULL;
        std::string key = conf.first;
        std::string bin_file_name = get<2>(one_block[key]);
        std::string desc_file_name = get<3>(one_block[key]);
        std::tie(is_feature, bin_stream, desc_stream) = conf.second;

        int data_num = is_feature ? feature_head[key].data_num : label_head[key].data_num;
        for (int i = 0; i < data_num; ++i) {
            char str[2048];
            desc_stream->getline(str, 2048);
            //TODO by zhengzaoxin, sscanf is unsafe, use sscanf_s
            int n_item = sscanf(str, "%s %d%zd%zd%zd%zd", file_name,
                                &speaker_id, &st_position_in_byte, &size_in_byte, &frame_len, &frame_dim);
            if (frame_len <= 0) {
                INTER_LOG("warning data_load : frame_len <= 0 %s", desc_file_name.c_str());
                close_stream(one_block_stream);
                return;
            }

            if (frame_dim == 0) {
                INTER_LOG("warning data_load : frame_dim == 0 %s", desc_file_name.c_str());
                close_stream(one_block_stream);
                return;
            }

            if (size_in_byte == 0) {
                INTER_LOG("warning data_load : size_in_byte == 0 %s", desc_file_name.c_str());
                close_stream(one_block_stream);
                return;
            }

            if (n_item != 6) {
                INTER_LOG("warning data_load : n_item != 6 %s", desc_file_name.c_str());
                close_stream(one_block_stream);
                return;
            }

            desc_map[key].push_back(std::make_tuple(file_name, speaker_id, st_position_in_byte,
                                                    size_in_byte, frame_len, frame_dim));
        }
    }

    // 求desc_map交集
    int data_num = get_intersection_name(desc_map);
    // 读取对应样本的二进制数据
    for (int data_id = 0; data_id < data_num; data_id++) {
        SpeechOneSentence::ParamFeatureT features_param;
        SpeechOneSentence::ParamLabelT labels_param;
        std::map<std::string, std::tuple<int,int> > map_position;
        std::map<std::string, std::string> file_name_map;

        size_t label_frame_len = 0;
        size_t feature_frame_len = 0;
        for (auto conf : one_block_stream) {
            std::string file_name;
            size_t st_position_in_byte = 0;
            size_t size_in_byte = 0;

            size_t frame_len = 0;
            // frame_dim or label_dim
            size_t frame_dim = 0;
            // size_t label_dim = 0;
            int speaker_id = -1;

            bool is_feature = false;
            BaseStream*bin_stream = NULL;
            BaseStream*desc_stream = NULL;
            std::string key = conf.first;
            std::string bin_file_name = get<2>(one_block[key]);
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;

            std::tie(file_name, speaker_id,
                     st_position_in_byte, size_in_byte, frame_len,
                     frame_dim) = desc_map[key][data_id];

            map_position[conf.first] = std::make_tuple(st_position_in_byte, size_in_byte);
            file_name_map[key] = file_name;

            // feature
            if (is_feature) {
                features_param[key] = std::make_tuple(feature_head[key].data_type, frame_len, frame_dim, speaker_id);
                feature_frame_len = frame_len;
            }
            // label
            else {
                labels_param[key] = std::make_tuple(label_head[key].label_type, frame_len, frame_dim);
                label_frame_len = frame_len;
            }
        }

        if (feature_frame_len == 0 || label_frame_len == 0) {
            continue;
        }

        // 构造sample
        SpeechOneSentence* sentence = 
            new SpeechOneSentence(features_param, labels_param, file_name_map);

        // 读取二进制数据
        for (auto conf : one_block_stream) {
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            std::string key = conf.first;
            std::string bin_file_name = get<2>(one_block[key]);
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            if (is_feature == true) {
                size_t st_position_in_byte = std::get<0>(map_position[conf.first]);
                size_t size_in_byte = std::get<1>(map_position[conf.first]);
                // feat data
                int ret = sentence->read_feature(conf.first, *bin_stream, st_position_in_byte, size_in_byte);
                // fatal error
                if (ret == -1) {
                    INTER_LOG("fatal error data_load : read feature file error %s", bin_file_name.c_str());
                    exit(0);
                }
                else if (ret != (int)size_in_byte) {
                    INTER_LOG("warning data_load : read feature file error %s", bin_file_name.c_str());
                    delete sentence;
                    close_stream(one_block_stream);
                    return;
                }
            }
            else {
                size_t st_position_in_byte = std::get<0>(map_position[conf.first]);
                size_t size_in_byte = std::get<1>(map_position[conf.first]);

                // label data
                int ret = sentence->read_label(conf.first, *bin_stream, st_position_in_byte, size_in_byte);
                if (ret != (int)size_in_byte) {
                    INTER_LOG("warning data_load : read label file error %s", bin_file_name.c_str());
                    delete sentence;
                    close_stream(one_block_stream);
                    return;
                }

                if (_replace_label.size()) {
                    std::vector<int> &rep = _replace_label;
                    sentence->replace_label(rep[0], rep[1]);
                }
            }
        }

        int frame_len = std::get<1>(features_param.begin()->second);

        if (_drop_sentence_len > 0 && _drop_sentence_len <(int) frame_len) {
            INTER_LOG("drop sentence %d", frame_len);
            delete sentence;
            continue;
        }

        int tmp_num = sentence->split_sentence(sample_buffer, 50, _split_sentence_len,
                                               _split_sentence_threshold,
                                               _integrity);
        if (tmp_num > 1) {
            delete sentence;
        }
        else {
            sample_buffer.push_back(sentence);
        }
    }

    close_stream(one_block_stream);
}

void SpeechExtractData::read_sample_normal(
    std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
    std::vector<BaseOneSample*>& sample_buffer, int thread_id) {

    std::map<std::string, std::tuple<bool, BaseStream*, BaseStream*> > one_block_stream;

    //打开文件
    for (auto conf : one_block) {
        std::string key = conf.first;
        bool is_feature = false;
        size_t idx = 0;
        std::string bin_file;
        std::string desc_file;
        std::tie(is_feature, idx, bin_file, desc_file) = conf.second;
        BaseStream* bin_stream = NULL;
        // open the feature file
        bin_stream = new IfStream(bin_file);
        //INTER_LOG("read file %s", bin_file.c_str());
        if (bin_stream->fail()) {
            INTER_LOG("warning data load: open file error %s", bin_file.c_str());
            delete bin_stream;
            close_stream(one_block_stream);
            return;
        }
        // open the desc
        // 判断描述文件是否被merge
        std::vector<std::string> desc_vec;
        split_string_to_vector(desc_file, ":", true, &desc_vec);
        if (desc_vec.size() == 1) {
            IfStream* desc_stream = new IfStream(desc_vec[0]);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: open file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
            // 描述文件被合并
        }else if (desc_vec.size() == 3) {
            size_t position = 0;
            sscanf(desc_vec[1].c_str(), "%zu", &position);
            IfStream* desc_stream = new IfStream(desc_vec[0]);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: open file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            desc_stream->seekg(position);
            if (desc_stream->fail()) {
                INTER_LOG("warning data load: seekg file error %s", desc_vec[0].c_str());
                delete desc_stream;
                delete bin_stream;
                close_stream(one_block_stream);
                return;
            }
            one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
        } else {
            CHECK2(false);
        }
    }

    //注意:读取数据,打包时需要满足不同特征或者不同标签的samples数一致,或者只取最少那个
    //读取头并且进行校验
    std::map<std::string, FeatureDescHead> feature_head;
    std::map<std::string, LabelDescHead> label_head;

    //读取样本总个数, 特征和标签的总个数必须一致
    int data_num = -1;
    for (auto conf : one_block_stream) {
        //feature desc
        if (std::get<0>(conf.second) == true) {
            FeatureDescHead head;
            BaseStream& file_stream = *std::get<2>(conf.second);
            if (!get_feature_desc_head(file_stream, head)) {
                INTER_LOG("warning data_load get_feature_desc_head fail %s", get<2>(one_block[conf.first]).c_str());
                close_stream(one_block_stream);
                return;
            }
            feature_head[conf.first] = head;
            if (data_num == -1) {
                data_num = head.data_num;
            }
            else {
                if (data_num != head.data_num) {
                    INTER_LOG("warning data_load: feat data_num = %d label data_num %d, %s",
                              head.data_num, data_num,  get<2>(one_block[conf.first]).c_str());
                    close_stream(one_block_stream);
                    return;
                }
            }
        }
        //label desc
        else if (std::get<0>(conf.second) == false) {
            LabelDescHead head;
            if (!get_label_desc_head(*std::get<2>(conf.second), head)) {
                INTER_LOG("warning data_load : get_label_desc_head fail %s", get<2>(one_block[conf.first]).c_str());
                close_stream(one_block_stream);
                return;
            }
            label_head[conf.first] = head;
            if (data_num == -1) {
                data_num = head.data_num;
            }
            else {
                if (data_num != head.data_num) {
                    INTER_LOG("warning data_load: label data_num = %d feat data_num %d, %s",
                              head.data_num, data_num,  get<2>(one_block[conf.first]).c_str());
                    close_stream(one_block_stream);
                    return;
                }
            }
        }
    }

    //读取数据
    for (int data_id = 0; data_id < data_num; data_id++) {
        SpeechOneSentence::ParamFeatureT features_param;
        SpeechOneSentence::ParamLabelT labels_param;
        std::map<std::string, std::tuple<int,int> > map_position;
        std::map<std::string, std::string>file_name_map;

        size_t label_frame_len = 0;
        size_t feature_frame_len = 0;
        for (auto conf : one_block_stream) {
            char file_name[2048];
            size_t st_position_in_byte = 0;
            size_t size_in_byte = 0;

            size_t frame_len = 0;
            size_t frame_dim = 0;
            size_t label_dim = 0;
            int speaker_id = -1;

            bool is_feature = false;
            BaseStream*bin_stream = NULL;
            BaseStream*desc_stream = NULL;
            std::string key = conf.first;
            std::string bin_file_name = get<2>(one_block[key]);
            std::string desc_file_name = get<3>(one_block[key]);
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            // feature
            if (is_feature) {
                char str[2048];
                desc_stream->getline(str, 2048);
                //TODO by zhengzaoxin, sscanf is unsafe, use sscanf_s
                int n_item = sscanf(str, "%s %d%zd%zd%zd%zd", file_name,
                                    &speaker_id, &st_position_in_byte, &size_in_byte, &frame_len, &frame_dim);
                if (frame_len <= 0) {
                    INTER_LOG("warning data_load : frame_len <= 0 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (frame_dim == 0) {
                    INTER_LOG("warning data_load : frame_dim == 0 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (size_in_byte == 0) {
                    INTER_LOG("warning data_load : size_in_byte == 0 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (n_item != 6) {
                    INTER_LOG("warning data_load : n_item != 6 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                features_param[key] = std::make_tuple(feature_head[key].data_type, frame_len, frame_dim, speaker_id);
                map_position[conf.first] = std::make_tuple(st_position_in_byte, size_in_byte);
                file_name_map[key] = file_name;
                feature_frame_len = frame_len;
            }
            // label
            else {
                char str[2048];
                desc_stream->getline(str, 2048);
                int n_item = sscanf(str, "%s %d%zd%zd%zd%zd",
                                    file_name,
                                    &speaker_id,
                                    &st_position_in_byte,
                                    &size_in_byte,
                                    &frame_len,
                                    &label_dim);

                if (frame_len <= 0) {
                    INTER_LOG("warning data_load : frame_len <= 0 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (size_in_byte == 0) {
                    INTER_LOG("warning data_load : size_in_byte == 0 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (n_item != 6) {
                    INTER_LOG("warning data_load : n_item != 6 %s", desc_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                labels_param[key] = std::make_tuple(label_head[key].label_type, frame_len, label_dim);
                map_position[conf.first] = std::make_tuple(st_position_in_byte, size_in_byte);
                label_frame_len = frame_len;
            }
        }

        if (feature_frame_len != label_frame_len) {
            INTER_LOG("warning data_load : frame_frame_len != label_frame_len %d != %d", (int)feature_frame_len,
                      (int)label_frame_len);
            close_stream(one_block_stream);
            return;
        }

        if (feature_frame_len == 0 || label_frame_len == 0) {
            continue;
        }

        SpeechOneSentence* sentence = 
            new SpeechOneSentence(features_param, labels_param, file_name_map);

        for (auto conf : one_block_stream) {
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            std::string key = conf.first;
            std::string bin_file_name = get<2>(one_block[key]);
            std::string desc_file_name = get<3>(one_block[key]);
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            if (is_feature == true) {
                size_t st_position_in_byte = std::get<0>(map_position[conf.first]);
                size_t size_in_byte = std::get<1>(map_position[conf.first]);
                //feat data
                int ret = sentence->read_feature(conf.first, *bin_stream, st_position_in_byte, size_in_byte);
                // fatal error
                if (ret == -1) {
                    INTER_LOG("fatal error data_load : read feature file error %s", bin_file_name.c_str());
                    exit(0);
                }
                else if (ret != (int)size_in_byte) {
                    INTER_LOG("warning data_load : read feature file error %s", bin_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }
            }
            else {
                size_t st_position_in_byte = std::get<0>(map_position[conf.first]);
                size_t size_in_byte = std::get<1>(map_position[conf.first]);

                //label data
                int ret = sentence->read_label(conf.first, *bin_stream, st_position_in_byte, size_in_byte);
                if (ret != (int)size_in_byte) {
                    INTER_LOG("warning data_load : read label file error %s", bin_file_name.c_str());
                    close_stream(one_block_stream);
                    return;
                }

                if (_replace_label.size()) {
                    std::vector<int> &rep = _replace_label;
                    sentence->replace_label(rep[0], rep[1]);
                }
            }
        }

        int frame_len = std::get<1>(features_param.begin()->second);

        if (_drop_sentence_len > 0 && _drop_sentence_len <(int) frame_len) {
            //INTER_LOG("drop sentence %d", frame_len);
            delete sentence;
            continue;
        }

        int tmp_num = sentence->split_sentence(sample_buffer, 50, _split_sentence_len,
                                               _split_sentence_threshold,
                                               _integrity);
        if (tmp_num > 1) {
            delete sentence;
        }
        else {
            sample_buffer.push_back(sentence);
        }
    }

    close_stream(one_block_stream);
}

bool SpeechExtractData::get_feature_desc_head(BaseStream& file_stream, FeatureDescHead &head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)&head.data_type,
                        &head.data_num,
                        &head.dim);
    if (head.dim != 2) {
        return false;
    }
    if (n_item != 3) {
        return false;
    }
    return true;
}

bool SpeechExtractData::get_label_desc_head(BaseStream& file_stream, LabelDescHead&head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)&head.label_type,
                        &head.data_num,
                        (int*)&head.dim);
    if (head.dim != 2) {
        return false;
    }
    if (n_item != 3) {
        return false;
    }
    return true;
}

void SpeechExtractData::sample_random(std::vector<BaseOneSample*> & sample_vec, int batch_size) {
    if (!_sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    INTER_LOG("random sample size %zu, sort_size %d", sample_vec.size(), batch_size);
    std::random_shuffle(sample_vec.begin(), sample_vec.end());
    if (batch_size == 1) {
        return;
    }
    //根据句子长度排序
    sort(sample_vec.begin(), sample_vec.end(), [](BaseOneSample* a, BaseOneSample* b)->bool {
        SpeechOneSentence* s1 = dynamic_cast<SpeechOneSentence*>(a);
        SpeechOneSentence* s2 = dynamic_cast<SpeechOneSentence*>(b);
        return s1->get_frame_num() < s2->get_frame_num();

    });

    time_t seed = time(NULL);
    srandom(seed);
   
    int group_num = (int)(sample_vec.size() / batch_size);
    INTER_LOG("balance %d", (int)_balance);
    if (_balance && _slack > 0) { 
        // 句子帧数可以相差slack个
        // 查找可以松弛的区间
        int cur = 0;
        while (cur < group_num) {
            int start = cur;
            int end = cur;
            while (end < group_num) {
                SpeechOneSentence* sentence1 = dynamic_cast<SpeechOneSentence*>(sample_vec[start * batch_size]);
                SpeechOneSentence* sentence2 = dynamic_cast<SpeechOneSentence*>(sample_vec[(end + 1) * batch_size - 1]);
                int frame1 = sentence1->get_frame_num();
                int frame2 = sentence2->get_frame_num();
                if (frame2 - frame1 >= _slack) {
                    cur = end + 1;
                    std::random_shuffle(
                            sample_vec.begin() + start * batch_size, 
                            sample_vec.begin() + std::min((end + 1) * batch_size, (int)sample_vec.size()));
                    
                    INTER_LOG("group %d start %d end %d", group_num, start, end);
                    INTER_LOG("frame1 %d frame2 %d slack %d", frame1, frame2, _slack);
                    for (int j = start; j <= end; ++j) {
                        sort(sample_vec.begin() + j * batch_size, 
                                sample_vec.begin() + (j + 1) * batch_size,
                                [](BaseOneSample* a, BaseOneSample* b)->bool {
                                SpeechOneSentence* s1 = dynamic_cast<SpeechOneSentence*>(a);
                                SpeechOneSentence* s2 = dynamic_cast<SpeechOneSentence*>(b);
                                return s1->get_frame_num() < s2->get_frame_num();

                                });
                    }
                    break;
                }
                else {
                    ++end;
                }
            }

            if (cur >= group_num || end >= group_num) {
                end = group_num - 1;
                if (start <= end) {
                    std::random_shuffle(
                            sample_vec.begin() + start * batch_size, 
                            sample_vec.begin() + std::min((end + 1) * batch_size, (int)sample_vec.size()));

                    INTER_LOG("group %d start %d end %d", group_num, start, end);
                    for (int j = start; j <= end; ++j) {
                        sort(sample_vec.begin() + j * batch_size, 
                                sample_vec.begin() + (j + 1) * batch_size,
                                [](BaseOneSample* a, BaseOneSample* b)->bool {
                                SpeechOneSentence* s1 = dynamic_cast<SpeechOneSentence*>(a);
                                SpeechOneSentence* s2 = dynamic_cast<SpeechOneSentence*>(b);
                                return s1->get_frame_num() < s2->get_frame_num();
                                });
                    }
                }
                break;
            }
        }
    }

    for (uint64_t i = 0; i < (uint64_t)group_num; ++i) {
        uint64_t j = random() % (group_num - i) + i;
        if (i == j) {
            continue;
        }
        // featData start position
        for (uint64_t ii = 0; ii < (uint64_t)batch_size; ++ii) {
            std::swap(sample_vec[i * batch_size + ii], sample_vec[j * batch_size + ii]);
        }
    }
#endif
}

void SpeechExtractData::extract_all_data(std::vector<BaseOneSample*>& samples) {
    samples.clear();

    if (_threads.size() == 0) {
        start_thread();
    }

    _reading_samples.reserve(_file_cnt * 2000);
    for (int j = 0; j < _file_cnt; j++) {
        if (_next_file_load_idx < (int)_train_data_file_vec.size()) {
            std::vector<BaseOneSample*> buffer = _message_vector_sample.pop();
            _reading_samples.insert(_reading_samples.end(), buffer.begin(), buffer.end());
            _next_file_load_idx += 1;
        }
    }

    for (auto sample : _reading_samples) {
        samples.push_back(sample);
    }

    _reading_samples.clear();
}

} // houyi
} // train
