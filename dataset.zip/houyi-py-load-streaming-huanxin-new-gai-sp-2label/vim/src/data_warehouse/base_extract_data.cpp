//by zhxfl 2017.12.10
#include <algorithm>
#include "base_extract_data.h"
#include "base_stream.h"
#include "parse_string.h"
#include <omp.h>

namespace houyi {
namespace train {

void BaseExtractData::start_thread() {
    for (int i = 0; i < (int)_train_data_file_vec.size(); ++i) {
        _consumer.push(i);
    }
    for (int i = 0; i < _thread_num; i++) {
        _consumer.push(-1);
    }
    for (int i = 0; i < _thread_num; i++) {
        _threads.push_back(std::move(std::thread(&BaseExtractData::inter_extract_data, this, i)));
    }
}

void BaseExtractData::inter_extract_data(int thread_id) {
    while (_consumer.size()) {
        int idx = _consumer.pop();
        if (idx == -1) {
            break;
        }
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > one_block = 
            _train_data_file_vec[idx];

        std::vector<BaseOneSample*> buffer;
        if (!_stop) {
            read_sample(
                    one_block,
                    buffer,
                    thread_id);
        }

        _message_vector_sample.push(buffer);
    }
}

void BaseExtractData::get_data_file_list() {
    //检查是否列表为空
    CHECK2(_feature_list.size() || _label_list.size());
    std::vector<std::pair<std::string, std::vector<std::string>>> all_list;
    all_list.reserve(_feature_list.size() + _label_list.size());
    all_list.insert(all_list.end(), _feature_list.begin(), _feature_list.end());
    all_list.insert(all_list.end(), _label_list.begin(), _label_list.end());
    _train_data_file_vec.clear();
    _num_block_per_set.clear();
    char str[1024];
    str[0] = 0;

    // only check the first feature set 
    auto sample_set = _feature_list[0].second;
    _num_block_per_set.resize(sample_set.size(), 0);
    for (size_t j = 0; j < sample_set.size(); j++) {
        _num_block_per_set[j] = count_file_lines(sample_set[j]);
    }

    // 打开所有list文件
    // <list<list中的列表<feat | label, feat_desc_file | label_desc file> > >
    std::vector< std::vector< std::tuple<bool, size_t, std::string, std::string> > > all_blocks;
    all_blocks.resize( all_list.size() );
    for (size_t i = 0; i < all_list.size(); i++) {
        std::pair<std::string, std::vector<std::string>> one = all_list[i];

        std::string key = one.first;
        std::vector<std::string> path_vec = one.second;
        for (size_t j = 0; j < path_vec.size(); j++) { 
            std::string path = path_vec[j];
            std::ifstream dataFile(path.c_str());
            CHECK(dataFile.is_open(), "File could not found: %s", path.c_str());
            while (! dataFile.eof()) {
                std::string bin_file;
                std::string desc_file;
                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                bin_file = std::string(str);

                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                desc_file = std::string(str);
                //特征文件
                if (i < _feature_list.size()) {
                    all_blocks[i].push_back(std::make_tuple(true, j, bin_file, desc_file));
                    //标签文件
                } else {
                    all_blocks[i].push_back(std::make_tuple(false, j, bin_file, desc_file));
                }
            }
            dataFile.close();
        }
    }

    for (size_t i = 1; i < all_blocks.size(); i++) {
        CHECK2(all_blocks[i - 1].size() == all_blocks[i].size());
    }

    for (size_t i = 0; i < all_blocks[0].size(); i++) {
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > one_block;
        for (size_t j = 0; j < all_blocks.size(); j++) {
            std::string key = all_list[j].first;
            one_block[key] = all_blocks[j][i];
        }
        _train_data_file_vec.push_back(one_block);
    }
}

void BaseExtractData::random_data_file_list() {
    if (false == _sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    srandom(time(NULL));
    std::random_shuffle(_train_data_file_vec.begin(), _train_data_file_vec.end());
    balance_multi_sample_set();
#endif
}

void BaseExtractData::extract_data(std::vector<BaseOneSample*>& samples, int sent_num) {
    for (int i = 0; i < sent_num; i++) {
        if (_ready_samples.empty()) {
            if (_threads.size() == 0) {
                start_thread();
            }
            _reading_samples.reserve(_file_cnt * 2000);
            for (int j = 0; j < _file_cnt; j++) {
                while (_next_file_load_idx < (int)_train_data_file_vec.size()) {
                    std::vector<BaseOneSample*> buffer = _message_vector_sample.pop();
                   _reading_samples.insert(_reading_samples.end(), buffer.begin(), buffer.end());
                   _next_file_load_idx += 1;
                   if (buffer.size()) break;
                }
            }

            move_sample();

            if (_ready_samples.empty()) {
                break;
            }
        }
        samples.push_back(_ready_samples.front());
        _ready_samples.pop();
    }
}

void BaseExtractData::balance_multi_sample_set() {
    if (_num_block_per_set.size() == 1) {
        return;
    }

    std::vector<std::map<std::string, std::tuple<bool, size_t, std::string, std::string>>>
        vec = _train_data_file_vec; 
    _train_data_file_vec.clear();

    std::vector<size_t> num_block_per_load(_num_block_per_set.size(), 1);
    size_t all_blocks = std::accumulate(_num_block_per_set.begin(), _num_block_per_set.end(), 0);
    for (size_t i = 0; i < _num_block_per_set.size(); i++) {
        float lb = (float)_num_block_per_set[i] / all_blocks;
        num_block_per_load[i] += std::max((size_t)0, (size_t)(_file_cnt * lb) - 1); 
    }
    size_t left_blocks = _file_cnt - 
        std::accumulate(num_block_per_load.begin(), num_block_per_load.end(), 0);
    
    struct find_idx {
        size_t _id = 0;
        find_idx(size_t id) : _id(id) {};
        bool operator() (const std::map<std::string, std::tuple<bool, size_t, std::string, std::string>>& e) {
            auto it = e.begin();
            return (get<1>(it->second) == _id);
        }
    };

    for (size_t i = 0; i < all_blocks / 2 / _file_cnt; i++) {
        for (size_t j = 0; j < _num_block_per_set.size(); j++) {
            for (size_t s = 0; s < num_block_per_load[j]; s++) {
                auto it = std::find_if(vec.begin(), vec.end(), find_idx(j)); 
                if (it != vec.end()) {
                    _train_data_file_vec.push_back(*it);
                    vec.erase(it);
                } else {
                    _train_data_file_vec.push_back(*vec.begin());
                    vec.erase(vec.begin());
                }
            }
        } 

        if (left_blocks) {
            if (vec.size() >= left_blocks) {
                _train_data_file_vec.insert(_train_data_file_vec.end(), vec.begin(), vec.begin() + left_blocks);
                vec.erase(vec.begin(), vec.begin() + left_blocks);
            } else {
                _train_data_file_vec.insert(_train_data_file_vec.end(), vec.begin(), vec.end());
                vec.clear();
            }
        }
    }  

    if (vec.size()) {
        _train_data_file_vec.insert(_train_data_file_vec.end(), vec.begin(), vec.end());
        vec.clear();
    }
}

} // namespace houyi
} // namespace train
