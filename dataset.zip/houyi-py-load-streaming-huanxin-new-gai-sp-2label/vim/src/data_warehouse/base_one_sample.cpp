/**
 * base_one_sample.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-02
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include <utility>
#include <vector>
#include "base_one_sample.h"

namespace houyi {
namespace train {

}
}
