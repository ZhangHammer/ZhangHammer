// by zzxfl 2016.09.30
#include "speech_batch_sample.h"
#include "speech_batch_feature.h"
#include <malloc.h>
namespace houyi {
namespace train {
SpeechBatchSample::SpeechBatchSample(int batch_size,
                                     ParamFeatureT features,
                                     ParamLabelT labels):BaseBatchSample(batch_size)
{
    _batch_desc = new SpeechBatchDesc();
    for (auto conf : features) {
        FeatureKeyT key = conf.first;
        DataType data_type;
        FrameNumT frame_num;
        FrameDimT frame_dim;
        std::tie(data_type, frame_num, frame_dim) = conf.second;
        SpeechBatchFeature* feature = new SpeechBatchFeature(data_type, batch_size,
                frame_num, frame_dim);
        _features[key] = feature;
        _feature_keys.push_back(key);
    }

    for (auto conf : labels) {
        LabelKeyT key = conf.first;
        LabelType label_type;
        FrameNumT frame_num;
        LabelDimT label_dim;
        std::tie(label_type, frame_num, label_dim) = conf.second;
        _labels[key] = new SpeechBatchLabel(label_type, batch_size, frame_num, label_dim);
        _label_keys.push_back(key);
    }
}

void SpeechBatchSample::resize(int batch_size,
        ParamFeatureT features,
        ParamLabelT labels) {
    BaseBatchSample::resize(batch_size);
    _batch_desc->clear();
    for (auto conf : features) {
        FeatureKeyT key = conf.first;
        DataType data_type;
        FrameNumT frame_num;
        FrameDimT frame_dim;
        std::tie(data_type, frame_num, frame_dim) = conf.second;
        rename_feature(key);

        SpeechBatchFeature *feat = static_cast<SpeechBatchFeature*>(_features[key]);

        feat->resize(data_type, batch_size, frame_num, frame_dim);
    }

    for (auto conf : labels) {
        LabelKeyT key = conf.first;
        LabelType label_type;
        FrameNumT frame_num;
        LabelDimT label_dim;
        std::tie(label_type, frame_num, label_dim) = conf.second;
        rename_label(key);
        SpeechBatchLabel* label = NULL;
        label = static_cast<SpeechBatchLabel*>(_labels[key]);
        label->resize(label_type, batch_size, frame_num, label_dim);
    }
}

SpeechBatchSample::~SpeechBatchSample() {
    for (auto conf : _features) {
        delete conf.second;
    }
    _features.clear();
    for (auto conf : _labels) {
        delete conf.second;
    }
    _labels.clear();
    if (_batch_desc) {
        delete _batch_desc;
    }
}


void SpeechBatchSample::clear_frame(int pos) {
    for (auto conf: _features) {
        Tensor<DType>& feature = conf.second->get_feature();
        feature.get_block(Dim(pos, 0),
                          Dim(pos + 1, feature.get_size(1))).zero();
    }

    for (auto conf : _labels) {
        SpeechBatchLabel& dest_label = *(dynamic_cast<SpeechBatchLabel* > (conf.second));
        Tensor<DType>label(Dim(1,dest_label.get_label_dim()),  cpu_device());
        Tensor<int>mask(Dim(1),  cpu_device());
        label.set_element(0);
        dest_label.insert(pos, label, mask);
    }
}

void SpeechBatchSample::clear() {
    for (auto conf: _features) {
        Tensor<DType>& feature = conf.second->get_feature();
        feature.zero();
    }

    for (auto conf : _labels) {
        SpeechBatchLabel& dest_label = *(dynamic_cast<SpeechBatchLabel* > (conf.second));
        dest_label.get_label().set_element(0);
    }
}


}
}
