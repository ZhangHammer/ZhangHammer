/**
 * image_reader_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-04
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "image_reader_config.h"
#include "data_tool.h"
#include "util.h"

namespace houyi {
namespace train {

void ImageReaderConfig::parse_params(std::string &config_line) {
    read_multi_feature_label(config_line);

    parse_from_string("readFromDisk", &config_line, &_read_from_disk);
    INTER_LOG("readFromDisk=%d", (int)_read_from_disk);

    parse_from_string("isReadAllSample", &config_line, &_is_read_all_sample);
    INTER_LOG("isReadAllSample=%d", (int)_is_read_all_sample);

    parse_from_string("splitImageSubSize", &config_line, &_split_image_sub_size);
    INTER_LOG("splitImageSubSize=%d", (int)_split_image_sub_size);

    parse_from_string("splitImagePerturb", &config_line, &_split_image_perturb);
    INTER_LOG("splitImagePerturb=%d", (int)_split_image_perturb);

    parse_from_string("isControlLabel", &config_line, &_is_control_label);
    INTER_LOG("isControlLabel=%d", (int)_is_control_label);

    parse_from_string("diskCache", &config_line, &_disk_cache);
    INTER_LOG("diskCache=%d", (int)_disk_cache);
}

}
}

