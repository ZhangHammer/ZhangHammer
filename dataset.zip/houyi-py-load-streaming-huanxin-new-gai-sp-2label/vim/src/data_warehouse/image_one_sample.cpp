/**
 * image_one_sample.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-02
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 * modify by zzxfl 2016.11.03 : 支持多特征多标签输入
 */
#include <utility>
#include <vector>
#include <fstream>
#include "image_one_sample.h"

namespace houyi {
namespace train {
// features std::tuple<FeatureDesc, DataType, size_t, size_t, size_t>
//          --> std::tuple<Datatype, height, width, channels>
// labels std::tuple<LabelType, size_t> i
//        --> std::tuple<LabelType, label_size>
ImageOneSample::ImageOneSample(
    ParamFeatureT features,
    ParamLabelT labels) {
    //初始化多个特征
    for (auto conf: features) {
        DataType type;
        FeatureDescT feature_desc;
        size_t height = 0;
        size_t width = 0;
        size_t channel = 0;
        std::string key = conf.first;
        std::tie(feature_desc, type, channel, height, width) = conf.second;
        ImageOneFeature* feature = NULL;

        switch (type) {
        case RGB24_TYPE:
        case BBGGRR_FLOAT_TYPE:
        case JPEG_TYPE:
            feature = new ImageOneFeature(feature_desc, type, channel, height, width);
            break;
        case GRAY_FLOAT_TYPE:
            feature = new ImageOneFeature(feature_desc, type, channel, height, width);
            break;
        default:
            CHECK(false ,"image type not support");
        }
        _feature_keys.push_back(key);
        _features[key] = feature;
        _file_name[key] = feature_desc;
        _scale[key] = 1.0;//特征放大缩小的系数,默认为1
    }
    //初始化多个label
    for (auto conf: labels) {
        BaseOneLabel* label = NULL;
        LabelType label_type = INT_LABEL_TYPE;
        size_t label_size = 0;
        std::string key = conf.first;
        std::tie(label_type, label_size) = conf.second;

        label = new ImageOneLabel(label_type, label_size);
        _label_keys.push_back(key);
        _labels[key] = label;
    }
}

ImageOneSample::~ImageOneSample() {
    for (auto d : _features) {
        delete d.second;
    }
    _features.clear();
    for (auto l : _labels) {
        delete l.second;
    }
    _labels.clear();

    _label_keys.clear();
    _feature_keys.clear();
}

int ImageOneSample::read_feature(
    std::string key,
    BaseStream&in_stream,
    size_t st_position_in_byte,
    size_t size_in_byte) {
    CHECK2(_features.find(key) != _features.end());
    ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
    int ret = feature->read_data(in_stream, st_position_in_byte, size_in_byte);
    return ret;
}

int ImageOneSample::read_label(
    std::string key,
    BaseStream&in_stream,
    size_t st_position_in_byte,
    size_t size_in_byte) {
    CHECK2(_labels.find(key) != _labels.end());
    ImageOneLabel* label = dynamic_cast<ImageOneLabel*>(_labels[key]);
    return label->read_label(in_stream, st_position_in_byte, size_in_byte);
}

int ImageOneSample::split_image(std::vector<ImageOneSample*>&vec, int perturb, int sub_size) {
    std::string feature_key = _feature_keys[0];
    std::string label_key = _label_keys[0];
    int counter = 0;
    //只支持单特征单标签
    CHECK2(_feature_keys.size() == 1);
    CHECK2(_label_keys.size() == 1);

    int channel = get_channel(feature_key);
    int height = get_height(feature_key);
    int width = get_width(feature_key);

    int remain_height = height;
    if (remain_height <= sub_size + perturb)
        return 1;

    int cur_height_pos = 0;
    do {
        int cur_height = sub_size + random() % perturb;
        if (cur_height > remain_height) {
            cur_height = remain_height;
            break;
        }
        ImageOneSample::ParamFeatureT feature_param;
        ImageOneSample::ParamLabelT label_param;
        feature_param[feature_key] = std::make_tuple(get_file_name(feature_key), get_data_type(feature_key),
                                     channel,
                                     cur_height,
                                     width);

        label_param[label_key] = std::make_tuple(get_label_type(label_key),
                                 get_label_dim(label_key));

        ImageOneSample* sample = new ImageOneSample(feature_param, label_param);
        sample->get_label_tensor(label_key).copy_from(this->get_label_tensor(label_key));
        Tensor<DType>& feat = sample->get_feature_tensor(feature_key);
        Tensor<DType>& feature_tensor = get_feature_tensor(feature_key);

        //拷贝特征
        for (int j = 0; j < channel; j++) {
            for (int h = 0; h < cur_height; h++) {
                DType* to = feat.get_data(Dim(j, h, 0));
                DType* from = feature_tensor.get_data(Dim(j, cur_height_pos + h, 0));
                memcpy(to, from, sizeof(float) * width);
            }
        }
        remain_height -= cur_height;
        cur_height_pos += cur_height;
        counter++;
        vec.push_back(sample);
    } while (remain_height > 0);
    return counter;
}

}
}
