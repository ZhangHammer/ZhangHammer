/**
 * image_data_reader.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-1
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <base_stream.h>
#include <chrono>
#include <omp.h>

#include "image_data_reader.h"
#include "image_one_sample.h"
#include "message_queue.h"

namespace houyi {
namespace train {

ImageDataReader :: ImageDataReader(BaseReaderConfig &cfg) : BaseDataReader(cfg) {
    _all_sample_idx = 0;
    ImageReaderConfig *image_cfg = dynamic_cast<ImageReaderConfig *>(&cfg);

    _extract_data_runtime.push_back(
        new ImageExtractData(
            image_cfg->get_feat_list(),
            image_cfg->get_label_list(),
            image_cfg->get_load_block_num(),
            image_cfg->get_device_num(),
            image_cfg->get_sample_random(),
            image_cfg->get_split_image_sub_size(),
            image_cfg->get_split_image_perturb()
        )
    );

    _read_from_disk = image_cfg->get_read_from_disk();
    _is_read_all_sample = image_cfg->get_is_read_all_sample();
    INTER_LOG("is_read_all_sample %d", _is_read_all_sample);

    if (_read_from_disk == false && _is_read_all_sample == false) {
        _sample_queue.set_max_length(30000);
    }

    _image_cfg = image_cfg;
    _sample_random = _image_cfg->get_sample_random();
    //一次性加载所有样本
    if (_is_read_all_sample) {
        read_all_sample();
    }
}

ImageDataReader::~ImageDataReader() {
    for (auto runtime : _extract_data_runtime) {
        delete runtime;
    }
}

void ImageDataReader::reset() {
    random_data_file_list();
    sample_random(_all_sample);
    for (auto runtime : _extract_data_runtime) {
        runtime->reset();
    }
}

void ImageDataReader::read_all_sample() {
    uint32_t image_counter = 0;
    std::vector<BaseOneSample*> sample_vec;
    while (true) {
        std::vector<BaseOneSample*> tmp_vec;
        _extract_data_runtime[0]->extract_data(tmp_vec, 1000);
        if (sample_vec.size()) {
            _sample_vector.insert(_sample_vector.end(), tmp_vec.begin(), tmp_vec.end());
        }else {
            break;
        }
    }
    _all_sample.swap(sample_vec);
    sample_random(_all_sample);
    INTER_LOG("read all sample %u", image_counter);
}

size_t ImageDataReader::get_samples_from_reader(
            std::vector<BaseOneSample*>& samples,
            int sample_num) {
#ifdef __PRINT_DATA_BUFFER_SIZE__
    INTER_LOG("reader buffer size: %d", (int)_sample_queue.size());
#endif
    if (_read_from_disk) {
        std::lock_guard<std::mutex> lock(_read_mutex);
        _extract_data_runtime[0]->extract_data(samples, sample_num);
        return samples.size();
    }
    else if (_is_read_all_sample) {
        std::lock_guard<std::mutex> lock(_read_mutex);

        int real_sample_num = 0;
        for (int i = 0; i < sample_num; i++) {
            if (_sample_queue.size() == 0) {
                size_t sample_cnt = 0;
                for (; _all_sample_idx < (int)_all_sample.size();) {
                    ImageOneSample* tmp = dynamic_cast<ImageOneSample*>(_all_sample[_all_sample_idx++]);
                    ImageOneSample* sample = new ImageOneSample(*tmp);
                    _sample_queue.push(sample);
                    sample_cnt++;
                }
                if (sample_cnt == 0)
                    break;
            }
            BaseOneSample* sample = _sample_queue.pop();
            samples.push_back(sample);
            real_sample_num ++;
        }
        return real_sample_num;
    }
    //从阻塞队列里面获取数据直到结尾数据为空
    else {
        //该逻辑不可重入，保证数据的有序性
        std::unique_lock<std::mutex>lock(_read_mutex);
        int real_sample_num = 0;
        for (int i = 0; i < sample_num; i++) {
            if (_finish_thread) {
                _finish_thread--;
                samples.push_back(NULL);
                break;
            }
            BaseOneSample* sample = _sample_queue.pop();

            if (sample == NULL) {
                samples.push_back(NULL);
                _finish_thread = _device_num;
                _finish_thread--;
                break;
            }
            real_sample_num ++;
            samples.push_back(sample);
        }
        return real_sample_num;
    }
}

void ImageDataReader::push_batch_to_reader(Tensor<DType>* feature, Tensor<DType>* label) {
    if (feature == NULL || label == NULL) {
        _sample_queue.push(NULL);
        return;
    }

    size_t batch_num = feature->get_size()[0];
    ImageOneSample::ParamFeatureT features_param;
    ImageOneSample::ParamLabelT labels_param;

    std::string feature_key =_image_cfg->get_feat_list()[0].first;
    std::string label_key = _image_cfg->get_label_list()[0].first;
    size_t channel = feature->get_c();
    size_t width = feature->get_w();
    size_t height = feature->get_h();
    DataType data_type;
    if (channel == 3) {
        data_type = BBGGRR_FLOAT_TYPE;
    }
    else if (channel == 1) {
        data_type = GRAY_FLOAT_TYPE;
    }
    else {
        CHECK(false, "error");
    }
    LabelType label_type = INT_LABEL_TYPE;
    size_t label_dim = label->get_w();
    std::vector<BaseOneSample*>tmp_sample_buffer;

    features_param[feature_key] = std::make_tuple("", data_type, channel, height, width);
    labels_param[label_key] = std::make_tuple(label_type, label_dim);
    for (size_t b = 0; b < batch_num; b++) {
        ImageOneSample* sample = new ImageOneSample(features_param, labels_param);
        //feature
        Tensor<DType> one_feature = feature->get_block(Dim(b, 0, 0, 0),
                                    Dim(b + 1, channel, height, width));
        //one_feature.reshape(Dim(channel, height, width));
        sample->get_feature_tensor(feature_key).copy_from(one_feature);
        //key
        Tensor<DType> one_label = label->get_block(Dim(b, 0), Dim(b + 1, label_dim));
        //one_label.reshape(Dim(label_dim));
        sample->get_label_tensor(label_key).copy_from(one_label);
        tmp_sample_buffer.push_back(sample);
    }
    sample_random(tmp_sample_buffer);
    for (auto sample : tmp_sample_buffer) {
        _sample_queue.push(sample);
    }
}

void ImageDataReader::random_data_file_list() {
    if (!_sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    for (auto runtime : _extract_data_runtime) {
        runtime->random_data_file_list();
    }
#endif
}


void ImageDataReader::sample_random(std::vector<BaseOneSample *> &sample_vector) {
    if (!_sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    srandom(time(NULL));
    std::random_shuffle(sample_vector.begin(), sample_vector.end());
    INTER_LOG("random samples");
#endif
}

}
}
