//by zzxfl 2016.08.30
#include "speech_frame_repository.h"
#include "speech_frame_processer.h"
#include "speech_sent_repository.h"
#include "speech_one_sentence.h"
#include "speech_batch_sample.h"
#include "object_factory.h"

namespace houyi {
namespace train {
SpeechBatchSample::ParamFeatureT
SpeechFrameRepository::get_features_param(SpeechOneSentence& sample) {
    SpeechBatchSample::ParamFeatureT feature_param;

    std::vector<std::string>feature_key = sample.get_feature_keys();
    for (auto key : feature_key) {
        feature_param[key] = std::make_tuple(
                                 sample.get_data_type(key),
                                 1,
                                 _cfg->get_do_splice() ? sample.get_frame_dim(key) * (1 + _cfg->get_left_context() + _cfg->get_right_context()) : sample.get_frame_dim(key));
    }
    return feature_param;
}

SpeechBatchSample::ParamLabelT SpeechFrameRepository::get_labels_param(SpeechOneSentence& sample) {
    SpeechBatchSample::ParamLabelT label_param;
    std::vector<std::string>label_key = sample.get_label_keys();

    for (auto key : label_key) {
        label_param[key] = std::make_tuple(
                               sample.get_label_type(key),
                               1,
                               sample.get_label_dim(key));
    }
    return label_param;
}

void SpeechFrameRepository::reset() {
    _laster_batch = false;
    BaseRepository::reset();
}

size_t SpeechFrameRepository::inter_get_batch(
    std::vector <BaseBatchSample*> & batches, size_t max_num) {
    _batch_size = _new_batch_size;

    if (_laster_batch == true) {
        INTER_LOG("epoch is finish, reset speech_frame_repository");
        return 0;
    }
    size_t counter = 0;

    SpeechFrameProcesser* speech_frame_processer = static_cast<SpeechFrameProcesser*>(_data_processer);

    for (size_t i = 0; i < max_num; i++) {
        int start_pos = 0;
        int end_pos = 0;
        int ret = speech_frame_processer->get_randomized_frames_from_proc(_batch_size, &start_pos, &end_pos);

        if (ret == -1) {
            _laster_batch = true;
            return 0;
        }
        
        const auto& sample_buf = speech_frame_processer->_ready_pool.first;

        const auto& frame_index = speech_frame_processer->_ready_pool.second;

        SpeechBatchSample::ParamFeatureT feature_param = get_features_param(
                    *(dynamic_cast<SpeechOneSentence*>(sample_buf[0])));
        SpeechBatchSample::ParamLabelT label_param = get_labels_param(
                    *(dynamic_cast<SpeechOneSentence*>(sample_buf[0])));
        SpeechBatchSample* bat = NULL;
        bat = static_cast<SpeechBatchSample*>(ObjectFactory<BaseBatchSample>::instance()->create_object());
        
        if (bat == NULL) {
            bat = new SpeechBatchSample(_batch_size,
                    feature_param, label_param);
        }
        bat->resize(_batch_size, feature_param, label_param);

        std::vector<std::string> label_keys = sample_buf[0]->get_label_keys();
        std::vector<std::string> feature_keys = sample_buf[0]->get_feature_keys();

        for (int c = start_pos; c < end_pos; c++) {
            int sent_id = frame_index[c].first;
            int frame_id = frame_index[c].second;
                
            SpeechOneSentence *sent = dynamic_cast<SpeechOneSentence *>(sample_buf[sent_id]);

            if (!_cfg->get_do_splice()) {
                sent->copy_next_frame(*bat, c - start_pos, frame_id);
            } else {
                sent->copy_spliced_frame(*bat, c - start_pos, frame_id, _cfg->get_left_context(), _cfg->get_right_context());
            }
        }
        if (end_pos - start_pos < (int)_batch_size) {
            bat->clear_frame(end_pos - start_pos);
        }
        batches.push_back((BaseBatchSample*)bat);
        counter ++;
    }
    return counter;
}

}//houyi
}//train
