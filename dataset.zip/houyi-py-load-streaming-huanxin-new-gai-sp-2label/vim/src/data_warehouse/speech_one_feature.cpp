//by zzxfl 2016.09.23
#include "speech_one_feature.h"
#include "data_tool.h"
namespace houyi {
namespace train {

int SpeechOneFeature::read_data(BaseStream& in_stream,
                                size_t st_position_in_byte,
                                size_t size_in_byte) {

    if (_data_type == FBANK_TYPE) {
        std::string buffer;
        CHECK2(_data.get_element_count() * sizeof(DType) == size_in_byte);

        in_stream.seekg(st_position_in_byte, std::ios::beg);
        in_stream.read((char*)_data.get_data(), size_in_byte);
        for (size_t i = 0; i < _data.get_element_count(); i++) {
            //TODO:统一了特征就去掉
            if (fabs(_data.get_data()[i]) >= 10e8) {
                INTER_LOG("fabs(_data.get_data()[i]) >= 10e8 %f", _data.get_data()[i]);
                return -1;
            }
        }

        size_t ret = in_stream.gcount();
        return ret;
    }
    else if (_data_type == FBANK_SWAP32_TYPE) {
        std::string buffer;
        CHECK2(_data.get_element_count() * sizeof(DType) == size_in_byte);

        in_stream.seekg(st_position_in_byte, std::ios::beg);
        in_stream.read((char*)_data.get_data(), size_in_byte);
        for (size_t i = 0; i < _data.get_element_count(); i++) {
            //TODO:统一了特征就去掉
            swap32((char*)&_data.get_data()[i]);
            if (fabs(_data.get_data()[i]) >= 10e8) {
                INTER_LOG("fabs(_data.get_data()[i]) >= 10e8 %f", _data.get_data()[i]);
                return -1;
            }
            //CHECK2(fabs(_data.get_data()[i]) <= 10e8);
        }

        size_t ret = in_stream.gcount();
        return ret;

    }
    else if (_data_type == FBANK_SHORT_TYPE) {
        //数据保存为short
        std::string buffer;
        CHECK2(_data.get_element_count() * sizeof(DType) == 
                sizeof(DType) / sizeof(short) * size_in_byte);
        in_stream.seekg(st_position_in_byte, std::ios::beg);
        in_stream.read((char*)_data.get_data(), size_in_byte);
        const short* short_data = 
            static_cast<const short*>(static_cast<void*>(_data.get_data()));

        //反过来遍历，避免要重新申请一个临时空间
        DType* dtye_data = _data.get_data();
        for (int i = static_cast<int>(_data.get_element_count() - 1); i >= 0; --i) {
            dtye_data[i] = static_cast<DType>(short_data[i]) * 0.001;
        }
        size_t ret = in_stream.gcount();
        return ret;
    }
    else {
        CHECK2(false);
        return 0;
    }
    return 0;
}//read_data

}//houyi
}//train

