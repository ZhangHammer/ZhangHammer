#include "object_factory.h"
#include "speech_batch_sample.h"
namespace houyi {
namespace train {

template <typename OBJECT>
OBJECT* ObjectFactory<OBJECT>::create_object() {
    //加锁,保护_queue
    std::lock_guard<std::mutex> lock(_mutex);
    //直接返回
    if (!_queue.empty()) {
        Node node = _queue.top();
        _queue.pop();
        //INTER_LOG("pop %d node.size %d", _queue.size(), node.size);
        return node.obj;
    }
    else {
        return NULL;
    }
}

template <typename OBJECT>
void ObjectFactory<OBJECT>::delete_object(OBJECT* obj) {
    //加锁,保护_queue
    std::lock_guard<std::mutex> lock(_mutex);
    //判断队列是否满了
    if (can_push()) {
        _queue.push(Node(obj->get_feature_size(), obj));
        //INTER_LOG("push %d node.size %d", _queue.size(), obj->get_feature_size());
    }else {
        if (_queue.size() == 0) {
            delete obj;
            return;
        }
        OBJECT* top_obj = _queue.top().obj;
        if (obj->get_feature_size() > top_obj->get_feature_size()) {
            _queue.pop();
            _queue.push(Node(obj->get_feature_size(), obj));
            //INTER_LOG("push %d node.size %d pop node.size %d", _queue.size(),
            //        obj->get_feature_size(),
            //        top_obj->get_feature_size());
            delete top_obj;
        }else {
            delete obj;
        }
    }
}
template class ObjectFactory<BaseBatchSample>;
}
}
