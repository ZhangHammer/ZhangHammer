/**
 * base_respository.cpp
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-5
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "image_repository.h"
#include "speech_frame_repository.h"
#include "speech_sent_repository.h"

namespace houyi {
namespace train {

BaseRepository* BaseRepository::create(
    BaseProcesser *proc, BaseReposConfig& cfg, int device_id) {
    BaseRepository* repos = NULL;
    switch (cfg.get_type()) {
    case REPOS_SPEECH_SENT:
        repos = new SpeechSentRepository(proc, cfg, device_id);
        break;
    case REPOS_SPEECH_FRAME:
        repos = new SpeechFrameRepository(proc, cfg, device_id);
        break;
    case REPOS_IMAGE:
        repos = new ImageRepository(proc, cfg, device_id);
        break;
    case REPOS_SPEECH_SENT_3D:
        INTER_LOG("use transBatchTranspose instead");
        CHECK2(false);
        break;
    default:
        CHECK2(false);
    }
    if (repos == NULL) {
        return NULL;
    }

    if (cfg.is_async()) {
        repos->start_async_load();
    }
    return repos;
}

void BaseRepository::perform_trans_stream(BaseBatchSample& batch, int idx) {
    CHECK2(idx < (int)_trans_stream.size());
    std::vector<BaseBatchTransformation*>&tmp = _trans_stream[idx];
    for (size_t i = 0; i < tmp.size(); i++) {
        tmp[i]->perform_trans(batch);
    }
}

void BaseRepository::trans_read(int thread_num) {
    BaseBatchTransformation* trans = NULL;
    _trans_stream.resize(thread_num);
    for (int t = 0; t < thread_num; t++) {
        std::vector<std::string>trans_lines = _cfg->get_trans_lines();
        for (size_t i = 0; i < trans_lines.size(); i++) {
            trans = BaseBatchTransformation::read(trans_lines[i]);
            _trans_stream[t].push_back(trans);
        }
    }
}

std::pair<BaseBatchSample*, DeviceBatchSample*> BaseRepository::get_device_batch_from_repos() {
#ifndef __BUILD_PY_DATA_LOAD__
    return _device_batch_queue.pop();
#else
    BaseBatchSample* bat = _batch_queue->pop();
    DeviceBatchSample* device_bat = NULL;
    return std::make_pair(bat, device_bat); 
#endif
}

void BaseRepository::start_async_load() {
    if (_async_buf_thread.joinable()) {
        return;
    }
    if (_batch_queue == NULL) {
        _batch_queue = new MessageQueue<BaseBatchSample*>();
        _batch_queue->set_max_length(_max_buf_num);
    } else {
        _batch_queue->clean();
    }
    _async_buf_thread = std::move(std::thread(&BaseRepository::async_buf_load, this));
#ifndef __BUILD_PY_DATA_LOAD__
    _thread_device_batch = std::move(std::thread(&BaseRepository::async_copy_to_device, this));
#endif
}

void BaseRepository::async_copy_to_device() {
    wind_init(_device_id);
    wind_set_gpu_device(_device_id);

    do {
        BaseBatchSample* base_batch_sample =_batch_queue->pop();
        if (base_batch_sample == NULL) {
            _device_batch_queue.push(std::make_pair(static_cast<BaseBatchSample*>(NULL),
                        static_cast<DeviceBatchSample*>(NULL)));
            break;
        }
        else {
            DeviceBatchSample* device_batch_sample = _unused_device_batch.pop();
            device_batch_sample->copy_from(base_batch_sample);
            _device_batch_queue.push(std::make_pair(base_batch_sample, device_batch_sample));
        }
    } while (true);
}

void BaseRepository::async_buf_load() {
    wind_init(_device_id);
    wind_set_gpu_device(_device_id);
    std::vector <BaseBatchSample*> batches;
    size_t bat_cnt = 0;
    do {
        bat_cnt = inter_get_batch(batches, 8);
#ifdef __PRINT_DATA_BUFFER_SIZE__
        INTER_LOG("%ld repository buffer size: %ld", std::thread::id::get_id(),
                    get_queue()->size());
#endif
        if (batches.size()) {
            for (size_t i = 0; i < batches.size(); i++) {
                perform_trans_stream(*batches[i], 0);
                get_queue()->push(batches[i]);
            }
            batches.clear();
        } else {
            get_queue()->push(NULL);
            break;
        }
    } while (bat_cnt);
}

}
}
