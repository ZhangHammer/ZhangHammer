// by zzxfl 2016.11.26
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "disc_image_data_reader.h"
#include "image_one_sample.h"
#include "message_queue.h"

namespace houyi {
namespace train {

void DiscImageDataReader::reset() {
    //从磁盘加载数据标志位复位
    _next_file_load_idx = 0;
    _done_image_num = 0;
    random_data_file_list();
}

void DiscImageDataReader::random_data_file_list() {
    if (!_sample_random) {
        return;
    }
    std::random_shuffle(_train_data_file_vec.begin(), _train_data_file_vec.end());
}

size_t DiscImageDataReader::get_samples_from_reader(
    std::vector<BaseOneSample*>& samples,
    int sample_num) {
    if (_read_from_disk) {
        std::lock_guard<std::mutex> lock(_read_mutex);
        int real_sample_num = 0;

        for (int i = 0; i < sample_num; i++) {

            //队列中的数据不够
            if (_sample_queue.size() == 0) {
                size_t sample_cnt = read_samples_from_disk();
                //磁盘中的数据已经读完
                if (sample_cnt == 0) {
                    break;
                }
                //cout<<"Image random"<<endl;
                sample_random(_sample_vector);
                //cout<<"Done!"<<endl;
                move_sample_to_queue();
            }
            BaseOneSample* sample = _sample_queue.pop();
            //static int idx = 0;
            //INTER_LOG("sample idx %d", idx++);

            samples.push_back(sample);
            //INTER_LOG("push_from disck idx %d  is from_dis %d", idx++, _read_from_disk);
            _done_image_num++;
            real_sample_num++;
        }

        return real_sample_num;
    }
    //从阻塞队列里面获取数据直到结尾数据为空
    else {
        //该逻辑不可重入，保证数据的有序性
        std::unique_lock<std::mutex>lock(_read_mutex);
        int real_sample_num = 0;
        for (int i = 0; i < sample_num; i++) {
            if (_finish_thread) {
                _finish_thread--;
                samples.push_back(NULL);
                break;
            }

            BaseOneSample* sample = _sample_queue.pop();

            if (sample == NULL) {
                samples.push_back(NULL);
                _finish_thread = _device_num;
                _finish_thread--;
                break;
            }
            _done_image_num++;
            real_sample_num++;
            samples.push_back(sample);
        }
        return real_sample_num;
    }
}

void DiscImageDataReader::push_batch_to_reader(Tensor<DType>* feature, Tensor<DType>* label) {
    //std::lock_guard<std::mutex> lock(_read_mutex);
    if (feature == NULL || label == NULL) {
        _sample_queue.push(NULL);
        return;
    }

    size_t batch_num = feature->get_size()[0];
    ImageOneSample::ParamFeatureT features_param;
    ImageOneSample::ParamLabelT labels_param;

    std::string feature_key = _image_reader_cfg->get_feat_list()[0].first;
    std::string label_key = _image_reader_cfg->get_label_list()[0].first;
    size_t channel = feature->get_size(1);
    size_t height = feature->get_size(2);
    size_t width = feature->get_size(3);
    //TODO 
    
    DataType data_type = BBGGRR_FLOAT_TYPE;
    LabelType label_type = INT_LABEL_TYPE;
    //DataType data_type = _image_reader_cfg->get_data_type();
    //LabelType label_type = _image_reader_cfg->get_label_type();
    //TODO 未测试
    size_t label_dim = label->get_size(1);

    features_param[feature_key] = std::make_tuple("", data_type, channel, height, width);
    labels_param[label_key] = std::make_tuple(label_type, label_dim);
    std::vector<ImageOneSample*>tmp_sample_buffer;

    for (size_t b = 0; b < batch_num; b++) {
        ImageOneSample* sample = new ImageOneSample(features_param, labels_param);
        //feature
        Tensor<DType> one_feature = feature->get_block(Dim(b, 0, 0, 0),
                                    Dim(b + 1, channel, height, width));
        //one_feature.reshape(Dim(channel, height, width));
        sample->get_feature_tensor(feature_key).copy_from(one_feature);
        //key
        Tensor<DType> one_label = label->get_block(Dim(b, 0), Dim(b + 1, label_dim));
        //one_label.reshape(Dim(label_dim));
        sample->get_label_tensor(label_key).copy_from(one_label);
        tmp_sample_buffer.push_back(sample);
        /*
        static int idx = 0;
        INTER_LOG("push %d idx %d", idx++, one_label.get_data()[0]);
        */
    }
    std::random_shuffle(tmp_sample_buffer.begin(), tmp_sample_buffer.end());
    for (auto sample : tmp_sample_buffer) {
        _sample_queue.push(sample);
    }
}

void DiscImageDataReader::sample_random(std::vector<BaseOneSample *> &sample_vector) {
    if (!_sample_random)
        return;
    srandom(time(NULL));
    //合并之前剩余的
    sample_vector.insert(sample_vector.end(), _sample_remain.begin(), _sample_remain.end());
    _sample_remain.clear();

    //标签分组
    std::map<int, std::vector<BaseOneSample*> > sample_map;
    for (auto sample : sample_vector)
    {
        std::vector<std::string> label_key = sample->get_label_keys();
        int label_id = sample->get_label_tensor(label_key[0]).get_data()[0];
        sample_map[label_id].push_back(sample);
    }

    // 同样标签的乱序
    sample_vector.clear();
    for (std::map<int, std::vector<BaseOneSample*>> ::iterator iter =
                sample_map.begin(); iter != sample_map.end(); iter++) {
        std::vector<BaseOneSample*>& tmp_vector = iter->second;
        std::random_shuffle(tmp_vector.begin(), tmp_vector.end());
        //拷贝出偶数个
        for (int i = 0; i < (int)tmp_vector.size() / 2 * 2; i++) {
            sample_vector.push_back(tmp_vector[i]);
        }
        //可能剩余一个放在_sample_remain等待下次使用
        if (tmp_vector.size() % 2 == 1) {
            _sample_remain.push_back(tmp_vector.back());
        }
    }
    // 分组成对乱序
    int group_num = sample_vector.size() / 2;
    for (int i = 0; i < group_num; ++i) {
        int j = random() % (group_num -i) + i;
        std::swap(sample_vector[j * 2 + 0], sample_vector[i * 2 + 0]);
        std::swap(sample_vector[j * 2 + 1], sample_vector[i * 2 + 1]);
    }
    INTER_LOG("remain buff %d", (int)_sample_remain.size());
}

void DiscImageDataReader::move_sample_to_queue() {
    for (auto it = _sample_vector.begin(); it != _sample_vector.end(); ++it) {
        _sample_queue.push(*it);
    }
    _sample_vector.clear();

}

size_t DiscImageDataReader::read_samples_from_disk() {
    int block_load = _max_block_load;

    int left_block = (int)(_train_data_file_vec.size()) - _next_file_load_idx;
    if (block_load> left_block) {
        block_load = left_block;
    }

    //所有block读取完毕，返回
    if (block_load == 0) {
        return 0;
    }

    uint32_t image_counter = 0;
    for (int i = _next_file_load_idx; i < block_load+
            _next_file_load_idx; i++) {
        image_counter += read_samples_from_disk(
                             _train_data_file_vec[i]);
    }

    __sync_fetch_and_add(&_next_file_load_idx, block_load);
    return image_counter;
}

/*
 *
 */
size_t DiscImageDataReader::read_samples_from_disk(std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block) {
    //打开文件
    std::map<std::string, std::tuple<bool, BaseStream*, BaseStream*> > one_block_stream;
    for (auto conf : one_block) {
        std::string key = conf.first;
        bool is_feature = false;
        size_t idx = 0;
        std::string bin_file;
        std::string desc_file;
        std::tie(is_feature, idx, bin_file, desc_file) = conf.second;
        // open the featFile
        BaseStream* bin_stream = new IfStream(bin_file);
        if (bin_stream->fail()) {
            perror(bin_file.c_str());
            exit(1);
        }
        // open the desc
        BaseStream* desc_stream = new IfStream(desc_file);
        //INTER_LOG("read file %s", desc_file.c_str());
        if (desc_stream->fail()) {
            perror(desc_file.c_str());
            exit(1);
        }
        one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
    }

    //注意:读取数据,打包时需要满足不同特征或者不同标签的samples数一致,或者只取最少那个
    //读取头并且进行校验
    std::map<std::string, FeatureDescHead> feature_head;
    std::map<std::string, LabelDescHead> label_head;
    int data_num = -1;

    for (auto conf : one_block_stream) {
        //feature_dest
        if (std::get<0>(conf.second) == true) {
            FeatureDescHead head;
            get_feature_desc_head(*std::get<2>(conf.second), head);
            feature_head[conf.first] = head;
            if (data_num == -1)
                data_num = head.data_num;
            else {
                CHECK2(data_num == head.data_num);
            }
        }
        //label_dest
        else if (std::get<0>(conf.second) == false) {
            LabelDescHead head;
            get_label_desc_head(*std::get<2>(conf.second), head);
            label_head[conf.first] = head;
            if (data_num == -1)
                data_num = head.data_num;
            else {
                CHECK2(data_num == head.data_num);
            }
        }
    }

    //读取数据
    for (int data_id = 0; data_id < data_num; data_id++) {
        ImageOneSample::ParamFeatureT features_param;
        ImageOneSample::ParamLabelT labels_param;
        std::map<std::string, std::pair<size_t, size_t> > map_position;

        for (auto conf : one_block_stream) {
            //feature_dest
            char file_name[2048];
            size_t start_position_in_byte = 0;
            size_t size_in_byte = 0;
            size_t channel = 0;
            size_t height = 0;
            size_t width = 0;
            size_t label_dim = 0;
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            if (is_feature == true) {
                char str[2048];
                desc_stream->getline(str, 2048);

                int n_item = sscanf(str, "%s %zd%zd%zd%zd%zd",
                                    file_name, &start_position_in_byte,
                                    &size_in_byte,
                                    &channel, &height, &width);
                CHECK2(n_item == 6);
                features_param[conf.first] = std::make_tuple(std::string(file_name), feature_head[conf.first].data_type, channel, height, width);
                map_position[conf.first] = std::make_pair(start_position_in_byte, size_in_byte);
            }
            //label_dest
            else if (is_feature == false) {
                char str[2048];
                desc_stream->getline(str, 2048);
                int n_item = sscanf(str, "%s %zd%zd%zd",
                                    file_name,
                                    &start_position_in_byte,
                                    &size_in_byte,
                                    &label_dim);

                CHECK2(n_item == 4);

                if (label_head[conf.first].label_type == INT_LABEL_TYPE)
                    CHECK2(size_in_byte / sizeof(int) == label_dim);

                if (label_head[conf.first].label_type == FLOAT_LABEL_TYPE)
                    CHECK2(size_in_byte / sizeof(float) == label_dim);

                labels_param[conf.first] = std::make_tuple(label_head[conf.first].label_type, label_dim);
                map_position[conf.first] = std::make_pair(start_position_in_byte, size_in_byte);
            }
        }
        ImageOneSample*sample = new ImageOneSample(features_param, labels_param);
        for (auto conf : one_block_stream) {
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            size_t start_position_in_byte = 0;
            size_t size_in_byte = 0;
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            start_position_in_byte = map_position[conf.first].first;
            size_in_byte = map_position[conf.first].second;
            if (is_feature == true) {
                sample->read_feature(conf.first, *bin_stream, start_position_in_byte, size_in_byte);
            }
            else if (is_feature == false) {
                sample->read_label(conf.first, *bin_stream, start_position_in_byte, size_in_byte);
            }
        }
        if (_image_reader_cfg->get_split_image_sub_size() != -1 &&
                _image_reader_cfg->get_split_image_perturb() != -1) {
            std::vector<ImageOneSample*>vec;
            if (sample->split_image(vec, _image_reader_cfg->get_split_image_sub_size(),
                                    _image_reader_cfg->get_split_image_perturb()) == 1) {
                _sample_vector.push_back(sample);
            }
            else {
                INTER_LOG("split image num %d", (int)vec.size());
                for (auto tmp : vec) {
                    _sample_vector.push_back(tmp);
                }
                delete sample;
            }
        }
        else {
            _sample_vector.push_back(sample);
        }
    }

    //sample_random(_sample_vector);

    for (auto conf : one_block_stream) {
        BaseStream* bin_stream = NULL;
        BaseStream* desc_stream = NULL;
        bool is_feature = false;
        std::tie(is_feature, bin_stream, desc_stream) = conf.second;
        bin_stream->close();
        desc_stream->close();
        delete bin_stream;
        delete desc_stream;
    }
    return data_num;
}

int DiscImageDataReader::get_feature_desc_head(BaseStream &file_stream, FeatureDescHead &head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)(&head.data_type),
                        &head.data_num,
                        &head.dim);
    CHECK(n_item == 3, "desc file head error");

    //INTER_LOG("train_data_type: %d", head.data_type);
    //INTER_LOG("train_data_num: %d", head.data_num);
    //INTER_LOG("train_data_store_type: %d", head.data_store_type);
    //INTER_LOG("image_height: %d", head.image_height);
    //INTER_LOG("image_width: %d", head.image_width);
    //INTER_LOG("image_channel: %d", head.image_channel);

    return sizeof(head);
}

int DiscImageDataReader::get_label_desc_head(BaseStream &file_stream, LabelDescHead&head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)&head.label_type,
                        &head.data_num,
                        &head.dim);
    CHECK(n_item == 3, "desc file head error");

    //INTER_LOG("label_type: %d", head.label_type);
    //INTER_LOG("data_num: %d", head.data_num);
    //INTER_LOG("train_data_store_type: %d", head.data_store_type);
    //INTER_LOG("label_size: %d", head.label_size);

    return sizeof(head);
}
/*
 *bref : 获取所有特征文件和标签文件
 *参数feat_list : pair -> first(feature key), second(list path)
 *参数label_list: pair -> first(label key), second(list path)
 */
void DiscImageDataReader::get_data_file_list(
    std::vector<std::pair<std::string, std::vector<std::string>>>& feat_list,
    std::vector<std::pair<std::string, std::vector<std::string>>>& label_list) {
    //检查是否列表为空
    CHECK2(feat_list.size() || label_list.size());
    std::vector<std::pair<std::string, std::vector<std::string>>> all_list;
    all_list.reserve(feat_list.size() + label_list.size());
    all_list.insert(all_list.end(), feat_list.begin(), feat_list.end());
    all_list.insert(all_list.end(), label_list.begin(), label_list.end());
    _train_data_file_vec.clear();

    //打开所有list文件
    //<list<list中的列表<feat | label, feat_desc_file | label_desc file> > >
    std::vector< std::vector< std::tuple<bool, size_t, std::string, std::string> > > all_blocks;
    all_blocks.resize( all_list.size() );
    char str[1024];
    str[0] = 0;
    for (size_t i = 0; i < all_list.size(); i++) {
        std::pair<std::string, std::vector<std::string>> one = all_list[i];

        std::string key = one.first;
        std::vector<std::string> path_vec = one.second;
        for (size_t j = 0; j < path_vec.size(); j++) {
            std::string path = path_vec[j];
            std::ifstream dataFile(path.c_str());
            while (! dataFile.eof()) {
                std::string bin_file;
                std::string desc_file;
                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                bin_file = std::string(str);

                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                desc_file = std::string(str);
                //特征文件
                if (i < feat_list.size()) {
                    all_blocks[i].push_back(std::make_tuple(true, j, bin_file, desc_file));
                    //标签文件
                } else {
                    all_blocks[i].push_back(std::make_tuple(false, j, bin_file, desc_file));
                }
            }
            dataFile.close();
        }
    }

    for (size_t i = 1; i < all_blocks.size(); i++) {
        CHECK2(all_blocks[i - 1].size() == all_blocks[i].size());
    }

    for (size_t i = 0; i < all_blocks[0].size(); i++) {
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > one_block;
        for (size_t j = 0; j < all_blocks.size(); j++) {
            std::string key = all_list[j].first;//TODO
            one_block[key] = all_blocks[j][i];
        }
        _train_data_file_vec.push_back(one_block);
    }
}


}
}
