//by zhxfl 2017.12.23
#include <omp.h>
#include <time.h>
#include <stdio.h> 

#include "wake_up_extract_data.h"
#include "vec_ops.h"
#include "text_utils.h"
#include "parse_string.h"

namespace houyi {
namespace train {

void WakeUpExtractData::read_sample(
    std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
    std::vector<BaseOneSample*>& sample_buffer, int thread_id) {

    //这里必须保证one_block的数据都是正常，进入这个接口前需要先做检查
    std::map<std::string, std::tuple<bool, std::ifstream*, std::ifstream*> > one_block_stream;

    //打开文件
    std::string feature_path;
    std::string label_path;
    std::string desc_path;
    int pair_id = 0;

    std::string feature_key;
    std::string label_key;

    for (auto conf : one_block) {
        std::string key = conf.first;
        bool is_feature = false;
        size_t idx = 0;
        std::string bin_file;
        std::string desc_file;
        std::tie(is_feature, idx, bin_file, desc_file) = conf.second;

        if (is_feature) {
            feature_key = key;
            feature_path = bin_file;
            pair_id = atoi(desc_file.c_str());
            CHECK2(_all_pair_vec.size() > (size_t)pair_id);
            label_path = _all_pair_vec[pair_id].second;
            desc_path = _all_pair_vec[pair_id].first;
        }
        else {
            label_key = key;
        }
    }

    std::ifstream feature_stream(feature_path);
    if (!feature_stream.is_open()) {
        INTER_LOG("open file fail %s", feature_path.c_str());
        return;
    }
    
    std::ifstream label_stream;
    if (!_cache_label_flag) {
        label_stream.open(label_path);
        if (!label_stream.is_open()) {
            INTER_LOG("open file fail %s", feature_path.c_str());
            return;
        }
    }

    //FeatureDescHead feature_head;
    std::vector<DescInfo> desc_info_vec;
    if (_cache_desc_flag) {
        desc_info_vec = _desc_cache[feature_path];
    }
    else {
        read_desc_file(feature_path, pair_id, desc_info_vec);
    }
    // if (desc_info_vec.size() >= 3000) {
    //     INTER_LOG("info_vec.size() >= 3000");
    //     return;
    // }
    if (desc_info_vec.size() <= 0) {
        INTER_LOG("info_vec.size() == 0");
        return;
    }
    
    int tot_frame = 0;
    int frame_dim = 0;
    DataType data_type = FBANK_SHORT_TYPE;
    int feature_head_size = get_feature_head(feature_stream, data_type, tot_frame, frame_dim);
    if (feature_head_size == -1) {
        INTER_LOG("feature head error");
        return;
    }  
    int label_blk_size = 0;
    // CHECK error file
    if (true) {
        int feature_size = data_type == FBANK_SHORT_TYPE ? 2 : 4;
        DescInfo& last_desc_info = desc_info_vec[desc_info_vec.size() - 1];
        int size_in_byte = (last_desc_info.feat_frame_beg + last_desc_info.frame_len)
            * frame_dim * feature_size + feature_head_size;
        feature_stream.seekg(0, std::ios::end);
        int feature_blk_size = feature_stream.tellg();
        feature_stream.seekg(8, std::ios::beg);
        if (feature_blk_size < size_in_byte) {
            INTER_LOG("feat_blk_size < size_in_byte %s", feature_path.c_str());
            return;
        }
        if (_cache_label_flag) {
            label_blk_size = _cache_label[pair_id].get_element_count();
        }
        else {
            label_stream.seekg(0, std::ios::end);
            label_blk_size = label_stream.tellg(); 
            label_stream.seekg(0, std::ios::beg);
        }
        int label_size = 1;
        size_in_byte = (last_desc_info.label_frame_beg + last_desc_info.frame_len) * label_size;
        if (label_blk_size < size_in_byte) {
            INTER_LOG("label_blk_size %d < size_in_byte %d %s",
                    label_blk_size,
                    size_in_byte,
                    label_path.c_str());
            return;
        }
    }
    //读取缓冲
    //INTER_LOG("%d %d %d", thread_id, frame_dim, tot_frame);
    if (_max_cache_frame[thread_id] < tot_frame) {
        if (_feature_block_buff[thread_id] != NULL) {
            _mm_free(_feature_block_buff[thread_id]);
            _mm_free(_feature_mid_block_buff[thread_id]);
        }
        
        _feature_block_buff[thread_id] = 
            (DType*)_mm_malloc(frame_dim * tot_frame * sizeof(DType), 16);
        _feature_mid_block_buff[thread_id] = 
            (short*)_mm_malloc(frame_dim * tot_frame * sizeof(short), 16);
        _max_cache_frame[thread_id] = tot_frame;
    }

    CHECK2(data_type == FBANK_SHORT_TYPE); 
    feature_stream.read((char*)_feature_mid_block_buff[thread_id], sizeof(short) * frame_dim * tot_frame);
    vec_short2float( _feature_block_buff[thread_id], 
            _feature_mid_block_buff[thread_id], 
            1000,
            frame_dim * tot_frame);
    if (_max_cache_label_size[thread_id] < label_blk_size) {
        if (_label_block_buff[thread_id] != NULL) {
            _mm_free(_label_block_buff[thread_id]);
            _mm_free(_label_mid_block_buff[thread_id]);
        }

        _label_block_buff[thread_id] = 
            (DType*)_mm_malloc(label_blk_size * sizeof(DType), 16);
        _label_mid_block_buff[thread_id] = 
            (unsigned char*)_mm_malloc(label_blk_size * sizeof(unsigned char), 16);

        _max_cache_label_size[thread_id] = label_blk_size;
    }
   
    if (_cache_label_flag) { 
        vec_char2float(_label_block_buff[thread_id],
                _cache_label[pair_id].get_data(),
                label_blk_size);
    }else {
        label_stream.read((char*)_label_mid_block_buff[thread_id], label_blk_size);

        vec_char2float(_label_block_buff[thread_id],
                _label_mid_block_buff[thread_id],
                label_blk_size);
    }
    
    // read feature
    for (size_t data_id = 0; data_id < desc_info_vec.size(); data_id++) {
        //过滤样本
        if (_id_map.find(desc_info_vec[data_id].speak_id) == _id_map.end()) {
            continue;
        }
        //int speak_id = _id_map[desc_info_vec[data_id].speak_id];
        int speak_id = desc_info_vec[data_id].speak_id;
        //INTER_LOG("speak_id %d", speak_id);
        SpeechOneSentence::ParamFeatureT features_param;
        SpeechOneSentence::ParamLabelT labels_param;
        std::map<std::string, std::string> file_name_map;
        int frame_len = desc_info_vec[data_id].frame_len;
        // 6720特征提取方法
        if (0 == _wake_up_trans_type) {

            features_param[feature_key] = std::make_tuple(data_type,
                    1,
                    _frame_dim,
                    _id_map[speak_id]);
            labels_param[label_key] = std::make_tuple(CHAR_LABEL_TYPE,
                    1,
                    1);
            file_name_map[feature_key] = desc_info_vec[data_id].name;
            SpeechOneSentence* sentence =
                new SpeechOneSentence(features_param, labels_param, file_name_map);

            if (trans(_label_block_buff[thread_id] + desc_info_vec[data_id].label_frame_beg,
                        _feature_block_buff[thread_id] + desc_info_vec[data_id].feat_frame_beg * frame_dim,
                        speak_id,
                        frame_len,
                        frame_dim,
                        sentence->get_feature_tensor(feature_key),
                        sentence->get_label_tensor(label_key),
                        _period_mean_tensor[thread_id]) == -1 ) {
                delete sentence;
            }
            else {
                sample_buffer.push_back(sentence);
                expand(sample_buffer, sentence);
            }
        // 根据对齐获取特征，不进行压缩 
        } else if (1 == _wake_up_trans_type) {
            SpeechOneSentence* sentence = 
                trans1(_label_block_buff[thread_id] + desc_info_vec[data_id].label_frame_beg,
                    _feature_block_buff[thread_id] + desc_info_vec[data_id].feat_frame_beg * frame_dim,
                    speak_id, frame_len, frame_dim, desc_info_vec[data_id], feature_key, label_key);

            if (sentence) {
                sample_buffer.push_back(sentence);
                expand(sample_buffer, sentence);
            } 
        } else {
            CHECK2(false);
        }
    }
    feature_stream.close();
    label_stream.close();
}

SpeechOneSentence* WakeUpExtractData::trans1(
        DType* align, 
        DType* feat,
        int wrdid,
        int frame_num,
        int frame_dim,
        DescInfo& desc_info,
        std::string& feature_key,
        std::string& label_key) {
    int speak_id = wrdid;
    if (wrdid == 30 || wrdid == 31 || wrdid == -30 || wrdid == -31) { 
        for (int i = 0; i < frame_num; i++) {
            if ((int) align[i] <= 101 && _trans_flag[(int)align[i]]) {
                align[i] = -1;
            }
        }
    }

    int cur_frame_num = 0;
    int start_frame_id = -1;
    for (int t = 0; t < frame_num; ++t) {
        int cur_align = (int) align[t];
        if (cur_align < 9) {
            continue;
        }
        start_frame_id = t;
        break;
    }
    
    if (start_frame_id == -1) {
        return NULL;
    }
    int end_frame_id = -1;
    for (int t = frame_num - 1; t >= 0; --t) {
        int cur_align = (int) align[t];
        if (cur_align < 9) {
            continue;
        }
        end_frame_id = t;
        break;
    }

    if (end_frame_id == -1) {
        return NULL;
    }

    if (start_frame_id > end_frame_id) {
        return NULL;
    }

    int real_frame_num = end_frame_id - start_frame_id; 
    int head_expand = rand() % 20;
    int tail_expand = rand() % 20;
    
    start_frame_id = start_frame_id - head_expand;
    if (start_frame_id < 0) {
        start_frame_id = 0;
    }

    end_frame_id = end_frame_id + tail_expand;
    if (end_frame_id > frame_num - 1) {
        end_frame_id = frame_num - 1;
    }

    cur_frame_num = end_frame_id - start_frame_id + 1;
    if (real_frame_num < 48 || real_frame_num > 200) {
        INTER_LOG("cur_frame_num %d < 48", real_frame_num);
        return NULL;
    }

    SpeechOneSentence::ParamFeatureT features_param;
    SpeechOneSentence::ParamLabelT labels_param;
    std::map<std::string, std::string> file_name_map;
    features_param[feature_key] = std::make_tuple(FBANK_SHORT_TYPE,
            cur_frame_num,
            frame_dim,
            _id_map[speak_id]);
    labels_param[label_key] = std::make_tuple(CHAR_LABEL_TYPE,
            1,
            1);
    file_name_map[feature_key] = desc_info.name;
    SpeechOneSentence* sentence =
        new SpeechOneSentence(features_param, labels_param, file_name_map);

    Tensor<DType>& feature_tensor = sentence->get_feature_tensor(feature_key);
    Tensor<DType>& label_tensor = sentence->get_label_tensor(label_key);
    
    //复制label
    label_tensor.get_data()[0] = _id_map[speak_id];
    // INTER_LOG("%d %d", speak_id, _id_map[speak_id]);

    //复制feature
    memcpy((char*)feature_tensor.get_data(), 
            (char*)(feat + start_frame_id * frame_dim),
            sizeof(DType) * frame_dim * cur_frame_num);

    return sentence;
}

int WakeUpExtractData::trans(DType* align, DType* feat,
        int wrdid, int frame_num, int frame_dim,
        Tensor<DType>& predict, 
        Tensor<DType>& label_tensor, 
        Tensor<DType>& period_mean_tensor) {

    int speak_id = wrdid;
    predict.zero();
    if (wrdid == 30 || wrdid == 31 || wrdid == -30 || wrdid == -31) { 
        for (int i = 0; i < frame_num; i++) {
            if ((int) align[i] <= 200&& _trans_flag[(int)align[i]]) {
                align[i] = -1;
            }
        }
    }
    
    period_mean_tensor.resize(Dim(frame_dim));
    DType* period_mean = period_mean_tensor.get_data();
    DType* predictor = predict.get_data();

    std::vector<int> part_align;
    int prev_state = -1;
    int ii = 0;
    int dur = 0;
    int dur_half = 0;
    int tot_dur = 0;
    for (int t = 0; t < frame_num; t++) {
        int cur_align = (int)align[t];
        if (cur_align < 9) {
            continue;
        }

        if (prev_state == -1) {
            prev_state = cur_align;
        }
        
        if (cur_align != prev_state) {
            dur = part_align.size();
            dur_half = dur >> 1;
            for (int cc = 0; cc < dur_half; cc++) {
                vec_add(predictor + ii * frame_dim,
                        feat + part_align[cc] * frame_dim,
                        frame_dim);
            }
            vec_add(period_mean, predictor + ii * frame_dim,
                frame_dim);
            vec_norm(predictor + ii++ * frame_dim,
                     frame_dim, dur_half);
            for (int cc = dur_half; cc < dur; cc++) {
                vec_add(predictor + ii * frame_dim,
                        feat + part_align[cc] * frame_dim,
                        frame_dim);
            }
            vec_add(period_mean, predictor + ii * frame_dim,
                frame_dim);
            vec_norm(predictor + ii++ * frame_dim,
                     frame_dim, dur - dur_half);
            tot_dur += dur;
            part_align.clear();
            prev_state = (int)align[t];
        }
        part_align.push_back(t);
    }

    // process last state
    dur = part_align.size();
    dur_half = dur >> 1;

    if (dur == 0) return -1;

    for (int cc = 0; cc < dur_half; cc++) {
        vec_add(predictor + ii * frame_dim,
                feat + part_align[cc] * frame_dim,
                frame_dim);
    }
    vec_add(period_mean, predictor + ii * frame_dim,
        frame_dim);
    vec_norm(predictor + ii++ * frame_dim,
             frame_dim, dur_half);
    for (int cc = dur_half; cc < dur; cc++) {
        vec_add(predictor + ii * frame_dim,
                feat + part_align[cc] * frame_dim,
                frame_dim);
    }
    vec_add(period_mean, predictor + ii * frame_dim,
        frame_dim);
    vec_norm(predictor + ii++ * frame_dim, frame_dim, dur - dur_half);
    tot_dur += dur;    

    //// Do keyword period sentence norm
    // vec_norm(period_mean, frame_dim, 1.0 * tot_dur);
    // for (int j = 0; j < ii * frame_dim; j++) {
    //     predictor[j] -= period_mean[j % frame_dim];
    // } 

    /// Do feature difference
    int word_num = ii / 12;
    if (word_num == 0) {
        INTER_LOG("abnormal value is found");
        return -1;
    }
    int quarter_dim = ii * frame_dim / word_num;
    for (int d = 0; d < quarter_dim * (word_num - 1); d++) {
        predictor[ii * frame_dim + d] = 
            predictor[quarter_dim + d] - predictor[d];
    }

    label_tensor.resize(Dim(1,1), false);
    CHECK2(_id_map.find(speak_id) != _id_map.end());
    label_tensor.get_data()[0] = _id_map[speak_id];

    // check abnormal value
    for (int i = 0; i < _frame_dim; i++) {
        if (isnan(predictor[i]) || isinf(predictor[i])) {
            INTER_LOG("abnormal value is found");
            return -1;
        }
    }
    return 0;
}

void WakeUpExtractData::sample_random(std::vector<BaseOneSample*> & sample_vec) {
    if (!_sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    INTER_LOG("random sample size %zu", sample_vec.size());
    std::random_shuffle(sample_vec.begin(), sample_vec.end());
#endif
}

void WakeUpExtractData::cache_desc_file(int desc_id, 
        std::unordered_map<std::string, std::vector<DescInfo>>& desc_cache) {
    CHECK2(_all_pair_vec.size() >= (size_t)desc_id);
    std::string desc_path = _all_pair_vec[desc_id].first;
    //TODO读取描述文件,放在desc_cache中
    std::ifstream desc_stream(desc_path.c_str());
    if (!desc_stream.is_open()) {
        INTER_LOG("open file fail %s", desc_path.c_str());
    }
    int num_lines = 0;
    int label_frame_offset = 0;
    std::string cur_feat_file;
    DescInfo info;
    char line[2048];
    while (desc_stream >> cur_feat_file >> num_lines >> label_frame_offset) {
        std::vector<DescInfo>& desc_info_vec = desc_cache[cur_feat_file];
        bool flag = (desc_info_vec.size() == 0);
        desc_stream.getline(line, 2048);
        for (int n = 0; n < num_lines; n++) {
            if (desc_stream.getline(line, 2048)) {
                if (!flag) {
                    continue;
                }
                std::vector<std::string> split_string;
                std::string line_str = std::string(line);
                split_string_to_vector(line_str, " ", true, &split_string);
                info.name = split_string[0];
                info.speak_id = atoi(split_string[1].c_str());

                info.label_frame_beg = label_frame_offset + atoi(split_string[2].c_str());
                if (split_string.size() == 4) {
                    info.feat_frame_beg = atoi(split_string[2].c_str());
                    info.frame_len = atoi(split_string[3].c_str());
                }else {
                    CHECK2(split_string.size() == 5);
                    info.feat_frame_beg = atoi(split_string[3].c_str());
                    info.frame_len = atoi(split_string[4].c_str());
                }

                desc_info_vec.push_back(info);
                CHECK2((int)desc_info_vec.size() <= num_lines);
            }
            //if (desc_stream >> info.name 
            //        >> info.speak_id
            //        >> info.feat_frame_beg
            //        >> info.frame_len) {
            //    if (flag) {
            //        info.label_frame_beg = label_frame_offset + info.feat_frame_beg;
            //        desc_info_vec.push_back(info);
            //        CHECK2((int)desc_info_vec.size() <= num_lines);
            //    }
            //}
        }
    }
    desc_stream.close();
}

void WakeUpExtractData::read_desc_file(std::string& path, int desc_id, std::vector<DescInfo>& desc_info_vec) {
    CHECK2(_all_pair_vec.size() >= (size_t)desc_id);
    std::string desc_path = _all_pair_vec[desc_id].first;
    //TODO读取描述文件,放在_desc_cache中
    std::ifstream desc_stream(desc_path.c_str());
    if (!desc_stream.is_open()) {
        INTER_LOG("open file fail %s", desc_path.c_str());
    }
    int num_lines = 0;
    int label_frame_offset = 0;
    std::string cur_feat_file;
    DescInfo info;
    bool push = false;
    char line[2048];
    while (desc_stream >> cur_feat_file >> num_lines >> label_frame_offset) {
        if (cur_feat_file == path) {
            push = true;
        }else {
            push = false;
        }

        //bool flag = (desc_info_vec.size() == 0);

        desc_stream.getline(line, 2048);
        for (int n = 0; n < num_lines; n++) {
            if (desc_stream.getline(line, 2048)) {
                if (!push) {
                    continue;
                }
                std::vector<std::string> split_string;
                std::string line_str = std::string(line);
                split_string_to_vector(line_str, " ", true, &split_string);
                if (split_string.size() < 3) {
                    continue;
                }
                info.name = split_string[0];
                info.speak_id = atoi(split_string[1].c_str());

                info.label_frame_beg = label_frame_offset + atoi(split_string[2].c_str());
                if (split_string.size() == 4) {
                    info.feat_frame_beg = atoi(split_string[2].c_str());
                    info.frame_len = atoi(split_string[3].c_str());
                }else {
                    CHECK2(split_string.size() == 5);
                    info.feat_frame_beg = atoi(split_string[3].c_str());
                    info.frame_len = atoi(split_string[4].c_str());
                }

                desc_info_vec.push_back(info);
                CHECK2((int)desc_info_vec.size() <= num_lines);
            }
        }
    }
    desc_stream.close();
}

void WakeUpExtractData::read_key_word_label_map() {
    std::ifstream fi_map_id(_key_word_label_map.c_str());
    if (!fi_map_id) {
        INTER_LOG("Failed to open file: %s", _key_word_label_map.c_str()); 
    }

    int keyword_id = 0;
    int map_keywor_id = 0;

    while (fi_map_id >> keyword_id >> map_keywor_id) {
        _id_map[keyword_id] = map_keywor_id;
    }
    fi_map_id.close();
}

void WakeUpExtractData::read_all_pair_vec() {
    std::ifstream fi_desc_label_pair(_all_pair_path.c_str());
    while (!fi_desc_label_pair) {
        INTER_CHECK(false, "Failed to open file: %s", _all_pair_path.c_str());
    }

    int pair_id = 0;
    std::pair<std::string, std::string> invalid;
    std::pair<std::string, std::string> desc_label_pair;
    invalid.first = "INVALID";
    invalid.second = "";
    _all_pair_vec.resize(100000, invalid);

    while (fi_desc_label_pair >> pair_id
            >> desc_label_pair.first >> desc_label_pair.second) {
        if (pair_id >= (int)_all_pair_vec.size()) {
            _all_pair_vec.resize(pair_id + 10, invalid);
        }
       _all_pair_vec[pair_id] = desc_label_pair;
    }
    fi_desc_label_pair.close();
}

int WakeUpExtractData::get_feature_head(std::ifstream& feature_stream,
        DataType& data_type, int & tot_frame, int& frame_dim) {
    feature_stream.read((char*)&tot_frame, sizeof(int));
    feature_stream.read((char*)&frame_dim, sizeof(int));
    feature_stream.seekg(0, std::ios::end);
    long feature_blk_size = feature_stream.tellg();
    feature_stream.seekg(8, std::ios::beg);
    if ((feature_blk_size - 8) / (tot_frame * frame_dim) == 2) {
        data_type = FBANK_SHORT_TYPE;
    }else {
        //CHECK2((feature_blk_size - 8) / (tot_frame * frame_dim) == 4);
        if ((feature_blk_size - 8) / (tot_frame * frame_dim) != 4) {
            return -1;
        }
    }
    return 8;
}

void WakeUpExtractData::expand(std::vector<BaseOneSample*>& from, SpeechOneSentence* sample) {
    if (_expand_radio > 1.0) {
        float remain_radio = _expand_radio - 1.0;
        if (1.0 * rand() / RAND_MAX <= remain_radio) {
            //PROG_ATOM_BEGIN("new");        
            SpeechOneSentence* sentence = 
                new SpeechOneSentence(*sample);
            sentence->copy_from(*sample);
            from.push_back(sentence);
        }
    }
}

void WakeUpExtractData::cache_label() {
    _cache_label.resize(_all_pair_vec.size(), cpu_device());
#pragma omp parallel for num_threads(24), schedule(dynamic)
    for (size_t i = 0; i < _all_pair_vec.size(); i++) {
        std::ifstream im(_all_pair_vec[i].second.c_str()); 
        if (im.is_open()) {
            INTER_LOG("cache label %d", (int)i);
            im.seekg(0, std::ios::end);
            size_t size = im.tellg();
            _cache_label[i].resize(Dim(size), false);
            im.seekg(0, std::ios::beg);
            im.read((char*)_cache_label[i].get_data(), size);
        }
    }
}

void WakeUpExtractData::get_data_file_list() {
    _train_data_file_vec.clear();
    //检查是否列表为空
    CHECK2(_feature_list.size() || _label_list.size());
    std::vector<std::pair<std::string, std::vector<std::string>>> all_list;
    all_list.reserve(_feature_list.size() + _label_list.size());
    all_list.insert(all_list.end(), _feature_list.begin(), _feature_list.end());
    all_list.insert(all_list.end(), _label_list.begin(), _label_list.end());
    _train_data_file_vec.clear();

    //打开所有list文件
    //<list<list中的列表<feat | label, feat_desc_file | label_desc file> > >
    std::vector< std::vector< std::tuple<bool, size_t, std::string, std::string> > > all_blocks;
    all_blocks.resize( all_list.size() );
    char str[1024];
    str[0] = 0;
    for (size_t i = 0; i < all_list.size(); i++) {
        std::pair<std::string, std::vector<std::string>> one = all_list[i];

        std::string key = one.first;
        std::vector<std::string> path_vec = one.second;
        for (size_t j = 0; j < path_vec.size(); j++) {
            std::string path = path_vec[j];
            std::ifstream dataFile(path.c_str());
            CHECK(dataFile.is_open(), "File could not found: %s", path.c_str());
            while (! dataFile.eof()) {
                std::string bin_file;
                std::string desc_file;
                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                bin_file = std::string(str);

                dataFile.getline(str, 1024);
                remove_white_space_comment(str);
                if ('\0' == str[0]) {
                    continue;
                }
                desc_file = std::string(str);
                std::vector<std::string> desc_file_vec;
                split_string_to_vector(desc_file, "_", true, &desc_file_vec);
                //特征文件
                if (i < _feature_list.size()) {
                    for (auto& desc : desc_file_vec) {
                        all_blocks[i].push_back(std::make_tuple(true, j, bin_file, desc));
                    }
                    //标签文件
                } else {
                    for (auto& desc : desc_file_vec) {
                        all_blocks[i].push_back(std::make_tuple(false, j, bin_file, desc));
                    }
                }
            }
            dataFile.close();
        }
    }

    for (size_t i = 1; i < all_blocks.size(); i++) {
        CHECK2(all_blocks[i - 1].size() == all_blocks[i].size());
    }

    for (size_t i = 0; i < all_blocks[0].size(); i++) {
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > one_block;
        for (size_t j = 0; j < all_blocks.size(); j++) {
            std::string key = all_list[j].first;
            one_block[key] = all_blocks[j][i];
        }
        _train_data_file_vec.push_back(one_block);
    }
}

} // houyi
} // train
