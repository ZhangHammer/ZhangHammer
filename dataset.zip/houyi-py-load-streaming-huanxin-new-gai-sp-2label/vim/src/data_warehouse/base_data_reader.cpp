/**
 * base_data_reader.cpp
 *
 * Author: madongpeng (madongpeng@baidu.com)
 * Created on: 2016-03-10
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "base_data_reader.h"
#include "image_data_reader.h"
#include "speech_data_reader.h"
#include "disc_image_data_reader.h"

namespace houyi {
namespace train {
//TODO zzxfl
BaseDataReader* BaseDataReader::create(BaseReaderConfig &cfg) {
    BaseDataReader* reader = NULL;
    switch (cfg.get_data_reader_type()) {
    case READER_IMAGE:
        reader = (BaseDataReader*)(new ImageDataReader(cfg));
        break;
    case READER_SPEECH:
        reader = (BaseDataReader*)(new SpeechDataReader(cfg));
        break;
    case READER_DISC_IMAGE:
        reader = (BaseDataReader*)(new DiscImageDataReader(cfg));
        break;
    default:
        INTER_CHECK(false, "unkonown reader type %d", (int)cfg.get_data_reader_type());
    }

    if (reader == NULL) {
        return NULL;
    }

    return reader;
}

}
}
