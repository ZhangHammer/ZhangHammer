/**
 * image_one_data.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-011
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include <utility>
#include <vector>
#include <fstream>
#include <iostream>
#include "image_one_feature.h"
#include "image_utils.h"

namespace houyi {
namespace train {

int ImageOneFeature::read_data(
    std::ifstream& in_stream, size_t st_position_in_byte, size_t size_in_byte) {

    //malloc buffer to read the dat
    std::string buffer;
    buffer.resize(size_in_byte);

    in_stream.seekg(st_position_in_byte, std::ios::beg);
    in_stream.read(&buffer[0], size_in_byte);

    size_t ret = in_stream.gcount();
    if (!in_stream) {
        INTER_LOG("read_data error");
    }

    decode_image(buffer, size_in_byte);
    return ret;
}

int ImageOneFeature::read_data(
    BaseStream&in_stream, size_t st_position_in_byte, size_t size_in_byte) {

    //malloc buffer to read the dat
    std::string buffer;
    buffer.resize(size_in_byte);

    in_stream.seekg(st_position_in_byte, std::ios::beg);
    in_stream.read(&buffer[0], size_in_byte);

    size_t ret = in_stream.gcount();

    decode_image(buffer, size_in_byte);
    return ret;
}

void ImageOneFeature::decode_image(std::string&buffer, size_t size_in_byte) {
    DType* data = NULL;
    switch (this->get_feature_type()) {
    case RGB24_TYPE:
    case SEQ_CHAR_TYPE:
        data = (DType*)_data.get_data();
        for (size_t i = 0; i < buffer.size(); i++) {
            data[i] = (unsigned char)(buffer[i]);
        }
        break;
    case BBGGRR_UC_TYPE:
        INTER_LOG("bbggrr_uc is not support");
        break;
    case BBGGRR_FLOAT_TYPE:
        data = (DType*)_data.get_data();
        memcpy(data, &buffer[0], size_in_byte);
        break;
    case GRAY_FLOAT_TYPE:
        data = (DType*)_data.get_data();
        memcpy(data, &buffer[0], size_in_byte);
        break;
    case JPEG_TYPE:
        decode_jpeg(buffer, size_in_byte);
        break;
    default:
        CHECK(false, "image type not support");
    }
}

void ImageOneFeature::decode_jpeg(std::string& buffer, size_t size_in_byte) {
#ifdef __WITH_OPENCV__
    std::vector<uchar>buffer_vec;
    buffer_vec.resize(buffer.size());
    memcpy(&buffer_vec[0], &buffer[0], size_in_byte);
    // image decode
    cv::Mat image = imdecode(cv::Mat(buffer_vec), CV_LOAD_IMAGE_COLOR);
    mat_to_tensor(image, _data);
#else
    CHECK2(false);
#endif
}

}
}
