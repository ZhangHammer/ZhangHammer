//by zhxfl 2017.12.21
#include <omp.h>
#include "image_extract_data.h"
#include "object_factory.h"

namespace houyi {
namespace train {
void ImageExtractData::read_sample(
    std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
    std::vector<BaseOneSample*>& sample_buffer, int thread_id) {
    //打开文件
    std::map<std::string, std::tuple<bool, BaseStream*, BaseStream*> > one_block_stream;
    for (auto conf : one_block) {
        std::string key = conf.first;
        bool is_feature = false;
        size_t idx = 0;
        std::string bin_file;
        std::string desc_file;

        std::tie(is_feature, idx, bin_file, desc_file) = conf.second;
        BaseStream* bin_stream = NULL;
        BaseStream* desc_stream = NULL;
        bin_stream = new IfStream(bin_file);
        desc_stream = new IfStream(desc_file);
        one_block_stream[key] = std::make_tuple(is_feature, bin_stream, desc_stream);
    }

    //注意:读取数据,打包时需要满足不同特征或者不同标签的samples数一致,或者只取最少那个
    //读取头并且进行校验
    std::map<std::string, FeatureDescHead> feature_head;
    std::map<std::string, LabelDescHead> label_head;
    int data_num = -1;

    for (auto conf : one_block_stream) {
        //feature_dest
        if (std::get<0>(conf.second) == true) {
            FeatureDescHead head;
            get_feature_desc_head(*std::get<2>(conf.second), head);
            feature_head[conf.first] = head;
            if (data_num == -1)
                data_num = head.data_num;
            else {
                CHECK2(data_num == head.data_num);
            }
        }
        //label_dest
        else if (std::get<0>(conf.second) == false) {
            LabelDescHead head;
            get_label_desc_head(*std::get<2>(conf.second), head);
            label_head[conf.first] = head;
            if (data_num == -1)
                data_num = head.data_num;
            else {
                CHECK2(data_num == head.data_num);
            }
        }
    }

    //读取数据
    for (int data_id = 0; data_id < data_num; data_id++) {
        ImageOneSample::ParamFeatureT features_param;
        ImageOneSample::ParamLabelT labels_param;
        std::map<std::string, std::pair<size_t, size_t> > map_position;

        for (auto conf : one_block_stream) {
            //feature_dest
            char file_name[2048];
            size_t start_position_in_byte = 0;
            size_t size_in_byte = 0;
            size_t channel = 0;
            size_t height = 0;
            size_t width = 0;
            size_t label_dim = 0;;
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            if (is_feature == true) {
                char str[2048];
                desc_stream->getline(str, 2048);
                //TODO use sscanf_s
                int n_item = sscanf(str, "%s %zu%zu%zu%zu%zu",
                                    file_name, &start_position_in_byte,
                                    &size_in_byte,
                                    &channel, &height, &width);
                CHECK2(n_item == 6);
                features_param[conf.first] = std::make_tuple(std::string(file_name), feature_head[conf.first].data_type, channel, height, width);
                map_position[conf.first] = std::make_pair(start_position_in_byte, size_in_byte);
            }
            //label_dest
            else if (is_feature == false) {
                char str[2048];
                desc_stream->getline(str, 2048);
                int n_item = sscanf(str, "%s %zu%zu%zu",
                                    file_name,
                                    &start_position_in_byte,
                                    &size_in_byte,
                                    &label_dim);

                CHECK2(n_item == 4);

                if (label_head[conf.first].label_type == INT_LABEL_TYPE)
                    CHECK2(size_in_byte / sizeof(int) == label_dim);

                if (label_head[conf.first].label_type == FLOAT_LABEL_TYPE)
                    CHECK2(size_in_byte / sizeof(float) == label_dim);

                labels_param[conf.first] = std::make_tuple(label_head[conf.first].label_type, label_dim);
                map_position[conf.first] = std::make_pair(start_position_in_byte, size_in_byte);
            }
        }

        ImageOneSample* sample = new ImageOneSample(features_param, labels_param);

        for (auto conf : one_block_stream) {
            BaseStream* bin_stream = NULL;
            BaseStream* desc_stream = NULL;
            bool is_feature = false;
            size_t start_position_in_byte = 0;
            size_t size_in_byte = 0;
            std::tie(is_feature, bin_stream, desc_stream) = conf.second;
            start_position_in_byte = map_position[conf.first].first;
            size_in_byte = map_position[conf.first].second;
            if (is_feature == true) {
                sample->read_feature(conf.first, *bin_stream, start_position_in_byte, size_in_byte);
            }
            else if (is_feature == false) {
                sample->read_label(conf.first, *bin_stream, start_position_in_byte, size_in_byte);
            }
        }
        if (_split_image_sub_size != -1 && _split_image_perturb) {
            std::vector<ImageOneSample*>vec;
            if (sample->split_image(vec, _split_image_perturb, _split_image_sub_size) == 1) {
                sample_buffer.push_back(sample);
            }
            else {
                INTER_LOG("split image num %d", (int)vec.size());
                sample_buffer.insert(sample_buffer.end(), vec.begin(), vec.end());
                delete sample;
            }
        }
        else {
            sample_buffer.push_back(sample);
        }
    }

    for (auto conf : one_block_stream) {
        BaseStream* bin_stream = NULL;
        BaseStream *desc_stream = NULL;
        bool is_feature = false;
        std::tie(is_feature, bin_stream, desc_stream) = conf.second;
        delete bin_stream;
        delete desc_stream;
    }
}

int ImageExtractData::get_feature_desc_head(BaseStream& file_stream, FeatureDescHead &head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)&head.data_type,
                        &head.data_num,
                        &head.dim);
    // channel height width
    CHECK2(head.dim == 3);
    CHECK(n_item == 3, "desc file head error");
    return sizeof(head);
}

int ImageExtractData::get_label_desc_head(BaseStream& file_stream, LabelDescHead&head) {
    char str[4097];
    file_stream.getline(str, 4096);
    int n_item = sscanf(str, "%d%d%d",
                        (int*)&head.label_type,
                        &head.data_num,
                        (int*)&head.dim);
    CHECK(n_item == 3, "desc file head error");
    return sizeof(head);
}

} // houyi
} // train
