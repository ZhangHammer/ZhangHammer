/**
 * base_reader_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-12
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "text_utils.h"
#include "base_reader_config.h"
#include "data_tool.h"
#include "image_reader_config.h"
#include "speech_reader_config.h"
#include "util.h"

namespace houyi {
namespace train {
/*
 * bref 解析公共部分参数
 */
void BaseReaderConfig::parse_common_params(std::string& param_lines) {
    //每次读取的数据块数目
    parse_from_string("fileLoadCnt", &param_lines, &_load_block_num);
    INTER_LOG("fileLoadCnt=%d", _load_block_num);
    //是否使用多线程进行磁盘数据读取
    parse_from_string("multiThreadReadDisk", &param_lines, &_mutil_thread_read_disk);
    INTER_LOG("multiThreadReadDisk= %d", _mutil_thread_read_disk);
    CHECK2(_mutil_thread_read_disk >= 1);

    parse_from_string("sampleRandom", &param_lines, &_sample_random);
    INTER_LOG("sampleRandom=%d", (int)_sample_random);

    parse_from_string("balance", &param_lines, &_balance);
    INTER_LOG("balance=%d", (int)_balance);
}

BaseReaderConfig* BaseReaderConfig::read(std::ifstream &input) {
    std::string param_lines;
    std::string type;
    DataReaderType data_reader_type;

    param_lines.clear();
    stream_to_string(input, "</Reader>", param_lines);

    parse_from_string("type", &param_lines, &type);
    string_to_enum(type, data_reader_type_name, &data_reader_type);
    BaseReaderConfig* rd = NULL;
    switch (data_reader_type) {
    case READER_IMAGE:
    case READER_DISC_IMAGE: {
        rd = new ImageReaderConfig();
        break;
    }
    case READER_SPEECH: {
        rd = new SpeechReaderConfig();
        break;
    }
    default:
        INTER_CHECK(false, "unknown reader type %d", (int)data_reader_type);
        return NULL;
    }
    rd->parse_common_params(param_lines);
    rd->parse_params(param_lines);
    rd->set_data_reader_type(data_reader_type);
    /*检查config_line是否都解析了，如果存残留项，报错提醒*/
    trim(&param_lines);
    CHECK(!is_token(param_lines),
            "data transform residual term [%s]",
            param_lines.c_str());

    return rd;
}

void BaseReaderConfig::read_multi_feature_label(std::string& config_line) {
    const std::string head = "<label_or_feature>";
    const std::string tail = "</label_or_feature>";
    std::size_t found1 = config_line.find(head);
    std::size_t found2 = config_line.find(tail);
    CHECK2(found1 != std::string::npos && found2 != std::string::npos);
    //head tail 之间的字符串，不包括head tail
    std::string sub_lines = config_line.substr(found1 + head.size(), found2 - found1 - head.size());
    //获取剩下的字符串
    std::string remain = config_line.substr(0, found1) +
                         config_line.substr(found2 + tail.size(), 
                            config_line.size() - found2 - tail.size());
    config_line = remain;
    INTER_LOG("multi label or features %s", sub_lines.c_str());

    //格式参考
    //feature = image1 : ./data/cifar-10/train/feature.lst
    //label = label1 : ./data/cifar-10/train/label.lst

    std::string feat;
    while (parse_from_string("feature", &sub_lines, &feat)) {
        std::string feat_name;
        std::string feat_list;
        std::vector<std::string> feat_list_vec;
        std::size_t pos = feat.find(":");
        feat_name = feat.substr(0, pos);
        feat_list = feat.substr(pos + 1, feat.size() - pos);
        split_string(feat_list_vec, feat_list, ':');
        _feature_list.push_back(std::make_pair(feat_name, feat_list_vec));
    }

    std::string label;
    while (parse_from_string("label", &sub_lines, &label)) {
        std::string label_name;
        std::string label_list;
        std::vector<std::string> label_list_vec;
        std::size_t pos = label.find(":");
        label_name = label.substr(0, pos);
        label_list = label.substr(pos + 1, label.size() - pos);
        split_string(label_list_vec, label_list, ':');
        _label_list.push_back(std::make_pair(label_name, label_list_vec));
    }
}

}
}

