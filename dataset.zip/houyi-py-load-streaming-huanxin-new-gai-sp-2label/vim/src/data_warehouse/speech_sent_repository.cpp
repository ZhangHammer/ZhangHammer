//by zzxfl 2016.08.30
#include <malloc.h>
#include "speech_sent_repository.h"
#include "speech_one_sentence.h"
#include "speech_batch_sample.h"
#include "object_factory.h"

namespace houyi {
namespace train {

SpeechBatchSample::ParamFeatureT
SpeechSentRepository::get_features_param(
    SpeechOneSentence& sample,
    std::map<std::string, int>& max_frame_num) {
    SpeechBatchSample::ParamFeatureT feature_param;

    std::vector<std::string>feature_key = sample.get_feature_keys();
    for (auto key : feature_key) {
        feature_param[key] = std::make_tuple(
                                 sample.get_data_type(key),
                                 max_frame_num[key],
                                 sample.get_frame_dim(key));
    }
    return feature_param;
}

SpeechBatchSample::ParamLabelT SpeechSentRepository::get_labels_param(SpeechOneSentence& sample, std::map<std::string, int>& max_frame_num) {
    SpeechBatchSample::ParamLabelT label_param;
    std::vector<std::string>label_key = sample.get_label_keys();

    for (auto key : label_key) {
        label_param[key] = std::make_tuple(
                               sample.get_label_type(key),
                               max_frame_num[key],
                               sample.get_label_dim(key));
    }
    return label_param;
}

std::map<std::string, int> SpeechSentRepository::get_max_frame_len(std::vector<BaseOneSample*>& samples) {
    std::map<std::string, int> cpy_num;
    for (auto& key: samples[0]->get_feature_keys()) {
        int max_frame_len = 0;
        for (auto sample : samples) {
            if (sample == NULL)
                continue;
            SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(sample);
            max_frame_len = std::max(max_frame_len, sent->get_frame_num(key));
        }
        int align = _cfg->get_align_speech_sentence();
        CHECK2(align >= 1);
        cpy_num[key] = (max_frame_len + align - 1) / align * align;
    }

    for (auto& key: samples[0]->get_label_keys()) {
        int max_frame_len = 0;
        for (auto sample : samples) {
            if (sample == NULL)
                continue;
            SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(sample);
            max_frame_len = std::max(max_frame_len, sent->get_frame_num(key));
        }
        int align = _cfg->get_align_speech_sentence();
        CHECK2(align >= 1);
        cpy_num[key] = (max_frame_len + align - 1) / align * align;
    }

    return cpy_num;
}

size_t SpeechSentRepository::inter_get_batch(
    std::vector<BaseBatchSample*> &batches, size_t max_num) {
    std::vector<BaseOneSample*> all_sample_buf;

    _batch_size = _new_batch_size;

    /*本epoch已经结束，需要reset之后才能重新启动数据加载*/
    if (_laster_batch == true)
    {
        return 0;
    }

    size_t counter = 0;
    BaseProcesser *speech_processer = dynamic_cast<BaseProcesser*>(_data_processer);

    int num = speech_processer->get_samples_from_proc(all_sample_buf, _batch_size * max_num);

    /*如果num == 0说明没有获取到任何数据，这种情况不可能出现*/
    CHECK2(num > 0);

    /*判断最后一个sample是否为null，如果是表明本epoch数据加载结束*/
    if (all_sample_buf.size() && all_sample_buf.back() == NULL) {
        _laster_batch = true;
        INTER_LOG("get laster batch sample !");
        //sample_buf中全部为NULL，直接结束
        if (all_sample_buf.size() == 1 && all_sample_buf[0] == NULL)
            return 0;
    }

    int bats_num = ((int)all_sample_buf.size() + _batch_size - 1) / _batch_size;

    std::vector<SpeechBatchSample*> bats(bats_num, NULL);
    //INTER_LOG("max_num %d", max_num);
#pragma omp parallel for
    for (size_t l = 0; l < max_num; l++) {
        std::vector<BaseOneSample*> sample_buf;
        for (int j = 0; j < (int)_batch_size; j++) {
            int f = l *_batch_size + j;
            if (f >= (int)all_sample_buf.size()) {
                break;
            }
            sample_buf.push_back(all_sample_buf[f]);
        }

        if (sample_buf.size() == 0 || (sample_buf.size() == 1 && sample_buf[0] == NULL )) {
            continue;
        }

        std::map<std::string, int> cpy_num = get_max_frame_len(sample_buf);

        if (cpy_num[sample_buf[0]->get_feature_keys()[0]] == 0) {
            INTER_LOG("sample_buf is empty");
            continue;
        }

        CHECK2(sample_buf[0] != NULL);

        SpeechBatchSample* bat = NULL;
        bat = static_cast<SpeechBatchSample*>(ObjectFactory<BaseBatchSample>::instance()->create_object());

        SpeechBatchSample::ParamFeatureT feature_param = get_features_param(
                *(static_cast<SpeechOneSentence*>(sample_buf[0])), cpy_num);
        SpeechBatchSample::ParamLabelT label_param = get_labels_param(
                *(static_cast<SpeechOneSentence*>(sample_buf[0])), cpy_num);
        if (bat == NULL) {
            bat = new SpeechBatchSample(_batch_size, feature_param, label_param);
        }else {
            bat->resize(_batch_size, feature_param, label_param);
        }

        bats[l] = bat;
        for (size_t b = 0; b < _batch_size; b++) {
            if (b < sample_buf.size() && sample_buf[b]) {
                SpeechOneSentence* sent = dynamic_cast<SpeechOneSentence*>(sample_buf[b]);
                sent->copy_sent(*bat, _batch_size, b);
            }//for
        }//for

        // 句子描述
        for (size_t b = 0; b < _batch_size; b++) {
            if (b < sample_buf.size() && sample_buf[b]) {
                for (std::string key : bat->get_feature_keys()) {
                    std::vector<std::string>&file_name
                        = bat->get_file_name(key);
                    file_name.push_back(sample_buf[b]->get_file_name(key));
                }
            }
            else {
                for (std::string key : bat->get_feature_keys()) {
                    std::vector<std::string>&file_name
                        = bat->get_file_name(key);
                    file_name.push_back("");

                }
            }
        }
        for (auto sample : sample_buf) {
            if (sample) {
                delete sample;
            }
        }
        //malloc_trim(0);
        sample_buf.clear();
        counter++;
    }

    for (size_t i = 0; i < bats.size(); i++) {
        batches.push_back(bats[i]);
    }
    return (int)batches.size();
}

}//houyi
}//train
