//by zzxfl 2016.09.23
#include <utility>
#include <vector>
#include <fstream>
#include "data_tool.h"
#include "speech_one_label.h"
namespace houyi {
namespace train {

int SpeechOneLabel::read_label(BaseStream& in_stream,
        size_t st_position_in_byte,
        size_t size_in_byte) {

    int ret = 0;
    in_stream.seekg(st_position_in_byte, std::ios::beg);
    in_stream.read((char*)_label.get_data(), size_in_byte);
    if (_type == INT_LABEL_TYPE) {
        CHECK(size_in_byte == (_label.get_element_count() * sizeof(DType)),
                "check label size");
        int* ori_ptr = (int*)(_label.get_data());
        for (size_t i = 0; i < _label.get_element_count(); i++) {
            CHECK2(ori_ptr[i] != -1);
            _label.get_data()[i] = (float)(ori_ptr[i]);
        }
    }
    else if (_type == CHAR_LABEL_TYPE) {
        CHECK(size_in_byte == (_label.get_element_count() * sizeof(unsigned char)),
                "check label size");
        unsigned char * ori_ptr = (unsigned char *)(_label.get_data());
        for (int i = static_cast<int>(_label.get_element_count() - 1); i >= 0; i--) {
            _label.get_data()[i] = static_cast<DType>(ori_ptr[i]);
            //CHECK2(fabs(_label.get_data()[i]) <= 10e8);
        }
    }
    ret = in_stream.gcount();
    return ret;
}//read_label

}//houyi
}//train
