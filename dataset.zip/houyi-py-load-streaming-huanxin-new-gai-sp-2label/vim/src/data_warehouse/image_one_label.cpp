/**
 * image_one_label.cpp
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-11
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <utility>
#include <vector>
#include "image_one_label.h"
#include <fstream>

namespace houyi {
namespace train {

int ImageOneLabel::read_label(
        BaseStream&in_stream,
        size_t st_position_in_byte,
        size_t size_in_byte) {
    CHECK(size_in_byte ==  (_label.get_element_count() * sizeof(DType)), "check label size");

    int ret = 0;
    DType *data = _label.get_data();
    size_t byte_cnt = _label.get_element_count() * sizeof(DType);
    in_stream.seekg(st_position_in_byte, std::ios::beg);
    in_stream.read((char *)data, byte_cnt);
    ret = in_stream.gcount();
    if (_type == INT_LABEL_TYPE) {
        int* orig_ptr = (int*)(_label.get_data());
        for (size_t i = 0; i < _label.get_element_count(); i++) {
            _label.get_data()[i] = (float)orig_ptr[i];
        }
    }

    return ret;
}

}
}
