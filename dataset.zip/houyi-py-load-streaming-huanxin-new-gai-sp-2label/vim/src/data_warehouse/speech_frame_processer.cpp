/**
 * speech_frame_processer.cpp
 *
 * Author: Chen Xu (chenxu13@baidu.com)
 * Created on: 2018-04-18
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#include <random>
#include <omp.h>
#include "speech_frame_processer.h"
#include "speech_one_sentence.h"

namespace houyi {
namespace train {

void SpeechFrameProcesser::generate_frame_index() {
    const auto& samples = _processing_pool.first;
    auto& frame_index = _processing_pool.second;

    frame_index.clear();
    for (int s = 0; s < (int)samples.size(); ++s) {
        SpeechOneSentence *sent = static_cast<SpeechOneSentence*>(samples[s]);
        int frame_num = sent->get_frame_num();
        for (int f = 0; f < frame_num; ++f) {
            frame_index.push_back(std::make_pair(s, f));
        }
    }

#ifndef __CLOSE_RANDOM__
    std::random_device rd;
    std::mt19937 g(rd()); 
    std::shuffle(frame_index.begin(), frame_index.end(), g);
#endif
}

void SpeechFrameProcesser::inter_async_load() {
    
    while (true) {
        std::vector<BaseOneSample*>& samples = _processing_pool.first;
        samples.clear();
        
        BaseDataReader* reader = get_reader();
        size_t cnt = reader->get_all_samples_from_reader(samples);

        INTER_LOG("SpeechFrameProcesser Load %d sentences from SpeechDataReader", (int)cnt);
        if (cnt == 0) {
            std::lock_guard<std::mutex> lk(_mtx);
            _is_started = false;
            _cv_processing_done.notify_all(); 
            INTER_LOG("No sentence from reader any more");
            break;
        }
        
        #pragma omp parallel for num_threads(_trans_stream.size())
        for (size_t s = 0; s < cnt; ++s) {
            try {
                perform_trans_stream(*samples[s], omp_get_thread_num()); 
            }
            catch (std::exception const&e) {
                std::cout << "omp exception" << e.what() << std::endl;
                CHECK2(false);
            }
        }
        
        generate_frame_index();
        
        std::unique_lock<std::mutex> lck(_mtx);
     
        _cv_samples_consumed.wait(lck, [this]{ return _request_counter == _device_num; });
        _ready_pool = _processing_pool;
        _num_frames_in_pool = (int)_ready_pool.second.size();
        _cur_load_pos = 0;
        _request_counter = 0;
        INTER_LOG("%d frames fully randomized in pool", _num_frames_in_pool);
        _ready_pool_update_done = true;
        _cv_processing_done.notify_all();
    }

    INTER_LOG("SpeechFrameProcesser async load thread finished");
}

int SpeechFrameProcesser::get_randomized_frames_from_proc(int max_num_frames, int* start_pos, int* end_pos) {
    std::unique_lock<std::mutex> lck(_mtx);   

    if (_num_frames_in_pool == 0) {
        ++_request_counter;
        if (_request_counter == _device_num) {
            // release buffer
            for (auto sample : _ready_pool.first) {
                if (sample) {
                    delete sample;
                }
            }
            _ready_pool.first.clear();
            _cv_samples_consumed.notify_one();
        }
        _cv_processing_done.wait(lck, [this]{ return _ready_pool_update_done || !_is_started; });
    }

    if (_num_frames_in_pool == 0 && !_is_started) {
        INTER_LOG("SpeechFrameProcesser noticed that async load thread is off");
        return -1;
    }

    *start_pos = _cur_load_pos;
    *end_pos = _cur_load_pos + max_num_frames;

    if (_num_frames_in_pool <= *end_pos) {
        *end_pos = _num_frames_in_pool;
    }

    _cur_load_pos += *end_pos - *start_pos;
    if (_cur_load_pos >= _num_frames_in_pool) {
        _num_frames_in_pool = 0;
        _ready_pool_update_done = false;
    }

    return *end_pos - *start_pos;
    
}

} // namespace train
} // namespace houyi
