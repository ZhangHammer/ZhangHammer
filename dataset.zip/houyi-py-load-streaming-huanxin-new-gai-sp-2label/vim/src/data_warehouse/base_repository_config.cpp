/**
 * base_repository_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-03-09
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include "base_repository_config.h"
#include <stack>
namespace houyi {
namespace train {

void BaseReposConfig::read(const char *cfg_file) {
    std::ifstream input(cfg_file);
    CHECK(input, "data configure file open error: %s", cfg_file);

    std::string line;
    std::string conf_line;
    while (std::getline(input, line)) {
        if (line.size() == 0) {
            continue;
        }
        remove_white_space_comment(line);
        if (line.size() == 0) {
            continue;
        }
        if (line == "<Reader>") {
            _reader_cfg = BaseReaderConfig::read(input);
        } else if (line == "<Processer>") {
            _proc_cfg = BaseProcConfig::read(input);
        } else {
            if (line == "<Repository>") {
                continue;
            }
            if (line == "</Repository>") {
                break;
            }
            conf_line.append("\t");
            conf_line.append(line);
        }
    }
    std::string type_str;
    int buf_num = 0;
    parse_from_string("type", &conf_line, &type_str);
    INTER_LOG("type %s", type_str.c_str());
    parse_from_string("asyncLoad", &conf_line, &_is_async);
    INTER_LOG("asyncLoad %d", (int)_is_async);
    parse_from_string("maxBufferNum", &conf_line, &buf_num);
    INTER_LOG("maxBufferNum %d", buf_num);
    parse_from_string("batchSize", &conf_line, &_batch_size);
    INTER_LOG("batchSize %d", _batch_size);

    parse_from_string("doSplice", &conf_line, &_do_splice);
    INTER_LOG("doSplice %d", (int)_do_splice);
    parse_from_string("leftContext", &conf_line, &_left_context);
    INTER_LOG("leftContext %d", (int)_left_context);
    parse_from_string("rightContext", &conf_line, &_right_context);
    INTER_LOG("rightContext %d", (int)_right_context);

    parse_from_string("alignSpeechSentence", &conf_line, &_align_speech_sentence);
    INTER_LOG("alignSpeechSentence %d", _align_speech_sentence);

    /*dim格式定义dim=[key1:1,2,3,4][key2:1,2,3,4]*/
    parse_dims(conf_line);
    
    CHECK2(_align_speech_sentence >= 1);
    _max_buf_num = (size_t)buf_num;
    string_to_enum(type_str, repos_type_name, &_type);

    size_t start_pos = conf_line.find("<Transform>");
    while (start_pos != std::string::npos) {
        std::string remain = conf_line.substr(0, start_pos);

        size_t end_pos = conf_line.find("</Transform>");
        CHECK(end_pos != std::string::npos, "can not find transform end");

        size_t len = end_pos - start_pos - 11;
        std::string trans_line = conf_line.substr(start_pos + 11, len);
        remain += conf_line.substr(end_pos + 12);
        _trans_lines.push_back(trans_line);
        INTER_LOG("%s", trans_line.c_str());
        conf_line = remain;
        start_pos = conf_line.find("<Transform>");
    }

    input.close();
    // 把batch_size 的信息传递给process和reader
    _proc_cfg->set_batch_size(_batch_size);
    _reader_cfg->set_batch_size(_batch_size);
}

void BaseReposConfig::parse_dims(std::string& config_line) {
    //dim格式定义dim=[key1:1,2,3,4][key2:1,2,3,4]
    std::string dim_string;
    parse_from_string("dim", &config_line, &dim_string);
    //确认找到参数
    CHECK(dim_string.size(), "data.cfg need item : dim=[key1:1,2][key2:2,3,4]");
    //分组
    std::stack<char> st;
    std::vector<std::string> dim_groud;
    for (size_t i = 0; i < dim_string.size(); i++) {
        if (dim_string[i] == '[') {
            //必须是空的，不然[]不对称
            CHECK2(st.empty());
            st.push(dim_string[i]);
        }
        else if (dim_string[i] == ']') {
            //回溯回去找[
            std::vector<char>sub_vec;
            while (!st.empty()) {
                char c = st.top();
                st.pop();
                if (c == '[') {
                    std::string sub_string(sub_vec.size(), ' ');
                    std::vector<char>::reverse_iterator r_iter = sub_vec.rbegin();
                    int index = 0;
                    for (; r_iter != sub_vec.rend(); ++r_iter) {
                        sub_string[index++] = *r_iter;
                    }
                    dim_groud.push_back(sub_string);
                    break;
                }
                else {
                    sub_vec.push_back(c);
                }
            }
            //必须为空，不然[]不对称
            CHECK2(st.empty());
        }
        else {
            st.push(dim_string[i]);
        }
    }
    
    for (size_t i = 0; i < dim_groud.size(); i++) {
        //提取key和value
        std::vector<std::string> key_value;
        split_string_to_vector(dim_groud[i], ":", true, &key_value);
        CHECK2(key_value.size() == 2);
        std::string key = key_value[0];
        std::string value = key_value[1];
        std::vector<int>dim_vec;
        split_string_to_integers(value, ",", true, &dim_vec);
        CHECK2(dim_vec.size());
        Dim dim(dim_vec);
        _dims[key] = dim;
    }
}

}// namespace houyi
}// namespace train

