//by zzxfl 2016.08.26
#include <malloc.h>  
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <chrono>
#include <omp.h>
#include <map>

#include "speech_data_reader.h"
#include "data_tool.h"
#include "speech_one_sentence.h"
#include "speech_extract_data.h"
#include "wake_up_extract_data.h"
#include "object_factory.h"

namespace houyi {
namespace train {

SpeechDataReader::SpeechDataReader(BaseReaderConfig &cfg)
    : BaseDataReader(cfg) {
    SpeechReaderConfig* speech_cfg = dynamic_cast<SpeechReaderConfig*>(&cfg);
    _barrier = std::make_shared<Barrier>(speech_cfg->get_device_num());
    _barrier->start();
    _speech_cfg = speech_cfg;
    _sample_random = speech_cfg->get_sample_random();
    _balance = speech_cfg->get_balance();
    _multi_species_data = speech_cfg->get_multi_species_data();
    if (_multi_species_data) {
        CHECK2(speech_cfg->get_speech_extract_type() == EXTRACT_SPEECH);
        CHECK2(speech_cfg->get_feat_list().size() == speech_cfg->get_label_list().size());
        for (size_t i = 0; i <  speech_cfg->get_feat_list().size(); i++) {
            std::vector<std::pair<std::string, std::vector<std::string>> > feature_list {
                speech_cfg->get_feat_list()[i]
            };
            std::vector<std::pair<std::string, std::vector<std::string>> > label_list {
                speech_cfg->get_label_list()[i]
            };
            _extract_data_runtime.push_back(
                    new SpeechExtractData(
                        feature_list,
                        label_list,
                        speech_cfg->get_load_block_num(),
                        speech_cfg->get_multi_thread_read_disk(),
                        speech_cfg->get_sample_random(),
                        speech_cfg->get_split_sentence_threshold(),
                        speech_cfg->get_split_sentence_len(),
                        speech_cfg->get_integrity(),
                        speech_cfg->get_drop_sentence_len(),
                        speech_cfg->get_intersection(),
                        speech_cfg->get_replace_labels(),
                        speech_cfg->get_batch_size(),
                        speech_cfg->get_device_num(),
                        speech_cfg->get_balance(),
                        speech_cfg->get_slack(),
                        speech_cfg->get_random_group_size()
            ));
        } 
        // 控制file_cnt比例 
        float file_cnt = speech_cfg->get_load_block_num();
        std::vector<float>file_cnt_vec;
        for (auto runtime : _extract_data_runtime) {
            file_cnt_vec.push_back(runtime->get_data_file_num());
        }
        float sum_file_cnt = std::accumulate(file_cnt_vec.begin(), file_cnt_vec.end(), 0);
        for (size_t i = 0; i < _extract_data_runtime.size(); i++) {
            float ratio = file_cnt_vec[i] / sum_file_cnt;
            _extract_data_runtime[i]->set_data_file_num(ratio * file_cnt);
            INTER_LOG("ratio file cnt %f", ratio * file_cnt);
            _file_cnt_ratio.push_back(ratio);
        }
    }
    else {
        if (speech_cfg->get_speech_extract_type() == EXTRACT_SPEECH) {
            _extract_data_runtime.push_back(
                    new SpeechExtractData(
                        speech_cfg->get_feat_list(),
                        speech_cfg->get_label_list(),
                        speech_cfg->get_load_block_num(),
                        speech_cfg->get_multi_thread_read_disk(),
                        speech_cfg->get_sample_random(),
                        speech_cfg->get_split_sentence_threshold(),
                        speech_cfg->get_split_sentence_len(),
                        speech_cfg->get_integrity(),
                        speech_cfg->get_drop_sentence_len(),
                        speech_cfg->get_intersection(),
                        speech_cfg->get_replace_labels(),
                        speech_cfg->get_batch_size(),
                        speech_cfg->get_device_num(),
                        speech_cfg->get_balance(),
                        speech_cfg->get_slack(),
                        speech_cfg->get_random_group_size()
                        ));
        }
        else {
            _extract_data_runtime.push_back(
                    new WakeUpExtractData(
                        speech_cfg->get_feat_list(),
                        speech_cfg->get_label_list(),
                        speech_cfg->get_load_block_num(),
                        speech_cfg->get_multi_thread_read_disk(),
                        speech_cfg->get_sample_random(),
                        speech_cfg->get_all_pair_path(),
                        speech_cfg->get_key_word_label_map(),
                        speech_cfg->get_expand_radio(),
                        speech_cfg->get_wake_up_trans_type()
                        ));
        }
    }

    random_data_file_list();
}

SpeechDataReader::~SpeechDataReader() {
    for (auto runtime : _extract_data_runtime) {
        delete runtime;
    }
    _barrier->stop();
}

void SpeechDataReader::reset() {
    random_data_file_list();

    for (auto runtime : _extract_data_runtime) {
        runtime->reset();
    }
    _barrier->start();
}

void SpeechDataReader::random_data_file_list() {
    if (!_sample_random) {
        return;
    }
#ifndef __CLOSE_RANDOM__
    for (auto runtime : _extract_data_runtime) {
        runtime->random_data_file_list();
    }
#endif
}

size_t SpeechDataReader::get_samples_from_reader(std::vector<BaseOneSample*>& samples, int sent_num) {
    std::unique_lock<std::mutex>lck(_read_mutex);
    auto clear_sample = [](std::vector<BaseOneSample*>& samples) {
        for (auto& s : samples) {
            delete s;
        }
        samples.clear();
    };
    // 中英文混合输入
    if (_multi_species_data) {
        CHECK2(_extract_data_runtime.size() == 2);
        CHECK2(_file_cnt_ratio.size() == 2);
        float ratio = 1.0f * rand() / RAND_MAX;
        if (ratio <= _file_cnt_ratio[0]) {
            _extract_data_runtime[0]->extract_data(samples, sent_num);
            if ((int)samples.size() < sent_num) {
                clear_sample(samples);
                _extract_data_runtime[1]->stop();
                INTER_LOG("extract 1 %d", (int)samples.size());
            }
            else {
                INTER_LOG("extract 0 %d", (int)samples.size());
            }
        }
        else {
            _extract_data_runtime[1]->extract_data(samples, sent_num);
            if ((int)samples.size() < sent_num) {
                clear_sample(samples);
                _extract_data_runtime[0]->stop();
                INTER_LOG("extract 0 %d", (int)samples.size());
            }
            else {
                INTER_LOG("extract 1 %d", (int)samples.size());
            }
        }
    }
    else {
        CHECK2(_extract_data_runtime.size() == 1);
        _extract_data_runtime[0]->extract_data(samples, sent_num);
        // 数据加载平衡
        if (_balance) {
            static thread_local int num = 0;
            int max = -1;
            for (size_t i = 0; i < samples.size(); ++i) {
                int frame_num = static_cast<SpeechOneSentence*>(samples[i])->get_frame_num();
                if (frame_num > max) {
                    max = frame_num;
                }
            }
            INTER_LOG("count=%d max_frame=%d batch_size=%d", num++, max, (int)samples.size());
            if (sent_num != (int)samples.size()) {
                _barrier->stop();
                return samples.size();
            }
            lck.unlock();

            _barrier->wait();
        }
    }

    return samples.size();
}

size_t SpeechDataReader::get_all_samples_from_reader(std::vector<BaseOneSample*>& samples) {
    std::unique_lock<std::mutex> lck(_read_mutex);
    CHECK2(_multi_species_data == false);
    CHECK2(_extract_data_runtime.size() == 1); 
    _extract_data_runtime[0]->extract_all_data(samples);

    return samples.size();
}

void SpeechDataReader::move_sample_to_queue(std::vector<BaseOneSample *> &sample_vector, std::queue<BaseOneSample *> &sample_queue) {
    for (auto sample : sample_vector) {
        sample_queue.push(sample);
    }
    sample_vector.clear();
}

}// houyi
}// train
