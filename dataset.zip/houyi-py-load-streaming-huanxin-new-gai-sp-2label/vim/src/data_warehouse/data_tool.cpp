#include<data_tool.h>

namespace houyi {
namespace train {
const char* label_type_name[] = {
    "intLabel",
    "floatLabel",
    "unkonwnLabel"
    "NULL"
};

// TODO 缩写，专有名词全部大写; 其他都用驼峰
const char *data_type_name[] = {
    "fbank",
    "PCM",
    "RGB24",
    "BBGGRRFloat",
    "JPEG",
    "BBGGRUC",
    "GrayFloat",
    "SeqChar",
    "fbankShort",
    "unknownData",
    "NULL"
};

const char *data_reader_type_name[] = {
    "speech",
    "image",
    "disc_image",
    "unknown",
    "NULL"
};

const char* repos_type_name[] = {
    "speech-sent",
    "speech-frame",
    "speech-pcm",
    "image",
    "speech-sent-3d",
    NULL
};

const char* speech_extract_type[] = {
    "extract_speech",
    "extract_wake_up"
};

void swap32(char *c)
{
    char t0 = c[0];
    char t1 = c[1];
    c[0] = c[3];
    c[1] = c[2];
    c[2] = t1;
    c[3] = t0;
}

void swap16(char* c)
{
    char t0 = c[0];
    c[0] = c[1];
    c[1] = t0;
}

}
}
