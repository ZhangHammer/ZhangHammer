/**
* @file:     speech_reader_config.cpp
* @author:   zousaisai@baidu.com
* @created:  2016-08-12 19:47
* @modified: 2016-08-12 19:47
* @brief:
*
**/

#include "speech_reader_config.h"
#include "text_utils.h"

namespace houyi {
namespace train {

void SpeechReaderConfig::parse_params(std::string &config_line) {
    parse_from_string("splitSentenceThreshold", &config_line, &_split_sentence_threshold);
    INTER_LOG("splitSentenceThreshold %d", (int)_split_sentence_threshold);

    parse_from_string("splitSentenceLen", &config_line, &_split_sentence_len);
    INTER_LOG("splitSentenceLen %d", (int)_split_sentence_len);

    parse_from_string("dropSentenceLen", &config_line, &_drop_sentence_len);
    INTER_LOG("dropSentenceLen %d", (int)_drop_sentence_len);

    parse_from_string("integrity", &config_line, &_integrity);
    INTER_LOG("integrity %d", (int)_integrity);

    parse_from_string("multiSpeciesData", &config_line, &_multi_species_data);
    INTER_LOG("multiSpeciesData %d", _multi_species_data);

    parse_from_string("replaceLabel", &config_line, &_replace_labels);
    if (_replace_labels.size()) {
        INTER_LOG("replaceLabel %d", _replace_labels[0]);
    }
    
    std::string extract_type;
    parse_from_string("speechExtractType", &config_line, &extract_type);
    string_to_enum(extract_type, speech_extract_type, &_extract_type);
    INTER_LOG("speechExtractType %d", _extract_type);

    parse_from_string("allPair", &config_line, &_all_pair_path);  
    INTER_LOG("allPair %s", _all_pair_path.c_str());

    parse_from_string("labelMap", &config_line, &_key_word_label_map);
    INTER_LOG("labelMap %s", _key_word_label_map.c_str());

    parse_from_string("expandRadio", &config_line, &_expand_radio);
    INTER_LOG("expandRadio %f", _expand_radio);

    parse_from_string("wakeUpTransType", &config_line, &_wake_up_trans_type);
    INTER_LOG("wakeUpTransType %d", _wake_up_trans_type);

    parse_from_string("intersection", &config_line, &_intersection);
    INTER_LOG("intersection %d", (int)_intersection);

    parse_from_string("slack", &config_line, &_slack);
    INTER_LOG("slack %d", (int)_slack);

    parse_from_string("randomGroupSize", &config_line, &_random_group_size);
    INTER_LOG("randomGroupSize %d", (int)_random_group_size);

    read_multi_feature_label(config_line);
}

} // namespace train
} // namespace houyi
