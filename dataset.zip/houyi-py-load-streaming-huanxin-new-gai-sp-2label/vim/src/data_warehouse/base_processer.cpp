/**
 * base_processer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-5
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#include <omp.h>
#include "base_data_reader.h"
#include "base_one_sample.h"
#include "base_processer.h"
#include "thread.h"
#include "object_factory.h"
#include "speech_frame_processer.h"

namespace houyi {
namespace train {

BaseProcesser* BaseProcesser::create(
    BaseDataReader* reader, BaseProcConfig &cfg) {
    if (cfg.get_type() == "speech-frame") {
        static SpeechFrameProcesser instance(reader, cfg);
        return &instance;
    } else {
        BaseProcesser* proc = new BaseProcesser(reader, cfg);
        return proc;
    }
}

void BaseProcesser::trans_read(int thread_num) {
    BaseTransformation* trans = NULL;
    _trans_stream.resize(thread_num);
    for (int t = 0; t < thread_num; t++) {
        std::vector<std::string>trans_lines = _cfg->get_trans_lines();
        for (size_t i = 0; i < trans_lines.size(); i++) {
            trans = BaseTransformation::read(trans_lines[i]);
            _trans_stream[t].push_back(trans);
        }
    }
}

size_t BaseProcesser::get_samples_from_proc(
    std::vector<BaseOneSample*>&samples, size_t max_num) {
    size_t counter = 0;
    if (_sample_queue) {
        for (size_t i = 0; i < max_num; i++) {
            BaseOneSample* sample = _sample_queue->pop();
            if (sample == NULL) {
                samples.push_back(sample);
                ++counter;
                break;
            }
            samples.push_back(sample);
            ++counter;
        }
    } else {
        counter = get_samples_from_reader(samples, max_num);
        /*填入一个空的sample标志epoch结束*/
        if (counter == 0) {
            samples.push_back(NULL);
            counter += 1;
        }
    }
    return counter;
}

void BaseProcesser::start_async_load() {
    if (!_cfg->is_async()) {
        return;
    }
    if (_async_pro_thread) {
        if (_async_pro_thread->is_alive()) {
            return;
        }
    }
    if (_sample_queue == NULL) {
        _sample_queue = new MessageQueue<BaseOneSample*>();
        _sample_queue->set_max_length(_max_sample_num);
    } else {
        _sample_queue->clean();
    }
    if (_async_pro_thread == NULL) {
        _async_pro_thread = new Thread();
    }
    _async_pro_thread->start(BaseProcesser::async_pro_load, (void *) this);
}

void * BaseProcesser::async_pro_load(void *data) {
    ThreadContext *ctx = static_cast<ThreadContext *>(data);
    BaseProcesser* proc = static_cast<BaseProcesser*>(ctx->get_param());
    BaseDataReader *reader = proc->get_reader();

    bool *global_alive_mark = ctx->get_alive();
    *global_alive_mark = true;
    sem_post(&ctx->_create_finish_sem);
    std::vector<BaseOneSample*> samples;
    size_t cnt = 0;
    size_t one_block_num = proc->get_cfg()->get_batch_size();
    do {
        cnt = 0;
        samples.clear();

        //TODO 每个线程处理20个
        cnt = reader->get_samples_from_reader(samples, one_block_num);
        //std::vector<bool> flag_vec(samples.size(), true);
#ifdef __PRINT_DATA_BUFFER_SIZE__
        INTER_LOG("%ld processor buffer size: %ld", pthread_self(), 
                    proc->get_queue()->size());
#endif
        std::vector<bool>flag_vec(samples.size(), true);
        //INTER_LOG("%d %d", flag_vec.size(), samples.size());
#pragma omp parallel for num_threads(proc->_trans_stream.size()), schedule(dynamic)
        for (size_t s = 0; s < samples.size(); s++) {
            try {
                if (samples[s] == NULL) {
                    continue;
                }
                if (proc->perform_trans_stream(*samples[s], omp_get_thread_num()) == false) {
                    INTER_LOG("drop sentence");
                    flag_vec[s] = false;
                }
            }
            catch (std::exception const&e) {
                std::cout << "omp exception" << e.what() << std::endl;
                CHECK2(false);
            }
        }
        bool flag = false;
        for (size_t s = 0; s < samples.size(); s++) {
            if (samples[s] == NULL) {
                flag = true;
            }
           if (flag_vec[s]) {
                proc->get_queue()->push(samples[s]);
            }
            else {
                delete samples[s];
            }
        }
        if (flag) {
            break;
        }
    } while (cnt == one_block_num);//TODO CHECK zzxfl
    proc->get_queue()->push(NULL);

    //INTER_LOG("%s:set a null sample to queue", __func__);
    *global_alive_mark = false;
    pthread_exit(NULL);
}

bool BaseProcesser::perform_trans_stream(BaseOneSample& sample, int idx) {
    CHECK2(idx < (int)_trans_stream.size());
    std::vector<BaseTransformation*>&tmp = _trans_stream[idx];
    for (size_t i = 0; i < tmp.size(); i++) {
        if (tmp[i]->perform_trans(sample) == -1) {
            INTER_LOG("drop sentence");
            return false;
        }
    }
    return true;
}

size_t BaseProcesser::get_samples_from_reader(
    std::vector<BaseOneSample*>&samples, size_t max_num) {
    // first get raw-data from reader
    // and then call process_raw_data
    std::vector<BaseOneSample*> raws;
    size_t counter = 0;
    size_t raw_num = _data_reader->get_samples_from_reader(raws, max_num);
    std::vector<bool> flag(raws.size(), true);
#pragma omp parallel for num_threads(_trans_stream.size()), schedule(dynamic)
    for (size_t s = 0; s < raw_num; s++) {
        BaseOneSample* sample = raws[s];
        if (sample == NULL) {
            continue;
        }
        if (!perform_trans_stream(*sample, omp_get_thread_num())) {
            flag[s] = false;
        }
    }
    for (size_t s = 0; s < raw_num; s++) {
        if (flag[s]) {
            samples.push_back(raws[s]);
            counter++;
        }
        else {
            if (raws[s]) {
                delete raws[s];
            }
        }
    }
    return counter;
}

}
}
