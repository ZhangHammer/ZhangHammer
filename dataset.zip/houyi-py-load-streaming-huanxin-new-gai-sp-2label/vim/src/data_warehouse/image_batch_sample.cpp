//by zzxfl 2016.11.04
#include "image_batch_sample.h"

namespace houyi {
namespace train {

ImageBatchSample::ImageBatchSample(size_t batch_size,
                                   ParamFeatureT features,
                                   ParamLabelT labels):BaseBatchSample(batch_size) {
    _batch_desc = new ImageBatchDesc();
    for (auto conf : features) {
        DataType data_type = BBGGRR_FLOAT_TYPE;
        size_t channel = 0;
        size_t height = 0;
        size_t width = 0;
        std::string key = conf.first;
        std::tie(data_type, channel, height, width) = conf.second;
        switch (data_type) {
        case BBGGRR_FLOAT_TYPE:
        case JPEG_TYPE:
        case GRAY_FLOAT_TYPE:
        case RGB24_TYPE:
            _features[key] = new ImageBatchFeature(data_type, batch_size, channel, height, width);
            _feature_keys.push_back(key);
            break;
        default:
            CHECK(false, "image type not support");
        }
    }

    for (auto conf : labels) {
        LabelType label_type = INT_LABEL_TYPE;
        size_t label_dim = 0;
        std::string key = conf.first;
        _label_keys.push_back(key);
        std::tie(label_type, label_dim) = conf.second;
        _labels[key] = new ImageBatchLabel(label_type, batch_size, label_dim);
    }
}

ImageBatchSample::~ImageBatchSample() {
    for (auto conf : _features) {
        delete conf.second;
    }
    _features.clear();
    for (auto conf : _labels) {
        delete conf.second;
    }
    _labels.clear();
    if (_batch_desc) {
        delete _batch_desc;
    }
}

void ImageBatchSample::resize(size_t batch_size, 
        ParamFeatureT features,
        ParamLabelT labels) {
    BaseBatchSample::resize(batch_size);
    _batch_desc->clear();
    for (auto conf : features) {
        DataType data_type = BBGGRR_FLOAT_TYPE;
        size_t channel = 0;
        size_t height = 0;
        size_t width = 0;
        std::string key = conf.first;
        std::tie(data_type, channel, height, width) = conf.second;
        switch (data_type) {
        case BBGGRR_FLOAT_TYPE:
        case JPEG_TYPE:
        case GRAY_FLOAT_TYPE:
        case RGB24_TYPE: {
            ImageBatchFeature* feature = static_cast<ImageBatchFeature*>(_features[key]);
            feature->resize(data_type, batch_size, channel, height, width);
            break;
        }
        default:
            CHECK(false, "image type not support");
        }
    }

    for (auto conf : labels) {
        LabelType label_type = INT_LABEL_TYPE;
        size_t label_dim = 0;
        std::string key = conf.first;
        std::tie(label_type, label_dim) = conf.second;
        ImageBatchLabel* label = static_cast<ImageBatchLabel*>(_labels[key]);
        label->resize(label_type, batch_size, label_dim);
    }
}


}//houyi
}//train
