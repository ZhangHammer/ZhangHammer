/**
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2018-08-13
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#pragma once
#include <pthread.h>
#include <vector>
#include <map>
#include <iostream>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "util.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class Sparse {
public:
    Sparse() {
        _sort.set_device(cpu_device());
    }

    Sparse(DType ratio) {
        _sparse_ratio = ratio;
    }

    ~Sparse() {
    }

    void set_sparse_ratio(DType ratio) {
        _sparse_ratio = ratio;
    }

    void sparsify(Tensor<DType>& inout);
    
    void sparsify(Tensor<DType>& out, const Tensor<DType>& in);

private:
    Tensor<DType> _sort;
    DType _sparse_ratio;
};

}
} 
