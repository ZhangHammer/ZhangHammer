/**
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2018-08-13
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_LOW_BIT_QUANT_H
#define HOUYI_TRAIN_PLATFORM_LOW_BIT_QUANT_H
#include <pthread.h>
#include <vector>
#include <map>
#include <iostream>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include "util.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class LowBitQuant {
public:
    LowBitQuant() {
    }

    LowBitQuant(size_t nbits) {
        init(nbits);
    }

    ~LowBitQuant() {
    }
    
    void init(size_t nbit);
    
    void quant_whole(bool transpose, size_t nbit, Tensor<DType>& out, Tensor<DType>& in, std::string, bool logging = false);
    
    bool can_quantize(Dim&);

private:
    void quant_internal(size_t nbit, Tensor<DType>& out, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec);

    void greedy_lsm_approximation(size_t nbit, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec); 

    void alt_lsm_approximation(size_t nbit, const Tensor<DType>& in, Tensor<DType>& alpha, std::vector<Tensor<DType>>& beta_vec); 

    void quant_map(std::vector<DType>& vmap, const Tensor<DType>& mat, const Tensor<DType>& alpha, size_t row_idx);

    void row_mul(Tensor<DType>& out, const Tensor<DType>& alpha, size_t alpha_idx, const Tensor<DType>& beta);

    void row_least_squares(Tensor<DType>& out, const std::vector<Tensor<DType>>& beta, const Tensor<DType>& in, int total, int cur); 

    void finetune_beta(std::vector<Tensor<DType>>& beta_vec, const Tensor<DType>& in, const Tensor<DType>& alpha);

    int binary_search_tree(const std::vector<DType>& vec, DType flag);
    
    static const size_t threads = 20;
    
    Tensor<DType> _alpha;
    std::vector<Tensor<DType>> _beta_vec;
    std::map<size_t, Tensor<DType>> _beta_template_map;
    Tensor<DType> _greedy_in_copy;
    Tensor<DType> _greedy_tmp;
    Tensor<DType> _error;
    Tensor<DType> _lsm_buffer1;
    Tensor<DType> _lsm_buffer2;
    Tensor<DType> _transpose;
    Tensor<DType> _transpose_quant;
    bool _enable_statis;
    std::vector<bool> _layer_quantize;
    std::vector<bool> _weight_quant_transpose;
    std::vector<size_t> _weight_quant_bits;
    Tensor<DType> _sort_buffer;
};

} // namespace train
} // namespace houyi

#endif

