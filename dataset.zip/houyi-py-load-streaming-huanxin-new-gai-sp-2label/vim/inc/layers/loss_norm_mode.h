/**
 * file: loss_norm_mode.h
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2017年05月19日 10时55分39秒
 *
 * copyright: Copyright (c) 2017, baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_LOSS_NORM_MODE_H
#define HOUYI_LAYERS_LOSS_NORM_MODE_H
namespace houyi {
namespace train {

enum LossNormMode {
    LOSS_NORM_FULL,
    LOSS_NORM_VALID,
    LOSS_NORM_BATCH_SIZE,
    LOSS_NORM_PRE_FIXED,
    LOSS_NORM_UNKNOWN
};

extern const char* LossNormModeName[];

}   /* namespace of train */
}   /* namespace of houyi */

#endif
