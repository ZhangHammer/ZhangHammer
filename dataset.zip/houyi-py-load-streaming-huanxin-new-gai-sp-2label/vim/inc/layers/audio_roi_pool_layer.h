#ifndef HOUYI_LAYERS_AUDIO_ROI_POOL_LAYER_H
#define HOUYI_LAYERS_AUDIO_ROI_POOL_LAYER_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class AudioROIPoolLayer : public Layer {
public:
    AudioROIPoolLayer(AudioROIPoolConfig& cfg);
    virtual void inter_forward(IOPackage* in_pack) {
        CHECK(false, "empty inter_forwatd is called");
    }
    virtual void inter_bprop_diff(IOPackage* in_pack, IOPackage* out_pack) {
        CHECK(false, "empty inter_bprop_diff is called");
    }

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);

    void build_map(const char* prefix = NULL) {
    }

    Layer* clone() {
        return new AudioROIPoolLayer(_cfg);
    }

    void store_model(std::ofstream&, SPEECH_NN_W_TYPE) {}
    void read_model(std::ifstream&, SPEECH_NN_W_TYPE) {}

    void init();
    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

protected:
    void set_device() {
        _seq_len.set_device(gpu_device());
        _out_feat_mask.set_device(gpu_device());
    }

private:
    AudioROIPoolConfig _cfg;
    AUDIO_ROI_POOL_TYPE _pool_type = AUDIO_ROI_POOL_AVG_TYPE;

    Tensor<int> _seq_len;
    Tensor<int> _out_feat_mask;
    Tensor<int> _max_idx;
    int _group_size;
    float _scale;
};

}
}

#endif
