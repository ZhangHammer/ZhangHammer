#ifndef HOUYI_LAYERS_AUDIO_ROI_POOL_OPS_H
#define HOUYI_LAYERS_AUDIO_ROI_POOL_OPS_H

#include <vector>
#include <iostream>

namespace houyi {
namespace train {

enum AUDIO_ROI_POOL_TYPE {
    AUDIO_ROI_POOL_MAX_TYPE,
    AUDIO_ROI_POOL_AVG_TYPE
};

void wind_audio_roi_pool_fwd(const Tensor<DType>& in,
        Tensor<int>& max_idx,
        const Tensor<int>& seq_len,
        Tensor<DType>& out,
        int group_size, float scale, AUDIO_ROI_POOL_TYPE pool_type);

void wind_audio_roi_pool_bp(const Tensor<DType>& in,
        Tensor<int>& max_idx, 
        const Tensor<int>& seq_len,
        Tensor<DType>& out,
        int group_size, float scale, AUDIO_ROI_POOL_TYPE pool_type);

}
}

#endif
