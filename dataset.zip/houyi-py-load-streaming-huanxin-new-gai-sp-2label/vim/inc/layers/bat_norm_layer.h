/**
 * Bat_normal_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-30
 *
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef APP_SEARCH_AUDIO_DNNRESEARCH_LSTM_BAT_NORM_LAYER_H
#define APP_SEARCH_AUDIO_DNNRESEARCH_LSTM_BAT_NORM_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include "wind/wind.h"
#include "weight.h"
#include "full_layer.h"

namespace houyi {
namespace train {

class BatNormalLayer : public Layer{
public:
    BatNormalLayer(BatNormConfig& config);
    BatNormalLayer(BatNormalLayer* from);
    virtual ~BatNormalLayer();
    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    Layer* clone() {
        return new BatNormalLayer(this);
    }

    void gauss_init(DType mean, DType stdv);
    void init_weight(const ModelInitConfig& global_cfg);
    void init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers);

    virtual void read_initial_mean_var();
    virtual void read_initial_mean_var(std::string bn_file_prefix);
    void store_mean_var();
    inline DenseWeight* w() {
        return &_w;
    }
    inline DenseWeight* w_t() {
        return &_w_t;
    }
    inline DenseWeight* bias() {
        return &_bias;
    }
    inline DenseWeight* bias_t() {
        return &_bias_t;
    }
    inline DenseWeight* dw() {
        return &_dw;
    }
    inline DenseWeight* d_bias() {
        return &_d_bias;
    }

    char* global_file_name() {
        return _global_mean_var;
    }
    Tensor<DType>* mean_vec() {
        return &_mean_vec;
    }
    Tensor<DType>* var_vec() {
        return &_var_vec;
    }
    DType get_eta() {
        return _eta;
    }
    DType get_moving_average_fraction() {
        return _moving_average_fraction;
    }
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    virtual void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    virtual void read_heter_model(std::ifstream& input);
    virtual void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

    void build_map(const char* prefix = NULL);
    BatNormConfig& config() {
        return _config;
    }
protected:
    void set_device(void) {
        _x_sharp_o.set_device(gpu_device());
        _x_bias.set_device(gpu_device());
        _acc_x_bias.set_device(gpu_device());
        _real_in.set_device(gpu_device());
        _buf_e.set_device(gpu_device());
        _mean_vec.set_device(gpu_device());
        _d_mean_vec.set_device(gpu_device());
        _var_vec.set_device(gpu_device());
        _d_var_vec.set_device(gpu_device());

        _acc_mean_vec.set_device(gpu_device());
        _acc_var_vec.set_device(gpu_device());

        _label_mask.set_device(gpu_device());
        _statis_mean_vec.set_device(gpu_device());
        _statis_var_vec.set_device(gpu_device());
    }

    void read_initial_mean_var_em1(const char* file_name);
    void read_initial_mean_var_em0(const char* file_name);
    void inter_forward_em1(std::vector<IOPackage*>& in_pack);
    void inter_forward_em0(std::vector<IOPackage*>& in_pack);

    int get_real_frame_num(IOPackage* in_pack);

protected:
    char* _global_mean_var; // initial meanVec and varVec
    DType _epsilon;
    Tensor<DType> _x_sharp_o;
    Tensor<DType> _x_bias;
    Tensor<DType> _acc_x_bias;
    Tensor<DType> _real_in;
    Tensor<DType> _buf_e;
    Tensor<DType> _mean_vec, _d_mean_vec;
    Tensor<DType> _var_vec, _d_var_vec;

    Tensor<DType> _acc_mean_vec;
    Tensor<DType> _acc_var_vec;

    int _real_frame_num;
    Tensor<DType> _label_host;
    Tensor<int> _label_mask;

    /* ut = _eta * ut + (1 - _eta) * ut-1
     * vt = _eta * vt + (1 - _eta) * vt-1*/
    DType _eta;

    Tensor<DType> _statis_mean_vec;
    Tensor<DType> _statis_var_vec;
    Tensor<DType> _tmp_var;

    DType _counter;
    uint64_t _store_item;

    int _frame_dim;
    DType _moving_average_fraction;
    pid_t _tid;
    pid_t _pid;

    DenseWeight  _w, _dw;
    DenseWeight  _bias, _d_bias;
    
    /*for inq */
    DenseWeight  _w_t;
    DenseWeight  _bias_t;
   
    Tensor<DType> _in_trans_buf;
    Tensor<DType> _diff_trans_buf;
    BatNormConfig _config;
};

}
}
#endif
