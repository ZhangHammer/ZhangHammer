/**
 * loss_store.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-05
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_LAYERS_LOSS_STORE_H
#define HOUYI_LAYERS_LOSS_STORE_H

#include <string>
#include <vector>
#include "wind/wind.h"
#include <algorithm>

namespace houyi {
namespace train {

enum LossType {
    LOSS_TYPE_CE,
    LOSS_TYPE_MSE,
    LOSS_TYPE_CTC,
    LOSS_TYPE_TRIPLET,
    LOSS_TYPE_SMOOTH_L1,
    LOSS_TYPE_SMOOTH_OHEM_L1,
    LOSS_TYPE_FOCAL,
    LOSS_TYPE_LR,
    LOSS_TYPE_MIX_LR,
    LOSS_TYPE_UNKNOWN
};

class Loss;
Loss* creat_loss(const LossType type, const std::string name);

class Loss {
public:
    Loss() {
        init();
    }
    Loss(LossType loss_type) {
        init();
        _type = loss_type;
    }
    Loss(LossType loss_type, std::string name) {
        init();
        _type = loss_type;
        _name = name;
    }
    Loss(double loss, LossType loss_type, std::string name) {
        init();
        _type = loss_type;
        _name = name;
    }
    virtual ~Loss() {
    }

    virtual void clear() {
        _loss = 0.0f;
        _frame_counter = 0;
        _sample_counter = 0;
    }

    virtual Loss operator+ (const Loss& loss) {
        Loss local_loss;
        local_loss.set_loss(_loss + loss.get_loss());
        local_loss.set_frame_counter(_frame_counter + loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter + loss.get_sample_counter());
        return local_loss;
    }

    virtual Loss operator- (const Loss& loss) {
        Loss local_loss;
        local_loss.set_loss(_loss - loss.get_loss());
        local_loss.set_frame_counter(_frame_counter - loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter - loss.get_sample_counter());
        return local_loss;
    }

    virtual Loss operator+= (const Loss& loss) {
        _loss = _loss + loss.get_loss();
        _frame_counter = _frame_counter + loss.get_frame_counter();
        _sample_counter = _sample_counter + loss.get_sample_counter();
        return *this;
    }

    virtual Loss operator-= (const Loss& loss) {
        _loss -= loss.get_loss();
        _frame_counter -= loss.get_frame_counter();
        _sample_counter -= loss.get_sample_counter();
        return *this;
    }

    virtual Loss operator= (const Loss& loss) {
        _loss = loss.get_loss();
        _frame_counter = loss.get_frame_counter();
        _sample_counter = loss.get_sample_counter();
        return *this;
    }

    LossType get_type() const {
        return _type;
    }

    double get_loss() const {
        return _loss;
    }

    std::string get_name() const {
        return _name;
    }

    void set_type(const LossType type) {
        _type = type;
    }
    void set_loss(const double loss) {
        _loss = loss;
    }

    void set_name(const std::string& name) {
        _name = name;
    }
    void set_frame_counter(size_t frame_counter) {
        _frame_counter = frame_counter;
    }
    size_t get_frame_counter() const {
        return _frame_counter;
    }
    void set_sample_counter(size_t sample_counter) {
        _sample_counter = sample_counter;
    }
    size_t get_sample_counter() const {
        return _sample_counter;
    }

protected:
    void init() {
        _loss = 0.0f;
        _frame_counter = 0;
        _sample_counter = 0;
        _type = LOSS_TYPE_UNKNOWN;
    }

protected:
    LossType _type;
    std::string _name;
    double _loss;
    //记录训练经过了多少样本，对语音来说是帧数，对图像分类来说是图片数
    size_t _frame_counter;
    //记录训练经过了多少样本，对语音来说是句子数，对图像分类来说是图片数
    size_t _sample_counter;
};

class CtcLoss : public Loss {
public:
    CtcLoss() : Loss() {
        init();
    }
    CtcLoss(LossType loss_type) : Loss(loss_type) {
        init();
        _type = loss_type;
    }
    CtcLoss(LossType loss_type, std::string name) : Loss(loss_type, name) {
        init();
        _type = loss_type;
        _name = name;
    }
    CtcLoss(double loss, LossType loss_type, std::string name) : Loss(loss, loss_type, name) {
        init();
        _type = loss_type;
        _name = name;
    }

    ~CtcLoss() {
    }

    void clear() {
        Loss::clear();
        _log_lh = 0.0f;
        _log_pzx = 0.0f;

        _ref_len = 0;
        _wer_len = 0;
        _ins_len = 0;
        _del_len = 0;
        _sub_len = 0;

        _local_rate = 0;
        _blank_rate = 0;
    }

    CtcLoss operator+ (const CtcLoss& loss) {
        CtcLoss local_loss;

        local_loss.set_loss(_loss + loss.get_loss());
        local_loss.set_frame_counter(_frame_counter + loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter + loss.get_sample_counter());
        local_loss.set_log_lh(_log_lh + loss.get_log_lh());
        local_loss.set_log_pzx(_log_pzx + loss.get_log_pzx());
        local_loss.set_ref_len(_ref_len + loss.get_ref_len());
        local_loss.set_wer_len(_wer_len + loss.get_wer_len());
        local_loss.set_ins_len(_ins_len + loss.get_ins_len());
        local_loss.set_del_len(_del_len + loss.get_del_len());
        local_loss.set_sub_len(_sub_len + loss.get_sub_len());
        local_loss.set_local_rate(_local_rate + loss.get_local_rate());
        local_loss.set_blank_rate(_blank_rate + loss.get_blank_rate());
        return local_loss;
    }

    CtcLoss operator- (const CtcLoss& loss) {
        CtcLoss local_loss;
        local_loss.set_loss(_loss - loss.get_loss());
        local_loss.set_frame_counter(_frame_counter - loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter - loss.get_sample_counter());
        local_loss.set_log_lh(_log_lh - loss.get_log_lh());
        local_loss.set_log_pzx(_log_pzx - loss.get_log_pzx());
        local_loss.set_ref_len(_ref_len - loss.get_ref_len());
        local_loss.set_wer_len(_wer_len - loss.get_wer_len());
        local_loss.set_ins_len(_ins_len - loss.get_ins_len());
        local_loss.set_del_len(_del_len - loss.get_del_len());
        local_loss.set_sub_len(_sub_len - loss.get_sub_len());
        local_loss.set_local_rate(_local_rate - loss.get_local_rate());
        local_loss.set_blank_rate(_blank_rate - loss.get_blank_rate());
        return local_loss;
    }

    CtcLoss operator+= (const CtcLoss& loss) {
        _loss += loss.get_loss();
        _frame_counter += loss.get_frame_counter();
        _sample_counter += loss.get_sample_counter();
        _log_lh += loss.get_log_lh();
        _log_pzx += loss.get_log_pzx();
        _ref_len += loss.get_ref_len();
        _wer_len += loss.get_wer_len();
        _ins_len += loss.get_ins_len();
        _del_len += loss.get_del_len();
        _sub_len += loss.get_sub_len();
        _local_rate += loss.get_local_rate();
        _blank_rate += loss.get_blank_rate();
        return *this;
    }

    CtcLoss operator-= (const CtcLoss& loss) {
        _loss -= loss.get_loss();
        _frame_counter -= loss.get_frame_counter();
        _sample_counter -= loss.get_sample_counter();
        _log_lh -= loss.get_log_lh();
        _log_pzx -= loss.get_log_pzx();
        _ref_len -= loss.get_ref_len();
        _wer_len -= loss.get_wer_len();
        _ins_len -= loss.get_ins_len();
        _del_len -= loss.get_del_len();
        _sub_len -= loss.get_sub_len();
        _local_rate -= loss.get_local_rate();
        _blank_rate -= loss.get_blank_rate();
        return *this;
    }

    CtcLoss operator= (const CtcLoss& loss) {
        _loss = loss.get_loss();
        _frame_counter = loss.get_frame_counter();
        _sample_counter = loss.get_sample_counter();
        _log_lh = loss.get_log_lh();
        _log_pzx = loss.get_log_pzx();
        _ref_len = loss.get_ref_len();
        _wer_len = loss.get_wer_len();
        _ins_len = loss.get_ins_len();
        _del_len = loss.get_del_len();
        _sub_len = loss.get_sub_len();
        _local_rate = loss.get_local_rate();
        _blank_rate = loss.get_blank_rate();
        return *this;
    }

    double get_loss() const {
        return _loss;
    }
    double get_log_lh() const {
        return _log_lh;
    }
    double get_log_pzx() const {
        return _log_pzx;
    }

    int get_ref_len() const {
        return _ref_len;
    }
    int get_wer_len() const {
        return _wer_len;
    }
    int get_ins_len() const {
        return _ins_len;
    }
    int get_del_len() const {
        return _del_len;
    }
    int get_sub_len() const {
        return _sub_len;
    }

    int get_local_rate() const {
        return _local_rate;
    }
    int get_blank_rate() const {
        return _blank_rate;
    }

    void set_loss(const double loss) {
        _loss = loss;
    }

    void set_log_lh(double log_lh) {
        _log_lh = log_lh;
    }
    void set_log_pzx(double log_pzx) {
        _log_pzx = log_pzx;
    }

    void set_ref_len(int ref_len) {
        _ref_len = ref_len;
    }
    void set_wer_len(int wer_len) {
        _wer_len = wer_len;
    }
    void set_ins_len(int ins_len) {
        _ins_len = ins_len;
    }
    void set_del_len(int del_len) {
        _del_len = del_len;
    }
    void set_sub_len(int sub_len) {
        _sub_len = sub_len;
    }

    void set_local_rate(int local_rate) {
        _local_rate = local_rate;
    }
    void set_blank_rate(int blank_rate) {
        _blank_rate = blank_rate;
    }

protected:
    void init() {
        Loss::init();
        _log_lh = 0.0f;
        _log_pzx = 0.0f;

        _ref_len = 0;
        _wer_len = 0;
        _ins_len = 0;
        _del_len = 0;
        _sub_len = 0;

        _local_rate = 0;
        _blank_rate = 0;
    }

protected:
    double _log_lh, _log_pzx;

    int _ref_len, _wer_len;
    int _ins_len, _del_len, _sub_len;

    int _local_rate;
    int _blank_rate;
};

class TripletLoss : public Loss {
public:
    TripletLoss() : Loss() {
        init();
    }
    TripletLoss(LossType loss_type) : Loss(loss_type) {
        init();
        _type = loss_type;
    }
    TripletLoss(LossType loss_type, std::string name) : Loss(loss_type, name) {
        init();
        _type = loss_type;
        _name = name;
    }
    TripletLoss(double loss, LossType loss_type, std::string name) : Loss(loss, loss_type, name) {
        init();
        _type = loss_type;
        _name = name;
    }

    ~TripletLoss() {
    }

    void clear() {
        Loss::clear();
        _ap_distance = 0.0f;
        _an_distance = 0.0f;

        _positive_apn = 0;
    }

    TripletLoss operator+ (const TripletLoss& loss) {
        TripletLoss local_loss;

        local_loss.set_loss(_loss + loss.get_loss());
        local_loss.set_frame_counter(_frame_counter + loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter + loss.get_sample_counter());
        local_loss.set_ap_distance(_ap_distance + loss.get_ap_distance());
        local_loss.set_an_distance(_an_distance + loss.get_an_distance());
        local_loss.set_positive_apn(_positive_apn + loss.get_positive_apn());
        return local_loss;
    }

    TripletLoss operator- (const TripletLoss& loss) {
        TripletLoss local_loss;
        local_loss.set_loss(_loss - loss.get_loss());
        local_loss.set_frame_counter(_frame_counter - loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter - loss.get_sample_counter());
        local_loss.set_ap_distance(_ap_distance - loss.get_ap_distance());
        local_loss.set_an_distance(_an_distance - loss.get_an_distance());
        local_loss.set_positive_apn(_positive_apn - loss.get_positive_apn());
        return local_loss;
    }

    TripletLoss operator+= (const TripletLoss& loss) {
        _loss += loss.get_loss();
        _frame_counter += loss.get_frame_counter();
        _sample_counter += loss.get_sample_counter();
        _ap_distance += loss.get_ap_distance();
        _an_distance += loss.get_an_distance();
        _positive_apn += loss.get_positive_apn();
        return *this;
    }

    TripletLoss operator-= (const TripletLoss& loss) {
        _loss -= loss.get_loss();
        _frame_counter -= loss.get_frame_counter();
        _sample_counter -= loss.get_sample_counter();
        _ap_distance -= loss.get_ap_distance();
        _an_distance -= loss.get_an_distance();
        _positive_apn -= loss.get_positive_apn();
        return *this;
    }

    TripletLoss operator= (const TripletLoss& loss) {
        _loss = loss.get_loss();
        _frame_counter = loss.get_frame_counter();
        _sample_counter = loss.get_sample_counter();
        _ap_distance = loss.get_ap_distance();
        _an_distance = loss.get_an_distance();
        _positive_apn = loss.get_positive_apn();
        return *this;
    }

    double get_an_distance() const {
        return _an_distance;
    }
    double get_ap_distance() const {
        return _ap_distance;
    }

    double get_positive_apn() const {
        return _positive_apn;
    }

    void set_positive_apn(int apn) {
        _positive_apn = apn;
    }

    void set_ap_distance(double distance) {
        _ap_distance = distance;
    }
    void set_an_distance(double distance) {
        _an_distance = distance;
    }

protected:
    void init() {
        Loss::init();
        _ap_distance = 0.0f;
        _an_distance = 0.0f;
        _positive_apn = 0;
    }

protected:
    /* loss>0的样本中，ap之间的距离 */
    double _ap_distance;
    /* loss>0的样本中，an之间的距离 */
    double _an_distance;

    /* loss>0的apn对的数量*/
    int _positive_apn;
};

class MixLrLoss : public Loss {
public:
    MixLrLoss() : Loss() {
        init();
    }
    MixLrLoss(LossType loss_type) : Loss(loss_type) {
        init();
        _type = loss_type;
    }
    MixLrLoss(LossType loss_type, std::string name) : Loss(loss_type, name) {
        init();
    }
    MixLrLoss(double loss, LossType loss_type, std::string name) : Loss(loss, loss_type, name) {
        init();
    }

    ~MixLrLoss() {
    }

    void clear() {
        Loss::clear();
        _loss_vec.clear();
        for (int i = 0; i < 8; ++i) {
            _loss_vec.push_back(0.0f);
        }
    }

    std::vector<double>& get_loss_vec() {
        return _loss_vec;
    }

    void set_loss_vec(std::vector<double>& loss_vec) {
        _loss_vec = loss_vec;
    }

    MixLrLoss operator+ (const MixLrLoss& loss) {
        MixLrLoss local_loss;
        local_loss.set_loss(_loss + loss.get_loss());
        local_loss.set_frame_counter(_frame_counter + loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter + loss.get_sample_counter());
    
        std::vector<double> v1 = const_cast<MixLrLoss*> (&loss)->get_loss_vec();
        std::vector<double> v2 = get_loss_vec();
        std::vector<double> v3(8, 0.0);
        std::transform(v1.begin(), v1.end(), v2.begin(), v3.begin(), std::plus<double>()); 
        local_loss.set_loss_vec(v3);

        return local_loss;
    }

    MixLrLoss operator- (const MixLrLoss& loss) {
        MixLrLoss local_loss;
        local_loss.set_loss(_loss - loss.get_loss());
        local_loss.set_frame_counter(_frame_counter - loss.get_frame_counter());
        local_loss.set_sample_counter(_sample_counter - loss.get_sample_counter());

        std::vector<double> v2 = const_cast<MixLrLoss*> (&loss)->get_loss_vec();
        std::vector<double> v1 = get_loss_vec();
        std::vector<double> v3(8, 0.0);
        std::transform(v1.begin(), v1.end(), v2.begin(), v3.begin(), std::minus<double>()); 
        local_loss.set_loss_vec(v3);

        return local_loss;
    }

    MixLrLoss operator+= (const MixLrLoss& loss) {
        _loss += loss.get_loss();
        _frame_counter += loss.get_frame_counter();
        _sample_counter += loss.get_sample_counter();

        std::vector<double> v1 = const_cast<MixLrLoss*> (&loss)->get_loss_vec();
        std::vector<double> v2 = get_loss_vec();
        std::vector<double> v3(8, 0.0);
        std::transform(v1.begin(), v1.end(), v2.begin(), v3.begin(), std::plus<double>()); 
        set_loss_vec(v3);
        return *this;
    }

    MixLrLoss operator-= (const MixLrLoss& loss) {
        _loss -= loss.get_loss();
        _frame_counter -= loss.get_frame_counter();
        _sample_counter -= loss.get_sample_counter();
        std::vector<double> v2 = const_cast<MixLrLoss*> (&loss)->get_loss_vec();
        std::vector<double> v1 = get_loss_vec();
        std::vector<double> v3(8, 0);
        std::transform(v1.begin(), v1.end(), v2.begin(), v3.begin(), std::minus<double>()); 

        set_loss_vec(v3);
        return *this;
    }

    MixLrLoss operator= (const MixLrLoss& loss) {
        _loss = loss.get_loss();
        _frame_counter = loss.get_frame_counter();
        _sample_counter = loss.get_sample_counter();
        std::vector<double> v1 = const_cast<MixLrLoss*> (&loss)->get_loss_vec();
        set_loss_vec(v1);
        return *this;
    }

protected:
    void init() {
        Loss::init();
        clear();
    }

public:
    std::vector<double> _loss_vec;
    /* loss>0的样本中，ap之间的距离 */
    //double _one_sigmoid_loss = 0.0;
    //double _one_ln_loss = 0.0;
    //double _zero_sigmoid_loss = 0.0;
    //double _zero_ln_loss = 0.0;
};

}
}

#endif
