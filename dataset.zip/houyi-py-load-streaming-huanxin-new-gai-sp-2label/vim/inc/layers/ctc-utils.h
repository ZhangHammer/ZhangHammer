/**
*@file:     ctc-utils.h
*@author:   zousaisai
*@created:  2016-08-05 12:29
*@modified: 2016-08-05 12:29
*@brief:
**/

#ifndef HOUYI_INC_LAYERS_CTC-UTILS_H
#define HOUYI_INC_LAYERS_CTC-UTILS_H

#pragma GCC diagnostic warning "-fpermissive"

/*
 * Some numeric limits and operations. These limits and operations
 * are used in CTC computation/evaluation.
 */
template <typename T>
struct NumericLimits;

template <>
struct NumericLimits<float> {
    static const float log_zero_ = -1e30f;
    static const float exp_limit_ = 88.722839f;
    static const float log_inf_ = 1e30f;
    static const float max_ = 3.4028235e+038f;
};

template <>
struct NumericLimits<double> {
    static const double log_zero_ = -1e100;
    static const double exp_limit_ = 709.78271289338397;
    static const double log_inf_ = 1e100;
    static const double max_ = 1.7976931348623157e+308;
};


// a + b, where a and b are assumed to be in the log scale
template <typename T>
static inline __host__ __device__ T AddAB(T a, T b) {
    if (a == NumericLimits<T>::log_zero_ || b == NumericLimits<T>::log_zero_) {
        return NumericLimits<T>::log_zero_;
    } else {
        return a + b;
    }
}

// a - b, where a and b are assumed to be in the log scale
template <typename T>
static inline __host__ __device__ T SubAB(T a, T b) {
    if (a == NumericLimits<T>::log_zero_) {
        return NumericLimits<T>::log_zero_;
    } else if (b == NumericLimits<T>::log_zero_) {
        return NumericLimits<T>::log_inf_;
    } else {
        return a - b;
    }
}

// exp(a)
template <typename T>
static inline __host__ __device__ T ExpA(T a) {
    if (a <= NumericLimits<T>::log_zero_) {
        return 0;
    } else if (a >= NumericLimits<T>::exp_limit_) {
        return NumericLimits<T>::max_;
    } else {
        return exp(a);
    }
}

// Approximation of  log(a + b) = log(a) + log(1 + b/a), if b < a
//                              = log(b) + log(1 + a/b), if a < b
template <typename T>
static inline __host__ __device__ T LogAPlusB(T a,
        T b) { // x and y are in log scale and so is the result
    if (b < a) {
        return AddAB(a, log(1 + ExpA(SubAB(b, a))));
    } else {
        return AddAB(b, log(1 + ExpA(SubAB(a, b))));
    }
}

#endif
