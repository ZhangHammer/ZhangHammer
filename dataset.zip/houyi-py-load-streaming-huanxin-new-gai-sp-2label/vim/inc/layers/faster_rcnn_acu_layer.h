/**
 * file: faster_rcnn_acu_layer.h
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2017年4月22日 00时37分44秒
 *
 * copyright: Copyright (c) 2017, baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_FASTER_RCNN_ACU_LAYER_H
#define HOUYI_LAYERS_FASTER_RCNN_ACU_LAYER_H

#include "util.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {

class FasterRCNNACULayer : public Layer {
public:
    FasterRCNNACULayer(FasterRCNNACUConfig& config);
    FasterRCNNACULayer(FasterRCNNACULayer* from);

    ~FasterRCNNACULayer() {
    }

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack) {}
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {}
    Layer* clone();

    void clip_boxes(Tensor<DType>& boxes, int width, int height);
    void nms_cpu(std::vector<std::tuple<DType, DType, DType, DType, DType, int> >& score_proposal,
                 std::vector<int>& idx, float thresh);
    void bbox_transform_inv(Tensor<DType>& boxes,
                            Tensor<DType>& deltas,
                            Tensor<DType>& pred_boxes);

    void build_map(const char* prefix = NULL) {}
    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    FasterRCNNACUConfig& config() {
        return _config;
    }

    void set_device() {
        _rpn_rois.set_device(CPU);
        _bbox.set_device(CPU);
        _score.set_device(CPU);
        _label.set_device(CPU);
        _pred_boxes.set_device(CPU);
        _image.set_device(CPU);
        _bbox_target.set_device(CPU);
        _bbox_target_xy.set_device(CPU);
    }

    //保存打分的结果
    void save_all_box(int image_idx, int c, float image_scale,
                      std::vector<std::tuple<DType, DType, DType,
                      DType, DType, int> >& score_proposal,
                      std::vector<int>& idx);

protected:
    void init() {
    }

private:
    FasterRCNNACUConfig _config;
    Tensor<DType> _rpn_rois;
    Tensor<DType> _bbox;
    Tensor<DType> _score;
    Tensor<DType> _label;
    Tensor<DType> _pred_boxes;
    Tensor<DType> _image;
    Tensor<DType> _bbox_target;
    Tensor<DType> _bbox_target_xy;
};

}
}

#endif
