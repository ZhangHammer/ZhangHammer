/**
 * file: python_layer.h
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年12月23日 17时35分11秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_PYTHON_LAYER_H
#define HOUYI_LAYERS_PYTHON_LAYER_H

#include <boost/python.hpp>
#include "layer.h"
#include "layer_config.h"
#include <mutex>

namespace bp = boost::python;

namespace houyi {
namespace train {

/*
 * 对python锁进行封装
 *
 */

class PythonLayer;
class PythonRuntime {
public:
    PythonRuntime() {
        Py_Initialize();
    }
    template<typename... Args>
    bp::object attr(bp::object self, std::string str, Args... args) {
        std::unique_lock<std::mutex> lock(_python_mutex);
        return self.attr(str.c_str())(args...);
    }
    static PythonRuntime& instance() {
        static PythonRuntime* runtime = new PythonRuntime();
        return *runtime;
    }
    template<typename T>
    T extract(bp::object oj) {
        std::unique_lock<std::mutex> lock(_python_mutex);
        return bp::extract<T>(oj);
    }

    bp::object import(std::string str) {
        std::unique_lock<std::mutex> lock(_python_mutex);
        return bp::import(str.c_str());
    }
    bp::object module_attr(bp::object module, std::string str, PythonConfig& cfg) {
        std::unique_lock<std::mutex> lock(_python_mutex);
        return module.attr(str.c_str())(cfg);
    }
private:
    std::mutex _python_mutex;
};

PythonLayer* get_python_layer(PythonConfig& cfg);

class PythonLayer : public Layer {
public:
    PythonLayer(PyObject* self, PythonConfig& cfg) : Layer(cfg),
    _self(bp::handle<>(bp::borrowed(self))), _config(cfg) {
        _self.attr("_param_str") = bp::str(cfg.get_param_str());
        _self.attr("_global_cfg_file") = bp::str(cfg.get_global_cfg_file());
    }
    ~PythonLayer() {
    }

    Layer* clone() {
        return get_python_layer(_config);
    }

    void build_map(const char* prefix = NULL) {
        PythonRuntime::instance().attr(_self, "build_map");
    }

    void forward(Argument& io_arg);
    bool backward(Argument& io_arg, Argument& diff_arg);

    void inter_forward(std::vector<IOPackage*>& pack) {
        PythonRuntime::instance().attr(_self, "inter_forward", pack);
    }
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
        PythonRuntime::instance().attr(_self, "inter_bprop_diff", in_pack, out_pack);
    }
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, std::vector<IOPackage*>& out_pack) {
        PythonRuntime::instance().attr(_self, "inter_bprop_grad", in_pack);
    }

    int is_echo_finish() {
        bp::object oj = PythonRuntime::instance().attr(_self, "is_echo_finish");
        return PythonRuntime::instance().extract<int>(oj);
    }

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {
        INTER_LOG("python layer do not support store model");
    }
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
        INTER_LOG("python layer do not support read model");
    }

    inline PythonConfig& config() {
        return _config;
    }

private:
    bp::object _self;
protected:
    PythonConfig _config;

};

}
}

#endif
