/**
 * focal_loss_layer.h
 * Author: fuxuanyu (fuxuanyu@baidu.com)
 * Created on: 2018-05-15
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_LAYER_FOCAL_LOSS_LAYER_H
#define HOUYI_LAYER_FOCAL_LOSS_LAYER_H
#include <vector>
#include "wind/wind.h"
#include "loss_layer.h"

namespace houyi {
namespace train {

class FocalLossLayer : public LossLayer {
public:
    FocalLossLayer(LossConfig& cfg) : LossLayer(cfg) {
        _gamma = cfg.get_focal_loss_gamma();
        _ratio = cfg.get_focal_loss_ratio();
    }
    ~FocalLossLayer() {
    }
    virtual FocalLossLayer* clone() {
        return new FocalLossLayer(_cfg);
    }
    virtual void cal_target(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label,
                            std::vector<IOPackage*>& target);
    virtual void cal_loss(std::vector<IOPackage*>& output,
                          std::vector<IOPackage*>& label,
                          std::vector<IOPackage*>& loss);
    Loss& get_cost_value(TGT_COST_TYPE type);
private:
    float _gamma;
    // 走focal loss的概率为ratio， 走ce_loss的概率为1.0 - ratio
    float _ratio = 1.0;
};

} //namespace houyi
} //namespace train
#endif
