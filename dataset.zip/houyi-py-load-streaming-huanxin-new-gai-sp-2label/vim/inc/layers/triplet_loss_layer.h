/**
 * file: triplet_loss_layer.h
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年11月27日 00时37分44秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_TRIPLET_LOSS_LAYER_H
#define HOUYI_LAYERS_TRIPLET_LOSS_LAYER_H
#include "wind/wind.h"
#include "layer_config.h"
#include "layer.h"
#include "loss_layer.h"

namespace houyi {
namespace train {

class TripletLossLayer : public LossLayer {
public:
    TripletLossLayer(LossConfig& cfg) : LossLayer(cfg) {
        _alpha = cfg.get_alpha();
        _positive_apn = 0;
        set_device();
    }
    ~TripletLossLayer() {}

    virtual void cal_target(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
    virtual void cal_loss(std::vector<IOPackage*>& output,
                          std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
    Loss& get_cost_value(TGT_COST_TYPE type);
    virtual Layer* clone() {
        return new TripletLossLayer(_cfg);
    }

    inline DType get_alpha() {
        return _alpha;
    }

protected:
    void set_device() {
        _a.set_device(gpu_device());
        _p.set_device(gpu_device());
        _n.set_device(gpu_device());
        _a_sub_p.set_device(gpu_device());
        _a_sub_n.set_device(gpu_device());
        _n_sub_p.set_device(gpu_device());
        _a_p_square.set_device(gpu_device());
        _a_n_square.set_device(gpu_device());
        _a_p_norm2.set_device(gpu_device());
        _a_n_norm2.set_device(gpu_device());

        _pre_diff_buf.set_device(gpu_device());
    }
protected:
    DType _alpha;

    Tensor<DType> _a;
    Tensor<DType> _p;
    Tensor<DType> _n;
    Tensor<DType> _a_sub_p;
    Tensor<DType> _a_sub_n;
    Tensor<DType> _n_sub_p;
    Tensor<DType> _a_p_square;
    Tensor<DType> _a_n_square;
    Tensor<DType> _a_p_norm2;
    Tensor<DType> _a_n_norm2;

    Tensor<DType> _pre_diff_buf;

    size_t _positive_apn;
};

}   /* namespace of train */
}   /* namespace of houyi */


#endif
