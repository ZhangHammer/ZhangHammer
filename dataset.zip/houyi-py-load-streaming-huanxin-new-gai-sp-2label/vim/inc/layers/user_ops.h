#ifndef HOUYI_LAYERS_USER_OPS_H
#define HOUYI_LAYERS_USER_OPS_H
#include <wind/wind.h>
#include "image_conv_ops.h"
#include "image_pooling_ops.h"
#include "audio_roi_pool_ops.h"

namespace houyi {
namespace train {

void wind_norm2_op(const Tensor<float>& in, Tensor<float>& norm2, Tensor<float>& out);
void wind_transpose(const Tensor<float>& in, Tensor<float>& out, Tensor<int>& transpose);
void wind_shrink_op(const Tensor<float>& I, Tensor<float>& O, int batch_size, int left_num,
                    int right_num, int dimM, int dimN);
void wind_expand_op(const Tensor<float>& I, Tensor<float>& O, int batch_size, int left_num,
                    int right_num, int dimM, int dimN);
template<typename T> void wind_skip_op(Tensor<T>& O,
                                       const Tensor<T>& I, int batch_size,
                                       int split_num, int skip_step, 
                                       const Tensor<int>& split_start,
                                       T invalid_value);
template<typename T> void wind_skip_1d_op(Tensor<T>& O,
                                       const Tensor<T>& I, int batch_size,
                                       int split_num, int skip_step, 
                                       const Tensor<int>& split_start, 
                                       T invalid_value);
void wind_skip_bp_op(Tensor<float>& O,
                     const Tensor<float>& I, int batch_size, int split_num,
                     int skip_step, const Tensor<int>& split_start);

void wind_focal_loss_bp_op(Tensor<float>& error,
                    const Tensor<float>& output,
                    const Tensor<float>& label,
                    float gamma);

void wind_quantize(Tensor<float>& inout, const Tensor<float>& alpha);

void wind_greedy_quantize(Tensor<float>& inout, int nbits, Tensor<float>& alpha);
void wind_fixed(Tensor<float>& inout, int); 

void wind_fixed(Tensor<float>& inout, const Tensor<float>& in, int); 

void wind_fixed_alpha(Tensor<float>& alpha, const Tensor<float>& in);

void wind_quant_conv_gemm_fwd(const ConvDesc &conv_desc,
        const Tensor<DType> &x, const Tensor<DType> &w,
        Tensor<DType> &out,
        void *work_space, size_t work_space_size_byte,
        DType alpha, DType beta, Tensor<DType> &buffer, Tensor<DType> &quant_alpha); 

//// for lr loss layer
//void wind_lr_loss_op(
//        Tensor<float>& out,
//        const Tensor<float>& in,
//        const Tensor<float>& label,
//        const Tensor<int>& mask,
//        DType alpha = 1.0f,
//        DType beta  = 0.0f);
//
//void wind_lr_bp_op(
//        Tensor<float>& out,
//        const Tensor<float>& in,
//        const Tensor<float>& label,
//        const Tensor<int>& mask,
//        DType alpha = 1.0f,
//        DType beta = 0.0f);
//
//// for mix-lr loss layer
//void wind_mix_lr_loss_op(
//        Tensor<float>& out,
//        const Tensor<float>& in,
//        const Tensor<float>& label,
//        const Tensor<int>& mask,
//        DType alpha = 1.0f,
//        DType beta  = 0.0f);
//
//void wind_mix_lr_bp_op(
//        Tensor<float>& out,
//        const Tensor<float>& in,
//        const Tensor<float>& label,
//        const Tensor<int>& mask,
//        DType alpha = 1.0f,
//        DType beta = 0.0f);
}   // namespace train
}   // namespace houyi
#endif
