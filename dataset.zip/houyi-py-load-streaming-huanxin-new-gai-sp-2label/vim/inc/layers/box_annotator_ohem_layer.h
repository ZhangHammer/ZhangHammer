//by zzxfl 2017.06.02
#ifndef HOUYI_LAYERS_BOX_ANNOTATOR_OHEM_LAYER_H
#define HOUYI_LAYERS_BOX_ANNOTATOR_OHEM_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class BoxAnnotatorOHEMLayer : public Layer {
public:
    BoxAnnotatorOHEMLayer(BoxAnnotatorOHEMConfig& config);
    BoxAnnotatorOHEMLayer(BoxAnnotatorOHEMLayer* from);
    virtual ~BoxAnnotatorOHEMLayer();

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    Layer* clone();
    virtual void inter_forward(IOPackage* in_pack) {
        CHECK2(false);
    }
    virtual void inter_bprop_diff(IOPackage* in_pack, IOPackage* out_pack) {
        CHECK2(false);
    }
    virtual void build_map(const char* prefix = NULL) {};

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    inline BoxAnnotatorOHEMConfig& config() {
        return _config;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

protected:
    void set_device() {
        _in_trans_buf.set_device(gpu_device());
        _diff_trans_buf.set_device(gpu_device());
        _in_rois.set_device(cpu_device());
        _in_loss.set_device(cpu_device());
        _in_labels.set_device(cpu_device());
        _in_bbox_loss_weights.set_device(cpu_device());
        _out_bbox_loss_weights.set_device(cpu_device());
        _out_labels.set_device(cpu_device());
    }
protected:
    BoxAnnotatorOHEMConfig _config;
    size_t _num;
    size_t _channel;
    size_t _height;
    size_t _width;
    size_t _spatial_dim;

    Tensor<DType> _in_trans_buf;
    Tensor<DType> _diff_trans_buf;
    Tensor<DType> _in_rois;
    Tensor<DType> _in_loss;
    Tensor<DType> _in_labels;
    Tensor<DType> _in_bbox_loss_weights;
    Tensor<DType> _out_labels;
    Tensor<DType> _out_bbox_loss_weights;
    DType _ignore_label;//TODO
    int _roi_per_img;//TODO
};
}
}

#endif
