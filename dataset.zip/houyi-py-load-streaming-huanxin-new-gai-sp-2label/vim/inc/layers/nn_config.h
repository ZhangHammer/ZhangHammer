/**
 * nn_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-9
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_NN_CONFIG_H
#define HOUYI_TRAIN_PLATFORM_NN_CONFIG_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "base_reader_config.h"
#include "base_processer_config.h"
#include "base_repository_config.h"
#include "layer_config.h"
#include "out_config.h"
#include "job.h"
#include "global_updater_config.h"
#include "batch_size_adjust_config.h"
#include "model_init_config.h"
#include "train_type.h"

//using namespace std;
namespace houyi {
namespace train {

class PeriodConfig {
protected:
    int        _epoch;
    int        _shrink_lr_period;
    int        _check_point;// for checkpoint
    int        _global_sync_period;
    int        _global_store_period;// for server side
    int        _model_period;// for worker side
    int        _log_period;
    int        _fixed_period;

    /* sync or async */
    TrainType _train_type;
    /* 累计几次进行更新 */
    int _local_sync_period;
public:
    PeriodConfig() {
        _epoch = 1;
        _shrink_lr_period = -1;
        _check_point = 0;
        _local_sync_period = 1;
        _global_sync_period = 0;

        _global_store_period = 5000;
        _log_period = 1000;
        _model_period = 100000;
        _fixed_period = 0;

        _train_type = TRAIN_UNKNOWN;
    }
    ~PeriodConfig() {}

    inline int local_sync_period() const {
        return _local_sync_period;
    }
    inline TrainType train_type() const {
        return _train_type;
    }

    inline int global_sync_period() const {
        return _global_sync_period;
    }

    inline int global_store_period() const {
        return _global_store_period;
    }

    inline int log_period() const {
        return _log_period;
    }
    inline int model_period() const {
        return _model_period;
    }

    inline int fixed_period() const {
        return _fixed_period;
    }

    inline int epoch() const {
        return _epoch;
    }
    inline int shrink_lr_period() const {
        return _shrink_lr_period;
    }

    inline int check_point() const {
        return _check_point;
    }

    void read(std::string& cfg_lines);
};

//todo:remove
class DiscTrainConfig {
protected:
    // for discrimination
    std::string      _kaldi_mdl_fn;
    std::string      _kaldi_fst_fn;
    std::string      _disc_config_file;
    std::string      _prior_name;
    int        _rescore_thread_num;
    int        _disc_train_thread_num;
    int        _disc_score_thread_num;

public:
    DiscTrainConfig() {
        _rescore_thread_num = 1;
        _disc_train_thread_num = 1;
        _disc_score_thread_num = 1;
    }
    ~DiscTrainConfig() {}
    inline std::string& prior_name() {
        return _prior_name;
    }
    inline int disc_train_thread_num() {
        return _disc_train_thread_num;
    }
    inline int disc_score_thread_num() {
        return _disc_score_thread_num;
    }
    inline int rescore_thread_num() {
        return _rescore_thread_num;
    }
    inline std::string& kaldi_mdl_fn() {
        return _kaldi_mdl_fn;
    }
    inline std::string& kaldi_fst_fn() {
        return _kaldi_fst_fn;
    }
    inline std::string& disc_config_name() {
        return _disc_config_file;
    }
    void read(std::string& cfg_lines);
};

class NNConfig {
protected:
    std::vector<int> _device_ids;
    bool _keep_history;
    bool _load_by_python;
    BaseReposConfig _data_cfg;
    ModelInitConfig _model_init_cfg;
    PeriodConfig _period_cfg;
    DiscTrainConfig _disc_cfg;
    GlobalUpdaterCfg _global_updater_cfg;
    BatchSizeAdjustCfg _batch_size_adjust_cfg;

    std::vector<LayerConfig*> _cfg_vec;
    std::vector<LossConfig*> _loss_cfg_vec;

    int _thread_num;
    int _batch_size;
    int _skip_num;
    JobType _job_type;
    std::string _data_cfg_file;

    /* 指定python module 的路径 */
    std::string _python_path;

    std::vector<std::string> _feature_keys;
    std::vector<std::string> _label_keys;

    std::string _python_global_cfg_file;

    bool _inq;
    std::vector<DType> _inq_ratio;
    int _inq_bit;

    DType _sample_statis_norm;
    std::string _name;
    size_t _quant_bits;
public:
    NNConfig();

    std::vector<bool> get_layer_quantize() {
        std::vector<bool> ret;
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            ret.push_back(_cfg_vec[i]->weight_quantize());
        }
        return ret;
    }

    std::vector<bool> get_weight_quant_transpose() {
        std::vector<bool> ret;
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            ret.push_back(_cfg_vec[i]->weight_quant_transpose());
        }
        return ret;
    }

    std::vector<size_t> get_weight_quant_bits() {
        std::vector<size_t> ret;
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            ret.push_back(_cfg_vec[i]->weight_quant_bits());
        }
        return ret;
    }

    std::vector<bool> get_weight_fixed_transpose() {
        std::vector<bool> ret;
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            ret.push_back(_cfg_vec[i]->weight_fixed_transpose());
        }
        return ret;
    }

    std::string get_python_input_feature_key() {
        CHECK2(_load_by_python);
        CHECK2(_cfg_vec[0]->output_keys().size() >= 1);
        CHECK2(_cfg_vec[0]->type() == PYTHON);
        PythonConfig* cfg = static_cast<PythonConfig*>(_cfg_vec[0]);
        CHECK2(cfg->get_python_layer_type() == DATA_LAYER);
        return _cfg_vec[0]->output_keys()[0];
    }
    std::string get_python_input_label_key() {
        CHECK2(_load_by_python);
        CHECK2(_cfg_vec[0]->output_keys().size() >= 2);
        CHECK2(_cfg_vec[0]->type() == PYTHON);
        PythonConfig* cfg = static_cast<PythonConfig*>(_cfg_vec[0]);
        CHECK2(cfg->get_python_layer_type() == DATA_LAYER);
        return _cfg_vec[0]->output_keys()[1];
    }

    int get_python_input_batch_size() {
        CHECK2(_load_by_python);
        CHECK2(_cfg_vec[0]->output_keys().size() >= 2);
        CHECK2(_cfg_vec[0]->type() == PYTHON);
        PythonConfig* cfg = static_cast<PythonConfig*>(_cfg_vec[0]);
        CHECK2(cfg->get_python_layer_type() == DATA_LAYER);
        return cfg->get_out_dim()[0][0];
    }

    virtual ~NNConfig();
    void read_config(const char* file);

    inline size_t quant_bits() {
        return _quant_bits;
    }

    inline bool is_load_by_python() {
        return _load_by_python;
    }

    inline std::string& data_cfg_file() {
        return _data_cfg_file;
    }

    inline ModelInitConfig& model_init_cfg() {
        return _model_init_cfg;
    }

    inline PeriodConfig& period_cfg() {
        return _period_cfg;
    }

    inline DiscTrainConfig& disc_cfg() {
        return _disc_cfg;
    }

    inline GlobalUpdaterCfg& get_global_updater_cfg() {
        return _global_updater_cfg;
    }

    inline BatchSizeAdjustCfg& get_batch_size_adjust_cfg() {
        return _batch_size_adjust_cfg;
    }

    inline BaseReposConfig& data_cfg() {
        return _data_cfg;
    }

    inline int device_id(int idx) {
        return _device_ids[idx];
    }

    inline std::vector<int>& device_ids() {
        return _device_ids;
    }

    inline int thread_num() {
        return _thread_num;
    }

    inline int batch_size() {
        return _batch_size;
    }
    inline JobType job_type() {
        return _job_type;
    }
    inline bool keep_history() {
        return _keep_history;
    }

    inline int get_batch_size() {
        return _batch_size;
    }

    inline std::vector<LayerConfig*>& layer_cfg_vec() {
        return _cfg_vec;
    }
    inline std::string& get_global_python_cfg_file() {
        return _python_global_cfg_file;
    }
    inline int skip_num() {
        return _skip_num;
    }
    inline const std::vector<LossConfig*>& loss_layer_cfg() {
        _loss_cfg_vec.clear();

        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            if (is_loss_layer(_cfg_vec[i]->type())) {
                _loss_cfg_vec.push_back(dynamic_cast<LossConfig*>(_cfg_vec[i]));
            }
        }

        return _loss_cfg_vec;
    }
    /* 通过layer name查找layer config */
    inline LayerConfig* get_layer_cfg_by_name(std::string& name) {
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            if (_cfg_vec[i]->layer_name() == name) {
                return _cfg_vec[i];
            }
        }

        return NULL;
    }
    /* 通过layer output key查找layer config */
    inline LayerConfig* get_layer_cfg_by_out_key(std::string& key) {
        for (size_t i = 0; i < _cfg_vec.size(); i++) {
            for (auto j = 0; j < _cfg_vec[i]->output_num(); j++) {
                if (_cfg_vec[i]->output_key(j) == key) {
                    return _cfg_vec[i];
                }
            }
        }

        return NULL;
    }
    inline const std::string& get_python_path() const {
        return _python_path;
    }
    void gen_feat_label_key(BaseReposConfig& cfg);
    bool is_feature_key(std::string key) {
        for (auto i : _feature_keys) {
            if (i == key) {
                return true;
            }
        }

        return false;
    }
    bool is_label_key(std::string key) {
        for (auto i : _label_keys) {
            if (i == key) {
                return true;
            }
        }

        return false;
    }
    std::vector<std::string> get_feature_keys() {
        return _feature_keys;
    }
    std::vector<std::string> get_label_keys() {
        return _label_keys;
    }

    inline bool inq() const {
        return _inq;
    }
    inline std::vector<DType> inq_ratio() const {
        return _inq_ratio;
    }
    inline int inq_bit() const {
        return _inq_bit;
    }
    inline DType get_sample_statis_norm() const {
        return _sample_statis_norm;
    }

    const std::string& get_name() {
        return _name;
    }
protected:
    void insert_splits();
};

}
} //namespace houyi
#endif
