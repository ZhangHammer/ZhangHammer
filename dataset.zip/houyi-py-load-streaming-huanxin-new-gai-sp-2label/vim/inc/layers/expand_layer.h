/**
 * expand_layer.h
 *
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2017-05-23
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_EXPAND_LAYER_H
#define HOUYI_LAYERS_EXPAND_LAYER_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {

class ExpandLayer : public Layer {
public:
    ExpandLayer(ExpandConfig& config);
    ExpandLayer(ExpandLayer* from);
    virtual ~ExpandLayer() {}

    Layer* clone();
    void build_map(const char* prefix = NULL) {}

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {}

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    inline ExpandConfig& config() {
        return _config;
    }

protected:
    void set_device() {
    }

    void init() {
    }
protected:
    ExpandConfig _config;
};

}
}

#endif
