// by zhxfl 2018.06.07
#ifndef HOUYI_TRAIN_PLATFORM_AUDIO_SPLICE_OPS_H
#define HOUYI_TRAIN_PLATFORM_AUDIO_SPLICE_OPS_H
#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_splice(Tensor<DType>& in, 
        Tensor<DType>& out, 
        Tensor<int>& seq_len, 
        int sample_num, int splice, 
        bool clear_delta);

}// namespace train
}// namespace houyi
#endif
