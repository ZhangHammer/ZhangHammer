/**
 * image_conv_layer.h
 *
 * Author: lifeng(lifeng20@lifeng.com)
 * Created on: 2016-07-21
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_IMAGE_CONV_LAYER_H
#define HOUYI_TRAIN_PLATFORM_IMAGE_CONV_LAYER_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class ImageConvLayer : public Layer {
public:
    ImageConvLayer(ImageConvConfig& config);
    ImageConvLayer(ImageConvLayer* from);

    ~ImageConvLayer() {
        _free();
    }

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    void build_map(const char* prefix = NULL);
    Layer* clone();

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_heter_model(std::ifstream& input);
    void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

    inline size_t get_output_maps() {
        return _output_maps;
    }
    inline size_t get_filter_height() {
        return _filter_height;
    }
    inline size_t get_filter_width() {
        return _filter_width;
    }
    inline size_t get_stride_height() {
        return _stride_height;
    }
    inline size_t get_stride_width() {
        return _stride_width;
    }
    inline size_t get_padding_height() {
        return _padding_height;
    }
    inline size_t get_padding_width() {
        return _padding_width;
    }
    inline size_t get_dilation_height() {
        return _dilation_height;
    }
    inline size_t get_dilation_width() {
        return _dilation_width;
    }
    ImageConvConfig& config() {
        return _config;
    }
    DenseWeight& w() {
        return _w;
    }
    DenseWeight& w_t() {
        return _w_t;
    }
    DenseWeight& bias() {
        return _bias;
    }
    DenseWeight& bias_t() {
        return _bias_t;
    }
    bool skip_label() {
        return _skip_label;
    }
    Tensor<int>& mask() {
        return _mask;
    }
    bool cal_mask() {
        return _cal_mask;
    }
    ConvDesc& conv_desc() {
        return _conv_desc;
    }

protected:
    void init(ImageConvConfig& conf);
    void init() {
        _type = IMAGE_CONV;
        _conv_algo_type = CONV_ALGO_AUTO;
        _conv_grad_algo_type = CONV_GRAD_ALGO_AUTO;
        _conv_diff_algo_type = CONV_DIFF_ALGO_AUTO;
        _conv_work_space_size_byte = 0;
        _conv_grad_work_space_size_byte = 0;
        _conv_diff_work_space_size_byte = 0;
        _output_maps = 0;
        _filter_height = 0;
        _filter_width = 0;
        _stride_height = 0;
        _stride_width = 0;
        _padding_height = 0;
        _padding_width = 0;
    }

    void _free() { }

private:
    ImageConvConfig _config;
    ConvDesc _conv_desc;
    ImageConvAlgoSeekerType _algo_seeker_type;

    Dim _pre_input_dim;
    bool _algo_inited;
    bool _grad_algo_inited;
    bool _diff_algo_inited;

    //倦积使用的算法
    ConvAlgo _conv_algo_type;
    //求梯度使用的算法
    ConvGradAlgo _conv_grad_algo_type;
    //求參差使用的算法
    ConvDiffAlgo _conv_diff_algo_type;

    //调用cudnn使用
    size_t _conv_work_space_size_byte;
    size_t _conv_grad_work_space_size_byte;
    size_t _conv_diff_work_space_size_byte;

    size_t _output_maps;
    size_t _filter_height;
    size_t _filter_width;
    size_t _stride_height;
    size_t _stride_width;
    size_t _padding_height;
    size_t _padding_width;

    size_t _dilation_height;
    size_t _dilation_width;

    DenseWeight _w;
    DenseWeight _d_w;

    DenseWeight _bias;
    DenseWeight _d_bias;

    /*  for inq */
    DenseWeight _w_t;
    DenseWeight _bias_t;
    bool _cal_mask = false;
    bool _skip_label = false;
    Tensor<int> _mask;
};

}
}
#endif
