/**
 * file: smooth_l1_loss_layer.h
 *
 * author: lifeng(lifeng20@baidu.com)
 * created: 2016年12月03日 00时37分44秒
 *
 * copyright: Copyright (c) 2016, baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_SMOOTH_L1_LOSS_LAYER_H
#define HOUYI_LAYERS_SMOOTH_L1_LOSS_LAYER_H

#include "wind/wind.h"
#include "argument.h"
#include "loss_layer.h"
#include "out_config.h"

namespace houyi {
namespace train {

class SmoothL1LossLayer : public LossLayer {
public:
    SmoothL1LossLayer(LossConfig& cfg) : LossLayer(cfg) {
        _sigma_square = cfg.get_sigma() * cfg.get_sigma();
        _lambda = cfg.get_lambda();
        _cost_buf.set_device(gpu_device());
        _w_in_b0_b1.set_device(gpu_device());
        _err.set_device(gpu_device());
        _has_weight = false;

        _loss_buf.resize(2);

        for (int i = 0; i < 2; i++) {
            if (_bp_down[i]) {
                _loss_buf[i].set_device(GPU);
            }
        }

    }
    ~SmoothL1LossLayer() {}

    void cal_target(std::vector<IOPackage*>& output,
                    std::vector<IOPackage*>& label,
                    std::vector<IOPackage*>& target);

    void cal_loss(std::vector<IOPackage*>& output,
                  std::vector<IOPackage*>& label,
                  std::vector<IOPackage*>& loss);

    Loss& get_cost_value(TGT_COST_TYPE type);
    Layer* clone() {
        return new SmoothL1LossLayer(_cfg);
    }
    float get_sigma() {
        return sqrt(_sigma_square);
    }
protected:
    Tensor<DType> _cost_buf;
    DType _sigma_square;
    DType _lambda;

    Tensor<DType> _w_in_b0_b1;
    Tensor<DType> _err;

    std::vector<Tensor<DType>> _loss_buf;
    bool _has_weight;
};

} //namespace train
}

#endif
