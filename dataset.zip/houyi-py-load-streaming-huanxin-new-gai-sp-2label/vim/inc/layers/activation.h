/**
 * activation.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_ACTIVATION_H
#define HOUYI_TRAIN_PLATFORM_ACTIVATION_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <limits>
#include <sys/time.h>
#include "glog/logging.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "out_config.h"

namespace houyi {
namespace train {

class Activation {
public:
    virtual ~Activation() {}
    static Activation* create(ActiveType type, int pooling_size = 0);
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out) {};
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff) {};

    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out, int t, int sample_num) {};
    virtual void backward(const Tensor<DType>& inDiff,
                          const Tensor<DType>& out, Tensor<DType>& outDiff,
                          int t, int sample_num, DType alpha, DType beta) {};
    virtual void backward(const Tensor<DType>& inDiff,
                          const Tensor<DType>& out, Tensor<DType>& outDiff,
                          int sample_num, DType alpha, DType beta) {};
};

class MaxOutActivation : public Activation {
public:
    MaxOutActivation(int pooling_size) {
        _pooling_size = pooling_size;
        _idx_mat.clear();
    };
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out, int t, int sample_num);
    virtual void backward(const Tensor<DType>& in_diff, const Tensor<DType>& out,
                          Tensor<DType>& out_diff,
                          int t, int sample_num, DType alpha, DType beta);
    //virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out, Tensor<DType>& outDiff,
    //        int sample_num);
private:
    std::vector<Tensor<int>> _idx_mat;
    int _pooling_size;
};

class LinearActivation : public Activation {
public:
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out);
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff);
};

class SigmoidActivation : public Activation {
public:
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out);
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff);
};

class TanhActivation : public Activation {
public:
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out);
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff);
};

class ReluActivation : public Activation {
public:
    Tensor<DType> _pnorm;
    ReluActivation() {
        _pnorm.set_device(cpu_device());
    }
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out);
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff);
};

class LogReluActivation : public Activation {
public:
    Tensor<DType> _relu_out, _rep, _relu_diff;

    LogReluActivation() {
        _relu_out.set_device(gpu_device());
        _rep.set_device(gpu_device());
        _relu_diff.set_device(gpu_device());
    }
    virtual void forward(const Tensor<DType>& in, Tensor<DType>& out);
    virtual void backward(const Tensor<DType>& inDiff, const Tensor<DType>& out,
                          Tensor<DType>& outDiff);
};

} //namespace train
}
#endif
