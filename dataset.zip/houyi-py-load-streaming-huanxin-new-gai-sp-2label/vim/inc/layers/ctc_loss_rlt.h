/**
 * ctc_loss_layer.h
 * Author: baijinfeng (baijinfeng@conew.com)
 * Created on: 2016-08-01
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef APP_SEARCH_AUDIO_DNNRESEARCH_LSTM_CTC_LOSS_RLT_H
#define APP_SEARCH_AUDIO_DNNRESEARCH_LSTM_CTC_LOSS_RLT_H
#include <pthread.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <limits>
#include <sys/time.h>
#include "activation.h"

namespace houyi {
namespace train {

class Item {
public:
    int    _idx;
    int    _value;

    void print() {
        std::cout << _idx << "\t" << _value << "\t";
    }
};

enum MatchType {
    MATCH,
    INS,
    DEL,
    SUB
};

typedef std::pair<Item, Item> ItemPair;
std::vector<ItemPair> lcs_valueing(std::vector<int>& fc1, std::vector<int>& fc2);

} //namespace houyi
} //namespace train
#endif
