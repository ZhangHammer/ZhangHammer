#ifndef HOUYI_LAYERS_MIX_LR_OP_H
#define HOUYI_LAYERS_MIX_LR_OP_H
#include <wind/wind.h>

namespace houyi {
namespace train {

// for lr loss layer
void wind_lr_loss_op(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType alpha = 1.0f,
        DType beta  = 0.0f);

void wind_lr_bp_op(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType alpha = 1.0f,
        DType beta = 0.0f);

// for mix-lr loss layer
void wind_mix_lr_loss_op(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType alpha = 1.0f,
        DType beta  = 0.0f);

void wind_mix_lr_bp_op(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType alpha = 1.0f,
        DType beta = 0.0f);

// 所有mask
void wind_mix_lr_one_sigmoid_loss(
    Tensor<float>& input,
    Tensor<float>& label,
    Tensor<int>& mask,
    Tensor<float>& value1,
    Tensor<float>& value2,
    Tensor<float>& value3,
    Tensor<float>& value4,
    Tensor<int>& count1,
    Tensor<int>& count2);

//void wind_mix_lr_one_sigmoid_loss(
//    Tensor<float>& input,
//    Tensor<int>& label);
//
//void wind_mix_lr_one_sigmoid_loss(
//    Tensor<float>& input,
//    Tensor<int>& label);
//
//void wind_mix_lr_one_sigmoid_loss(
//    Tensor<float>& input,
//    Tensor<int>& label);
}   // namespace train
}   // namespace houyi
#endif
