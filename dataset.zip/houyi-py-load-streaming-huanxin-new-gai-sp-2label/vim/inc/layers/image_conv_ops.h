#ifndef HOUYI_LAYERS_IMAGE_CONV_OPS_H
#define HOUYI_LAYERS_IMAGE_CONV_OPS_H
#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_image_conv_cal_mask(Tensor<DType>& out, 
        Tensor<int>& to_mask, 
        Tensor<int>& from_mask,
        int kernel_height,
        int padding_height,
        int stride_height);

void wind_image_conv_skip_label(Tensor<DType>& in, 
        Tensor<DType>& out,
        int kernel_height,
        int padding_height,
        int stride_height, 
        int batch_size);

}// namespace train
}// namespace houyi
#endif
