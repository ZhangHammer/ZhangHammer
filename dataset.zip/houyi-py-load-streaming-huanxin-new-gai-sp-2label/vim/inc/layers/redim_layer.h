//by zhxfl 2017.11.03
#ifndef HOUYI_LAYERS_REDIM_LAYER_H
#define HOUYI_LAYERS_REDIM_LAYER_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {

class RedimLayer : public Layer {
public:
    RedimLayer(RedimConfig& config);
    RedimLayer(RedimLayer* from);
    virtual ~RedimLayer() {}

    Layer* clone();
    void build_map(const char* prefix = NULL) {}

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

    inline RedimConfig& config() {
        return _config;
    }

protected:
    void set_device() {
    }

    void init() {
    }
protected:
    RedimConfig _config;
};

}
}

#endif
