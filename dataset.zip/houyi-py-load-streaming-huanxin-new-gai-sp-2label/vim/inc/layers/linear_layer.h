/**
 * linear_layer.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-30
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_TRAIN_PLATFORM_LINEAR_LAYER_H
#define HOUYI_TRAIN_PLATFORM_LINEAR_LAYER_H

#include "layer.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
class LinearLayer : public Layer {
protected:
    float* _scalars;

    Tensor<DType> _pool_vec;
    Tensor<unsigned long> _address;
    OPERATOR_TYPE _op;
public:
    LinearLayer(LinearConfig& cfg);
    LinearLayer(LinearLayer* from);
    ~LinearLayer() {
        if (_scalars) {
            free(_scalars);
            _scalars = NULL;
        }
    }

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    void set_device() {
        _pool_vec.set_device(gpu_device());
    }
    inline float* scalars() {
        return _scalars;
    }
    inline OPERATOR_TYPE op() {
        return _op;
    }
    virtual Layer* clone() {
        return new LinearLayer(this);
    }

    virtual void build_map(const char* prefix = NULL) {
        _w_map.clear();
        _dw_map.clear();
    }
    virtual void inter_forward(std::vector<IOPackage*>& in_pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {}

    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    void add(std::vector<IOPackage*>& src, Tensor<DType>* dst);
    void add_derivative(std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst);

    void channel_append(std::vector<IOPackage*>& src, Tensor<DType>* dst);
    void channel_append_derivative(std::vector<IOPackage*>& src, 
                std::vector<IOPackage*>& dst);

    void col_append(std::vector<IOPackage*>& src, Tensor<DType>* dst);
    void col_append_derivative(std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst);
private:
    template<typename T>
        void alternate_merge_tensor(Tensor<T>&dst, Tensor<T>&src1, Tensor<T>&src2);
    template<typename T>
        void alternate_split_tensor(Tensor<T>&src, Tensor<T>&dst1, Tensor<T>&dst2);

    void row_alternate_append(std::vector<IOPackage*>& src, std::vector<IOPackage*>& dst);
    void row_alternate_append_derivative(std::vector<IOPackage*>& src, 
            std::vector<IOPackage*>& dst);
};
}
}
#endif

