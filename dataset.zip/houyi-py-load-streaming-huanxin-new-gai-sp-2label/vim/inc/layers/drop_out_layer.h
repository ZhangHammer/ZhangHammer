/**
 * drop_out.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-30
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_DROP_OUT_LAYER_H
#define HOUYI_TRAIN_PLATFORM_DROP_OUT_LAYER_H
#include <vector>
#include <iostream>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class DropOutLayer : public Layer {
public:
    DropOutLayer(DropOutConfig& config);
    DropOutLayer(DropOutLayer* from);
    virtual ~DropOutLayer();

    Layer* clone();
    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void build_map(const char* prefix = NULL) {}

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {}

    inline DropOutConfig& config() {
        return _config;
    }

    inline bool get_scale_train() {
        return _scale_train;
    }
    inline void set_scale_train(bool scale_train) {
        _scale_train = scale_train;
    }
    inline DType drop_rate() {
        return _drop_rate;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

protected:
    void set_device() {
        _input_mask.set_device(gpu_device());
    }
protected:
    DropOutConfig _config;

    //drop rate
    DType _drop_rate;
    bool   _scale_train;
    Tensor<DType> _input_mask;
};

}
}
#endif
