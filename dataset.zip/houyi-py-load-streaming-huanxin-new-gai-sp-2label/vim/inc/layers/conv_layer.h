/**
 * conv_layer.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-09-9
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_CONV_LAYER_H
#define HOUYI_TRAIN_PLATFORM_CONV_LAYER_H

#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class ConvLayer : public Layer {
public:
    ConvLayer(ConvConfig& config);
    ConvLayer(ConvLayer* from);

    ~ConvLayer();

    void build_map(const char* prefix = NULL);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    Layer* clone();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_heter_model(std::ifstream& input);
    void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

    inline ConvConfig& config() {
        return _config;
    }
    inline DenseWeight* d_bias(int idx) {
        return &_d_bias_vec[idx];
    }
    inline DenseWeight* dw() {
        return &_dw;
    }
    inline DenseWeight* bias(int idx) {
        return &_bias_vec[idx];
    }
    inline DenseWeight* bias_t(int idx) {
        return &_bias_vec_t[idx];
    }
    inline DenseWeight* w() {
        return &_w;
    }
    inline DenseWeight* w_t() {
        return &_w_t;
    }
protected:
    void input_error_bp(Tensor<DType>& inputError);
    void set_device() {
        _conv_start_pos.set_device(gpu_device());
        _conv_end_pos.set_device(gpu_device());
        _conv_size.set_device(gpu_device());
        _pooling_pivot.set_device(gpu_device());
        _idx.set_device(gpu_device());

        _out.set_device(gpu_device());
        _out_conv.set_device(gpu_device());
        _x.set_device(gpu_device());
        _e.set_device(gpu_device());
        _dx.set_device(gpu_device());
    }

protected:
    int _group_num, _filter_size, _filter_num;
    int _fbank_dim, _temporal_dim, _conv_out_dim, _delta;
    ConvConfig _config;

    Tensor<int> _conv_start_pos, _conv_end_pos, _conv_size;

    int _pooling_size, _pooling_out_dim;
    Tensor<int> _pooling_pivot;

    DenseWeight _w, _dw;
    std::vector<DenseWeight> _bias_vec, _d_bias_vec;

    /* for INQ */
    DenseWeight _w_t;
    std::vector<DenseWeight> _bias_vec_t;

    Tensor<DType>_out, _out_conv, _x, _dx, _e;
    Tensor<int> _idx;

    /* 但前batch的总帧数，由resize_out设置 */
    int _frame_num;
};
}
}
#endif
