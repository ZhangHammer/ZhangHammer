/**
 * model_init_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-04-28
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_MODEL_INIT_CONFIG_H
#define HOUYI_LAYERS_MODEL_INIT_CONFIG_H

#include "wind/wind.h"

//using namespace std;
namespace houyi {
namespace train {

enum ModelInitType {
    GAUSS_INIT,
    CONSTANT_INIT,
    MODEL_INIT,
    UNIFORM_INIT,
    MSRA_INIT,
    XAVIER_INIT,
    MODEL_INIT_TYPE_UNKNOWN
};

enum MSRAType {
    IN_MSRA_TYPE,
    OUT_MSRA_TYPE,
    AVG_MSRA_TYPE,
    MSRA_TYPE_UNKNOWN
};

enum XavierType {
    IN_XAVIER_TYPE,
    OUT_XAVIER_TYPE,
    AVG_XAVIER_TYPE,
    XAVIER_TYPE_UNKNOWN
};

class ModelInitConfig {
protected:
    std::string _model_name;
    std::string _model_cfg;
    std::string _md_model_name;
    std::string _inq_model_name;
    int _model_start;
    int _model_end;

    DType _init_mean;
    DType _init_stdv;

    std::string _heter_name;
    int _heter_start;
    int _heter_end;

    std::string _hfnn_name;
    int _hfnn_start;
    int _hfnn_end;

    /************************ for weight filler **********************/
    ModelInitType _weight_init_type;

    DType _weight_mean;
    DType _weight_stdv;

    DType _weight_value;

    std::string _weight_name;

    DType _weight_max;
    DType _weight_min;

    MSRAType _weight_msra_type;
    XavierType _weight_xavier_type;
    /***************************** end *******************************/

    /************************ for bias filler **********************/
    ModelInitType _bias_init_type;

    DType _bias_mean;
    DType _bias_stdv;

    DType _bias_value;

    std::string _bias_name;

    DType _bias_max;
    DType _bias_min;

    MSRAType _bias_msra_type;
    XavierType _bias_xavier_type;
    /***************************** end *******************************/

public:
    ModelInitConfig() {
        _model_start = 0;
        _model_end = -1;
        _heter_start = 0;
        _heter_end = -1;
        _init_mean = 0.0;
        _init_stdv = 0.02;
        _hfnn_start = 0;
        _hfnn_end = -1;

        _weight_init_type = MODEL_INIT_TYPE_UNKNOWN;
        _weight_mean = 0.0;
        _weight_stdv = 0.02;
        _weight_value = 0;
        _weight_max = 0;
        _weight_min = 0;
        _weight_msra_type = IN_MSRA_TYPE;
        _weight_xavier_type = IN_XAVIER_TYPE;

        _bias_init_type = MODEL_INIT_TYPE_UNKNOWN;
        _bias_mean = 0.0;
        _bias_stdv = 0.02;
        _bias_value = 0;
        _bias_max = 0;
        _bias_min = 0;
        _bias_msra_type = IN_MSRA_TYPE;
        _bias_xavier_type = IN_XAVIER_TYPE;
    }
    ~ModelInitConfig() {}
    inline const std::string& model_name() const {
        return _model_name;
    }
    inline const std::string& model_cfg() const {
        return _model_cfg;
    }
    inline const std::string& md_model_name() const {
        return _md_model_name;
    }
    inline const std::string& inq_model_name() const {
        return _inq_model_name;
    }
    inline int model_end() const {
        return _model_end;
    }
    inline int model_start() const {
        return _model_start;
    }
    inline const std::string& heter_name() const {
        return _heter_name;
    }
    inline int heter_end() const {
        return _heter_end;
    }
    inline int heter_start() const {
        return _heter_start;
    }
    inline const std::string& hfnn_name() const {
        return _hfnn_name;
    }
    inline int hfnn_end() const {
        return _hfnn_end;
    }
    inline int hfnn_start() const {
        return _hfnn_start;
    }
    inline DType init_mean() const {
        return _init_mean;
    }
    inline DType init_stdv() const {
        return _init_stdv;
    }

    inline void clear_mean_stdv() {
        _init_mean = -1;
        _init_stdv = -1;
    }

    inline const ModelInitType& weight_init_type() const {
        return _weight_init_type;
    }
    inline void set_weight_init_type(ModelInitType& type) {
        _weight_init_type = type;
    }
    inline DType weight_mean() const {
        return _weight_mean;
    }
    inline DType weight_stdv() const {
        return _weight_stdv;
    }
    inline DType weight_value() const {
        return _weight_value;
    }
    inline std::string weight_name() const {
        return _weight_name;
    }
    inline DType weight_max() const {
        return _weight_max;
    }
    inline DType weight_min() const {
        return _weight_min;
    }
    inline MSRAType weight_msra_type() const {
        return _weight_msra_type;
    }
    inline XavierType weight_xavier_type() const {
        return _weight_xavier_type;
    }

    inline const ModelInitType& bias_init_type() const {
        return _bias_init_type;
    }
    inline void set_bias_init_type(ModelInitType& type) {
        _bias_init_type = type;
    }
    inline DType bias_mean() const {
        return _bias_mean;
    }
    inline DType bias_stdv() const {
        return _bias_stdv;
    }
    inline DType bias_value() const {
        return _bias_value;
    }
    inline std::string bias_name() const {
        return _bias_name;
    }
    inline DType bias_max() const {
        return _bias_max;
    }
    inline DType bias_min() const {
        return _bias_min;
    }
    inline MSRAType bias_msra_type() const {
        return _bias_msra_type;
    }
    inline XavierType bias_xavier_type() const {
        return _bias_xavier_type;
    }

    void read(std::string& cfg_lines);
};

}
} //namespace houyi

#endif
