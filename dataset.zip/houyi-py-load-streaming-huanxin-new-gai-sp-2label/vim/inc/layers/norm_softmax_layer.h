/**
 * norm_softmax_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-28
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_LAYERS_NORM_SOFTMAX_LAYER_H
#define HOUYI_LAYERS_NORM_SOFTMAX_LAYER_H

#include <vector>
#include <new>
#include "wind/wind.h"
#include "argument.h"
#include "layer.h"
#include "out_config.h"

namespace houyi {
namespace train {

class NormSoftmaxLayer : public Layer {
public:
    NormSoftmaxLayer(NormSoftmaxConfig& cfg) : Layer(cfg) {
        _type = cfg.type();
        _cfg = cfg;
        _sft_row_sum.set_device(gpu_device());
        _buf.set_device(gpu_device());
        _start_axis = cfg.get_start_axis();
        _end_axis = cfg.get_end_axis();
    }

    NormSoftmaxLayer(NormSoftmaxLayer* from) : Layer(from) {
        new(this) NormSoftmaxLayer(from->config());
        layer_set(from->get_input(), from->get_sample_num());
    }

    inline NormSoftmaxConfig& config() {
        return _cfg;
    }

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    virtual Layer* clone() {
        return new NormSoftmaxLayer(this);
    }

    virtual void build_map(const char* prefix = NULL) {
        _w_map.clear();
        _dw_map.clear();
    }
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

protected:
    Tensor<DType> _sft_row_sum;
    Tensor<DType> _buf;
    NormSoftmaxConfig _cfg;

    int _start_axis;
    int _end_axis;
};

} //namespace train
}

#endif
