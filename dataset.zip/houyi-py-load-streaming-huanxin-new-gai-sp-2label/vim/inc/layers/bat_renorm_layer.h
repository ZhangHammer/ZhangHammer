/**
 * Bat_renormal_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-06-06
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_BAT_RENORM_LAYER_H
#define HOUYI_LAYERS_BAT_RENORM_LAYER_H

#include "wind/wind.h"
#include "weight.h"
#include "layer_config.h"
#include "layer.h"
#include "argument.h"

namespace houyi {
namespace train {

class BatRenormalLayer: public Layer {
public:
    BatRenormalLayer(BatRenormConfig& config);
    BatRenormalLayer(BatRenormalLayer* from);
    virtual ~BatRenormalLayer();
    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    void gauss_init(DType mean, DType stdv);
    void init_weight(const ModelInitConfig& global_cfg);
    void init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers);

    void read_initial_mean_var();
    void read_initial_mean_var(std::string bn_file_prefix);

    void build_map(const char* prefix = NULL);

    Layer* clone() {
        return new BatRenormalLayer(this);
    }

    std::string& global_file_name() {
        return _global_mean_var;
    }
    Tensor<DType>& mean_vec() {
        return _mean_vec;
    }
    Tensor<DType>& var_vec() {
        return _var_vec;
    }
    DenseWeight& gamma() {
        return _gamma;
    }
    DenseWeight& beta() {
        return _beta;
    }
    BatRenormConfig& config() {
        return _config;
    }
    DType r_max() {
        return _r_max;
    }
    DType d_max() {
        return _d_max;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void store_bn();
protected:
    void set_device(void) {
        _x_sharp_o.set_device(gpu_device());
        _x_bias.set_device(gpu_device());
        _acc_x_bias.set_device(gpu_device());
        _real_in.set_device(gpu_device());
        _buf_e.set_device(gpu_device());
        _mean_vec.set_device(gpu_device());
        _d_mean_vec.set_device(gpu_device());
        _var_vec.set_device(gpu_device());
        _var_reciprocal_vec.set_device(gpu_device());
        _d_var_vec.set_device(gpu_device());
        _statis_mean_vec.set_device(gpu_device());
        _statis_var_vec.set_device(gpu_device());
        _label_host.set_device(CPU);
    }

    void read_initial_mean_var_inf(const char* file_name);
    void read_initial_mean_var_train(const char* file_name);
    void inter_forward_inf(std::vector<IOPackage*>& in_pack);
    void inter_forward_train(std::vector<IOPackage*>& in_pack);

    int get_real_frame_num(IOPackage* in_pack);

protected:
    std::string _global_mean_var; // initial meanVec and varVec
    DType _epsilon;
    DType _deta;
    BatRenormConfig _config;

    DenseWeight  _gamma, _d_gamma;
    DenseWeight  _beta, _d_beta;

    Tensor<DType> _x_sharp_o;
    Tensor<DType> _x_bias;
    Tensor<DType> _acc_x_bias;
    Tensor<DType> _real_in;
    Tensor<DType> _buf_e;

    Tensor<DType> _mean_vec, _d_mean_vec;
    Tensor<DType> _var_vec, _d_var_vec;
    Tensor<DType> _var_reciprocal_vec;

    Tensor<DType> _statis_mean_vec;
    Tensor<DType> _statis_var_vec;

    Tensor<DType> _r;
    Tensor<DType> _d;
    DType _r_max;
    DType _d_max;

    int _real_frame_num;
    Tensor<DType> _label_host;
    Tensor<int> _label_mask;

    size_t _store_item;
    int _frame_dim;
};

}
}

#endif
