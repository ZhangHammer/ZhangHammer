//by zhxfl 2017.11.30
#ifndef HOUYI_TRAIN_PLATFORM_FAST_GRU_LAYER_H
#define HOUYI_TRAIN_PLATFORM_FAST_GRU_LAYER_H

#include <vector>
#include <iostream>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "gru_ops.h"
#include "cec.h"

namespace houyi {
namespace train {

class FastGruLayer : public Layer {
protected:
    FastGruConfig _config;

    Activation *_reset_act, *_update_act, *_state_act;
    
    // _w(input_dim, output_dim * 3): _w_reset, _w_update, _w_state
    DenseWeight _w, _dw;

    // _bias(1, output_dim * 3): _bias_reset, _bias_update, _bias_state
    DenseWeight _bias, _dbias;

    // _u(output_dim , output_dim * 3) : _u_reset, _u_update, _u_state
    DenseWeight _u, _du;
    
    // _w_x_bias(frame_num, output_dim * 3) : x(frame_num, intput_dim) * _w + _bias 
    Tensor<DType> _w_x_bias;
    
    // _u_h_t_1(sample_num, output_dim * 3) : h(t-1)(sample_num, output_dim) * _u(output_dim, output_dim * 3)
    Tensor<DType> _u_h_t_1;
    
    // _out(frame_num * 3, output_dim) : (frame_num * 3, output_dim)
    // merge (reset_gate, update_gate, _quasi_state)
    Tensor<DType> _out;
    // _out_error(frame_num , output_dim * 3)
    // merge (reset_gate, update_gate, _quasi_state)
    Tensor<DType> _out_error;

    std::vector<DType> _final_mean;
    std::vector<DType> _final_stdv;
    std::vector<DType> _mean;
    std::vector<DType> _stdv;

    int _mean_counter;
    int _mean_batch_number;
    float _threshold;
    float _threshold_ratio;

    // Buffer
    StateMatrix _hidden_state;
    StateMatrix _partial_hidden;

    Tensor<DType> _back_error;
    Tensor<DType> _back_error_tmp;
    int _sub_seq_size;
    size_t _input_dim;
    size_t _output_dim;
    int _tbptt;
    int _updatett;
    int _skip_num;

    //Reverse
    Tensor<int> _seq_len;
    Tensor<DType> _reverse;
    Tensor<DType> _reverse_out;
    Tensor<DType> _reverse_in_diff;
    Tensor<DType> _reverse_pre_diff;

public:
    FastGruLayer(FastGruConfig& conf);
    FastGruLayer(FastGruLayer* from);
    ~FastGruLayer();
    void set_device();

    void gauss_init_weight(DType mean, DType stdv);
    virtual void build_map(const char* prefix = NULL);

    void inter_forward(std::vector<IOPackage*>& in_pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    virtual Layer* clone();

    void cal_time_gradient();
    void time_backward(
        const Tensor<DType>& in_feat, const Tensor<DType>& in_diff, Tensor<DType>& out_diff);
    //void input_error_backprop(Tensor<DType>& outError);
    void linear_gradient(const Tensor<DType>& x);
    void clear_gradient();
    bool clip_gradient();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_tensor(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void store_history();
    virtual void clear_history();
    virtual void clear_history(int idx);

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void set_next_start();

    inline FastGruConfig& config() {
        return _config;
    }
    bool check_dw_norm(Tensor<DType>&dw, DType &norm, DType final_mean,
            DType final_stdv, const char* dw_name);

    void input_error_backprop(Tensor<DType>& out_error);
public:
    enum WType {W_RESET, W_UPDATE, W_STATE};

#define GET_W_COL(weight, type, output_dim) \
    switch (type) { \
        case W_RESET: \
            return weight->range_col(0, 1, output_dim); \
        case W_UPDATE: \
            return weight->range_col(1, 2, output_dim);\
        case W_STATE:\
            return weight->range_col(2, 3, output_dim);\
        default:\
            CHECK2(false);\
    } \
    return Tensor<DType>(Dim(1));

#define GET_W_ROW(weight, type, output_dim) \
    switch (type) { \
        case W_RESET: \
            return weight->range_row(0, 1, output_dim); \
        case W_UPDATE: \
            return weight->range_row(1, 2, output_dim);\
        case W_STATE:\
            return weight->range_row(2, 3, output_dim);\
        default:\
            CHECK2(false);\
    } \
    return Tensor<DType>(Dim(1));

    inline Tensor<DType> get_w(WType type) {
        GET_W_COL(_w.w(), type, _output_dim);
    }

    inline Tensor<DType> get_bias(WType type) {
        GET_W_COL(_bias.w(), type, _output_dim);
    }

    inline Tensor<DType> get_u(WType type) {
        GET_W_COL(_u.w(), type, _output_dim);
    }

    inline Tensor<DType> get_dw(WType type) {
        GET_W_COL(_dw.w(), type, _output_dim);
    }

    inline Tensor<DType> get_dbias(WType type) {
        GET_W_COL(_dbias.w(), type, _output_dim);
    }

    inline Tensor<DType> get_du(WType type) {
        GET_W_COL(_du.w(), type, _output_dim);
    }

    inline Tensor<DType> get_w_x_bias(WType type) {
        GET_W_COL((&_w_x_bias), type, _output_dim);
    }

    inline Tensor<DType> get_u_h_t_1(WType type) {
        GET_W_COL((&_u_h_t_1), type, _output_dim);
    }

    inline Tensor<DType> get_out(WType type) {
        GET_W_ROW((&_out), type, _sample_num* _sub_seq_size);
    }

    inline Tensor<DType> get_out_error(WType type) {
        GET_W_COL((&_out_error), type, _output_dim);
    }
};
}
}
#endif
