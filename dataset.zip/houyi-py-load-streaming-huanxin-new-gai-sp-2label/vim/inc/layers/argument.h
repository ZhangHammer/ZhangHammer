/**
 * argument.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-25
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_ARGUMENT_H
#define HOUYI_TRAIN_PLATFORM_ARGUMENT_H
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <map>
#include "util.h"
#include "wind/wind.h"
#include "activation.h"
#include "layer_config.h"
#include "weight.h"
#include "updater.h"
#include "base_batch_desc.h"
#include "io_package.h"


namespace houyi {
namespace train {

class Argument {
public:
    Argument() {
        _pack_map.clear();
        _feat_desc = NULL;
    }
    ~Argument() {

        IOPackage* prior = NULL;
        PacksMap::iterator itr = _pack_map.find("prior");

        if (itr != _pack_map.end()) {
            prior = itr->second;
        }

        if (prior) {
            delete prior;
            prior = NULL;
        }

        //PacksMap::iterator it;
        //for(it = _pack_map.begin(); it != _pack_map.end(); it++) {
        //    if (it->second != NULL) delete it->second;
        //}
        _pack_map.clear();
    }
    
    void reset() {
        _pack_map.clear();
    }

    void insert(std::string key, IOPackage* pack) {
        if (_pack_map.find(key) != _pack_map.end()) {
            _pack_map[key] = pack;
        } else {
            _pack_map.insert(PacksMap::value_type(key, pack));
        }
    }

    void append_train_data(Argument& args2);
    void remove_train_data(Argument& args2);
    void insert_train_pack(std::vector<std::string>& feat_key, std::vector<IOPackage*>& feat,
                           std::vector<std::string>& label_key, std::vector<IOPackage*>& label,
                           BaseBatchDesc& feat_desc) {
        for (size_t i = 0; i < feat.size(); i++) {
            insert(feat_key[i], feat[i]);
        }

        _feat_key = feat_key;

        for (size_t i = 0; i < label.size(); i++) {
            insert(label_key[i], label[i]);
        }

        _label_key = label_key;

        _feat_desc = &feat_desc;
    }
    void insert_prior(Tensor<DType>* prior);
    Tensor<DType>* get_prior();
    IOPackage* get_pack(std::string key);
    BaseBatchDesc* get_feat_desc();

    inline PacksMap& pack_map() {
        return _pack_map;
    }

    inline int get_sample_num() {
        return _sample_num;
    }

    inline void set_sample_num(int sample_num) {
        _sample_num = sample_num;
    }

    inline std::vector<std::string>& feat_key() {
        return _feat_key;
    }

    inline std::vector<std::string>& label_key() {
        return _label_key;
    }

    inline void set_feat_key(std::vector<std::string>& feat_key) {
        _feat_key = feat_key;
    }

    inline void set_label_key(std::vector<std::string>& label_key) {
        _label_key = label_key;
    }

    inline std::vector<std::string>& get_feat_desc_key() {
        return _feat_desc_key;
    }

    inline size_t size() {
        return _pack_map.size();
    }

    inline bool is_feat_key(std::string& key) {
        for (size_t i = 0; i < _feat_key.size(); i++) {
            if (key == _feat_key[i]) {
                return true;
            }
        }

        return false;
    }
protected:
    std::vector<std::string> _feat_key;
    std::vector<std::string> _feat_desc_key;
    std::vector<std::string> _label_key;

    PacksMap _pack_map;
    /* 析构时不需要释放 */
    BaseBatchDesc* _feat_desc;

    int _sample_num;
};

}
} //namespace houyi
#endif
