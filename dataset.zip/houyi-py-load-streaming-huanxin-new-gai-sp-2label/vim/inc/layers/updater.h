/**
 * updater.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-19
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef IM_TRAIN_PLATFORM_UPDATER_H
#define IM_TRAIN_PLATFORM_UPDATER_H

#include <new>
#include <vector>
#include <map>
#include <stdlib.h>
#include "wind/wind.h"
#include "weight.h"
#include "layer_config.h"
#include "global_updater_config.h"

namespace houyi {
namespace train {
typedef std::map<std::string, BaseWeight*> WeightsMap;

#define MAP_LOOP(l_map) \
    for (houyi::train::WeightsMap::iterator itr1 = l_map.begin(); itr1 != l_map.end(); ++itr1)

class BaseUpdater {
public:
    BaseUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) {
        _base_learn_rate = (cfg.learn_rate() >= 0) ? cfg.learn_rate() : global_cfg.get_learn_rate();
        _learn_rate = (cfg.learn_rate() >= 0) ? cfg.learn_rate() : global_cfg.get_learn_rate();
        _momentum = (cfg.momentum() >= 0) ? cfg.momentum() : global_cfg.get_momentum();
        _l2_penalty = (cfg.l2_penalty() >= 0) ? cfg.l2_penalty() : global_cfg.get_l2_penalty();
        _sample_counter = 0;
        _collect_counter = 0;

        _cfg = cfg;
        _global_cfg = global_cfg;

        _cur_step = 0;
        _iter_cnt_tmp = 0;
    }
    virtual ~BaseUpdater() {}

    static BaseUpdater* create(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg);
    virtual BaseUpdater* clone() = 0;

    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num) = 0;
    virtual void accum_to(WeightsMap& accum, DType alpha, DType beta) = 0;
    virtual void copy_from(WeightsMap& accum) = 0;
    virtual void copy_to(WeightsMap& accum) = 0;
    virtual void clone_to(WeightsMap& accum) = 0; 
    virtual void update(WeightsMap& weights) = 0;
    virtual void zero() {
        _sample_counter = 0;
        _collect_counter = 0;
    }

    inline GlobalUpdaterCfg& get_global_cfg() {
        return _global_cfg;
    }
    inline UpdaterConfig& get_cfg() {
        return _cfg;
    }

    virtual void adjust(DType lr, DType mom, DType l2 = -1.0f) {
        if (lr >= 0.0f && fabs(lr - 0.0f) > 1e-10) {
            _learn_rate = lr;
            _base_learn_rate = lr;

            if (fabs(_learn_rate - 1.0f) < 1e-10) {
                _global_cfg.set_lr_adjust_type(FIXED_LR);
            }
        }

        if (mom >= 0.0f && fabs(mom - 0.0f) > 1e-10) {
            _momentum = mom;
        }

        if (l2 >= 0.0f && fabs(l2 - 0.0f) > 1e-10) {
            _l2_penalty = l2;
        }
    }
    virtual void adjust_lr(size_t iter_cnt);
    void inc_sample_num(int num) {
        if (num > 0) {
            _sample_counter += (size_t)num;
        }
    }
    inline DType learn_rate() {
        return _learn_rate;
    }
    inline DType momentum() {
        return _momentum;
    }
    inline DType l2_penalty() {
        return _l2_penalty;
    }
    inline DType threshold() {
        return _cfg.threshold();
    }
    inline DType threshold_ratio() {
        return _cfg.threshold_ratio();
    }
    virtual WeightsMap& md_weights() {
        WeightsMap* ret = NULL;
        return *ret;
    }
protected:
    std::string _type;
    DType _base_learn_rate;
    DType _learn_rate;
    DType _momentum;
    DType _l2_penalty;
    GlobalUpdaterCfg _global_cfg;
    UpdaterConfig _cfg;
    size_t _sample_counter; // maybe need
    size_t _collect_counter;
    int _cur_step;
    size_t _iter_cnt_tmp;
};

class SgdUpdater : public BaseUpdater {
public:
    SgdUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : BaseUpdater(cfg,
                global_cfg) {
    }
    virtual ~SgdUpdater() {}
    virtual BaseUpdater* clone() {
        return new SgdUpdater(_cfg, _global_cfg);
    }
    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num);
    virtual void update(WeightsMap& weights);
    virtual void accum_to(WeightsMap& accum, DType alpha, DType beta);
    virtual void copy_from(WeightsMap& accum);
    virtual void copy_to(WeightsMap& accum);
    virtual void zero();
    virtual void update_w(BaseWeight* w, BaseWeight* grad, 
            BaseWeight* mdw, DType learn_rate, DType momentum);
    void init_md_weight(const WeightsMap& grads);
    virtual WeightsMap& md_weights() {
        return _md_weights;
    }
    virtual void clone_to(WeightsMap& accum); 
protected:
    void scale_momentum();
    WeightsMap _md_weights;
    WeightsMap _dw_weights;
};

class NesterovSgdUpdater : public SgdUpdater{
public:
    NesterovSgdUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : SgdUpdater(cfg,
                global_cfg) {
    }
    virtual ~NesterovSgdUpdater() {}
    virtual BaseUpdater* clone() {
        return new NesterovSgdUpdater(_cfg, _global_cfg);
    }
    virtual void update_w(BaseWeight* w, BaseWeight* grad, 
            BaseWeight* mdw, DType learn_rate, DType momentum);
};

class AdamUpdater : public SgdUpdater {
public:
    AdamUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : SgdUpdater(cfg,
                global_cfg) {
        _t = 0;
        _epsilon = 1e-8;
        _beta1t = 0;
        _beta1 = (cfg.get_beta1() >= 0) ? cfg.get_beta1() : global_cfg.get_beta1();
        _beta2 = (cfg.get_beta2() >= 0) ? cfg.get_beta2() : global_cfg.get_beta2();
        _lambda = (cfg.get_lambda() >= 0) ? cfg.get_lambda() : global_cfg.get_lambda();
        _learn_rate = (cfg.get_alpha() >= 0) ? cfg.get_alpha() : global_cfg.get_alpha();
        _base_learn_rate = (cfg.get_alpha() >= 0) ? cfg.get_alpha() : global_cfg.get_alpha();
    }
    virtual ~AdamUpdater() {}
    virtual BaseUpdater* clone() {
        return new AdamUpdater(_cfg, _global_cfg);
    }
    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num);
    virtual void update(WeightsMap& weights);
    void init_md_weight(const WeightsMap& grads);
protected:
    WeightsMap _mt_weights;
    WeightsMap _vt_weights;
    WeightsMap _tmp_weights;

    float _epsilon;
    float _beta1;
    float _beta1t;
    float _beta2;
    float _lambda;
    int _t;
};

class RmsUpdater : public SgdUpdater {
public:
    RmsUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : SgdUpdater(cfg,
                global_cfg) {
        _epsilon = 1e-8;
        _gamma = (cfg.get_rms_gamma() >= 0) ? cfg.get_rms_gamma() : global_cfg.get_rms_gamma();
        _learn_rate = (cfg.get_rms_eta() >= 0) ? cfg.get_rms_eta() : global_cfg.get_rms_eta();
        _base_learn_rate = (cfg.get_rms_eta() >= 0) ? cfg.get_rms_eta() : global_cfg.get_rms_eta();
    }
    virtual ~RmsUpdater() {}
    virtual BaseUpdater* clone() {
        return new RmsUpdater(_cfg, _global_cfg);
    }
    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num);
    virtual void update(WeightsMap& weights);
    void init_md_weight(const WeightsMap& grads);
protected:
    WeightsMap _et_weights;
    WeightsMap _tmp;

    DType _gamma;
    DType _epsilon;
};

class NormUpdater : public SgdUpdater {
public:
    NormUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : SgdUpdater(cfg,
                global_cfg) {
        _threshold = cfg.threshold();
        _threshold_ratio = cfg.threshold_ratio();
    }
    ~NormUpdater() {}
    virtual BaseUpdater* clone() {
        return new NormUpdater(_cfg, _global_cfg);
    }
    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num);
protected:
    DType _threshold;
    DType _threshold_ratio; // TO fuxiaoyin, This variable may be updated dynamically
};


class AvgUpdater : public SgdUpdater {
public:
    AvgUpdater(const UpdaterConfig& cfg, const GlobalUpdaterCfg& global_cfg) : SgdUpdater(cfg,
                global_cfg) {

    }
    ~AvgUpdater() {}
    virtual BaseUpdater* clone() {
        return new AvgUpdater(_cfg, _global_cfg);
    }
    virtual void collect(const WeightsMap& grads, WeightsMap& weights, int sample_num);
    void update(WeightsMap& weights);
};

extern void zero_weight_map(WeightsMap& map);
extern void copy_weight_map(WeightsMap& dst_map,
                            WeightsMap& src_map, WindStream cp_in_stream);
extern void copy_weight_map(WeightsMap& dst_map, WeightsMap& src_map);
extern void init_weight_map(WeightsMap& dst_map,
                            WeightsMap& src_map, const Device& device);
extern void clone_weight_map(WeightsMap& dst_map, WeightsMap& src_map);
extern void release_weight_map(WeightsMap& dst_map);

}
}
#endif
