/**
 * roi_pool_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-27
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_LAYERS_ROI_POOL_LAYER_H
#define HOUYI_LAYERS_ROI_POOL_LAYER_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class ROIPoolLayer : public Layer {
public:
    ROIPoolLayer(ROIPoolConfig& cfg);
    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    virtual void inter_forward(IOPackage* in_pack) {
        CHECK(false, "empty inter_forwatd is called");
    }
    virtual void inter_bprop_diff(IOPackage* in_pack, IOPackage* out_pack) {
        CHECK(false, "empty inter_bprop_diff is called");
    }

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);

    void build_map(const char* prefix = NULL) {
    }

    Layer* clone() {
        return new ROIPoolLayer(_cfg);
    }

    void store_model(std::ofstream&, SPEECH_NN_W_TYPE) {}
    void read_model(std::ifstream&, SPEECH_NN_W_TYPE) {}

    void init();

protected:
    void set_device() {
        _max_idx.set_device(GPU);
    }

private:
    ROIPoolConfig _cfg;
    ROIPoolingDesc _roi_pool_dec;

    PoolingType _pooling_type;
    size_t _width;
    size_t _height;
    size_t _input_maps;
    DType _spatial_scale;

    size_t _pooled_height;
    size_t _pooled_width;
    size_t _roi_num;
    Tensor<int> _max_idx;

};

}
}

#endif
