#ifndef HOUYI_LAYERS_GRU_OPS_H
#define HOUYI_LAYERS_GRU_OPS_H
#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_gru_forward(Tensor<DType>& out, 
        Tensor<DType>& u_h_t_1, 
        Tensor<DType>& w_x_bias,
        Tensor<DType>& partial_hidden_cur_o,
        Tensor<DType>& hidden_state_cur_o,
        Tensor<DType>& hidden_state_all_o,
        int t, int st_row, 
        int sample_num, int sub_seq_size);

void wind_gru_backward(Tensor<DType>& delta_h,
        Tensor<DType>& back_error,
        Tensor<DType>& out_error,
        Tensor<DType>& out,  
        Tensor<DType>& hidden_state_all_o,
        Tensor<DType>& partial_hidden_all_o,
        Tensor<DType>& partial_hidden_error,
        Tensor<DType>& back_error_tmp,
        int t, int st_row,
        int sample_num, int sub_seq_size);

// out = (1 - a)* b + a * c
void wind_interpolate_elem_mul(Tensor<DType>a, 
        Tensor<DType>b, Tensor<DType>c, Tensor<DType>out);

}// namespace train
}// namespace houyi
#endif
