#ifndef HOUYI_LAYERS_IMAGE_POOLING_OPS_H
#define HOUYI_LAYERS_IMAGE_POOLING_OPS_H
#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_image_pool_cal_mask(Tensor<DType>& out, 
        Tensor<int>& to_mask, 
        Tensor<int>& from_mask,
        int kernel_height,
        int padding_height,
        int stride_height);

}// namespace train
}// namespace houyi
#endif
