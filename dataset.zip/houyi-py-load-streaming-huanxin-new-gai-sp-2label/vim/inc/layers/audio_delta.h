// by zhxfl 2018.06.07
#ifndef HOUYI_TRAIN_PLATFORM_AUDIO_DELTA_H
#define HOUYI_TRAIN_PLATFORM_AUDIO_DELTA_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class AudioDelta : public Layer {
public:
    AudioDelta(AudioDeltaConfig& config);
    AudioDelta(AudioDelta* from);
    virtual ~AudioDelta();

    Layer* clone();
    virtual void build_map(const char* prefix = NULL);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    inline AudioDeltaConfig& config() {
        return _config;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

protected:
    void set_device() {
    }
protected:
    AudioDeltaConfig _config;
    int _windows;
    Tensor<int> _seq_len;
};
}
}
#endif
