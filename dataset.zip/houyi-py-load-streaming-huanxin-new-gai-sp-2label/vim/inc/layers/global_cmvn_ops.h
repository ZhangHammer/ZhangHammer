// by zhxfl 2018.07.09
#ifndef HOUYI_TRAIN_PLATFORM_GLOBAL_CMVN_OPS_H
#define HOUYI_TRAIN_PLATFORM_GLOBAL_CMVN_OPS_H
#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_global_cmvn(Tensor<DType>& in, 
        Tensor<DType>& out, 
        Tensor<int>& mask, 
        Tensor<DType>& mean,
        Tensor<DType>& std_inv_var,
        int sample_num);

}// namespace train
}// namespace houyi
#endif
