// by zzxfl 2017.05.12
#ifndef HOUYI_LAYERS_TRANSPOSE_LAYER_H
#define HOUYI_LAYERS_TRANSPOSE_LAYER_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
/*
type=transpose
name=??
inputs=??
reshape1=1:1:1:1
transpose=0:1:3:2
reshape2=
*/

namespace houyi {
namespace train {

class TransposeLayer : public Layer {
public:
    TransposeLayer(TransposeConfig& config);
    TransposeLayer(TransposeLayer* from);
    virtual ~TransposeLayer() {}

    Layer* clone();
    void build_map(const char* prefix = NULL) {}

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    std::vector<int> get_transpose_dim(const Dim& dim);

    int get_layer_size() {
        return 1;
    }

    inline TransposeConfig& config() {
        return _config;
    }
protected:
    void set_device() {
    }

    void init() {
    }
protected:
    TransposeConfig _config;
    Tensor<int>_transpose;
    Tensor<int>_re_transpose;
};

}
}

#endif
