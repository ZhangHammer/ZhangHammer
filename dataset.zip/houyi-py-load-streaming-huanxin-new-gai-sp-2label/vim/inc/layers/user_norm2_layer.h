/**
 * user_norm2_layer.h
 * example for user op
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-01
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_USER_NORM2_LAYER_H
#define HOUYI_LAYERS_USER_NORM2_LAYER_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class UserNorm2Layer : public Layer {
public:
    UserNorm2Layer(Norm2Config& config);
    UserNorm2Layer(UserNorm2Layer* from);
    virtual ~UserNorm2Layer() {}

    Layer* clone();
    void build_map(const char* prefix = NULL) {}

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    inline Norm2Config& config() {
        return _config;
    }
    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

protected:
    void set_device() {
        _norm2.set_device(gpu_device());
        _diff_buf.set_device(gpu_device());
        _vec_buf.set_device(gpu_device());
    }
protected:
    Norm2Config _config;

    Tensor<DType> _norm2;
    Tensor<DType> _diff_buf;
    Tensor<DType> _vec_buf;
};

}
}

#endif
