/**
 * image_bat_norm_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-09-01
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_IMAGE_BAT_NORM_LAYER_H
#define HOUYI_TRAIN_PLATFORM_IMAGE_BAT_NORM_LAYER_H
#include <vector>
#include "wind/wind.h"
#include "weight.h"
#include "layer.h"

namespace houyi {
namespace train {

class ImageBatNormalLayer : public Layer {
public:
    ImageBatNormalLayer(ImageBatNormConfig& config);
    ImageBatNormalLayer(ImageBatNormalLayer* from);
    ~ImageBatNormalLayer();

    virtual void build_map(const char* prefix = NULL);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    void inter_forward_eval(std::vector<IOPackage*>& in_pack);
    void inter_forward_train(std::vector<IOPackage*>& in_pack);

    void gauss_init(DType mean, DType stdv);
    void init_weight(const ModelInitConfig& global_cfg);
    void init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers);
    void inq_init_weight();
    void inq_init_bias();

    virtual void read_initial_mean_var();
    virtual void read_initial_mean_var(std::string bn_file_prefix);
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    virtual void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    Layer* clone();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    std::string& global_file_name() {
        return _global_mean_var;
    }
    Tensor<DType>* mean_vec() {
        return &_mean_vec;
    }
    Tensor<DType>* var_vec() {
        return &_var_vec;
    }
    inline DType epsilon() {
        return _epsilon;
    }
    inline BatNormType norm_type() {
        return _norm_type;
    }
    inline DenseWeight* beta() {
        return &_beta;
    }
    inline DenseWeight* beta_t() {
        return &_beta_t;
    }
    inline DenseWeight* gamma() {
        return &_gamma;
    }
    inline DenseWeight* gamma_t() {
        return &_gamma_t;
    }
    inline DenseWeight* d_beta() {
        return &_d_beta;
    }
    inline DenseWeight* d_gamma() {
        return &_d_gamma;
    }
    inline ImageBatNormConfig& config() {
        return _config;
    }
    inline size_t counter() {
        return _counter;
    }
protected:
    void store_mean_var();
    void set_device(void) {
        _mean_vec.set_device(gpu_device());
        _var_vec.set_device(gpu_device());

        _run_mean_vec.set_device(gpu_device());
        _run_var_vec.set_device(gpu_device());

        _static_mean_vec.set_device(gpu_device());
        _static_var_vec.set_device(gpu_device());
    }
    void read_initial_mean_var_eval(const char* file_name);
    void read_initial_mean_var_train(const char* file_name);
protected:
    ImageBatNormConfig _config;
    BatNormType _norm_type;
    DType _epsilon;
    size_t _statis_threshold;

    std::string _global_mean_var; // initial meanVec and varVec

    //每次前向生成的mean和var，后向使用
    Tensor<DType> _mean_vec;
    Tensor<DType> _var_vec;

    //每次前向生成的mean和var，统计使用
    Tensor<DType> _run_mean_vec;
    Tensor<DType> _run_var_vec;
    //统计使用
    Tensor<DType> _static_mean_vec;
    Tensor<DType> _static_var_vec;

    DenseWeight _gamma, _d_gamma;
    DenseWeight _beta, _d_beta;

    /* for inq */
    DenseWeight _gamma_t;
    DenseWeight _beta_t;

    size_t _mean_var_dim;
    //记录统计了多少sample，feature_map或者frame
    float _counter;
    size_t _store_item;
    DType _moving_average_fraction;
};

}
}
#endif
