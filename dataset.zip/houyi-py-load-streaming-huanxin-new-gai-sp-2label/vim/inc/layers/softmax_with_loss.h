/**
 * softmax_with_loss.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_LAYERS_SOFTMAX_WITH_LOSS_H
#define HOUYI_LAYERS_SOFTMAX_WITH_LOSS_H

#include "wind/wind.h"
#include "argument.h"
#include "layer.h"
#include "out_config.h"

namespace houyi {
namespace train {

class SoftmaxWithLossLayer : public Layer {
public:
    SoftmaxWithLossLayer(SoftmaxWithLossConfig& cfg) : Layer(cfg) {
        _type = cfg.type();
        _cfg = cfg;
        _sft_row_sum.set_device(gpu_device());
        _start_axis = cfg.get_start_axis();
        _end_axis = cfg.get_end_axis();
        _enable_focal_loss = false;
        if (_focal_loss_ratio > 0) {
            _enable_focal_loss = true;
        }
    }

    SoftmaxWithLossLayer(SoftmaxWithLossLayer* from) : Layer(from) {
        new(this) SoftmaxWithLossLayer(from->config());
    }

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

    inline SoftmaxWithLossConfig& config() {
        return _cfg;
    }

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) {}

    virtual Layer* clone() {
        return new SoftmaxWithLossLayer(this);
    }
    virtual void build_map(const char* prefix = NULL) {
        _w_map.clear();
        _dw_map.clear();
    }
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

protected:
    Tensor<DType> _sft_row_sum;
    SoftmaxWithLossConfig _cfg;

    size_t _input_dim;
    size_t _output_dim;
    int _start_axis;
    int _end_axis;

    float _focal_loss_ratio;
    bool _enable_focal_loss;
};

} //namespace train
}

#endif
