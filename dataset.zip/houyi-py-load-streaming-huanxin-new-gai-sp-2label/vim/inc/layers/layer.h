/**
 * Layer.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-06-18
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_LAYER_H
#define HOUYI_TRAIN_PLATFORM_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cfloat>
#include "util.h"
#include "wind/wind.h"
#include "activation.h"
#include "layer_config.h"
#include "weight.h"
#include "updater.h"
#include "argument.h"
#include "job.h"
#include "tools.h"

namespace houyi {
namespace train {

enum SPEECH_NN_W_TYPE {
    WEIGHT, D_WEIGHT, MD_WEIGHT, INIT_WEIGHT
};

class Layer {
protected:
    LayerType _type;
    int _id;
    std::string _name;
    std::vector<std::string> _input_keys;
    std::vector<std::string> _output_keys;
    std::vector<std::string> _label_key;
    std::vector<std::string> _feat_desc_keys;

    JobType   _job_type;
    JobType   _global_job_type;

    std::vector<IOPackage*> _input;
    std::vector<IOPackage> _output;
    std::vector<IOPackage> _diff;

    ActiveType  _act_type;
    Activation* _act;

    bool        _has_bias;
    bool        _need_update;
    bool        _read;
    bool        _weight_flag;

    int         _sample_num;
    int         _nxt_start;

    BaseUpdater* _updater;

    WeightsMap _w_map;
    WeightsMap _dw_map;

    //data struct for reversal layer
    std::vector<int> _length_vec;
    bool _is_reversal;

    Tensor<int> _fwd_map_vec;
    Tensor<int> _bwd_map_vec;
    Tensor<int> _fwd_map_vec_d;
    Tensor<int> _bwd_map_vec_d;

    IOPackage _invert_in_mat;
    IOPackage _invert_out_mat;
    IOPackage _invert_in_diff;
    IOPackage _invert_out_diff;

    DType _init_mean;
    DType _init_stdv;

    size_t _layer_result_output_num;

    std::vector<int> _bp_down;
    //允许layer进行bp
    bool _enable_bp;
    std::vector<bool> _diff_ready;

    ModelInitConfig _model_init_cfg;

    bool _inq;                     
    std::vector<DType> _inq_ratio;      
    int _inq_bit;                  
    std::vector<DType> _inq_weight_max; 
    std::vector<DType> _inq_bias_max;   

    std::vector<Tensor<DType>> _intl_quant_alpha_vec;
    size_t _intl_quant_bits;
    size_t _weight_quant_bits;
    BitQuantAlgo _intl_quant_algo;
    size_t _quant_cnt;
    std::vector<Tensor<DType>> _batch_quant_alpha_vec;

    bool _feature_share_input;

    // 指向 trainer 分配的空间
    Tensor<unsigned char>* _workspace = NULL;
public:
    /*
     * 设置layer，这个方法只在初始化的时候调用一次，其他时候禁止使用
     */
    virtual void layer_set(std::vector<IOPackage*>& inputs, int sample_num) = 0;

    inline WeightsMap& w_map() {
        return _w_map;
    }
    inline WeightsMap& dw_map() {
        return _dw_map;
    }
    Layer(LayerConfig& cfg);

    Layer(Layer* from);

    virtual ~Layer() {
        if (_act) {
            delete _act;
        }

        _act = NULL;
    }
    inline void register_args(
        Argument& out_args, Argument& diff_args) {
        for (size_t i = 0; i < _output_keys.size(); i++) {
            out_args.insert(_output_keys[i], &_output[i]);
            diff_args.insert(_output_keys[i], &_diff[i]);
        }
    }

    virtual void resize_out(std::vector<IOPackage*> &inputs, int sample_num) = 0;

    virtual void forward(Argument& io_arg);
    virtual bool backward(Argument& io_arg, Argument& diff_arg);
    ////////////////////////////////////////////////////////////////
    virtual void store_history() {}
    virtual void clear_history() {}
    virtual void clear_history(int idx) {}
    virtual void inter_forward(std::vector<IOPackage*>& pack) = 0;
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) = 0;
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack) = 0;

    virtual Layer* clone() = 0;
    virtual void build_map(const char* prefix = NULL) = 0;

    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) = 0;
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) = 0;
    virtual void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}
    virtual void read_heter_model(std::ifstream& input) {}
    virtual void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {
        INTER_LOG("%s inq not support", _name.c_str());
    }
    virtual void read_initial_mean_var() {}
    virtual void read_initial_mean_var(std::string bn_file_prefix) {}

    /////////////////////////////////////////////////////////////////
    virtual void update();
    virtual void update(WeightsMap& w_vec, WindStream cpInStream_);
    virtual void copy_in(WeightsMap& bufVec, SPEECH_NN_W_TYPE t);
    virtual int  copy_out(WeightsMap& bufVec, SPEECH_NN_W_TYPE t);
    virtual void zero_buf(SPEECH_NN_W_TYPE);
    virtual void copy_out_async(WeightsMap& _dw_vec,
                                SPEECH_NN_W_TYPE t, WindStream cpOutStream);
    virtual void accum_grad(WeightsMap& dw_vec,
                            DType alpha, DType beta);
    virtual void  clean_delta_w();

    virtual void init_weight(const ModelInitConfig& global_cfg);
    virtual void init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers);
    virtual void uniform_init_weight(DType lo, DType hi);
    virtual void uniform_init_bias(DType lo, DType hi);
    virtual void constant_init_weight(DType const_value);
    virtual void constant_init_bias(DType const_value);
    virtual void constant_init(DType const_value);
    virtual void gauss_init_weight(DType mean, DType stdv);
    virtual void gauss_init_bias(DType mean, DType stdv);
    virtual void gauss_init(DType mean, DType stdv);
    virtual void msra_init_weight(MSRAType type);
    virtual void msra_init_bias(MSRAType type);
    virtual void xavier_init_weight(XavierType type);
    virtual void xavier_init_bias(XavierType type);

    /*  for inq */                                                            
    void inq_init_weight();                                                  
    void inq_init_bias();                                                    
    void inq_quantization(Tensor<DType> &w, Tensor<DType> &w_t, DType &max); 

    size_t count_elem_num(WeightsMap& map);
    virtual void zero_out_pack();
    virtual void zero_diff_pack();

    inline int id() {
        return _id;
    }
    inline const std::string& name() const {
        return _name;
    }
    inline int input_num() {
        return (int)_input_keys.size();
    }
    inline std::vector<std::string>& input_keys() {
        return _input_keys;
    }
    inline std::string& input_key(int i) {
        return _input_keys[i];
    }
    inline bool has_bias() {
        return _has_bias;
    }
    inline int output_num() {
        return (int)_output_keys.size();
    }
    inline std::vector<std::string>& output_keys() {
        return _output_keys;
    }
    inline std::string& output_key(int i) {
        return _output_keys[i];
    }
    inline bool need_update() {
        return _need_update;
    }
    inline bool need_read() {
        return _read;
    }
    inline LayerType type() {
        return _type;
    }
    inline std::string type_str() {
        return get_layer_type_str(_type);
    }
    inline JobType job_type() {
        return (_job_type != UNKNOWN_JOB) ? _job_type : _global_job_type;
    }
    inline JobType global_job_type() {
        return _global_job_type;
    }
    inline void set_global_job_type(JobType job_type) {
        _global_job_type = job_type;
    }
    inline ActiveType act_type() {
        return _act_type;
    }
    inline Activation* act() {
        return _act;
    }
    inline int set_sample_num() {
        return _sample_num;
    }
    inline int get_sample_num() {
        return _sample_num;
    }
    inline bool is_reversal() {
        return _is_reversal;
    }
    inline int nxt_start() {
        return _nxt_start;
    }
    virtual void weight_flag(bool weight_flag) {
        _weight_flag = weight_flag;
    }
    virtual bool weight_flag() {
        return _weight_flag;
    }
    inline BaseUpdater* updater() {
        return _updater;
    }
    inline std::vector<IOPackage*>& get_input() {
        return _input;
    }
    inline std::vector<IOPackage>& output() {
        return _output;
    }
    inline IOPackage& output(std::string key) {
        for (size_t i = 0; i < _output_keys.size(); i++) {
            if (_output_keys[i] == key) {
                return _output[i];
            }
        }

        return _output[0];
    }
    inline std::vector<IOPackage>* output_for_python() {
        return &_output;
    }
    inline std::vector<IOPackage>& diff() {
        return _diff;
    }
    inline IOPackage& diff(std::string key) {
        for (size_t i = 0; i < _output_keys.size(); i++) {
            if (_output_keys[i] == key) {
                return _diff[i];
            }
        }

        CHECK2(false);
        return _diff[0];
    }
    virtual void set_drop_flag(bool drop_flag) {

    }
    inline std::vector<std::string>& get_label_key() {
        return _label_key;
    }
    inline std::string& get_label_key(size_t idx) {
        return _label_key[idx];
    }
    inline std::vector<std::string>& get_feat_desc_key() {
        return _feat_desc_keys;
    }
    inline std::vector<int>& get_bp_down() {
        return _bp_down;
    }
    inline int& get_bp_down(std::string input_key) {
        int idx = 0;
        for (auto key : _input_keys) {
            if (key == input_key) {
                break;
            }
            idx++;
        }
        return _bp_down[idx];
    }
    inline void set_enable_bp(bool flag) {
        _enable_bp = flag;
    }
    inline bool get_enable_bp() {
        return _enable_bp;
    }
    inline void set_diff_ready(std::vector<bool>& flag) {
        _diff_ready = flag;
    }

    virtual void init_grad(WeightsMap& dw_vec);

    virtual int  get_threshold(DType** low, DType** up) {
        return 0;
    }
    virtual void set_threshold(const DType* low, const DType* up, int cnt) {}

    inline void set_reverse_flag(bool flag) {
        _is_reversal = flag;
    }
    void reverse_encode(const IOPackage& src, IOPackage& dest);
    void reverse_decode(const IOPackage& src, IOPackage& dest);

    size_t layer_result_output_num() {
        return _layer_result_output_num;
    }
    ModelInitConfig& model_init_cfg() {
        return _model_init_cfg;
    }
    bool get_inq() {
        return _inq;
    }
    std::vector<DType> get_inq_ratio() {
        return _inq_ratio;
    }
    int get_inq_bit() {
        return _inq_bit;
    }
    const std::vector<DType> &get_inq_weight_max() const {
        return _inq_weight_max;
    }
    const std::vector<DType> &get_inq_bias_max() const { 
        return _inq_bias_max;
    }
    bool get_feature_share_input() {
        return _feature_share_input;
    }
    virtual void store_mean_var() {
        //INTER_LOG("It isn`t BN layer, nothing to do");
    }
    void set_workspace(Tensor<unsigned char>* workspace) {
        _workspace = workspace;
    }

    void print_input_dim(std::string prefix, std::vector<IOPackage*>& in);
    void print_input_dim(std::string prefix, std::vector<IOPackage>& in);
    void print_output_dim(std::string prefix, std::vector<IOPackage*>& in);
    void print_output_dim(std::string prefix, std::vector<IOPackage>& in);
    void free_output() {
        _output.clear();
    }

    void greedy_quantize(Tensor<DType> inout, size_t nbits); 
    bool bit_quantize(Tensor<DType> inout, size_t idx); 

protected:
    void set_device() {
        _fwd_map_vec.set_device(cpu_device());
        _bwd_map_vec.set_device(cpu_device());
        _fwd_map_vec_d.set_device(gpu_device());
        _bwd_map_vec_d.set_device(gpu_device());
    }
    void init() {
        _inq_weight_max.clear();
        _inq_bias_max.clear();
    }
};

}
} //namespace houyi
#endif
