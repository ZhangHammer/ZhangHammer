/**
 * fast_lstm.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-08-25
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_TRAIN_PLATFORM_FAST_LSTM_H
#define HOUYI_TRAIN_PLATFORM_FAST_LSTM_H

#include <vector>
#include <iostream>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "cec.h"

namespace houyi {
namespace train {

class FastLstmLayer : public Layer {
protected:
    LstmConfig _config;
    int _skip_num;
    int _t_bptt;
    int _feat_dim;
    int _cell_dim;
    int _rec_dim;
    int _out_dim;

    DenseWeight _bias, _d_bias;
    DenseWeight _bias_t;
    DenseWeight _w_r, _dw_r;
    DenseWeight _w_r_t;

    // Gate-CEC-Wx
    int         _gcec_x_h;
    int         _gcec_x_w;
    DenseWeight _w_x_gcec, _dw_x_gcec;
    DenseWeight _w_x_gcec_t;
    DenseWeight _bias_gcec, _d_bias_gcec;
    DenseWeight _bias_gcec_t;

    // Gate-CEC-Wr
    int         _gcec_r_h;
    int         _gcec_r_w;
    DenseWeight _w_r_gcec, _dw_r_gcec;
    DenseWeight _w_r_gcec_t;

    // Gate-CEC-Wc
    int         _gcec_c_w;
    DenseWeight _w_c_gcec, _dw_c_gcec;
    DenseWeight _w_c_gcec_t;

    // noise for gradient
    Tensor<DType> _gauss_dw_r;
    Tensor<DType> _gauss_dw_x_gcec;
    Tensor<DType> _gauss_dbias_gcec;
    Tensor<DType> _gauss_dw_r_gcec;
    Tensor<DType> _gauss_dw_c_gcec;

    // Activation
    Activation* _rec_act;
    Activation* _mid_act;

    // Limitination
    DType _threshold; // for gradient
    DType _dr_threshold;
    DType _dc_threshold;
    DType _statis_dc;
    DType _statis_dr;
    int _statis_counter;
    DType _threshold_ratio;

    int _statis_sentence_counter;
    DType _statis_max;
    DType _cec_min;
    DType _cec_max;
    int _max_min_sentence_number;
    int _max_min_sentence_counter;

    int _max_min_counter;
    Tensor<DType> _o_max;
    Tensor<DType> _o_min;

    Tensor<DType> _o_max_sum;
    Tensor<DType> _o_min_sum;

    DType _final_mean_norm_dw_r;
    DType _final_stdv_norm_dw_r;
    DType _final_mean_norm_dw_x_gcec;
    DType _final_stdv_norm_dw_x_gcec;
    DType _final_mean_norm_dw_r_gcec;
    DType _final_stdv_norm_dw_r_gcec;
    DType _final_mean_norm_dw_c_gcec;
    DType _final_stdv_norm_dw_c_gcec;
    DType _final_mean_norm_d_bias_gcec;
    DType _final_stdv_norm_d_bias_gcec;

    DType _mean_norm_dw_r;
    DType _stdv_norm_dw_r;
    DType _mean_norm_dw_x_gcec;
    DType _stdv_norm_dw_x_gcec;
    DType _mean_norm_dw_r_gcec;
    DType _stdv_norm_dw_r_gcec;
    DType _mean_norm_dw_c_gcec;
    DType _stdv_norm_dw_c_gcec;
    DType _mean_norm_d_bias_gcec;
    DType _stdv_norm_d_bias_gcec;

    int _mean_counter;
    int _mean_batch_number;

    // Buffer
    StateMatrix _state_oe_c;
    StateMatrix _state_oe_r;
    Tensor<DType>    _gcec_o;

    Tensor<DType>    _in_gate_o;
    Tensor<DType>    _out_gate_o;
    Tensor<DType>    _fgt_gate_o;
    Tensor<DType>    _gc_o;

    Tensor<DType>    _m_o;
    Tensor<DType>    _hc_o;

    Tensor<DType>    _error_gcec;
    Tensor<DType>    _error_m;
    Tensor<DType>    _back_error_c;
    Tensor<DType>    _back_error_r;
    Tensor<DType>    _cur_error_c;

    // Reverse
    Tensor<int>      _seq_len;
    Tensor<DType>    _reverse;
    Tensor<DType>    _reverse_out;
    Tensor<DType>    _reverse_in_diff;
    Tensor<DType>    _reverse_pre_diff;

    int _sub_seq_size;
public:

    FastLstmLayer(LstmConfig& conf);
    FastLstmLayer(FastLstmLayer* from);
    ~FastLstmLayer() {};

    void set_device() {
        _gauss_dw_r.set_device(gpu_device());
        _gauss_dw_x_gcec.set_device(gpu_device());
        _gauss_dbias_gcec.set_device(gpu_device());
        _gauss_dw_r_gcec.set_device(gpu_device());
        _gauss_dw_c_gcec.set_device(gpu_device());

        _o_max.set_device(gpu_device());
        _o_min.set_device(gpu_device());

        _o_max_sum.set_device(gpu_device());
        _o_min_sum.set_device(gpu_device());

        _gcec_o.set_device(gpu_device());
        _in_gate_o.set_device(gpu_device());
        _out_gate_o.set_device(gpu_device());
        _fgt_gate_o.set_device(gpu_device());
        _gc_o.set_device(gpu_device());

        _m_o.set_device(gpu_device());
        _hc_o.set_device(gpu_device());

        _error_gcec.set_device(gpu_device());
        _error_m.set_device(gpu_device());
        _back_error_c.set_device(gpu_device());
        _back_error_r.set_device(gpu_device());
        _cur_error_c.set_device(gpu_device());

        _reverse.set_device(gpu_device());
        _reverse_out.set_device(gpu_device());
        _reverse_in_diff.set_device(gpu_device());
        _reverse_pre_diff.set_device(gpu_device());
        _seq_len.set_device(gpu_device());
    }

    virtual void build_map(const char* prefix = NULL);

    void inter_forward(std::vector<IOPackage*>& in_pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    virtual Layer* clone();

    void heuristic_clear_history(std::vector<int>& his_vec);
    void squash_out(int t);
    void output_gate_backward(
        int t, Tensor<DType>& error_m, Tensor<DType>& hc_o,
        Tensor<DType>& o_r, Tensor<DType>& o_c);
    void cells_gate_backward(
        int t, Tensor<DType>& error_m,
        Tensor<DType>& out_gate_o, // outG-_all_o
        Tensor<DType>& in_gate_o, // inG-_all_o
        Tensor<DType>& hc_o);
    void forget_gate_backward(
        int t, Tensor<DType>& cur_error_c, Tensor<DType>& cur_c_o);
    void input_gate_backward(
        int t, Tensor<DType>& cur_error_c,
        Tensor<DType>& gc_o, Tensor<DType>& r_o);
    void calcu_rec_back_error(int t);
    void cal_time_gradient();
    void calcu_cec_back_error(int t);
    //void store_history();
    void time_backward(
        const Tensor<DType>& in_feat, const Tensor<DType>& in_diff, Tensor<DType>& out_diff);
    void input_error_backprop(Tensor<DType>& outError);
    void linear_gradient(const Tensor<DType>& x);
    void linear_backprop(const Tensor<DType>& inError);
    void clear_gradient();
    bool clip_gradient();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_tensor(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void store_history();
    virtual void clear_history();
    virtual void clear_history(int idx);

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void set_next_start();

    inline LstmConfig& config() {
        return _config;
    }

    inline DenseWeight* w_x_gcec() {
        return &_w_x_gcec;
    }
    inline DenseWeight* w_x_gcec_t() {
        return &_w_x_gcec_t;
    }

    inline DenseWeight* bias_gcec() {
        return &_bias_gcec;
    }

    inline DenseWeight* bias_gcec_t() {
        return &_bias_gcec_t;
    }

    inline DenseWeight* w_c_gcec() {
        return &_w_c_gcec;
    }
    inline DenseWeight* w_c_gcec_t() {
        return &_w_c_gcec_t;
    }
    inline DenseWeight* w_r_gcec() {
        return &_w_r_gcec;
    }
    inline DenseWeight* w_r_gcec_t() {
        return &_w_r_gcec_t;
    }
    inline DenseWeight* w_r() {
        return &_w_r;
    }
    inline DenseWeight* w_r_t() {
        return &_w_r_t;
    }
    enum GateType {
        INPUT_OUT, FORGET_OUT, OUTPUT_OUT, CELL_OUT,
        INPUT_ERROR, FORGET_ERROR, OUTPUT_ERROR, CELL_ERROR
    };
    enum CellWType {
        INPUT_C, FORGET_C, OUTPUT_C
    };

    inline Tensor<DType> get_w_c(CellWType t) {
        switch (t) {
        case INPUT_C:
            return _w_c_gcec.w()->range_row(0, 1);
            break;

        case FORGET_C:
            return _w_c_gcec.w()->range_row(1, 2);
            break;

        case OUTPUT_C:
            return _w_c_gcec.w()->range_row(2, 3);
            break;

        default:
            CHECK(false, "unknow type:%d", t);
        }
    }
    inline Tensor<DType> get_dw_c(CellWType t) {
        switch (t) {
        case INPUT_C:
            return _dw_c_gcec.w()->range_row(0, 1);
            break;

        case FORGET_C:
            return _dw_c_gcec.w()->range_row(1, 2);
            break;

        case OUTPUT_C:
            return _dw_c_gcec.w()->range_row(2, 3);
            break;

        default:
            CHECK(false, "unknow type:%d", t);
        }
    }

    inline Tensor<DType> get_oe(GateType t) {
        switch (t) {
        case INPUT_OUT:
            return _gcec_o.range_col(0, 1, _cell_dim);
            break;

        case FORGET_OUT:
            return _gcec_o.range_col(1, 2, _cell_dim);
            break;

        case OUTPUT_OUT:
            return _gcec_o.range_col(2, 3, _cell_dim);
            break;

        case CELL_OUT:
            return _gcec_o.range_col(3, 4, _cell_dim);
            break;

        case INPUT_ERROR:
            return _error_gcec.range_col(0, 1, _cell_dim);
            break;

        case FORGET_ERROR:
            return _error_gcec.range_col(1, 2, _cell_dim);
            break;

        case OUTPUT_ERROR:
            return _error_gcec.range_col(2, 3, _cell_dim);
            break;

        case CELL_ERROR:
            return _error_gcec.range_col(3, 4, _cell_dim);
            break;

        default:
            CHECK(false, "unknow type:%d", t);
        }
    }
    void clip_error_update(Tensor<DType>& E, DType threshold);

    void intl_quantize(Tensor<DType>& tensor, int idx);
};
}
}
#endif
