/**
 * disc_nn_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-14
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_DISC_NN_CFG_H
#define HOUYI_LAYERS_DISC_NN_CFG_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "base_reader_config.h"
#include "base_processer_config.h"
#include "base_repository_config.h"
#include "layer_config.h"
#include "out_config.h"
#include "job.h"
#include "nn_config.h"

//using namespace std;
namespace houyi {
namespace train {

enum DecoderType {
    DECODER,
    TRIPLET_DECODER,
    SELECT_DECODER,
    UNKNOWN_DECODER
};

extern const char* decoder_type_name[];

enum TripletSelectType {
    RANDOM_HARD_TRIP_SEL_TYPE,
    SEMI_HARD_TRIP_SEL_TYPE,
    MOST_HARD_TRIP_SEL_TYPE,
    UNKNOWN_TRIP_SEL_TYPE
};
extern const char* triplet_select_type_name[];

class DecoderConfig {
public:
    DecoderConfig() {
        init();
    }

    inline DecoderType get_type() {
        return _type;
    }
    inline size_t get_epoch() {
        return _epoch;
    }
    inline void set_epoch(size_t epoch) {
        _epoch = epoch;
    }
    inline size_t get_score_thread_num() {
        return _score_thread_num;
    }
    inline void set_score_thread_num(size_t thread_num) {
        _score_thread_num = thread_num;
    }
    inline size_t get_decode_period() {
        return _decode_period;
    }
    inline DType get_alpha() {
        return _alpha;
    }
    inline void set_alpha(DType alpha) {
        _alpha = alpha;
    }

    inline DType get_recall() {
        return _recall;
    }

    inline DType get_select_ratio() {
        return _select_ratio;
    }

    inline TripletSelectType get_triplet_select_type() {
        return _triplet_select_type;
    }

    inline DType get_pos_neg_ratio() {
        return _pos_neg_ratio;
    }

    inline DType get_score_threshold() {
        return _score_threshold;
    }

    void read(const char* cfg_name);

protected:
    void init() {
        _type = DECODER;
        _epoch = 0;
        _score_thread_num = 0;
        _decode_period = 0;
        _alpha = 0.0f;
        _recall = -1.0f;
        _select_ratio = -1.0f;
        _pos_neg_ratio = -1.0f;
        _score_threshold = -1.0f;
        _triplet_select_type = UNKNOWN_TRIP_SEL_TYPE;
    }

private:
    DecoderType _type;
    size_t _epoch;
    size_t _score_thread_num;
    size_t _decode_period;
    DType _alpha;
    /* 召回率 */
    DType _recall;
    /* 按照比例选择样本 */
    DType _select_ratio;
    /* 正负样本所占的比例 */
    DType _pos_neg_ratio;
    /* 根据loss的大小挑选 */
    DType _score_threshold;
    TripletSelectType _triplet_select_type;
};

class DiscPeriodConfig : public PeriodConfig {
protected:
    int _model_update_period;

public:
    DiscPeriodConfig() : PeriodConfig() {
        _model_update_period = 10000;
    }
    ~DiscPeriodConfig() {}

    inline int model_update_period() const {
        return _model_update_period;
    }

    void read(std::string& cfg_lines);
};

class DiscNNConfig : public NNConfig {
protected:
    DiscPeriodConfig _disc_period_cfg;
    DecoderConfig _decoder_cfg;
    std::string _decoder_cfg_file;

    int _disc_score_thread_num;
    std::string _call_before_predict;
    std::string _call_after_predict;

    BaseReposConfig _dev_set_data_cfg;
    std::string _dev_set_data_cfg_file;
public:
    DiscNNConfig();
    ~DiscNNConfig() {}
    void read_config(const char* file);

    inline BaseReposConfig& dev_set_data_cfg() {
        return _dev_set_data_cfg;
    }

    inline std::string dev_set_data_cfg_file() {
        return _dev_set_data_cfg_file;
    }
    inline DiscPeriodConfig& disc_period_cfg() {
        return _disc_period_cfg;
    }

    inline int disc_score_thread_num() {
        return _disc_score_thread_num;
    }
    inline std::string& call_after_predict() {
        return _call_after_predict;
    }
    inline std::string& call_before_predict() {
        return _call_before_predict;
    }

    inline DecoderConfig& decoder_cfg() {
        return _decoder_cfg;
    }

};

}
} //namespace houyi

#endif
