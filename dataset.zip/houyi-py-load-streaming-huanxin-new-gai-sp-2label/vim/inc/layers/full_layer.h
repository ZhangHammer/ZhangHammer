/**
 * full_layer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-20
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_FULL_LAYER_H
#define HOUYI_TRAIN_PLATFORM_FULL_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class FullLayer : public Layer {
public:
    FullLayer(FullConfig& config);
    FullLayer(FullLayer* from);
    virtual ~FullLayer();

    Layer* clone();
    virtual void build_map(const char* prefix = NULL);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    inline DenseWeight* w() {
        return &_w;
    }
    inline DenseWeight* w_t() {
        return &_w_t;
    }
    inline DenseWeight* bias() {
        return &_bias;
    }
    inline DenseWeight* bias_t() {
        return &_bias_t;
    }
    inline DenseWeight* dw() {
        return &_dw;
    }
    inline DenseWeight* d_bias() {
        return &_d_bias;
    }
    inline FullConfig& config() {
        return _config;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_heter_model(std::ifstream& input);
    void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

    //virtual void setBatchSize(int batchSize);
protected:
    void set_device() {
        _in_trans_buf.set_device(gpu_device());
        _diff_trans_buf.set_device(gpu_device());
    }
protected:
    FullConfig _config;

    DenseWeight  _w, _dw;
    DenseWeight  _bias, _d_bias;

    /*  for inq */        
    DenseWeight  _w_t;   
    DenseWeight  _bias_t;

    Tensor<DType> _in_trans_buf;
    Tensor<DType> _diff_trans_buf;
};
}
}
#endif
