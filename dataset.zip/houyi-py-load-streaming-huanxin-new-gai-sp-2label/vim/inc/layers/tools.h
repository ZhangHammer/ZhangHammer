#ifndef HOUYI_TRAIN_PLATFORM_TOOLS_H
#define HOUYI_TRAIN_PLATFORM_TOOLS_H
#include "nn_config.h"

namespace houyi {
namespace train {

void set_train_size(int train_size);

int get_train_size();

void set_train_rank(int train_rank);

int get_train_rank();

// 时间, 格式如下(年月日时分秒): 20161124112460
void get_datetime(char*);

int get_max(int* data, int cnt);

void get_act_type(char* str, ActiveType& actType);

void get_layer_type(char* str, LayerType& lyType);

std::string get_layer_type_str(LayerType type);

void get_job_type(char* str, JobType& jobType);

int get_item_num(const char* str);

void get_item_from_str(char* str, const char* format,
                       int num, int itemSize, char* dest);
int exec_cmd(char*);

}
}
#endif
