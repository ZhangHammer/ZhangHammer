/**
 * ImagePoolingLayer.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-22
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_TRAIN_PLATFORM_IMAGE_POOLING_LAYER_H
#define HOUYI_TRAIN_PLATFORM_IMAGE_POOLING_LAYER_H

#include <vector>
#include <iostream>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class PoolingLayer : public Layer {
public:
    PoolingLayer(ImagePoolingConfig& cfg);
    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    void build_map(const char* prefix = NULL) {
    }

    Layer* clone() {
        return new PoolingLayer(_cfg);
    }

    void store_model(std::ofstream&, SPEECH_NN_W_TYPE) {}
    void read_model(std::ifstream&, SPEECH_NN_W_TYPE) {}

    void init();

private:
    PoolingType _pooling_type;
    PoolingDesc _pooling_desc;
    size_t _win_height;
    size_t _win_width;
    size_t _stride_height;
    size_t _stride_width;
    size_t _padding_width;
    size_t _padding_height;

    ImagePoolingConfig _cfg;
    bool _cal_mask = false;
    bool _skip_label = false;

    Tensor<int> _mask;
};
}
}
#endif
