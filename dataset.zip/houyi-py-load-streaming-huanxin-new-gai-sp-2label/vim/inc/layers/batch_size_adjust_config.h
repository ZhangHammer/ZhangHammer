/**
 * batch_size_adjust_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-12-12
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_BATCH_SIZE_ADJUST_CONFIG_H
#define HOUYI_LAYERS_BATCH_SIZE_ADJUST_CONFIG_H
#include "wind/wind.h"

namespace houyi {
namespace train {

enum BatchSizeAdjustType {
    FIXED_BS,
    STEP_BS,
    MULTI_STEP_BS,
    LINEAR_BS,
    MULTI_LINEAR_BS,
    UNKNOWN_BS
};

class BatchSizeAdjustCfg{
protected:
    /* for batch size adjust */
    /*
    *   - fixed: always return base_lr.
    *   - step: return base_lr * gamma ^ (floor(iter / step))
    *   - multiStep: similar to step but it allows non uniform steps defined by
    *     stepvalue
    *   - linear: return base_lr + gamma * (floor(iter / step))
    *   - multiLinear: similar to step but it allows non uniform steps defined by
    *     stepvalue
    */
    BatchSizeAdjustType _type;
    DType _gamma;
    int _step;
    std::vector<int> _step_value;

public:
    BatchSizeAdjustCfg();

    inline BatchSizeAdjustType get_type() {
        return _type;
    }
    inline void set_type(BatchSizeAdjustType type) {
        _type = type;
    }
    inline DType get_gamma() {
        return _gamma;
    }
    inline int get_step() {
        return _step;
    }
    inline std::vector<int>& get_step_value() {
        return _step_value;
    }

    void read(std::string& cfg_lines);
};

}
} //namespace houyi

#endif
