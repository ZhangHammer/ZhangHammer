/**
 * loss_layer.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_LAYERS_LOSS_LAYER_H
#define HOUYI_LAYERS_LOSS_LAYER_H

#include <vector>
#include <new>
#include "wind/wind.h"
#include "argument.h"
#include "layer.h"
#include "out_config.h"

namespace houyi {
namespace train {

class LossLayer : public Layer {
public:
    LossLayer(LossConfig& cfg) : Layer(cfg) {
        _cfg = cfg;
        _type = cfg.get_type();
        _cost_type = cfg.cost_type();
        _loss_type = cfg.loss_type();
        _loss = creat_loss(_loss_type, std::string("loss-layer"));
        _real_sample_count = 0;
        _cur_norm = 0.0f;
    }
    LossLayer(LossLayer* from) : Layer(from) {
        //new(this) LossLayer(from->config());
    }
    virtual ~LossLayer() {
        if (_loss != NULL) {
            delete _loss;
        }
    }
    virtual void layer_set(std::vector<IOPackage*>& inputs, int sample_num); 
    virtual void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

    inline LossConfig& config() {
        return _cfg;
    }
    virtual Layer* clone() = 0;
    virtual void build_map(const char* prefix = NULL) {
        _w_map.clear();
        _dw_map.clear();
    }
    inline LossType loss_type() {
        return _loss_type;
    }
    inline DType cur_norm() {
        return _cur_norm;
    }
    virtual void forward(Argument& args);
    virtual bool backward(Argument& in_arg, Argument& diff_arg);
    void inter_forward(std::vector<IOPackage*>& pack) {}
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}
    virtual Loss& get_cost_value() {
        return get_cost_value(_cost_type);
    }
    virtual Loss& get_cost_value(TGT_COST_TYPE type) = 0;
    virtual void cal_target(std::vector<IOPackage*>& output, std::vector<IOPackage*>& label,
                            std::vector<IOPackage*>& target) = 0;
    virtual void cal_loss(std::vector<IOPackage*>& output, std::vector<IOPackage*>& label,
                          std::vector<IOPackage*>& loss) = 0;
    ////////////////////////////////////////////////////////////////
    virtual void inter_forward(IOPackage* pack) {}
    virtual void inter_bprop_diff(IOPackage* in_pack, IOPackage* out_pack) {}
    virtual void inter_bprop_grad(IOPackage* in_pack) {}
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    virtual void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}
    size_t get_real_sample_num(Tensor<DType>& label, DType ignore_label);
    size_t get_real_sample_num(Tensor<DType>& label, Tensor<int>& mask, DType ignore_label);
    DType get_normalizer(LossNormMode norm_mode, Tensor<DType>& input,
                         DType real_sample_count, DType pre_fixed_normalizer);
protected:
    LossConfig _cfg;
    LayerType _type;
    TGT_COST_TYPE _cost_type;
    LossType _loss_type;
    Loss* _loss;
    std::vector<IOPackage*> _in_vec;
    std::vector<IOPackage*> _label_vec;
    std::vector<IOPackage*> _out_vec;

    size_t _real_sample_count;
    DType _cur_norm;
    std::vector<std::string> _batch_file_name;
};

class CrossEntryLossLayer : public LossLayer {
public:
    CrossEntryLossLayer(LossConfig& cfg) : LossLayer(cfg) {
        _cost_buf.set_device(gpu_device());
        _start_axis = cfg.get_start_axis();
        _end_axis = cfg.get_end_axis();
        _outer = 0;
        _channel = 0;
        _inner = 0;
        _cost_buf.set_device(GPU);
        _row_max_idx.set_device(GPU);
        _right_sample = 0;
        _total_sample = 0;
    }
    ~CrossEntryLossLayer() {}
    virtual void cal_target(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
    virtual void cal_loss(std::vector<IOPackage*>& output,
                          std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
    Loss& get_cost_value(TGT_COST_TYPE type);
    virtual Layer* clone() {
        return new CrossEntryLossLayer(_cfg);
    }
protected:
    Tensor<DType> _cost_buf;
    int _start_axis;
    int _end_axis;
    index_t _outer;
    index_t _channel;
    index_t _inner;

    Tensor<int> _row_max_idx;
    int _right_sample;
    int _total_sample;
};

class MSELossLayer : public LossLayer {
public:
    MSELossLayer(LossConfig& cfg) : LossLayer(cfg) {}
    ~MSELossLayer() {}
    virtual void cal_target(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
    virtual void cal_loss(std::vector<IOPackage*>& output,
                          std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
    Loss& get_cost_value(TGT_COST_TYPE type);
    virtual Layer* clone() {
        return new MSELossLayer(_cfg);
    }
};

class LRLossLayer : public LossLayer {
    public:
        LRLossLayer(LossConfig& cfg) : LossLayer(cfg) {
            _debug_count = 0;
        };
        ~LRLossLayer() {};
        virtual void cal_target(std::vector<IOPackage*>& output,
                std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
        virtual void cal_loss(std::vector<IOPackage*>& output,
                std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
        Loss& get_cost_value(TGT_COST_TYPE type);
        virtual Layer* clone() {
            return new LRLossLayer(_cfg);
        }
    private:
        size_t _debug_count;
};

class MixLRLossLayer : public LossLayer {
    public:
        MixLRLossLayer(LossConfig& cfg) : LossLayer(cfg) {
            _debug_count = 0;
            _count1.set_device(gpu_device());
            _count2.set_device(gpu_device());
            _value1.set_device(gpu_device());
            _value2.set_device(gpu_device());
            _value3.set_device(gpu_device());
            _value4.set_device(gpu_device());
        };
        ~MixLRLossLayer() {};
        virtual void cal_target(std::vector<IOPackage*>& output,
                std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
        virtual void cal_loss(std::vector<IOPackage*>& output,
                std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
        Loss& get_cost_value(TGT_COST_TYPE type);
        virtual Layer* clone() {
            return new MixLRLossLayer(_cfg);
        }
    private:
        size_t _debug_count;
        Tensor<int> _count1;
        Tensor<int> _count2;
        Tensor<DType> _value1;
        Tensor<DType> _value2;
        Tensor<DType> _value3;
        Tensor<DType> _value4;
};

} //namespace train
}

#endif
