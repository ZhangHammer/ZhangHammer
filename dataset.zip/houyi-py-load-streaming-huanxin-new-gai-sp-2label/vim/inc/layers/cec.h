/**
 * cec.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-8-25
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_CEC_H
#define HOUYI_TRAIN_PLATFORM_CEC_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include "glog/logging.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {
class StateMatrix {
public:
    Tensor<DType> _all_o;
    Tensor<DType>* _cur_o;
    Tensor<DType>* _pre_o;
    Tensor<DType> _error;
    std::vector<int> _len;
    Tensor<int>* _mask;

    StateMatrix() {
        _all_o.clear();
        _error.clear();
        _cur_o = NULL;
        _pre_o = NULL;
        _mask = NULL;
    }

    StateMatrix(int nSampNum, int nTbptt, int nColDim) {
        _all_o.resize(Dim(nTbptt + nSampNum, nColDim));
        _error.resize(Dim(nSampNum, nColDim));
        //_cur_o = new Tensor<DType>(_all_o.get_row(nTbptt), Dim(nSampNum, nColDim), gpu_device());
        //_pre_o = new Tensor<DType>(_all_o.get_row(0), Dim(nTbptt, nColDim), gpu_device());
        _cur_o = new Tensor<DType>(_all_o._buffer,
                                   Dim(nSampNum, nColDim), nColDim, _all_o.get_row(nTbptt));
        _pre_o = new Tensor<DType>(_all_o._buffer,
                                   Dim(nTbptt, nColDim), nColDim, _all_o.get_row(0));
    }

    ~StateMatrix() {
        if (_cur_o) {
            _cur_o->clear();
            delete _cur_o;
            _cur_o = NULL;
        }

        if (_pre_o) {
            _pre_o->clear();
            delete _pre_o;
            _pre_o = NULL;
        }

        if (_mask) {
            _mask->clear();
            delete _mask;
            _mask = NULL;
        }
    }

    void set_device() {
        _all_o.set_device(gpu_device());
        _error.set_device(gpu_device());
    }

    void set_sent_length(Tensor<int>* mask, int batch_size) {
        if (_mask == NULL) {
            _mask = new Tensor<int>(mask->get_size(), cpu_device());
        } else {
            _mask->resize(mask->get_size());
        }

        _mask->copy_from(*mask);

        _len.resize(batch_size);
        int len = mask->get_size(0) / batch_size;
        int* ptr = _mask->get_data() + (len - 1) * batch_size;

        // 使用 label 是否为 -1 来判断数据是否有效是不可靠的
        // 改为 判断 mask 是否为 0
        for (int b = 0; b < batch_size; b++) {
            _len[b] = 0;

            if ((int)ptr[b] != 0) {
                _len[b] = (len - 1) * batch_size + b;
            }
        }

        for (int i = len - 1; i > 0; i--) {
            int* ptr = _mask->get_data() + i * batch_size;

            for (int b = 0; b < batch_size; b++) {
                if (((int)ptr[b] == 0) && (ptr[b - batch_size] != 0)) {
                    _len[b] = (i - 1) * batch_size + b;
                }
            }
        }
    }

    void store_cur_out() {
        size_t s_row = _cur_o->get_height() - _pre_o->get_height();
        size_t e_row = _cur_o->get_height();
        _pre_o->copy_from(_cur_o->range_row(s_row, e_row));
    }

    void store_cur_out(int batch_size) {
        CHECK2(*std::max_element(_len.begin(), _len.end()) < (int)_cur_o->get_height());

        for (int b = 0; b < batch_size; b++) {
            if (_len[b] > 0) {
                _pre_o->range_row(b, b + 1).copy_from(_cur_o->range_row(_len[b] - 1, _len[b]));
            } else {
                _pre_o->range_row(b, b + 1).zero();
            }
        }
    }

    void reset(int sentIdx, int step) {
        for (size_t i = sentIdx; i < _pre_o->get_height(); i += step) {
            _pre_o->range_row(i, i + 1, 1).zero();
        }
    }
    void reset() {
        _pre_o->zero();
    }

    void resize(int nSampNum, int nTbptt, int nColDim) {
        _all_o.resize(Dim(nSampNum + nTbptt, nColDim));
        _error.resize(Dim(nSampNum, nColDim));

        if (_cur_o) {
            _cur_o->clear();
            delete _cur_o;
            _cur_o  = NULL;
        }

        if (_pre_o) {
            _pre_o->clear();
            delete _pre_o;
            _pre_o  = NULL;
        }

        if (nSampNum * nTbptt != 0) {
            _cur_o = new Tensor<DType>(_all_o._buffer,
                                       Dim(nSampNum, nColDim), nColDim, _all_o.get_row(nTbptt));
            _pre_o = new Tensor<DType>(_all_o._buffer,
                                       Dim(nTbptt, nColDim), nColDim, _all_o.get_row(0));
        }
    }

    void add_diff(Tensor<DType>& mDiff, DType alpha = 1.0f, DType beta = 1.0f) {
        _error.elem_add(_error, mDiff, alpha, beta);
    }
};

//class Gate {
//public:
//    int    _sub_seq_size;
//    int    _batch_size;
//    int    _tbptt,  _update_tt;
//    size_t _feat_dim, _cell_dim, _rec_dim;
//
//    DType _learn_rate;
//    DenseWeight _w_x, _w_r, _w_c, _bias;
//
//    DenseWeight _dw_x, _dw_r, _dw_c, _d_bias;
//    DenseWeight _mdw_x, _mdw_r, _mdw_c, _md_bias;
//    StateMatrix _state_oe;
//    Tensor<DType> _cur_e;
//    Tensor<DType> _cur_input_forget;
//
//    bool     _need_update;
//    Tensor<DType> _time_diff;
//
//    Gate(int Tbptt, size_t featDim,
//            size_t cellDim, size_t outDim, bool need_update = true);
//    void copy_from(Gate *from);
//
//    int  copy_out(std::vector<BaseWeight*> &buf_vec,
//            SPEECH_NN_W_TYPE t, int start_idx);
//    int  copy_in(std::vector<BaseWeight*> &buf_vec,
//            SPEECH_NN_W_TYPE t, int start_idx);
//
//    void zero_buf(SPEECH_NN_W_TYPE t);
//
//    ~Gate();
//    void init_weight(DType constV);
//    void init_weight(DType lo, DType hi);
//    void set_learn_rate(DType learn_rate) {
//        _learn_rate = learn_rate;
//    }
//    void set_batch_size(int sub_seq_size, int batch_size);
//    void scale_momentum(DType momentum);
//
//    void input_forward(const Tensor<DType> & input);
//    void time_forward(int t, Tensor<DType> &Oc, Tensor<DType> &Or);
//    void backward_prop(int t, Tensor<DType> &Es, Tensor<DType> & Or,
//            Tensor<DType>& Oc, Tensor<DType>& gOc, const Tensor<DType> & x, int gate_type);
//    void time_backward(int t, Tensor<DType> &Ec,
//            Tensor<DType> &gOc, Tensor<DType> &Oc, Tensor<DType> &Or, int gate_type);
//    void update(const Tensor<DType> &x, DType threshold, DType l2Penalty);
//    bool clip_gradient(DType threshold, DType threshold_ratio);
//    void clear_gradient();
//    void cal_time_gradient(Tensor<DType> &Oc, Tensor<DType> &Or);
//    void cal_bprop_gradient(Tensor<DType> &Or);
//    void init_weight(bool random, DType constV);
//
//    inline DenseWeight*  w_r() {
//        return &_w_r;
//    }
//    inline DenseWeight*  w_c() {
//        return &_w_c;
//    }
//    inline DenseWeight*  w_x() {
//        return &_w_x;
//    }
//    inline DenseWeight*  bias() {
//        return &_bias;
//    }
//    inline DenseWeight*  dw_r() {
//        return &_dw_r;
//    }
//    inline DenseWeight*  dw_c() {
//        return &_dw_c;
//    }
//    inline DenseWeight*  dw_x() {
//        return &_dw_x;
//    }
//    inline DenseWeight*  d_bias() {
//        return &_d_bias;
//    }
//};
//
//class OutGate : public Gate {
//public:
//    OutGate(int Tbptt, size_t featDim, size_t cellDim, size_t recDim, bool need_update = true)
//        : Gate(Tbptt, featDim, cellDim, recDim, need_update) {}
//    void time_forward(int t, Tensor<DType> &Oc, Tensor<DType> &Or);
//    void backward_prop(int t, Tensor<DType> &Em, Tensor<DType> &Ohc,
//            Tensor<DType> &Or, Tensor<DType> &Oc, const Tensor<DType> &x);
//    void time_backward(int t, Tensor<DType> &Em,
//            Tensor<DType> &hcO, Tensor<DType> &Or, Tensor<DType> &Oc);
//    void update(const Tensor<DType> &Oc, const Tensor<DType> &x,
//            DType threshold, DType l2Penalty);
//    void cal_time_gradient(Tensor<DType> &Oc, Tensor<DType> &Or);
//    void cal_bprop_gradient(Tensor<DType> &Or);
//};
//
//class Cells {
//public:
//    Cells(int Tbptt, size_t featDim, size_t cellDim, size_t recDim, bool need_update = true);
//    void copy_from(Cells *from);
//    int  copy_out(std::vector<BaseWeight*> &buf_vec,
//            SPEECH_NN_W_TYPE t, int start_idx);
//    int  copy_in(std::vector<BaseWeight*> &buf_vec,
//            SPEECH_NN_W_TYPE t, int start_idx);
//    void zero_buf(SPEECH_NN_W_TYPE t);
//    ~Cells();
//    void init_weight(DType constV);
//    void init_weight(DType lo, DType hi);
//    void set_batch_size(int sub_seq_size, int batch_size);
//    void scale_momentum(DType momentum);
//
//    void squash_out(int t);
//
//    void input_forward(const Tensor<DType>& input);
//    void time_forward(int t, Tensor<DType>& o_r, Tensor<DType>& o_i, Tensor<DType>& o_f);
//    void time_forward(int t, Tensor<DType>& o_r, Tensor<DType>& o_i);
//
//    void backward_prop(int t, Tensor<DType> &Es,
//            Tensor<DType> &Oi, Tensor<DType> & Or, const Tensor<DType> &x);
//    void time_backward(int t, Tensor<DType> &Em, Tensor<DType> &Eo,
//            Tensor<DType> &Oo, Tensor<DType> &Oi, Tensor<DType> &Ohc,
//            Tensor<DType> &Woc, Tensor<DType> &Ebc, Tensor<DType> &Or);
//    void update(const Tensor<DType> &x, DType threshold, DType l2Penalty);
//    bool clip_gradient(DType threshold, DType threshold_ratio);
//    void clear_gradient();
//    void cal_time_gradient(Tensor<DType> &Or);
//    void cal_bprop_gradient(Tensor<DType> &Or);
//    void reset(int idx);
//
//    inline DenseWeight*  w_r() {
//        return &_w_r;
//    }
//    inline DenseWeight*  w_x() {
//        return &_w_x;
//    }
//    inline DenseWeight*  bias() {
//        return &_bias;
//    }
//    inline DenseWeight*  dw_r() {
//        return &_dw_r;
//    }
//    inline DenseWeight*  dw_x() {
//        return &_dw_x;
//    }
//    inline DenseWeight*  d_bias() {
//        return &_d_bias;
//    }
//
//    int      _batch_size;
//    int      _sub_seq_size;
//    int      _tbptt, _update_tt;
//    DType   _learn_rate;
//    DenseWeight _w_x, _w_r, _bias;
//
//    DenseWeight _dw_x,  _dw_r, _d_bias;
//    DenseWeight _mdw_x, _mdw_r, _md_bias;
//    StateMatrix _stateoe_g, _state_oe;
//    Tensor<DType> _cur_e, _buf_e;
//    size_t   _feat_dim, _cell_dim, _rec_dim;
//
//    // for squash output
//    Tensor<DType> _o_max, _o_min;
//    Tensor<DType> _o_max_sum, _o_min_sum;
//    DType   _max, _min;
//    size_t   _max_min_counter;
//    size_t   _max_min_sentence_number;
//    size_t   _max_min_sentence_counter;
//
//    bool     _need_update;
//    Tensor<DType> _forget_output;
//
//    Tensor<DType> _time_diff;
//};

}
}
#endif
