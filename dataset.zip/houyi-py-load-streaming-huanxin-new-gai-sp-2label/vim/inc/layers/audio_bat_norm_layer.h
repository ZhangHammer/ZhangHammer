/**
 * audio_bat_norm_layer.h
 * Author: chencheng19 (chencheng19@baidu.com)
 * Created on: 2017-11-9
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_AUDIO_BAT_NORM_LAYER_H
#define HOUYI_TRAIN_PLATFORM_AUDIO_BAT_NORM_LAYER_H
#include <vector>
#include <iostream>
#include "wind/wind.h"
#include "weight.h"
#include "layer_config.h"
#include "layer.h"
#include "argument.h"

namespace houyi {
namespace train {

class AudioBatNormalLayer : public Layer {
public:
    AudioBatNormalLayer(BatNormConfig& config);
    AudioBatNormalLayer(AudioBatNormalLayer* from);
    virtual ~AudioBatNormalLayer();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack);

    void gauss_init(DType mean, DType stdv);
    void init_weight(const ModelInitConfig& global_cfg);
    void init_weight(const ModelInitConfig& global_cfg, std::vector<Layer*>& layers);

    virtual void read_initial_mean_var();
    virtual void read_initial_mean_var(std::string bn_file_prefix);

    virtual void build_map(const char* prefix = NULL);

    Layer* clone() {
        return new AudioBatNormalLayer(this);
    }

    char* global_file_name() {
        return _global_mean_var;
    }

    DenseWeight& gamma() {
        return _gamma;
    }

    DenseWeight& gamma_t() {
        return _gamma_t;
    }

    DenseWeight& beta() {
        return _beta;
    }

    DenseWeight& beta_t() {
        return _beta;
    }

    BatNormConfig& config() {
        return _config;
    }
    virtual void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_heter_model(std::ifstream& input);
    void read_inq_model(std::ifstream& input, SPEECH_NN_W_TYPE t);

    void store_mean_var();

    Tensor<DType>* mean_vec() {
        return &_mean_vec;
    }
    Tensor<DType>* var_vec() {
        return &_var_vec;
    }
protected:
    void set_device(void) {
        _mean_vec.set_device(gpu_device());
        _var_vec.set_device(gpu_device());
        _run_mean.set_device(gpu_device());
        _run_var.set_device(gpu_device());
        _statis_mean_vec.set_device(gpu_device());
        _statis_var_vec.set_device(gpu_device());
    }

    void read_initial_mean_var_em1(const char* file_name);
    void read_initial_mean_var_em0(const char* file_name);
    void inter_forward_em1(std::vector<IOPackage*>& in_pack);
    void inter_forward_em0(std::vector<IOPackage*>& in_pack);

    int get_real_frame_num(IOPackage* in_pack);

protected:
    BatNormConfig _config;

    DenseWeight _gamma;
    DenseWeight _d_gamma;
    DenseWeight _beta;
    DenseWeight _d_beta;

    // for inq
    DenseWeight _gamma_t;
    DenseWeight _beta_t;

    Tensor<DType> _mean_vec;
    Tensor<DType> _var_vec;

    Tensor<DType> _run_mean;
    Tensor<DType> _run_var;

    Tensor<DType> _statis_mean_vec;
    Tensor<DType> _statis_var_vec;

    Tensor<int>* _mask;

    char* _global_mean_var; // initial meanVec and varVec
    int _real_frame_num;
    DType _epsilon;
    /* ut = _eta * ut + (1 - _eta) * ut-1
     * vt = _eta * vt + (1 - _eta) * vt-1*/
    DType _eta;

    DType _counter;
    uint64_t _store_item;

    int _frame_dim;
    int _store_mean_var_peroid;
    DType _moving_average_fraction;
    pid_t _tid;
    pid_t _pid;
};

}
}
#endif
