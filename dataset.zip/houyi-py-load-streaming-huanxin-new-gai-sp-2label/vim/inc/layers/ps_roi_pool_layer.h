//by zzxfl 2017.05.03
#ifndef HOUYI_LAYERS_PS_ROI_POOL_LAYER_H
#define HOUYI_LAYERS_PS_ROI_POOL_LAYER_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class PSROIPoolLayer : public Layer {
public:
    PSROIPoolLayer(PSROIPoolConfig& cfg);
    virtual void inter_forward(IOPackage* in_pack) {
        CHECK(false, "empty inter_forwatd is called");
    }
    virtual void inter_bprop_diff(IOPackage* in_pack, IOPackage* out_pack) {
        CHECK(false, "empty inter_bprop_diff is called");
    }

    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);

    void build_map(const char* prefix = NULL) {
    }

    Layer* clone() {
        return new PSROIPoolLayer(_cfg);
    }

    void store_model(std::ofstream&, SPEECH_NN_W_TYPE) {}
    void read_model(std::ifstream&, SPEECH_NN_W_TYPE) {}

    void init();
    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

protected:
    void set_device() {
        _max_channel.set_device(GPU);
    }

private:
    PSROIPoolConfig _cfg;
    PSROIPoolingDesc _ps_roi_pool_dec;

    DType _spatial_scale;
    int _output_maps;
    int _group_size;
    Tensor<int> _max_channel; // TODO
};

}
}

#endif
