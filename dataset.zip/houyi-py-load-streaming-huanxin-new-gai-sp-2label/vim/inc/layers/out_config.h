/**
 * out_config.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-11-8
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_OUT_CONFIG_H
#define HOUYI_TRAIN_PLATFORM_OUT_CONFIG_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

enum OutType {O_SINGLE_SOFTMAX, O_MULTI_SOFTMAX,
              O_CTC_SOFTMAX, O_MIX_SOFTMAX, O_LINEAR, O_MIX_LINEAR, O_UNKNOWN_TYPE
             };
//todo remove
enum PoolType {POOLING_MAX, POOLING_TARGET, POOLING_AVG, POOLING_UNKNOWN_TYPE};

class OutputConfig {
protected:
    OutType    _o_type;
    //batch size
    int        _sent_num;
    int        _o_layer_num;
    std::vector<int>       _o_layer_ids;
    std::vector<float>     _o_scalars;
    Tensor<DType>* _prior;
public:
    OutputConfig() {
        _o_type = O_UNKNOWN_TYPE;
        _o_layer_num = 0;
        _o_layer_ids.clear();
        _o_scalars.clear();
        _prior = NULL;
    }

    virtual ~OutputConfig() {
        _o_layer_ids.clear();
        _o_scalars.clear();

        if (_prior) {
            delete _prior;
            _prior = NULL;
        }
    }
    static OutputConfig* create(OutType);
    static OutputConfig* read(std::ifstream& input);

    void set_out_info(int n, int* ids, DType* scalars);

    inline Tensor<DType>* prior() const {
        return _prior;
    }

    inline int bat_sent_num() const {
        return _sent_num;
    }

    inline void bat_sent_num(int sent_num) {
        _sent_num = sent_num;
    }

    inline int o_layer_num() const {
        return _o_layer_num;
    }
    inline const std::vector<int>& o_layer_ids() const {
        return _o_layer_ids;
    }
    inline const std::vector<float>& o_scalars() const {
        return _o_scalars;
    }
    inline OutType o_type() const {
        return _o_type;
    }
    void read_prior(const char* prior_name);
    virtual void read_config(std::string& cfg_line);
};

class SingleSoftMaxCfg : public OutputConfig {
public:
    SingleSoftMaxCfg() : OutputConfig() {
        _o_type = O_SINGLE_SOFTMAX;
    }
};

class MultiSoftMaxCfg : public OutputConfig {
public:
    MultiSoftMaxCfg() : OutputConfig() {
        _o_type = O_MULTI_SOFTMAX;
    }
};

class CtcSoftMaxCfg : public OutputConfig {
public:
    CtcSoftMaxCfg() : OutputConfig() {
        _o_type = O_CTC_SOFTMAX;
    }

    virtual void read_config(std::string& cfg_line) {
        OutputConfig::read_config(cfg_line);
    }
};

class MixSoftMaxCfg : public OutputConfig {
private:
    int _pooling_out_dim;
    int _pooling_size;
    PoolType _pooling_type; // max-pooling or avg-pooling
public:
    MixSoftMaxCfg() : OutputConfig() {
        _o_type = O_MIX_SOFTMAX;
    }

    inline PoolType pooling_type() const {
        return _pooling_type;
    }

    inline int pooling_size() const {
        return _pooling_size;
    }

    inline int pooling_out_dim() const {
        return _pooling_out_dim;
    }
    virtual void read_config(std::string& cfg_line);
};

class LinearOutCfg : public OutputConfig {
public:
    LinearOutCfg() : OutputConfig() {
        _o_type = O_LINEAR;
    }
    virtual void read_config(std::string& cfg_line) {
        OutputConfig::read_config(cfg_line);
    }
};

class MixLinearOutCfg : public OutputConfig {
private:
    int _pooling_size;
    int _pooling_out_dim;
public:
    MixLinearOutCfg() : OutputConfig() {
        _o_type          = O_MIX_LINEAR;
        _pooling_size    = 0;
        _pooling_out_dim = 0;
    }
    inline int pooling_size() const {
        return _pooling_size;
    }
    inline int pooling_out_dim() const {
        return _pooling_out_dim;
    }
    virtual void read_config(std::string& cfg_line);
};
}
} //namespace houyi
#endif
