/**
 * layer_config.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-11-26
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_LAYER_CONFIG_H
#define HOUYI_TRAIN_PLATFORM_LAYER_CONFIG_H
#include <string.h>
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "out_config.h"
#include "job.h"
#include "loss_store.h"
#include "global_updater_config.h"
#include "model_init_config.h"
#include "loss_norm_mode.h"
#include "audio_roi_pool_ops.h"
namespace houyi {
namespace train {

enum ActiveType {
    ACT_LINEAR,
    ACT_SIGMOID,
    ACT_TANH,
    ACT_RELU,
    ACT_MAXOUT,
    ACT_LOGRELU,
    ACT_UNKNOWN
};

enum BitQuantAlgo {
    QUANT_BIT,
    QUANT_GREEDY,
    QUANT_FIXED,
    QUANT_UNKNOWN
};

enum LayerType {
    FULL,
    LSTM,
    CONV,
    BAT_NORM,
    STATISC,
    LINEAR,
    IMAGE_CONV,
    IMAGE_POOL,
    SOFTMAX_WITH_LOSS,
    LOSS_CE, LOSS_MSE,
    LOSS_CTC,
    DROP_OUT,
    IMAGE_BAT_NORM,
    NORM2,
    LOSS_TRIPLET,
    ROI_POOL,
    SOFTMAX_NORM,
    RESHAPE,
    PYTHON,
    LOSS_SMOOTH_L1,
    ANCHOR_TARGET,
    PROPOSAL,
    PROPOSAL_TARGET,
    FASTER_RCNN_ACU,
    PS_ROI_POOL,
    RFCN_ACU,
    LOSS_SMOOTH_OHEM_L1,
    TRANSPOSE,
    EXPAND,
    SKIP,
    BOX_ANNOTATOR_OHEM,
    DATA_LAYER,
    BAT_RENORM,
    SPLIT,
    GRU,
    REDIM,
    FAST_GRU,
    LOSS_FOCAL,
    AUDIO_DELTA,
    AUDIO_SPLICE,
    BIT_QUANT,
    AUDIO_ROI_POOL,
    IMAGE_CONV_QUANT,
    GLOBAL_CMVN,
    LOSS_LR,
    LOSS_MIX_LR,
    UNKNOWN_LAYER
};

bool is_loss_layer(LayerType type);

enum TGT_COST_TYPE {
    TGT_ACU,
    TGT_ERR,
    CLASSIFY_ACU,
    CLASSIFY_ERR,
    TGT_UNKNOWN
};

enum OPERATOR_TYPE {
    OP_ADD, OP_MAX, OP_AVG,
    OP_ELEM_MUL, OP_ELEM_DIV,
    OP_CHANNEL_APPEND,
    OP_COL_APPEND, OP_ROW_APPEND,
    OP_CROSS_APPEND,
    OP_ROW_ALTERNATE_APPEND,
    OP_UNKNOWN
};

enum ImageConvAlgoSeekerType {
    GET_SEEKER = 0,
    FIND_SEEKER = 1
};

class UpdaterConfig {
public:
    UpdaterConfig() {
        init();
    }
    UpdaterConfig(const std::string& type) {
        init();
        _type = type;
    }
    ~UpdaterConfig() {}
    void init() {
        /* 默认值小于0,使用全局设置，当大于等于0时表示变量被设置，使用局部设置 */
        _type = "unknown";

        _learn_rate = -1.0f;
        _momentum  = -1.0f;
        _l2_penalty = -1.0f;
        _threshold = -1.0f;
        _threshold_ratio = -1.0f;

        _beta1 = -1.0f;
        _beta2 = -1.0f;
        _lambda = -1.0f;
        _alpha = -1.0f;

        _rms_gamma = -1.0f;
        _rms_eta = -1.0f;
    }

    void read(std::string& cfg_line);

    inline const std::string& type() const {
        return _type;
    }
    inline DType learn_rate() const {
        return _learn_rate;
    }

    inline DType momentum() const {
        return _momentum;
    }

    inline DType l2_penalty() const {
        return _l2_penalty;
    }

    inline DType threshold() const {
        return _threshold;
    }
    inline DType threshold_ratio() const {
        return _threshold_ratio;
    }

    inline DType get_beta1() const {
        return _beta1;
    }
    inline DType get_beta2() const {
        return _beta2;
    }
    inline DType get_lambda() const {
        return _lambda;
    }
    inline DType get_alpha() const {
        return _alpha;
    }
    inline DType get_rms_gamma() const {
        return _rms_gamma;
    }
    inline DType get_rms_eta() const {
        return _rms_eta;
    }
protected:
    std::string     _type;

    DType     _l2_penalty;

    /* sgd */
    DType    _threshold;
    DType     _threshold_ratio;
    DType     _learn_rate;
    DType     _momentum;

    /* adam */
    DType _beta1;
    DType _beta2;
    DType _lambda;
    DType _alpha;

    /* rms */
    DType _rms_gamma;
    DType _rms_eta;
};

class LayerConfig {
protected:
    int  _layer_id; //this variable cannot be initialized from the configuration file
    std::string _layer_name;
    std::vector<std::string> _input_keys;
    std::vector<std::string> _output_keys;
    std::vector<std::string> _label_key;
    std::vector<std::string> _feat_desc_keys;

    LayerType  _type;
    ActiveType _act;
    UpdaterConfig _up_cfg;
    GlobalUpdaterCfg _global_up_cfg;

    ModelInitConfig _model_init_cfg;
    ModelInitConfig _global_model_init_cfg;

    int _batch_size;
    int _sub_seq_size;
    bool _is_reversal;

    bool _has_bias;
    bool _need_update;
    bool _read;
    //打印多少layer的中间结果
    int _layer_result_output_num;

    /* 是否做后向传播 暂时只有smooth_l1_loss支持*/
    std::vector<int> _bp_down;

    JobType _job_type;
    JobType _global_job_type;

    bool _inq;
    std::vector<DType> _inq_ratio;
    int _inq_bit;

    bool _weight_quantize;

    bool _weight_quant_transpose;

    bool _weight_fixed_transpose;

    size_t _weight_quant_bits;

    size_t _intl_quant_bits;

    std::vector<DType> _intl_quant_alpha;

    BitQuantAlgo _intl_quant_algo;

    /*
     *中英文混合训练时会在第一层配置两个feature key，
     *但是同时只有一个有效，需要将_feature_share_input设置为true
     */
    bool _feature_share_input;
public:
    LayerConfig();
    virtual ~LayerConfig() {
    }

    std::vector<DType> intl_quant_alpha() {
        return _intl_quant_alpha;
    }

    virtual void read_config(std::string& cfg_line);
    static LayerConfig* creat_layer_cfg(LayerType type);
    static LayerConfig* read(std::ifstream& input);
    virtual void set_batch_size(int batch_size) {
        _batch_size   = batch_size;
    }
    virtual int get_batch_size() {
        return _batch_size;
    }
    virtual void set_batch_size(int sub_seq_size, int batch_size) {
        _sub_seq_size = sub_seq_size;
        _batch_size   = batch_size;
    }
    inline void  set_layer_id(int id) {
        _layer_id = id;
    }
    inline int layer_id() {
        return _layer_id;
    }

    inline std::string& layer_name() {
        return _layer_name;
    }

    inline int input_num() {
        return (int)_input_keys.size();
    }

    inline std::string& input_key(int i) {
        return _input_keys[i];
    }

    inline std::vector<std::string>& input_keys() {
        return _input_keys;
    }
    inline int output_num() {
        return (int)_output_keys.size();
    }

    inline std::string& output_key(int i) {
        return _output_keys[i];
    }

    inline size_t get_output_idx(std::string key) {
        for (size_t i = 0; i < _output_keys.size(); i++) {
            if (_output_keys[i] == key) {
                return i;
            }
        }

        CHECK2(false);
        return -1;
    }

    inline std::vector<std::string>& output_keys() {
        return _output_keys;
    }

    inline std::vector<std::string>& get_feat_desc_keys() {
        return _feat_desc_keys;
    }

    inline LayerType type() {
        return _type;
    }
    inline ActiveType act() {
        return _act;
    }
    inline const UpdaterConfig& up_cfg() {
        return _up_cfg;
    }
    inline const GlobalUpdaterCfg& get_global_up_cfg() {
        return _global_up_cfg;
    }
    inline void set_global_up_cfg(GlobalUpdaterCfg& up_cfg) {
        _global_up_cfg = up_cfg;
    }
    inline const ModelInitConfig& get_model_init_cfg() {
        return _model_init_cfg;
    }
    inline const ModelInitConfig& get_global_model_init_cfg() {
        return _global_model_init_cfg;
    }
    inline void set_global_model_init_cfg(ModelInitConfig& cfg) {
        _global_model_init_cfg = cfg;
    }
    inline int sub_seq_size() {
        return _sub_seq_size;
    }
    inline bool has_bias() {
        return _has_bias;
    }
    inline bool need_update() {
        return _need_update;
    }
    inline bool read() {
        return _read;
    }
    inline bool is_reversal() {
        return _is_reversal;
    }
    inline void set_update(bool need) {
        _need_update = need;
    }
    inline JobType job_type() {
        return _job_type;
    }
    inline JobType global_job_type() {
        return _global_job_type;
    }
    inline void set_global_job_type(JobType job_type) {
        _global_job_type = job_type;
    }
    inline int layer_result_output_num() {
        return _layer_result_output_num;
    }
    inline std::vector<std::string>& get_label_key() {
        return _label_key;
    }
    inline std::string& get_label_key(int idx) {
        return _label_key[idx];
    }

    inline std::vector<int>& get_bp_down() {
        return _bp_down;
    }

    virtual void set_global_cfg_file(std::string& file) {
        return;
    }
    inline void set_inq(bool inq) {
        _inq = inq; 
    }
    inline bool get_inq(void) {
        return _inq;
    }
    inline void set_inq_ratio(std::vector<DType> &ratio) {
        _inq_ratio = ratio;
    }
    inline std::vector<DType> &get_inq_ratio(void) {
        return _inq_ratio;
    }

    inline void set_inq_bit(int &bit) {
        _inq_bit = bit;
    }
    inline int &get_inq_bit(void) {
        return _inq_bit; 
    } 
    inline bool get_feature_share_input() {
        return _feature_share_input;
    }
    inline bool weight_quantize() {
        return _weight_quantize;
    }
    inline size_t weight_quant_bits() {
        return _weight_quant_bits;
    }
    inline size_t intl_quant_bits() {
        return _intl_quant_bits;
    }
    inline BitQuantAlgo intl_quant_algo() {
        return _intl_quant_algo;
    }
    inline bool weight_quant_transpose() {
        return _weight_quant_transpose;
    }
    inline bool weight_fixed_transpose() {
        return _weight_fixed_transpose;
    }
};

class FullConfig : public LayerConfig {
protected:
    int _output_dim;
    int _insert_model_col = -1;
    int _insert_model_len = -1;
public:
    FullConfig();
    void read_config(std::string& cfg_line);
    inline int get_output_dim() {
        return _output_dim;
    }
    inline int get_insert_model_col() {
        return _insert_model_col;
    }
    inline int get_insert_model_len() {
        return _insert_model_len;
    }
};

class ConvConfig : public LayerConfig {
protected:
    //int _in_dim;  int _out_dim;
    int _group_num;
    int _filter_size;
    int _filter_num;
    int _fbank_dim;
    int _temporal_dim;
    int _conv_out_dim;
    int _delta;

    int* _conv_start_pos;
    int* _conv_end_pos;
    int* _conv_size;

    int  _pooling_size;
    int* _pooling_pivot;
    int  _pooling_out_dim;

public:
    ConvConfig();
    ~ConvConfig();
    void read_config(std::string& cfg_line);
    inline int group_num() {
        return _group_num;
    }
    inline int filter_size() {
        return _filter_size;
    }
    inline int filter_num() {
        return _filter_num;
    }
    inline int fbank_num() {
        return _fbank_dim;
    }
    inline int temporal_dim() {
        return _temporal_dim;
    }
    inline int conv_out_dim() {
        return _conv_out_dim;
    }
    inline int delta() {
        return _delta;
    }
    inline int pooling_size() {
        return _pooling_size;
    }
    inline int pooling_out_dim() {
        return _pooling_out_dim;
    }
    inline int  conv_size(int idx) {
        return _conv_size[idx];
    }
    inline int* conv_size() {
        return _conv_size;
    }
    inline int* conv_start() {
        return _conv_start_pos;
    }
    inline int* conv_end() {
        return _conv_end_pos;
    }
    inline int* pooling_pivot() {
        return _pooling_pivot;
    }
    ConvConfig& operator=(ConvConfig& cfgIn);

    inline void conv_pos(int* sPos, int* ePos, int* size) {
        CHECK2(sPos && ePos && size);
        memcpy(sPos, _conv_start_pos, sizeof(int) * _group_num);
        memcpy(ePos, _conv_end_pos, sizeof(int) * _group_num);
        memcpy(size, _conv_size, sizeof(int) * _group_num);
    }

    inline void pooling(int* pivot, int& pSize, int& pOutDim) {
        CHECK2(pivot);
        //memcpy(pivot, _pooling_pivot, sizeof(int) * _pooling_size);
        memcpy(pivot, _pooling_pivot, sizeof(int) * _pooling_out_dim);
        pSize = _pooling_size;
        pOutDim = _pooling_out_dim;
    }
};

class GruConfig : public LayerConfig {
public:
    GruConfig() : LayerConfig(){
        _type = GRU;
    }
    void read_config(std::string& cfg_line);

    inline int out_dim() {
        return _out_dim;
    }

    inline int tbptt() {
        return _tbptt;
    }

    inline int updatett() {
        return _updatett;
    }

    inline ActiveType reset_act() {
        return _reset_act;
    }

    inline ActiveType update_act() {
        return _update_act;
    }

    inline ActiveType state_act() {
        return _state_act;
    }

    inline DType threshold() {
        return _up_cfg.threshold();
    }

    inline DType threshold_ratio() {
        return _up_cfg.threshold_ratio();
    }

    inline int mean_statistic_num() {
        return _mean_statistic_num;
    }

    inline int skip_num() {
        return _skip_num;
    }

protected:
    int _out_dim = 0;
    int _tbptt = 1;
    int _updatett = 1;
    int _skip_num = 1;
    
    ActiveType _reset_act = ACT_SIGMOID;
    ActiveType _update_act = ACT_SIGMOID;
    ActiveType _state_act = ACT_TANH;

    int _mean_statistic_num = 0;
};

class FastGruConfig : public LayerConfig {
public:
    FastGruConfig() : LayerConfig(){
        _type = FAST_GRU;
    }
    void read_config(std::string& cfg_line);

    inline int out_dim() {
        return _out_dim;
    }

    inline int tbptt() {
        return _tbptt;
    }

    inline int updatett() {
        return _updatett;
    }

    inline ActiveType reset_act() {
        return _reset_act;
    }

    inline ActiveType update_act() {
        return _update_act;
    }

    inline ActiveType state_act() {
        return _state_act;
    }

    inline DType threshold() {
        return _up_cfg.threshold();
    }

    inline DType threshold_ratio() {
        return _up_cfg.threshold_ratio();
    }

    inline int mean_statistic_num() {
        return _mean_statistic_num;
    }

    inline int skip_num() {
        return _skip_num;
    }

protected:
    int _out_dim = 0;
    int _tbptt = 1;
    int _updatett = 1;
    int _skip_num = 1;
    
    ActiveType _reset_act = ACT_SIGMOID;
    ActiveType _update_act = ACT_SIGMOID;
    ActiveType _state_act = ACT_TANH;

    DType _threshold = -1.0;
    DType _threshold_ratio = -1.0;
    int _mean_statistic_num = 0;
};

class LstmConfig : public LayerConfig {
protected:
    int _cell_dim;
    int _rec_dim;
    int _prj_dim;
    int _output_dim;

    // skip num maybe different for different layer
    int _skip_num;

    ActiveType _rec_act;
    ActiveType _mid_act;
    int _pooling_size;
    bool _no_forget_gate;

    int _tbptt;
    int _updatett;
    //int subSeqSize_;
    bool _is_append;    //config for bi-lstm layer

    DType _threshold_ratio;
    int    _mean_statistic_num;
    int    _error_statistic_num;
    int    _cec_o_statistic_num;
    DType _dr_threshold, _dc_threshold;
    DType _cec_out_limit_lo, _cec_out_limit_hi;
    bool _drop_gradient;
public:
    LstmConfig();
    void read_config(std::string& cfg_line);
    inline int skip_num() {
        return _skip_num;
    }
    inline int get_output_dim() {
        return _output_dim;
    }
    inline int cell_dim() {
        return _cell_dim;
    }
    inline int rec_dim() {
        return _rec_dim;
    }
    inline int prj_dim() {
        return _prj_dim;
    }
    inline ActiveType rec_act() {
        return _rec_act;
    }
    inline ActiveType mid_act() {
        return _mid_act;
    }
    inline int pooling_size() {
        return _pooling_size;
    }
    inline int no_forget() {
        return _no_forget_gate;
    }

    inline int tbptt() {
        return _tbptt;
    }
    inline int updatett() {
        return _updatett;
    }
    inline DType threshold_ratio() {
        return _threshold_ratio;
    }
    inline DType cec_out_limit_lo() {
        return _cec_out_limit_lo;
    }
    inline DType cec_out_limit_hi() {
        return _cec_out_limit_hi;
    }
    inline DType dr_threshold() {
        return _dr_threshold;
    }
    inline DType dc_threshold() {
        return _dc_threshold;
    }
    inline int error_statistic_num() {
        return _error_statistic_num;
    }
    inline int cec_o_statistic_num() {
        return _cec_o_statistic_num;
    }
    inline int mean_statistic_num() {
        return _mean_statistic_num;
    }
    inline bool is_append() {
        return _is_append;
    }
    inline bool get_drop_gradient() {
        return _drop_gradient;
    }
};

class BatNormConfig : public LayerConfig{
protected:
    std::string _mean_var_file;
    DType _eta;
    DType _moving_average_fraction;
public:
    BatNormConfig();
    ~BatNormConfig();
    const std::string& mean_var_file() {
        return _mean_var_file;
    }
    const DType get_eta() {
        return _eta;
    }
    inline DType get_moving_average_fraction() {
        return _moving_average_fraction;
    }
    void read_config(std::string& cfg_line);
};

class BatRenormConfig : public FullConfig {
protected:
    std::string _mean_var_file;
    DType _epsilon;
    DType _deta;
    DType _r_max;
    DType _d_max;
public:
    BatRenormConfig();
    ~BatRenormConfig();
    const std::string& mean_var_file() {
        return _mean_var_file;
    }
    inline DType epsilon() {
        return _epsilon;
    }
    const DType get_deta() {
        return _deta;
    }
    const DType get_r_max() {
        return _r_max;
    }
    const DType get_d_max() {
        return _d_max;
    }
    void read_config(std::string& cfg_line);
};

class ImageBatNormConfig : public LayerConfig {
protected:
    std::string _mean_var_file;

    DType _epsilon;
    BatNormType _norm_type;
    int _statis_threshold;
    DType _moving_average_fraction;

public:
    ImageBatNormConfig();
    ~ImageBatNormConfig();

    inline DType get_moving_averate_fraction() {
        return _moving_average_fraction ;
    }

    inline int statis_threshold() {
        return _statis_threshold;
    }
    inline DType epsilon() {
        return _epsilon;
    }
    inline BatNormType norm_type() {
        return _norm_type;
    }
    const std::string& mean_var_file() {
        return _mean_var_file;
    }
    void read_config(std::string& cfg_line);
};

class StatisConfig : public FullConfig {
public:
    StatisConfig() : FullConfig() {
        _type = STATISC;
    }
};

class LinearConfig : public LayerConfig {
protected:
    float* _scalars;
    OPERATOR_TYPE _op;
public:
    LinearConfig() : LayerConfig() {
        _type = LINEAR;
        _op   = OP_ADD;
        _scalars = NULL;
    }

    ~LinearConfig() {
        if (_scalars) {
            free(_scalars);
            _scalars = NULL;
        }
    }

    inline float scalars(int idx) {
        return _scalars[idx];
    }
    inline OPERATOR_TYPE op() {
        return _op;
    }

    void read_config(std::string& cfg_line);
};

class ImageConvConfig : public LayerConfig {
public:
    ImageConvConfig() : LayerConfig() {
        _type = IMAGE_CONV;
        _output_maps = 0;
        _filter_height = 1;
        _filter_width = 1;
        _stride_height = 1;
        _stride_width = 1;
        _padding_height = 0;
        _padding_width = 0;
        _dilation_height = 1;
        _dilation_width = 1;
        _algo_seeker_type = GET_SEEKER;
        _weight_quant_transpose = false;
        _weight_fixed_transpose = true;
    }

    inline ImageConvAlgoSeekerType get_algo_seeker_type() {
        return _algo_seeker_type;
    }
    inline int get_output_maps() {
        return _output_maps;
    }

    inline int get_filter_height() {
        return _filter_height;
    }
    inline int get_filter_width() {
        return _filter_width;
    }
    inline int get_stride_height() {
        return _stride_height;
    }
    inline int get_stride_width() {
        return _stride_width;
    }
    inline int get_padding_height() {
        return _padding_height;
    }
    inline int get_padding_width() {
        return _padding_width;
    }
    inline int get_dilation_height() {
        return _dilation_height;
    }
    inline int get_dilation_width() {
        return _dilation_width;
    }
    inline bool get_cal_mask() {
        return _cal_mask;
    }
    inline bool get_skip_label() {
        return _skip_label;
    }
    void read_config(std::string& cfg_line);
private:
    ImageConvAlgoSeekerType _algo_seeker_type;
    int _output_maps;
    int _filter_height;
    int _filter_width;
    int _stride_height;
    int _stride_width;
    int _padding_height;
    int _padding_width;
    int _dilation_height;
    int _dilation_width;
    bool _cal_mask = false;
    bool _skip_label = false;
};

class ImageConvQuantConfig : public ImageConvConfig {
public:
    ImageConvQuantConfig() : ImageConvConfig() {
        _type = IMAGE_CONV_QUANT;
        _nbits = 0;
    }

    virtual ~ImageConvQuantConfig() {
    }

    void read_config(std::string& cfg_line);

    inline int nbits() {
        return _nbits;
    }
private:
    int _nbits;
};

class ImagePoolingConfig : public LayerConfig {
public:
    ImagePoolingConfig() {
        _type = IMAGE_POOL;
        _pooling_type = POOL_TYPE_UNKNOWN;
        _win_height = 1;
        _win_width = 1;
        _stride_height = 1;
        _stride_width = 1;
        _padding_width = 0;
        _padding_height = 0;

        _global_pooling = false;
    }
    void read_config(std::string& cfg_line);

    inline PoolingType get_pooling_type() {
        return _pooling_type;
    }
    inline int get_win_height() {
        return _win_height;
    }
    inline int get_win_width() {
        return _win_width;
    }
    inline int get_stride_height() {
        return _stride_height;
    }
    inline int get_stride_width() {
        return _stride_width;
    }

    inline int get_padding_height() {
        return _padding_height;
    }
    inline int get_padding_width() {
        return _padding_width;
    }

    inline bool get_global_pooling() {
        return _global_pooling;
    }

    inline bool get_cal_mask() {
        return _cal_mask;
    }

    inline bool get_skip_label() {
        return _skip_label;
    }

private:
    PoolingType _pooling_type;
    int _win_height;
    int _win_width;
    int _stride_height;
    int _stride_width;
    int _padding_height;
    int _padding_width;

    /* 如果为true，则winHeigit为输入feature map的height， winWidth为输入feature map的width */
    bool _global_pooling;
    bool _cal_mask = false;
    bool _skip_label = false;
};

class SoftmaxWithLossConfig : public LayerConfig {
public:
    SoftmaxWithLossConfig() : LayerConfig() {
        _type = SOFTMAX_WITH_LOSS;
        _start_axis = 1;
        _end_axis = -1;
        _with_log = false;
    }
    inline bool get_with_log() {
        return _with_log;
    }
    virtual void read_config(std::string& cfg_line);

    inline int get_start_axis() {
        return _start_axis;
    }

    inline int get_end_axis() {
        return _end_axis;
    }

protected:
    int _start_axis;
    int _end_axis;
    bool _with_log;
};

class NormSoftmaxConfig : public LayerConfig {
public:
    NormSoftmaxConfig() : LayerConfig() {
        _type = SOFTMAX_NORM;
        _start_axis = 1;
        _end_axis = -1;
    }
    virtual void read_config(std::string& cfg_line);

    inline int get_start_axis() {
        return _start_axis;
    }

    inline int get_end_axis() {
        return _end_axis;
    }

protected:
    int _start_axis;
    int _end_axis;
};

class LossConfig : public LayerConfig {
public:
    LossConfig() : LayerConfig() {
        init();
    }
    LossConfig(LayerType type) : LayerConfig() {
        init();
        _type = type;
        _loss_type = convert_loss_type(_type);
    }
    ~LossConfig() {
    }
    void init() {
        _cost_type = TGT_ERR;
        _blank_index = -1;
        _type = LOSS_CE;
        _loss_type = LOSS_TYPE_CE;
        _prior = NULL;
        _local_ctc = false;
        _batch_clear_prob = 0;
        _batch_clear_num = 0;
        _alpha = 0.0f;
        _sigma = 1.0f;
        _lambda = 1.0f;
        _start_axis = 1;
        _end_axis = -1;
        _ignore_label = -1;
        _norm_mode = LOSS_NORM_BATCH_SIZE;
        _loss_weight = 1.0f;
        _with_log = false;
        _pre_fixed_normalizer = 128;
    }
    virtual void read_config(std::string& cfg_line);
    LossType convert_loss_type(LayerType type);
    inline LayerType get_type() {
        return _type;
    }
    inline int get_pre_fixed_normalizer() {
        return _pre_fixed_normalizer;
    }
    inline int get_with_log() {
        return _loss_weight;
    }
    inline int blank_index() {
        return _blank_index;
    }
    inline TGT_COST_TYPE cost_type() {
        return _cost_type;
    }
    inline LossType loss_type() {
        return _loss_type;
    }
    void read_prior(const char* prior_name);
    inline Tensor<DType>* prior() {
        return _prior;
    }
    inline void prior(Tensor<DType>* pri) {
        _prior = pri;
    }

    inline int get_start_axis() {
        return _start_axis;
    }

    inline int get_end_axis() {
        return _end_axis;
    }

    inline bool is_local_ctc() {
        return _local_ctc;
    }
    inline int get_batch_clear_prob() {
        return _batch_clear_prob;
    }
    inline int get_batch_clear_num() {
        return _batch_clear_num;
    }
    inline DType get_alpha() {
        return _alpha;
    }
    inline DType get_sigma() {
        return _sigma;
    }
    inline DType get_lambda() {
        return _lambda;
    }
    inline DType get_ignore_label() {
        return _ignore_label;
    }
    inline LossNormMode get_norm_mode() {
        return _norm_mode;
    }
    inline DType get_loss_weight() {
        return _loss_weight;
    }
    inline DType get_pre_fixed() {
        return _pre_fixed;
    }
    inline DType get_focal_loss_gamma() {
        return _focal_loss_gamma;
    }
    inline DType get_focal_loss_ratio() {
        return _focal_loss_ratio;
    }

protected:
    /* acu or err */
    TGT_COST_TYPE _cost_type;
    /* mse, ce or ctc */
    LossType _loss_type;

    /* ce, for softmax */
    int _start_axis;
    int _end_axis;

    int _blank_index;
    Tensor<DType>* _prior;

    /* ctc */
    bool _local_ctc;
    int _batch_clear_prob;
    int _batch_clear_num;

    /* triplet loss */
    DType _alpha;

    /* smooth l1 loss */
    DType _sigma;
    DType _lambda;

    /* todo:计算loss和diff时忽略的label */
    float _ignore_label;

    /* 计算出的loss和梯度除做归一化的类型 */
    LossNormMode _norm_mode;
    /* 通过配置设置norm值 */
    DType _pre_fixed;

    /* 计算出的diff的权重 */
    DType _loss_weight;

    /* smooth_l1_loss_ohem for rfcn*/
    int _pre_fixed_normalizer;

    /*控制softmax是否取log*/
    bool _with_log;

    /* focal loss */
    DType _focal_loss_gamma = -1.0f;

    /* focal loss ratio 配置focal loss 的概率*/
    DType _focal_loss_ratio = 1.0f;
};

class DropOutConfig : public LayerConfig {
public:
    DropOutConfig() : LayerConfig() {
        _type     = DROP_OUT;
        _dropout_rate = -1.0f;
        _scale_train = false;
    }
    ~DropOutConfig() {}
    void read_config(std::string& cfg_line);

    inline DType drop_rate() {
        return _dropout_rate;
    }

    inline int get_scale_train() {
        return _scale_train;
    }

protected:
    DType _dropout_rate;
    bool _scale_train;
};

class Norm2Config : public LayerConfig {
public:
    Norm2Config();
    ~Norm2Config() {}

    void read_config(std::string& cfg_line);
};

class PSROIPoolConfig : public LayerConfig {
public:
    PSROIPoolConfig() {
        _type = PS_ROI_POOL;
        _output_maps = 0;
        _group_size = 0;
        _spatial_scale = 1.0f;
    }
    void read_config(std::string& cfg_line);

    inline int get_output_maps() {
        return _output_maps;
    }

    inline int get_group_size() {
        return _group_size;
    }

    inline DType get_spatial_scale() {
        return _spatial_scale;
    }

private:
    int _output_maps;
    int _group_size;
    DType _spatial_scale;
};

class BoxAnnotatorOHEMConfig : public LayerConfig {
public:
    BoxAnnotatorOHEMConfig() {
        _type = BOX_ANNOTATOR_OHEM;
        _roi_per_img = 128;
        _ignore_label = -1;
    }

    void read_config(std::string& cfg_line);

    inline int get_roi_per_img() {
        return _roi_per_img;
    }

    inline int get_ignore_label() {
        return _ignore_label;
    }

private:
    int _ignore_label;
    int _roi_per_img;
};

class ROIPoolConfig : public LayerConfig {
public:
    ROIPoolConfig() {
        _type = ROI_POOL;
        _pooling_type = MAX_POOLING_TYPE;
        _pooled_height = 0;
        _pooled_width = 0;
        _roi_num = 1;
        _spatial_scale = 1.0f;
    }
    void read_config(std::string& cfg_line);

    inline PoolingType get_pooling_type() {
        return _pooling_type;
    }
    inline int get_pooled_height() {
        return _pooled_height;
    }
    inline int get_pooled_width() {
        return _pooled_width;
    }
    inline int get_roi_num() {
        return _roi_num;
    }
    inline DType get_spatial_scale() {
        return _spatial_scale;
    }

private:
    PoolingType _pooling_type;
    int _pooled_height;
    int _pooled_width;
    int _roi_num;
    DType _spatial_scale;
};

class TransposeConfig: public LayerConfig {
protected:
    std::vector<int> _transpose;
public:
    TransposeConfig();
    ~TransposeConfig() {}

    inline std::vector<int> get_transpose() {
        return _transpose;
    }
    inline size_t get_ori_position(int j) {
        for (int i = 0; i < (int)_transpose.size(); i++) {
            if (_transpose[i] == j) {
                return i;
            }
        }
        CHECK2(false);
    }

    void read_config(std::string& cfg_line);
};

class ExpandConfig : public LayerConfig {
protected:
    int _left_context;
    int _right_context;
public:
    ExpandConfig();
    ~ExpandConfig() {}

    inline int get_left_context() {
        return _left_context;
    }

    inline int get_right_context() {
        return _right_context;
    }

    void read_config(std::string& cfg_line);
};

class SkipConfig : public LayerConfig {
protected:
    int _split_num;
    int _skip_step;
    std::vector<int> _split_start;

public:
    SkipConfig();
    ~SkipConfig() {}

    std::vector<int> get_shape(Dim input_dim, int sample_num) {
        std::vector<int> output_dim;

        if (input_dim.get_size() == 2) {
            int frame_num = input_dim[0] / sample_num;
            output_dim.push_back(sample_num * _split_num * ((frame_num + _skip_step) 
                            / (_skip_step + 1)));
            output_dim.push_back(input_dim[1]);
        } else if (input_dim.get_size() == 4) {
            int frame_num = input_dim[0] / sample_num;
            output_dim.push_back(sample_num * _split_num * ((frame_num + _skip_step) 
                            / (_skip_step + 1)));
            output_dim.push_back(input_dim[2] * input_dim[3]);
        }
        else {
            CHECK(false, "input dim error");
        }

        return output_dim;
    }

    inline int get_split_num() {
        return _split_num;
    }

    inline int get_skip_step() {
        return _skip_step;
    }

    inline std::vector<int>& get_split_start() {
        return _split_start;
    }

    void read_config(std::string& cfg_line);
};

class ReshapeConfig : public LayerConfig {
protected:
    std::vector<int>_dim;//输入的配置
public:
    ReshapeConfig();
    ~ReshapeConfig() {}

    std::vector<int> get_shape(Dim input_dim) {
        std::vector<int>reshape;
        size_t count = 1;
        int replace_count = 0;
        int replace_idx = -1;

        for (size_t i = 0; i < _dim.size(); i++) {
            //拷贝
            if (_dim[i] == 0) {
                CHECK2((int)i < (int)input_dim.get_size()); 
                reshape.push_back(input_dim[i]);
                count *= reshape[i];
            }
            //重新算，只能有一个
            else if (_dim[i] == -1) {
                replace_count++;
                replace_idx = i;
                reshape.push_back(-2);
            }
            //使用配置的
            else {
                reshape.push_back(_dim[i]);
                count *= reshape[i];
            }
        }

        CHECK2(replace_count <= 1);

        if (replace_count == 1) {
            reshape[replace_idx] = input_dim.product() / count;
        }

        if (replace_count == 0) {
            CHECK2((size_t)input_dim.product() == count);
        } else {
            CHECK2((size_t)input_dim.product() == count * reshape[replace_idx]);
        }

        return reshape;
    }

    void read_config(std::string& cfg_line);
};

/*
 * 输入数据维度为=a:b:c:d
 * dim = 0:1,2,3
 * 输出数据维度为=a:b*c*d
 */
class RedimConfig : public LayerConfig {
protected:
    std::vector< std::vector<int> > _dim;//输入的配置
public:
    RedimConfig();
    ~RedimConfig() {}

    std::vector<int> get_shape(Dim input_dim) {
        CHECK2(input_dim.get_size() == 4);
        std::vector<int>ret;

        for (size_t i = 0; i < _dim.size(); i++) {
            size_t value = 1;
            for (size_t j = 0; j < _dim[i].size(); j++) {
                CHECK2(_dim[i][j] < (int)input_dim.get_size());
                value *= input_dim[_dim[i][j]];
            }
            ret.push_back(value);
        }
        return ret;
    }

    void read_config(std::string& cfg_line);
};

class PythonConfig : public LayerConfig {
protected:
    std::vector<Dim> _out_dim;
    std::string _python_model;
    std::string _param_str;
    std::string _global_cfg_file;

    std::string _python_layer_type_str;
    LayerType _python_layer_type;
public:
    PythonConfig();
    ~PythonConfig() {
    }

    PythonConfig& operator=(PythonConfig& cfgIn);
    void read_config(std::string& cfg_line);

    std::string& get_python_layer_type_str() {
        return _python_layer_type_str;
    }
    LayerType& get_python_layer_type() {
        return _python_layer_type;
    }
    std::string& get_python_model() {
        return _python_model;
    }
    std::string& get_param_str() {
        return _param_str;
    }
    std::string& get_global_cfg_file() {
        return _global_cfg_file;
    }
    void set_global_cfg_file(std::string& file) {
        _global_cfg_file = file;
    }
    std::vector<Dim> get_out_dim();
    Dim get_out_dim(std::string key);
};

class FasterRCNNACUConfig : public LayerConfig {
    /*
    * eg:
    * [Layer]
    * type=faster_rcnn_acu
    * name=faster_rcnn_acu
    * inputs=train-data0:rois:bbox_pred:loss_cls:bbox_targets
    * label= gt_boxes
    * STDS =0.1:0.1:0.2:0.2
    * MEANS=0.0:0.0:0.0:0.0
    * [end]
    */
protected:
    std::vector<DType> _stds;
    std::vector<DType> _means;
    bool _show;
    bool _store_gt_box;
    DType _score_threshold;

public:
    FasterRCNNACUConfig();
    ~FasterRCNNACUConfig() {
    }

    FasterRCNNACUConfig& operator=(FasterRCNNACUConfig& cfgIn);
    void read_config(std::string& cfg_line);
    std::vector<DType> get_means();
    std::vector<DType> get_stds();
    bool is_show() {
        return _show;
    }
    bool get_store_gt_box() {
        return _store_gt_box;
    }
    DType get_score_threshold() {
        return _score_threshold;
    }
};

class RfcnAcuConfig : public LayerConfig {
    /*
    * eg:
    * [Layer]
    * type=rfcn_acu
    * name=rfcn_acu
    * inputs=train-data0:rois:bbox_pred:loss_cls:bbox_targets
    * label= gt_boxes
    * STDS =0.1:0.1:0.2:0.2
    * MEANS=0.0:0.0:0.0:0.0
    * [end]
    */
protected:
    std::vector<float> _stds;
    std::vector<float> _means;
    bool _show;
public:
    RfcnAcuConfig();
    ~RfcnAcuConfig() {
    }

    RfcnAcuConfig& operator=(RfcnAcuConfig& cfgIn);
    void read_config(std::string& cfg_line);
    std::vector<float> get_means();
    std::vector<float> get_stds();
    bool is_show() {
        return _show;
    }
};

class SplitConfig : public LayerConfig {
    /*
    *  eg:
    *  [Layer]
    *  type=split
    *  name=split
    *  inputs=in
    *  outputs=out1:out2:out3
    *  [end]
    */
public:
    SplitConfig() {
        _type = SPLIT;
    }
    ~SplitConfig() {}
};

class AudioROIPoolConfig : public LayerConfig {
    /*
    *  eg:
    *  [Layer]
    *  type=audio_roi_pool
    *  name=audio_roi_pool1
    *  poolType = max | avg 
    *  inputs=in
    *  outputs=out
    *  groupSize = 5
    *  [end]
    */
protected:
    int _group_size;
    AUDIO_ROI_POOL_TYPE _pool_type = AUDIO_ROI_POOL_AVG_TYPE;    
public:
    AudioROIPoolConfig();
    AudioROIPoolConfig& operator=(AudioROIPoolConfig& cfgIn);
    inline AUDIO_ROI_POOL_TYPE get_pool_type() {
        return _pool_type;
    }
    void read_config(std::string& cfg_line);
    ~AudioROIPoolConfig() {}
    int get_group_size() {
        return _group_size;
    }
};

class AudioDeltaConfig: public LayerConfig {
    /*
    *  eg:
    *  [Layer]
    *  type=audio_delta
    *  name=audio_delta
    *  windows = 2
    *  inputs=in
    *  [end]
    */
public:
    AudioDeltaConfig() {
        _type = AUDIO_DELTA;
    }
    ~AudioDeltaConfig() {}
    void read_config(std::string& cfg_line);
    inline int get_windows() {
        return _windows;
    }
private:
    int _windows = 2;
};

class AudioSpliceConfig: public LayerConfig {
    /*
    *  eg:
    *  [Layer]
    *  type=audio_splice
    *  name=audio_splice
    *  windows = 2
    *  inputs=in
    *  [end]
    */
public:
    AudioSpliceConfig() {
        _type = AUDIO_SPLICE;
    }
    ~AudioSpliceConfig() {}
    void read_config(std::string& cfg_line);
    inline int get_splice() {
        return _splice;
    }
    inline int get_clear_delta() {
        return _clear_delta;
    }
private:
    int _splice = 5;
    bool _clear_delta = true;
};

class BitQuantConfig: public LayerConfig {
    /*
    *  eg:
    *  [Layer]
    *  type=bit_quant
    *  name=bit_quant0
    *  algo = bit/greedy
    *  nbits = 3
    *  alpha = 0.1:0.2:0.3
    *  inputs=in
    *  [end]
    */
public:
    BitQuantConfig() {
        _type = BIT_QUANT;
    }
    ~BitQuantConfig() {}
    void read_config(std::string& cfg_line);
    size_t get_nbits() {
        return _nbits;
    }
    std::vector<DType> get_alpha() {
        return _alpha;
    } 
    BitQuantAlgo get_algo() {
        return _algo;
    }
private:
    size_t _nbits;
    std::vector<DType> _alpha;
    BitQuantAlgo _algo;
    
};


class GlobalCmvnConfig: public LayerConfig {
public:
    GlobalCmvnConfig();
    ~GlobalCmvnConfig();
    void read_config(std::string& cfg_line);
    inline std::string mean_var_file() {
        return _mean_var_file;
    }
private:
    std::string _mean_var_file;
};

} //namespace houyi
}
#endif
