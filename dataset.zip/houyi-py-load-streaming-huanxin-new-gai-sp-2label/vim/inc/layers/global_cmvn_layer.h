//by zhuweixin 2018.0610
#ifndef HOUYI_TRAIN_PLATFORM_GLOBAL_CMVN_LAYER_H
#define HOUYI_TRAIN_PLATFORM_GLOBAL_CMVN_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "global_cmvn_ops.h"

namespace houyi {
namespace train {

class GlobalCmvnLayer : public Layer {
public:
    GlobalCmvnLayer(GlobalCmvnConfig& config);
    GlobalCmvnLayer(GlobalCmvnLayer* from);
    virtual ~GlobalCmvnLayer() {};

    virtual void build_map(const char* prefix = NULL) {}
    virtual void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    virtual void resize_out(std::vector<IOPackage*>& inputs, int sample_num);
    void read_initial_mean_var();
    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
            std::vector<IOPackage*>& out_pack);
    char* global_file_name() {
        return _global_mean_var;
    }

    Layer* clone();
    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    inline GlobalCmvnConfig& config() {
        return _config;
    }

    void set_device() {
        _cpu_mean.set_device(cpu_device());
        _cpu_std_inv_var.set_device(cpu_device());
        _mean.set_device(gpu_device());
        _std_inv_var.set_device(gpu_device());
    }
protected:
    GlobalCmvnConfig _config;

private:
    char* _global_mean_var; // initial meanVec and varVec
    Tensor<DType> _cpu_mean;
    Tensor<DType> _cpu_std_inv_var;
    Tensor<DType> _mean;
    Tensor<DType> _std_inv_var;

};

} //train
} //houyi
#endif
