/*
 *Filename: job.h
 *Description:
 *
 *Version: 1.0
 *Created: 2016年09月06日 10时19分49秒
 *Author: lifeng(lifeng20@baidu.com)
 *
 *Copyright: Copyright (c) baidu, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_JOB_H
#define HOUYI_TRAIN_PLATFORM_JOB_H

namespace houyi {
namespace train {

enum JobType {
    TRAIN,
    DISC_TRAIN,
    PREDICT,
    SPEECH_PREDICT,
    IMAGE_PREDICT,
    IMAGE_VOTE_PREDICT,
    IMAGE_MSE_PREDICT,
    DISC_PREDICT,
    UNKNOWN_JOB
};

bool is_predict_job(JobType job_type);

extern const char* jobTypeName[];

}
}

#endif
