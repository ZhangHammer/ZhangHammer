//by zhxfl 2017.10.17
#ifndef HOUYI_TRAIN_PLATFORM_GRU_LAYER_H
#define HOUYI_TRAIN_PLATFORM_GRU_LAYER_H

#include <vector>
#include <iostream>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "cec.h"

namespace houyi {
namespace train {

class GruLayer : public Layer {
protected:
    GruConfig _config;

    Activation *_reset_act, *_update_act, *_state_act;

    DenseWeight _w_reset, _dw_reset;
    DenseWeight _w_update, _dw_update;
    DenseWeight _w_state, _dw_state;

    DenseWeight _u_reset, _du_reset;
    DenseWeight _u_update, _du_update;
    DenseWeight _u_state, _du_state;

    DenseWeight _bias_reset, _d_bias_reset;
    DenseWeight _bias_update, _d_bias_update;
    DenseWeight _bias_state, _d_bias_state;

    DType _final_mean_dw_reset;
    DType _final_stdv_dw_reset;
    DType _final_mean_dw_update;
    DType _final_stdv_dw_update;
    DType _final_mean_dw_state;
    DType _final_stdv_dw_state;

    DType _final_mean_du_reset;
    DType _final_stdv_du_reset;
    DType _final_mean_du_update;
    DType _final_stdv_du_update;
    DType _final_mean_du_state;
    DType _final_stdv_du_state;

    DType _final_mean_d_bias_reset;
    DType _final_stdv_d_bias_reset;
    DType _final_mean_d_bias_update;
    DType _final_stdv_d_bias_update;
    DType _final_mean_d_bias_state;
    DType _final_stdv_d_bias_state;

    DType _mean_dw_reset;
    DType _stdv_dw_reset;
    DType _mean_dw_update;
    DType _stdv_dw_update;
    DType _mean_dw_state;
    DType _stdv_dw_state;

    DType _mean_du_reset;
    DType _stdv_du_reset;
    DType _mean_du_update;
    DType _stdv_du_update;
    DType _mean_du_state;
    DType _stdv_du_state;

    DType _mean_d_bias_reset;
    DType _stdv_d_bias_reset;
    DType _mean_d_bias_update;
    DType _stdv_d_bias_update;
    DType _mean_d_bias_state;
    DType _stdv_d_bias_state;

    int _mean_counter;
    int _mean_batch_number;
    float _threshold;
    float _threshold_ratio;

    // Buffer
    StateMatrix _reset_gate;
    StateMatrix _update_gate;
    StateMatrix _hidden_state;
    StateMatrix _quasi_state;
    StateMatrix _partial_hidden;

    Tensor<DType> _back_error;
    int _sample_num;
    int _sub_seq_size;
    size_t _input_dim;
    size_t _output_dim;
    int _tbptt;
    int _updatett;
    int _skip_num;

    //Reverse
    Tensor<int> _seq_len;
    Tensor<DType> _reverse;
    Tensor<DType> _reverse_out;
    Tensor<DType> _reverse_in_diff;
    Tensor<DType> _reverse_pre_diff;

public:
    GruLayer(GruConfig& conf);
    GruLayer(GruLayer* from);
    void gauss_init_weight(DType mean, DType stdv);
    ~GruLayer();
    void set_device();

    virtual void build_map(const char* prefix = NULL);

    void inter_forward(std::vector<IOPackage*>& in_pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);

    virtual Layer* clone();

    void cal_time_gradient();
    void time_backward(
        const Tensor<DType>& in_feat, const Tensor<DType>& in_diff, Tensor<DType>& out_diff);
    //void input_error_backprop(Tensor<DType>& outError);
    void linear_gradient(const Tensor<DType>& x);
    void clear_gradient();
    bool clip_gradient();

    void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    void resize_tensor(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void store_history();
    virtual void clear_history();
    virtual void clear_history(int idx);

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void set_next_start();

    inline GruConfig& config() {
        return _config;
    }
    bool check_dw_norm(DenseWeight &dw, DType &norm, DType final_mean,
            DType final_stdv, const char* dw_name);

    void input_error_backprop(Tensor<DType>& out_error);
public:
// get weight and bias
    inline DenseWeight* w_reset() {
        return &_w_reset;
    }

    inline DenseWeight* w_update() {
        return &_w_update;
    }

    inline DenseWeight* w_state() {
        return &_w_state;
    }

    inline DenseWeight* u_reset() {
        return &_u_reset;
    }

    inline DenseWeight* u_update() {
        return &_u_update;
    }

    inline DenseWeight* u_state() {
        return &_u_state;
    }

    inline DenseWeight* bias_reset() {
        return &_bias_reset;
    }

    inline DenseWeight* bias_update() {
        return &_bias_update;
    }

    inline DenseWeight* bias_state() {
        return &_bias_state;
    }
};
}
}
#endif
