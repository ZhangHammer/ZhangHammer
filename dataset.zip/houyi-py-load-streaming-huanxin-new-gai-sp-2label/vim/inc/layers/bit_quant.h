// by wangguibin 2018.06.08
#ifndef HOUYI_TRAIN_PLATFORM_BIT_QUANT_H
#define HOUYI_TRAIN_PLATFORM_BIT_QUANT_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "weight.h"

namespace houyi {
namespace train {

class BitQuant : public Layer {
public:
    BitQuant(BitQuantConfig& config);
    BitQuant(BitQuant* from);
    virtual ~BitQuant();

    Layer* clone();
    virtual void build_map(const char* prefix = NULL);

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
                std::vector<IOPackage*>& out_pack);
    virtual void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    inline BitQuantConfig& config() {
        return _config;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t);
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    void read_hfnn_model(std::ifstream& input, SPEECH_NN_W_TYPE t);
    bool bit_quantize(Tensor<DType>& out, const Tensor<DType>& in);
    bool greedy_quantize(Tensor<DType>& out, const Tensor<DType>& in);
    void store_quant_alpha(int device_id);

protected:
    void set_device() {
    }
protected:
    BitQuantConfig _config;
    size_t _nbits;
    std::vector<DType> _input_alpha;
    Tensor<DType> _alpha;
    Tensor<DType> _batch_alpha;
    Tensor<DType> _batch_beta;
    BitQuantAlgo _algo;
};
}
}
#endif
