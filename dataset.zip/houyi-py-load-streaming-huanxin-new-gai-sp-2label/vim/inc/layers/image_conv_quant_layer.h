/**
 * image_conv_quant_layer.h
 *
 * Author: wolf(wangkai35@baidu.com)
 * Created on: 2018-07-11
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_IMAGE_CONV_QUANT_LAYER_H
#define HOUYI_TRAIN_PLATFORM_IMAGE_CONV_QUANT_LAYER_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"
#include "image_conv_layer.h"
#include "weight.h"

namespace houyi {
namespace train {
class ImageConvQuantLayer : public ImageConvLayer {
public:
    ImageConvQuantLayer(ImageConvQuantConfig& config);
    ImageConvQuantLayer(ImageConvQuantLayer* from);

    void init(ImageConvQuantConfig& config) {
        _config = config;
        _nbits = config.nbits();
        _type = IMAGE_CONV_QUANT;
        _transpose_buffer.set_device(gpu_device());
        _alpha.set_device(gpu_device());
        _alpha.resize(Dim(1, _nbits));
    }

    ~ImageConvQuantLayer() {
        _free();
    }

    virtual void inter_forward(std::vector<IOPackage*>& pack);

    Layer* clone();

    ImageConvQuantConfig& config() {
        return _config;
    }

private:
    ImageConvQuantConfig _config;
    size_t _conv_work_space_size_byte;
    int _nbits;
    Tensor<DType> _transpose_buffer;
    Tensor<DType> _alpha;
};

}
}
#endif
