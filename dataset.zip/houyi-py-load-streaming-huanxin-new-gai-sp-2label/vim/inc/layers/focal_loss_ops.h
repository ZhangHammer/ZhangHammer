/**
 * focal_loss_ops.h
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-05-15
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_LAYERS_FOCAL_LOSS_OPS_H
#define HOUYI_LAYERS_FOCAL_LOSS_OPS_H

#include <wind/wind.h>

namespace houyi {
namespace train {

void wind_focal_loss_cal_error(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType gamma = 2.0f);

void wind_focal_loss_cal_loss(
        Tensor<float>& out,
        const Tensor<float>& in,
        const Tensor<float>& label,
        const Tensor<int>& mask,
        DType gamma = 2.0f);

}// namespace train
}// namespace houyi
#endif

