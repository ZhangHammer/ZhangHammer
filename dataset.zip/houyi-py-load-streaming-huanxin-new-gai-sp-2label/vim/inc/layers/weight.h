/**
 * weight.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-18
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_WEIGHT_H
#define HOUYI_LAYERS_WEIGHT_H

#include <vector>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <set>
#include "util.h"
//#include "wind_base.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

#define MAX_SERIAL_SIZE(m, n) \
    (sizeof(float) * (m) * (n) + sizeof(int) * (m) + sizeof(int) * 3 + sizeof(uint64_t))

enum WeighType {
    WEIGHT_DENSE,
    WEIGHT_EXTDENSE,
    WEIGHT_DISC,
    WEIGHT_UNKNOWN
};

//enum WeightUpdataType {
//    UPDATA_LEARN_RATE,
//    UPDATA_AVG,
//    UPDATA_UNKNOWN
//};

class DenseWeight;
class ExtDenseWeight;
class DiscWeight;

class BaseWeight {
protected:
    WeighType _type;
    //WeightUpdataType _update_type;

    //
    char*      _serial_buf;
    size_t     _serial_buf_bytes;
    size_t     _serial_bytes;

    void _init() {
        _type = WEIGHT_UNKNOWN;
        //_update_type = UPDATA_LEARN_RATE;
        _serial_buf = NULL;
        _serial_buf_bytes = 0;
        _serial_bytes = 0;
    }

public:
    BaseWeight() {
        _init();
    }

    //BaseWeight(WeightUpdataType type) {
    //    _init();
    //    //_update_type = type;
    //}

    virtual ~BaseWeight() {
        if (_serial_buf) {
            wind_gpu_free_host(_serial_buf);
            _serial_buf = NULL;
        }

        _init();
    }

    inline WeighType type() const {
        return _type;
    }
    //inline WeightUpdataType update_type() const {
    //    return _update_type;
    //}
    virtual size_t  height() const {
        return 0;
    }
    virtual size_t  width() const {
        return 0;
    }
    virtual size_t  channel() const {
        return 0;
    }
    virtual size_t  number() const {
        return 0;
    }
    virtual const Dim& get_size() const {
        Dim* dim = NULL;
        return *dim;
    }
    inline char* serial_buf() {
        return _serial_buf;
    }
    inline size_t serial_buf_bytes() {
        return _serial_buf_bytes;
    }

    inline size_t serial_bytes() {
        return _serial_bytes;
    }

    virtual size_t get_element_cnt() {
        return 0;
    }

    virtual const Device& get_device() {
        INTER_LOG("epmty func is called");
        const Device* device = NULL;
        return *device;
    }
    virtual bool is_init() = 0;
    //void alloc_serial_buf(int height, int width);
    virtual BaseWeight* clone() = 0;
    virtual BaseWeight* clone(const Device& device) = 0;
    virtual void zero() = 0;
    virtual void add(BaseWeight* w, float alpha, float beta) = 0;
    virtual void mul_scalar(float scalar) = 0;
    virtual DType norm() = 0;
    virtual void random(DType lo, DType hi) = 0;
    virtual void set_const(DType v) = 0;
    virtual void gauss_random(DType mean, DType stdv) = 0;
    virtual void init_weight(DType lo, DType hi) {
        CHECK(false, "error");
    }
    virtual void init_weight(DType const_value) {
        CHECK(false, "error");
    }
    virtual void gauss_init_weight(DType mean, DType stdv) {
        CHECK(false, "error");
    }
    virtual Tensor<DType>* w() const {
        return NULL;
    }

    virtual void resize_like(BaseWeight& src) {
        CHECK(false, "error");
    }

    virtual void copy_from(const BaseWeight* w) = 0;
    virtual void copy_from(const BaseWeight* w, WindStream stream) = 0;
    virtual void fixed_loss() = 0;
    virtual size_t serialize() = 0;
    virtual size_t deserialize() = 0;
};

class DenseWeight : public BaseWeight {
protected:
    Tensor<DType>* _w;

public:
    DenseWeight() {
        _w = NULL;
        _type  = WEIGHT_DENSE;
    }

    //DenseWeight(WeightUpdataType update_type) : BaseWeight(update_type){
    //    _w = NULL;
    //    _type  = WEIGHT_DENSE;
    //}

    ~DenseWeight() {
        if (_w) {
            delete _w;
            _w = NULL;
        }
    }

    DenseWeight(const Dim& size, const Device& device);
    //DenseWeight(const Dim &size, const Device &device, WeightUpdataType update_type);

    inline bool is_init() {
        return _w->is_init();
    }
    inline size_t  height() const {
        return _w->get_h();
    }
    inline size_t  width() const {
        return _w->get_w();
        return 0;
    }
    inline size_t  channel() const {
        return _w->get_c();
        return 0;
    }
    inline size_t  number() const {
        return _w->get_n();
    }
    const Dim& get_size() const {
        return _w->get_size();
    }
    const Device& get_device() {
        return _w->get_device();
    }

    void fixed_loss();

    inline Tensor<DType>* w() const {
        CHECK2(_w);
        return _w;
    }

    size_t get_element_cnt() {
        return _w->get_element_count();
    }

    virtual BaseWeight* clone();
    virtual BaseWeight* clone(const Device& device);
    virtual void resize(const Dim& size, const Device& deivce);
    virtual void zero();
    virtual void add(BaseWeight* w, float alpha, float beta);
    virtual void mul_scalar(float scalar);
    virtual DType norm();
    virtual void random(DType lo, DType hi);
    virtual void set_const(DType v);
    virtual void gauss_random(DType mean, DType stdv);
    void resize_like(BaseWeight& src) {
        resize(src.get_size(), src.get_device());
    }
    virtual void copy_from(const BaseWeight* w);
    virtual void copy_from(const BaseWeight* w, WindStream stream);
    virtual size_t serialize();
    virtual size_t deserialize();

    virtual void copy_from(const DenseWeight& w);
    virtual void copy_from(const DiscWeight& w);
    virtual void add(DenseWeight& w, float alpha, float beta);
    virtual void add(DiscWeight& w, float alpha, float beta);

    void store_model(std::ofstream& output);
    void read_model(std::ifstream& input);
    void init_weight(DType lo, DType hi);
    void init_weight(DType const_value);
    void gauss_init_weight(DType mean, DType stdv);
};

class ExtDenseWeight: public DenseWeight {
protected:
    std::vector<int> _update_set;
    std::vector<int> _backup_update_set;

public:
    ExtDenseWeight() {
        _type = WEIGHT_EXTDENSE;
    }

    virtual ~ExtDenseWeight() {
    }

    ExtDenseWeight(size_t height, size_t width, bool on_gpu);

    virtual BaseWeight* clone(bool on_gpu);

    void set_update(std::vector<int>& in) {
        _update_set = in;
    }

    std::vector<int>& get_update() {
        return _update_set;
    };

    void clear_update() {
        _update_set.clear();
    }

    virtual void zero();

    virtual void copy_from(const BaseWeight*, WindStream);
    virtual void copy_from(const BaseWeight*);
    virtual void copy_from(const DenseWeight& w);
    virtual void copy_from(const ExtDenseWeight& w);
    virtual void copy_from(const DiscWeight& w);

    virtual void copy_add(const DiscWeight& w);

    virtual void add(const BaseWeight* w, float alpha, float beta);
    virtual void add(const DenseWeight& w, float alpha, float beta);
    virtual void add(const ExtDenseWeight& w, float alpha, float beta);
    virtual void add(const DiscWeight& w, float alpha, float beta);
    virtual void mul_scalar(float scalar) {
        // TODO:
    }
    virtual DType norm() {
        // TODO:
        return 0.0f;
    }
    virtual void random(DType lo, DType hi) {
        // TODO
    }
    virtual void set_const(DType v) {
        // TODO
    }

    virtual void gauss_random(DType mean, DType stdv) {
        // TODO
    }
    virtual size_t serialize();
    virtual size_t deserialize();

    virtual void save_update() {
        _backup_update_set = _update_set;
    }

    virtual void restore_update() {
        _update_set = _backup_update_set;
    }
};

class DiscWeight : public DenseWeight {
protected:
    std::vector<int> _update_set;

public:
    DiscWeight() {
        _type  = WEIGHT_DISC;
    }

    virtual ~DiscWeight() {
    }

    DiscWeight(size_t height, size_t width, bool on_gpu);

    virtual BaseWeight* clone(bool on_gpu);

    virtual void zero();

    virtual void copy_from(const BaseWeight*, WindStream);
    virtual void copy_from(const BaseWeight*);
    virtual void copy_from(const DenseWeight& w);
    virtual void copy_from(const DiscWeight& w);
    virtual void copy_from(const ExtDenseWeight& w);

    virtual void add(const BaseWeight* w, float alpha, float beta);
    virtual void add(const DenseWeight& w, float alpha, float beta);
    virtual void add(const DiscWeight& w, float alpha, float beta);
    virtual void add(const ExtDenseWeight& w, float alpha, float beta);
    virtual void mul_scalar(float scalar) {
        // TODO:
    }
    virtual DType norm() {
        // TODO:
        return 0.0f;
    }

    virtual void random(DType lo, DType hi) {
        // TODO
    }
    virtual void set_const(DType v) {
        // TODO
    }
    virtual void gauss_random(DType mean, DType stdv) {
        // TODO
    }
    virtual size_t serialize();
    virtual size_t deserialize();

    void set_update(std::vector<int>& in) {
        _update_set = in;
    }

    std::vector<int>& get_update() {
        return _update_set;
    };

    void clear_update() {
        _update_set.clear();
    }

    void resize(size_t w_org_height, size_t w_org_width, bool on_gpu);
};

int unique_insert(std::vector<int>& vec, int ele);

void unique_combine(std::vector<int>& dst, std::vector<int>& src);
}
}

#endif
