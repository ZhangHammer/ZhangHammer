/**
 * ctc_loss_layer.h
 * Author: baijinfeng (baijinfeng@conew.com)
 * Created on: 2016-08-01
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_LAYER_LSTM_CTC_LOSS_LAYER_H
#define HOUYI_LAYER_LSTM_CTC_LOSS_LAYER_H
#include <vector>
#include <algorithm>
#include <iostream>
#include <limits>
#include "glog/logging.h"
#include "wind/wind.h"
#include "layer_config.h"
#include "out_config.h"
#include "ctc_loss_rlt.h"
#include "loss_layer.h"

namespace houyi {
namespace train {

class CtcLossLayer : public LossLayer {
protected:
    Tensor<DType> _cpu_label_vec;
    Tensor<DType>  _log_in, _host_out, _log_in_gpu;
    Tensor<DType>  _alpha, _beta, _prev;
    DType     _minus_log_epsilon;
    Tensor<DType>*  _prior;
    DType     _log_zero;
    int        _blank_index;
    int        _num_utt;
    bool       _local_ctc;
    //CtcResults _rlt_log;

    Tensor<DType> _device_alpha, _device_beta;
    Tensor<DType> _device_pzx;
    Tensor<DType> _ctc_err;

    Tensor<DType> _host_pzx;
    std::vector<int> _frame_num_utt;
    std::vector<std::vector<int> > _formatted_labels;

    Tensor<DType> _tmp_in;
    int _sent_id;

    Tensor<int> _cpu_mask;
public:
    void _init() {
        _sent_id           = 0;
        _prior             = NULL;
        _num_utt           = 0;
        _local_ctc         = 0;
        _blank_index       = -1;
        _minus_log_epsilon = 50.0f;

        if (std::numeric_limits<DType>::has_infinity == true) {
            _log_zero = -std::numeric_limits<DType>::infinity();
        } else {
            _log_zero = -10000.0;
        }
    }

    CtcLossLayer(LossConfig& cfg) : LossLayer(cfg) {
        _init();
        set_device();
        set_prior(cfg.prior(), cfg.get_batch_size());
        _blank_index = cfg.blank_index();
        _local_ctc = cfg.is_local_ctc();
    }

    ~CtcLossLayer() {
        if (_prior) {
            delete _prior;
            _prior = NULL;
        }
    }

    void set_device() {
        _log_in.set_device(cpu_device());
        _log_in_gpu.set_device(gpu_device());
        _host_out.set_device(cpu_device());
        _alpha.set_device(cpu_device());
        _beta.set_device(cpu_device());
        _prev.set_device(cpu_device());

        _device_alpha.set_device(gpu_device());
        _device_beta.set_device(gpu_device());
        _ctc_err.set_device(gpu_device());

        _cpu_label_vec.set_device(cpu_device());
        _device_pzx.set_device(gpu_device());
        _host_pzx.set_device(cpu_device());

        _tmp_in.set_device(cpu_device());

        _cpu_mask.set_device(cpu_device());
    }

    inline void set_prior(Tensor<DType>* prior, int sent_num) {
        if (_prior == NULL) {
            _prior = new Tensor<DType>(Dim(prior->get_height(), prior->get_width()), gpu_device());
        } else {
            _prior->resize(prior->get_size());
        }

        _prior->copy_from(*prior);
    }

    //virtual CtcResults get_ctc_result() {
    //    return _rlt_log;
    //}

    inline Tensor<DType>* get_prior() {
        return _prior;
    }

    inline int get_blank_label() {
        return _blank_index;
    }

    inline bool is_local_ctc() {
        return _local_ctc;
    }

    inline void set_local_ctc(bool local_ctc) {
        _local_ctc = local_ctc;
    }
    inline void set_blank_label(int blank_index) {
        _blank_index = blank_index;
    }

    inline DType log_sum_exp(DType x, DType y) {
        return log_sum_exp(x, y, false);
    }

    inline DType log_sum_exp(DType x, DType y, bool flg) {
        if (flg) {
            return y;
        }

        DType vmin = (x > y) ? y : x;
        DType vmax = (x > y) ? x : y;

        if (vmax >= vmin + _minus_log_epsilon) {
            return vmax;
        } else {
            return vmax + log(exp(vmin - vmax) + 1.0);
        }
    }

    DType get_vtb_error(const Tensor<int>& mask,
            const Tensor<DType>& label, Tensor<DType>& in, Tensor<DType>& in_prior,
                        Tensor<DType>& out);
    DType get_ctc_error(const Tensor<int>& mask, 
            const Tensor<DType>& label, Tensor<DType>& in, Tensor<DType>& in_prior,
                        Tensor<DType>& out);
    DType get_ctc_error_v2(const Tensor<int>& mask, 
            const Tensor<DType>& label, Tensor<DType>& in, Tensor<DType>& in_prior,
                           Tensor<DType>& out);
    void   get_ctc_error_parallel(const Tensor<int>& mask,
                                  const Tensor<DType>& label,
                                  Tensor<DType>& in, Tensor<DType>& in_prior,
                                  Tensor<DType>& out);
    void   write_ctc_score(const Tensor<int>&mask, const Tensor<DType>& label,
                           Tensor<DType>& in, Tensor<DType>& in_prior,
                           Tensor<DType>& out);
    virtual CtcLossLayer* clone();
    virtual void cal_result();

    virtual void cal_target(std::vector<IOPackage*>& output,
                            std::vector<IOPackage*>& label, std::vector<IOPackage*>& target);
    virtual void cal_loss(std::vector<IOPackage*>& output,
                          std::vector<IOPackage*>& label, std::vector<IOPackage*>& loss);
    Loss& get_cost_value(TGT_COST_TYPE type);

private:
    void insert_blank(std::vector<int>& labels);
    void remove_blank(std::vector<int>& labels);
    void debug_error(const Tensor<int>& mask, 
            const Tensor<DType>& label, 
            Tensor<DType>& in, 
            Tensor<DType>& in_prior,
            Tensor<DType>& out);

    inline void get_ref(const std::vector<int>& ctc_vec, std::vector<int>& ref) {
        ref = ctc_vec;
        remove_blank(ref);
    }

    inline void get_hyp(const std::vector<int>& hyp_org, std::vector<int>& hyp) {
        hyp = hyp_org;
        std::vector<int>::iterator it = unique(hyp.begin(), hyp.end());
        hyp.erase(it, hyp.end());
        remove_blank(hyp);
    }

    void get_syllable_ctc_label(const std::vector<int>& fix_label_vec,
                                std::vector<int>& ctc_label_vec);
    void get_local_path(std::vector<ItemPair>& res,
                        std::vector< std::pair<int, int> >& pos_pair,
                        std::vector< std::vector<int> >& local_path);
    void get_label_map(const std::vector<int>& hyp,
                       std::vector< std::pair<int, int> >& pos_pair);
    void best_decode(Tensor<DType>& log_in, int ii,
                     int num_frame,
                     std::vector<int>& hyp);
    void write_result(const std::vector<int>& fix_label_vec,
                      const std::vector<int>& ref,
                      const std::vector<int>& hyp_org,
                      const std::vector<int>& hyp);
    void stat_wer(std::vector<ItemPair>& res,
                  std::vector<int>& ref,
                  CtcLoss& loss);

    int calc_alpha(Tensor<DType>& log_in, int ii, int num_frame, std::vector<int>& label_vec);
    int calc_alpha(Tensor<DType>& log_in, int ii, int num_frame,
                   std::vector<int>& label_vec, std::vector< std::vector<int> >& local_path);
    int calc_local_alpha(Tensor<DType>& log_in, int ii,
                         std::vector<int>& label_vec,
                         std::vector<int> triple_st,
                         std::vector<int> triple_ed);
    int calc_local_alpha_st(Tensor<DType>& log_in, int ii,
                            std::vector<int>& label_vec,
                            std::vector<int> triple_st);
    int calc_local_alpha_ed(Tensor<DType>& log_in, int ii,
                            std::vector<int>& label_vec,
                            int num_frame,
                            std::vector<int> triple_ed);
    int calc_std_alpha(Tensor<DType>& log_in, int ii,
                       std::vector<int>& label_vec,
                       int tt_st, int tt_ed,
                       int ss_st, int ss_ed);

    int calc_beta(Tensor<DType>& log_in, int ii, int num_frame, std::vector<int>& label_vec);
    int calc_beta(Tensor<DType>& log_in, int ii, int num_frame,
                  std::vector<int>& label_vec,
                  std::vector< std::vector<int> >& local_path);
    int calc_local_beta(Tensor<DType>& log_in, int ii,
                        std::vector<int>& label_vec,
                        std::vector<int> triple_st,
                        std::vector<int> triple_ed);
    int calc_local_beta_st(Tensor<DType>& log_in, int ii,
                           std::vector<int>& label_vec,
                           std::vector<int> triple_st);
    int calc_local_beta_ed(Tensor<DType>& log_in, int ii,
                           std::vector<int>& label_vec,
                           int num_frame,
                           std::vector<int> triple_ed);
    int calc_std_beta(Tensor<DType>& log_in, int ii,
                      std::vector<int>& label_vec, int tt_st,
                      int tt_ed, int ss_st, int ss_ed);

    DType calc_diff(Tensor<DType>& host_out, int ii, int num_frame,
                    std::vector<int>& label_vec);
    DType calc_diff(Tensor<DType>& host_out,
                    int ii, int num_frame,
                    std::vector<int>& label_vec,
                    std::vector< std::vector<int> >& local_path);
};

} //namespace houyi
} //namespace train
#endif
