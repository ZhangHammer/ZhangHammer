/**
 * predict_nn_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-10-17
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_PREDICT_NN_CONFIG_H
#define HOUYI_LAYERS_PREDICT_NN_CONFIG_H

#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "base_reader_config.h"
#include "base_processer_config.h"
#include "base_repository_config.h"
#include "layer_config.h"
#include "out_config.h"
#include "nn_config.h"
#include "job.h"

namespace houyi {
namespace train {

class InOutFileConfig : public ModelInitConfig {
protected:
    std::string _model_file;
    std::string _inq_model_file;
    std::string _model_file_list;

    std::string _score_store_dir;
    std::string _score_store_kaldi_dir;
    
    /*保存分类的结果*/
    std::string _classify_store_dir;

    /* file used for store loss */
    std::string _loss_file;
public:
    InOutFileConfig() : ModelInitConfig() {
    }
    ~InOutFileConfig() {}
    inline const std::string& model_file() const {
        return _model_file;
    }
    inline const std::string& inq_model_file() const {
        return _inq_model_file;
    }
    inline const std::string& model_file_list() const {
        return _model_file_list;
    }
    inline const std::string& score_store_dir() const {
        return _score_store_dir;
    }
    inline const std::string& score_store_kaldi_dir() const {
        return _score_store_kaldi_dir;
    }
    inline const std::string& loss_file() const {
        return _loss_file;
    }
    inline const std::string& classify_store_dir () const {
        return _classify_store_dir;
    }
    void read(std::string& cfg_lines);
};

class PredictPeriodConfig : public PeriodConfig {
protected:
    int _predict_period;

public:
    PredictPeriodConfig() : PeriodConfig() {
        _predict_period = 100000;
    }
    ~PredictPeriodConfig() {}

    inline int predict_period() const {
        return _predict_period;
    }

    void read(std::string& cfg_lines);
};

class PredictNnConfig : public NNConfig {
protected:
    InOutFileConfig _in_out_file_cfg;
    PredictPeriodConfig _period_cfg;

    std::string _call_before_predict;
    std::string _call_after_predict;
public:
    PredictNnConfig();
    ~PredictNnConfig();
    void read_config(const char* file);

    inline std::string& call_after_predict() {
        return _call_after_predict;
    }
    inline std::string& call_before_predict() {
        return _call_before_predict;
    }

    inline InOutFileConfig& in_out_file_cfg() {
        return _in_out_file_cfg;
    }

    inline PredictPeriodConfig& period_cfg() {
        return _period_cfg;
    }
};

}
} //namespace houyi

#endif
