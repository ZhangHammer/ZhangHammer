/**
 * global_updater_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2017-02-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_GLOBAL_UPDATER_CONFIG_H
#define HOUYI_LAYERS_GLOBAL_UPDATER_CONFIG_H
#include "wind/wind.h"
namespace houyi {
namespace train {

enum LrAdjustType {
    FIXED_LR,
    STEP_LR,
    LINEAR_STEP_LR,
    EXP_LR,
    INV_LR,
    MULTI_STEP_LR,
    POLY_LR,
    SIGMOID_LR,
    LINEAR_MULTI_STEP_LR,
    UNKNOWN_LR
};

class GlobalUpdaterCfg {
protected:
    /* for lr adjust */
    /*
    *   - fixed: always return base_lr.
    *   - step: return base_lr * gamma ^ (floor(iter / step))
    *   - linear: return base_lr + gamma * (floor(iter / step))
    *   - exp: return base_lr * gamma ^ iter
    *   - inv: return base_lr * (1 + gamma * iter) ^ (- power)
    *   - multistep: similar to step but it allows non uniform steps defined by
    *     stepvalue
    *   - poly: the effective learning rate follows a polynomial decay, to be
    *     zero by the maxIter. return base_lr (1 - iter/maxIter) ^ (power)
    *   - sigmoid: the effective learning rate follows a sigmod decay
    *     return base_lr ( 1/(1 + exp(-gamma * (iter - stepsize))))
    *   - linear_multi_step: similar to linear step but it allows non uniform steps 
    *     defined by stepvalue
    *
    */
    LrAdjustType _lr_adjust_type;
    DType _gamma;
    int _step;
    std::vector<int> _step_value;
    DType _power;
    int _max_iter;

    /* gradient descent optimization algorithms type*/
    std::string _gd_type;

    /* for sgd */
    DType _threshold;
    DType _threshold_ratio;
    DType _learn_rate;
    DType _momentum;
    DType _l2_penalty;

    /* for adam */
    DType _adam_beta1;
    DType _adam_beta2;
    DType _adam_lambda;
    DType _adam_alpha;

    /* rms */
    DType _rms_gamma;
    DType _rms_eta;

    int _iter_size;
    int _device_num;

    /* Layer-wise Adaptive Rate Scaling */
    /*  
     * learn_rate = base_learn_rate * lars_ratio * norm2(w) / norm2(dw)
     */
    bool _lars;
    DType _lars_ratio;

    /* linearly increase learn rate from _warmup_lr to _learn_rate */
    bool _warmup;
    int _warmup_iter;
    DType _warmup_lr;

    int _lr_print_period;
public:
    GlobalUpdaterCfg();

    inline LrAdjustType get_lr_adjust_type() {
        return _lr_adjust_type;
    }
    inline void set_lr_adjust_type(LrAdjustType type) {
        _lr_adjust_type = type;
    }
    inline int get_step() {
        return _step;
    }
    inline std::vector<int>& get_step_value() {
        return _step_value;
    }
    inline int get_max_iter() {
        return _max_iter;
    }

    inline DType get_gamma() {
        return _gamma;
    }
    inline DType get_power() {
        return _power;
    }

    inline const std::string& get_gd_type() const {
        return _gd_type;
    }
    inline DType get_learn_rate() const {
        return _learn_rate;
    }

    inline DType get_momentum() const {
        return _momentum;
    }

    inline DType get_l2_penalty() const {
        return _l2_penalty;
    }

    inline DType get_threshold() const {
        return _threshold;
    }
    inline DType threshold_ratio() const {
        return _threshold_ratio;
    }

    inline DType get_beta1() const {
        return _adam_beta1;
    }
    inline DType get_beta2() const {
        return _adam_beta2;
    }
    inline DType get_lambda() const {
        return _adam_lambda;
    }
    inline DType get_alpha() const {
        return _adam_alpha;
    }
    inline DType get_rms_gamma() const {
        return _rms_gamma;
    }
    inline DType get_rms_eta() const {
        return _rms_eta;
    }
    inline int get_iter_size() const {
        return _iter_size;
    }
    inline void set_iter_size(int iter_size) {
        _iter_size = iter_size;
    }
    inline int get_device_num() const {
        return _device_num;
    }
    inline void set_device_num(int device_num) {
        _device_num = device_num;
    }
    inline bool get_lars() {
        return _lars;
    }
    inline DType get_lars_ratio() {
        return _lars_ratio;
    }
    inline bool get_warmup() {
        return _warmup;
    }
    inline DType get_warmup_lr() {
        return _warmup_lr;
    }
    inline int get_warmup_iter() {
        return _warmup_iter;
    }
    inline int get_lr_print_period() {
        return _lr_print_period;
    }

    void read(std::string& cfg_lines);
};

}
} //namespace houyi

#endif
