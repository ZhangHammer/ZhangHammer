/**
 * split_layer.h
 *
 * Author: chencheng19(chencheng19@baidu.com)
 * Created on: 2017-09-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_TRAIN_PLATFORM_SPLIT_LAYER_H
#define HOUYI_TRAIN_PLATFORM_SPLIT_LAYER_H
#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/time.h>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {

class SplitLayer : public Layer {
public:
    SplitLayer(SplitConfig& config);
    SplitLayer(SplitLayer* from);
    virtual ~SplitLayer() {}

    Layer* clone();
    virtual void build_map(const char* prefix = NULL) {}

    virtual void inter_forward(std::vector<IOPackage*>& pack);
    virtual void inter_bprop_diff(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack);
    virtual void inter_bprop_grad(std::vector<IOPackage*>& in_pack,
                std::vector<IOPackage*>& out_pack) {}
    virtual void layer_set(std::vector<IOPackage*> &inputs, int sample_num);
    virtual void resize_out(std::vector<IOPackage*> &inputs, int sample_num);
    inline SplitConfig& config() {
        return _config;
    }

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {};
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {};

    //virtual void setBatchSize(int batchSize);
protected:
    void set_device() { }
protected:
    SplitConfig _config;
};

}   // namespace train
}   // namespace iml
#endif
