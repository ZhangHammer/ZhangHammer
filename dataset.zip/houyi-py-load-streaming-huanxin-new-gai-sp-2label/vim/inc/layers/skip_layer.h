/**
 * skip_layer.h
 *
 * Author: wangkai35(wangkai35@baidu.com)
 * Created on: 2017-05-26
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_SKIP_LAYER_H
#define HOUYI_LAYERS_SKIP_LAYER_H
#include <vector>
#include <iostream>
#include "util.h"
#include "wind/wind.h"
#include "layer.h"

namespace houyi {
namespace train {

class SkipLayer : public Layer {
public:
    SkipLayer(SkipConfig& config);
    SkipLayer(SkipLayer* from);
    virtual ~SkipLayer() {}

    Layer* clone();
    void build_map(const char* prefix = NULL) {}

    void inter_forward(IOPackage* in_pack) {
        INTER_LOG("%s should not be called", __FUNCTION__);
    }
    void inter_forward(std::vector<IOPackage*>& pack);
    void inter_bprop_diff(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack);
    void inter_bprop_grad(std::vector<IOPackage*>& in_pack, 
        std::vector<IOPackage*>& out_pack) {}

    void store_model(std::ofstream& output, SPEECH_NN_W_TYPE t) {}
    void read_model(std::ifstream& input, SPEECH_NN_W_TYPE t) {}

    inline SkipConfig& config() {
        return _config;
    }

    void layer_set(std::vector<IOPackage*>& inputs, int sample_num);
    void resize_out(std::vector<IOPackage*>& inputs, int sample_num);

protected:
    void set_device() {
    }

    void init() {
    }
protected:
    SkipConfig _config;
    int  _last_len;
    Tensor<int>* _split_start;
    Tensor<int>* _split_start_host;
    Tensor<DType> _label{gpu_device()};
    Tensor<int> _mask{gpu_device()};
};

}
}

#endif
