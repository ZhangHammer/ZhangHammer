/**
 * stat_indicatior.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-10-19
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_CONTROLER_STAT_INDICATOR_H
#define HOUYI_CONTROLER_STAT_INDICATOR_H
#include "multi_neural_network.h"
#include "base_batch_sample.h"
#include "base_data_reader.h"
#include "base_processer.h"
#include "base_repository.h"
#include "loss_store.h"
#include "tb_writer.h"

#include <chrono>

namespace houyi {
namespace train {

class StatIndicator;
StatIndicator* creat_indicator(const PeriodConfig& cfg, 
            const LossType type, const std::string& layer_name);

class StatIndicator {
public:
    StatIndicator() {
        _init();
        set_device();
    }
    StatIndicator(const PeriodConfig& cfg, LossType loss_type, const std::string& layer_name) {
        _init();
        set_device();
        _layer_name = layer_name;
        _model_period = cfg.model_period();
        _log_period = cfg.log_period();
        _shrink_lr_period = cfg.shrink_lr_period();

        _type = loss_type;
        _last_cost = creat_loss(loss_type, std::string("last-cost"));
        _train_cost = creat_loss(loss_type, std::string("total-cost"));
        _cur_train_cost = creat_loss(loss_type, std::string("cur-cost"));
    }

    StatIndicator(const PeriodConfig& cfg, LossType loss_type, std::string& last_cost_name,
                  std::string& train_cost_name, std::string& cur_train_cost_name,
                  const std::string& layer_name) {
        _init();
        set_device();
        _layer_name = layer_name;
        _model_period = cfg.model_period();
        _log_period = cfg.log_period();
        _shrink_lr_period = cfg.shrink_lr_period();

        _type = loss_type;
        _last_cost = creat_loss(loss_type, last_cost_name);
        _train_cost = creat_loss(loss_type, train_cost_name);
        _cur_train_cost = creat_loss(loss_type, cur_train_cost_name);
    }
    virtual ~StatIndicator() {
        if (_last_cost != NULL) {
            delete _last_cost;
        }

        if (_train_cost != NULL) {
            delete _train_cost;
        }

        if (_cur_train_cost != NULL) {
            delete _cur_train_cost;
        }
    }

    void reset() {
        _clear();
    }
    void zero() {
        _total_iter_counter = 0;
        _sample_counter = 0;
        _frame_counter = 0;
        _train_cost->clear();
        _cur_train_cost->clear();
        _cur_frame_counter = 0.0f;
        _cur_sample_counter = 0.0f;
    }
    void zero_current() {
        _cur_train_cost->clear();
        _cur_frame_counter = 0.0f;
        _cur_sample_counter = 0.0f;
    }

    void set_predict_period(size_t predict_period)  {
        _predict_period = predict_period;
    }

    void set_disc_update_period(size_t period)  {
        _disc_update_period = period;
    }

    int increase_sentframe_num(BaseBatchSample* bat);
    void sample_num_norm(DType norm);

    int increase_sample_num(int batch_size) {
        _frame_counter += batch_size;
        _sample_counter += batch_size;
        _cur_frame_counter += batch_size;
        _cur_sample_counter += batch_size;
        return batch_size;
    }

    void increase_iter(int iter) {
        _total_iter_counter += iter;
    }
    virtual void cal_loss(Loss& cost);
    bool is_time_log();
    bool is_time_model();
    bool is_time_predict();
    bool is_time_disc_update();

    virtual void update_values(Loss& cost);
    virtual void increase_values(const StatIndicator* ref);

    virtual void show_current_log() {
        std::string prefix;
        show_current_log(prefix);
    }
    virtual void show_current_log(std::string& prefix);
    virtual void show_current_log(std::vector<BaseUpdater*>& updater_vec,
                                  std::vector<WeightsMap>& w_vec,
                                  NeuralNetwork* nn) {
        std::string prefix;
        show_current_log(prefix, updater_vec, w_vec, nn);
    }
    virtual void show_current_log(std::string& prefix,
                                  std::vector<BaseUpdater*>& updater_vec,
                                  std::vector<WeightsMap>& w_vec,
                                  NeuralNetwork* nn);

    virtual bool show_latest_log() {
        std::string prefix;
        return show_latest_log(prefix);
    }
    virtual bool show_latest_log(std::string& prefix);

    virtual void show_global_log() {
        std::string prefix;
        show_global_log(prefix);

    }
    virtual void show_global_log(std::string& prefix);

    //todo: remove use show_global_log
    virtual void show_model_loss(std::string& model_name);
    virtual void store_model_loss(std::string& loss_file_name, std::string& model_name);

    Loss* get_cur_train_cost() {
        return _cur_train_cost;
    }
    size_t get_cur_frame_counter() {
        return _cur_frame_counter;
    }

    void set_tb_writer(TensorBoardWriter* writer) {
        _writer = writer;
    }
    void set_device() {
        _cpu_label_mask.set_device(CPU);
    }

    std::string& get_layer_name() {
        return _layer_name;
    }

protected:
    void _clear() {
        _sample_counter    = 0;
        _frame_counter   = 0;

        if (_last_cost != NULL) {
            _last_cost->clear();
        }

        _last_frame_counter = 0;
        _last_sample_counter = 0;

        if (_train_cost != NULL) {
            _train_cost->clear();
        }

        //log周期范围内的train cost
        if (_cur_train_cost != NULL) {
            _cur_train_cost->clear();
        }

        _cur_frame_counter = 0;
        _cur_sample_counter = 0;

        _model_item      = 1;
        _log_item        = 1;

        _predict_item      = 1;

        _disc_update_item = 1;
    }
    void _init() {
        _shrink_lr_period = 1E6;
        _log_period = 1000;
        _model_period = 500000;
        _predict_period = 20000;
        _disc_update_period = 20000;

        _last_cost = NULL;
        _train_cost = NULL;
        _cur_train_cost = NULL;

        _type = LOSS_TYPE_UNKNOWN;

        _total_iter_counter = 0;

        _sample_counter    = 0;
        _frame_counter   = 0;

        _last_frame_counter = 0;
        _last_sample_counter = 0;

        _cur_frame_counter = 0;
        _cur_sample_counter = 0;

        _model_item      = 1;
        _log_item        = 1;

        _predict_item      = 1;

        _disc_update_item = 1;
        _cur_clock = std::chrono::high_resolution_clock::now();
        _writer = NULL;
        _step = 1;
    }

public:
    LossType _type;
    Loss* _train_cost;
    std::string _layer_name;
    //
    size_t _model_item;
    size_t _log_item;

    /*
     * 记录整个训练过程中经过了多少个iter, 一个iter包含多个mini batch,
     * 具体数量由localSyncPeriod设置，一个epoch结束不清零
    */
    size_t _total_iter_counter;

    size_t _sample_counter;
    size_t _frame_counter;

    size_t _log_period;
    size_t _model_period;
    size_t _shrink_lr_period;

    Loss* _last_cost;
    size_t _last_frame_counter;
    size_t _last_sample_counter;

    //log周期范围内的train cost
    Loss* _cur_train_cost;
    size_t _cur_frame_counter;
    size_t _cur_sample_counter;

    size_t _predict_item;
    size_t _predict_period;

    size_t _disc_update_period;
    size_t _disc_update_item;

    std::chrono::high_resolution_clock::time_point _cur_clock;
    TensorBoardWriter* _writer;
    uint64_t _step;

    Tensor<int> _cpu_label_mask;
};

class CtcStatIndicator : public StatIndicator {
public:
    CtcStatIndicator() : StatIndicator() {
        _init();
    }
    CtcStatIndicator(const PeriodConfig& cfg, LossType loss_type, 
                const std::string& layer_name) : StatIndicator(cfg, loss_type, layer_name) {
    }

    CtcStatIndicator(const PeriodConfig& cfg, LossType loss_type, std::string& last_cost_name,
                std::string& train_cost_name, std::string& cur_train_cost_name, 
                const std::string& layer_name) :
                StatIndicator(cfg, loss_type, last_cost_name, train_cost_name, 
                cur_train_cost_name, layer_name) {
    }

    ~CtcStatIndicator() {
    }

    void cal_loss(Loss& cost);
    void update_values(Loss& cost);
    void increase_values(const StatIndicator* ref);

    void show_current_log(std::string& prefix);
    bool show_latest_log(std::string& prefix);
    void show_global_log(std::string& prefix);

protected:
    void _clear() {
    }
    void _init() {
    }

public:
};

class TripletStatIndicator : public StatIndicator {
public:
    TripletStatIndicator() : StatIndicator() {
        _init();
    }
    TripletStatIndicator(const PeriodConfig& cfg, LossType loss_type, 
                const std::string& layer_name) : StatIndicator(cfg, loss_type, layer_name) {
    }

    TripletStatIndicator(const PeriodConfig& cfg, LossType loss_type,
                std::string& last_cost_name, std::string& train_cost_name, std::string&
                cur_train_cost_name, const std::string& layer_name) : 
                StatIndicator(cfg, loss_type, last_cost_name, 
                train_cost_name, cur_train_cost_name, layer_name) {
    }

    ~TripletStatIndicator() {
    }

    void cal_loss(Loss& cost);
    void update_values(Loss& cost);
    void increase_values(const StatIndicator* ref);

    void show_current_log(std::string& prefix);
    bool show_latest_log(std::string& prefix);
    void show_global_log(std::string& prefix);

protected:
    void _clear() {
    }
    void _init() {
    }
};

class MixLrStatIndicator : public StatIndicator {
public:
    MixLrStatIndicator() : StatIndicator() {
        _init();
    }
    MixLrStatIndicator(const PeriodConfig& cfg, LossType loss_type, 
                const std::string& layer_name) : StatIndicator(cfg, loss_type, layer_name) {
    }

    MixLrStatIndicator(const PeriodConfig& cfg, LossType loss_type,
                std::string& last_cost_name, std::string& train_cost_name, std::string&
                cur_train_cost_name, const std::string& layer_name) : 
                StatIndicator(cfg, loss_type, last_cost_name, 
                train_cost_name, cur_train_cost_name, layer_name) {
    }

    ~MixLrStatIndicator() {
    }

    void cal_loss(Loss& cost);
    void update_values(Loss& cost);
    void increase_values(const StatIndicator* ref);

    void show_current_log(std::string& prefix);
    bool show_latest_log(std::string& prefix);
    void show_global_log(std::string& prefix);

protected:
    void _clear() {
    }
    void _init() {
    }
};
}
}

#endif
