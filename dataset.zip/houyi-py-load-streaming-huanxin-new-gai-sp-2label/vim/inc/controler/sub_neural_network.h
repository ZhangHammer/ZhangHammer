/**
 * sub_neural_network.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_TRAIN_PLATFORM_SUB_NEURAL_NETWORK_H
#define HOUYI_TRAIN_PLATFORM_SUB_NEURAL_NETWORK_H
#include "message_queue.h"
#include "neural_network.h"
#include <semaphore.h>
#include "train_type.h"
#include "nccl_wrapper.h"

namespace houyi {
namespace train {
class DwMessage;

class SubNeuralNetwork : public NeuralNetwork {
protected:
    std::vector<DwMessage*> _layer_msg_vec;
    MessageQueue<DwMessage*>* _dw_mq;

    int _async_period_num;
    TrainType _train_type;
    int _self_update_counter;

    int _done_iter_num;
   
#ifdef __ENABLE_NCCL__ 
    std::shared_ptr<Nccl> _intra_node_comm;
#endif

public:
    SubNeuralNetwork() : NeuralNetwork() {
        _dw_mq = NULL;
        _layer_msg_vec.clear();
        _async_period_num = 1;
        _train_type = TRAIN_UNKNOWN;
        _self_update_counter = 0;

        _done_iter_num = 0;
    }
    SubNeuralNetwork(NeuralNetwork* parent,
                     MessageQueue<DwMessage*>* dwMsgQ,
                     int async_period_num, 
                     TrainType train_type = TRAIN_UNKNOWN);

    SubNeuralNetwork(NeuralNetwork* parent,
                     MessageQueue<DwMessage*>* dwMsgQ) {
        new(this) SubNeuralNetwork(parent, dwMsgQ, 1);
    }

    ~SubNeuralNetwork();

    inline void set_async_period(int period) {
        _async_period_num = period;
    }
    int done_iter_num() {
        return _done_iter_num;
    }

#ifdef __ENABLE_NCCL__ 
    inline void set_intra_node_comm(std::shared_ptr<Nccl>& comm) {
        _intra_node_comm = comm;
    }
#endif

    void backward();
    void update();
    void done_message();
    void loss_ready_message();
    void send_message(int id);
    void adjust_lr(size_t iter_cnt);
    void gen_bp_flag();
    void store_mean_var();
};

class DwMessage {
protected:
    NeuralNetwork* _nn;
    int _layer_id;
    DType _learn_rate;
    int _device_id;

    //vector<int> _map_idx;
    WeightsMap _dw_vec;
    WindStream _cp_out_stream;
    WindEvent _cp_out_event;

    sem_t _updated;
    WindStream _cp_in_stream;
    WindEvent _cp_in_event;

    bool _init_gpu;
    WeightsMap _gpu_dw_vec;

public:
    DwMessage(SubNeuralNetwork* n, int l, bool init_gpu);

    DwMessage(SubNeuralNetwork* n, int l) {
        new(this) DwMessage(n, l, false);
    }
    ~DwMessage();
    inline int layer_id() {
        return _layer_id;
    }
    inline int device_id() {
        return _device_id;
    }
    inline NeuralNetwork* nn() {
        return _nn;
    }
    inline WeightsMap& dw_vec() {
        return _dw_vec;
    }

    void set_device_info(WindStream oStream, WindStream iStream);
    void accum_grad(DType alpha, DType beta);
    void zero_accum_grad();
    void copy_out(SPEECH_NN_W_TYPE); // called by train-thread
    void sync_copy_out();// called by main-thread
    void update(WeightsMap& w_vec); // called by main-thread
    void sync_update(); // called by train-thread
};

class SyncCls {
public:

    SyncCls() {
        _flag = false;
        _busy_flag = false;
        sem_init(&_copy_done_sem, 0, 0);
    }
    ~SyncCls() {
        sem_destroy(&_copy_done_sem);

        for (int l = 0; l < _train_nn->layer_size(); l++) {
            release_weight_map(_w_vec[l]);
        }
    }

    void set_sub_nn(SubNeuralNetwork* Train_nn) {
        _train_nn = Train_nn;
        _w_vec.resize(Train_nn->layer_size());
    }

    inline bool flag_is_set() {
        return _flag;
    }
    inline void set_flag()   {
        _flag = true;
    }
    inline void clear_flag() {
        _flag = false;
    }
    inline bool busy_flag_is_set() {
        return _busy_flag;
    }
    inline void set_busy_flag() {
        _busy_flag = true;
    }
    inline void clear_busy_flag() {
        _busy_flag = false;
    }

    void copy_done() {
        sem_post(&_copy_done_sem);
    }
    void wait_copy_done() {
        sem_wait(&_copy_done_sem);
    }
    void copy_models(NeuralNetwork* Gen_nn);

private:
    bool _flag;
    bool _busy_flag;
    sem_t _copy_done_sem;
    SubNeuralNetwork* _train_nn;
    std::vector<WeightsMap> _w_vec;
};
}
}
#endif
