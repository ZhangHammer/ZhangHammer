#ifndef HOUYI_TRAIN_PLATFORM_MAJOR_TRAIN_THREAD_H
#define HOUYI_TRAIN_PLATFORM_MAJOR_TRAIN_THREAD_H

#include "sub_trainer.h"
#include "trainer.h"
#include "multi_trainer.h"
#include "multi_neural_network.h"
#include "sub_neural_network.h"

namespace houyi {
namespace train {

class SubTrainer;
class MultiTrainer;

class AsyncTrainThread {
private:
    pthread_t _thread_id;
    int       _device_id;
    NNConfig* _nn_cfg;
    MultiNeuralNetwork* _local_multi_nn;
    SubTrainer**  _sub_traners;
    MultiTrainer*     _local_trainer;

    bool _thread_exit;

    bool _multi_node_training;

public:

    AsyncTrainThread(
        NNConfig* cfg, MultiNeuralNetwork* muti_nn,
        SubTrainer* sub_traners[], MultiTrainer* trainer);
    //TrainThread* train_threads[], MultiTrainer *trainer);

    ~AsyncTrainThread() {
        _nn_cfg         = NULL;
        _local_multi_nn = NULL;
        _sub_traners  = NULL;
        _local_trainer  = NULL;
    }

    pthread_t* thread_id() {
        return &_thread_id;
    }
    int        device_id() {
        return _device_id;
    }

    bool is_thread_exit() {
        return _thread_exit;
    }

    void sync_train(int curEpoch);
    bool sync_with_server(int* cur_up_couter, int cur_thread_id, int need_up_num);
    void async_train(int curEpoch);
    static void* run_thread(void* self);
    void run();
};
}
}
#endif
