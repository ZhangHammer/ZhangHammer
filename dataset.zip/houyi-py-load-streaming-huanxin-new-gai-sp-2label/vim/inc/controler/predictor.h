/**
 * predictor.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-10-17
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_CONTROLER_PREDICTOR_H
#define HOUYI_CONTROLER_PREDICTOR_H
#include "predict_nn_config.h"
#include "base_batch_sample.h"
#include "base_data_reader.h"
#include "base_processer.h"
#include "base_repository.h"
#include "stat_indicator.h"
#include "message_queue.h"

namespace houyi {
namespace train {

class Predictor {
public:
    Predictor() {
        _init();
        set_device();
    }
    Predictor(PredictNnConfig* nn_cfg);
    virtual ~Predictor();
    virtual void reset();

    virtual void show_current_log();
    virtual void show_model_loss(std::string& model_name);
    virtual void store_model_loss(std::string& loss_file_name, std::string& model_name);
    virtual void store_score(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
                std::string& model_name, int batch_count, BaseBatchSample* bat);
    virtual void store_kaldi_score(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
            std::string& model_name, int batch_count, BaseBatchSample* bat);
    virtual void store_classify(Tensor<DType>& score, Tensor<int>& mask, std::string& dir, 
                std::string& model_name, int batch_count, BaseBatchSample* bat);

    std::pair<BaseBatchSample*, DeviceBatchSample*> load_data();

    void copy_batch(Argument& dest, BaseBatchSample& src, DeviceBatchSample& device_batch);

    void start();
    static void* run_thread(void* self);
    virtual void run();

    inline int device_id() {
        return _device_id;
    }

    inline NeuralNetwork& get_nn() {
        return *_nn;
    }
    inline bool is_thread_exit() {
        return _thread_exit;
    }

    MessageQueue<std::string*>* get_model_file_queue() {
        return _model_file_queue;
    }

    int get_predict_period() {
        return _predict_period;
    }

protected:
    void _init() {
        _id = 0;
        _device_id = 0;
        _thread_exit = false;
        _nn_cfg = NULL;
        _reset_mark = NULL;
        _reset_counter = 0;
        _data_reader = NULL;
        _data_proccer = NULL;
        _data_repos = NULL;
        _nn = NULL;
        _work_thread = NULL;
        _model_file_queue = NULL;
    }
    void set_device() {
        _score_mask.set_device(GPU);
    }

protected:
    int _id;
    int _device_id;
    /* flag for predict thread finish */
    bool _thread_exit;

    //config
    PredictNnConfig* _nn_cfg;

    /* Statistical indicators */
    std::vector<StatIndicator*> _stat_indicator;
    std::vector<std::string> _out_layer_name;
    int* _reset_mark;
    int _reset_counter;

    // data
    /* data-reader */
    BaseDataReader* _data_reader;
    BaseProcesser* _data_proccer;
    BaseRepository* _data_repos;

    // nnet
    NeuralNetwork* _nn;

    // model to predict
    std::string _model_file;
    std::string _inq_model_file;
    std::string _model_file_list;
    std::set<std::string> _pre_model_set;

    /* directory for store score */
    std::string _score_store_dir;

    /* directory for store score */
    std::string _score_store_kaldi_dir;

    /*保存打分的分类结果*/
    std::string _classify_store_dir;

    /* file used for store loss */
    std::string _loss_file;

    std::vector<IOPackage*> _feat_pack;
    std::vector<IOPackage*> _label_pack;
    Argument _bat_data;

    Thread* _work_thread;

    /* mutex for data load */
    pthread_mutex_t _load_mutex;

    /* period for predict model */
    int _predict_period;
    /* bin call before predict */
    std::string _call_before_predict;
    /* bin call after predict */
    std::string _call_after_predict;

    MessageQueue<std::string*>* _model_file_queue;

    // mask in cpu
    Tensor<int> _score_mask;

protected:
    /* workspace for all layer, such as conv */
    Tensor<unsigned char>* _worksapce = NULL;
};

extern Predictor* creat_predictor(PredictNnConfig& cfg);

}
}

#endif
