/**
 * Trainer.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-25
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_TRAINER_H
#define HOUYI_TRAIN_PLATFORM_TRAINER_H

#include "multi_neural_network.h"
#include "base_batch_sample.h"
#include "base_data_reader.h"
#include "base_processer.h"
#include "base_repository.h"
#include "stat_indicator.h"

namespace houyi {
namespace train {

class Trainer {
public:
    Trainer() {
        _init();
    }
    Trainer(NNConfig* nn_cfg);
    virtual ~Trainer();
    virtual void reset();
    std::pair<BaseBatchSample*, DeviceBatchSample*> load_data();
    void copy_batch(Argument& dest, BaseBatchSample& src, DeviceBatchSample& device_batch);
    void store_model(const char* prefix_name, int cur_epoch, char* model_name);
    NeuralNetwork& get_nn() {
        return *_nn;
    }
    void set_predict_period(size_t predict_period)  {
        for (size_t i = 0; i < _stat_indicator.size(); i++) {
            _stat_indicator[i]->set_predict_period(predict_period);
        }
    }

    void set_disc_update_period(size_t period)  {
        for (size_t i = 0; i < _stat_indicator.size(); i++) {
            _stat_indicator[i]->set_disc_update_period(period);
        }
    }

    MessageQueue<std::string*>* get_model_predict_queue() {
        return _model_predict_queue;
    }

    MessageQueue<std::string*>* get_disc_update_queue() {
        return _disc_update_queue;
    }

    void set_model_predict_queue(MessageQueue<std::string*>* model_predict_queue) {
        _model_predict_queue = model_predict_queue;
    }

    void set_disc_update_queue(MessageQueue<std::string*>* queue) {
        _disc_update_queue = queue;
    }

    TensorBoardWriter* get_tb_writer() {
        return _tb_writer;
    }

protected:
    int _id;
    int _device_id;

    void _init() {
        _nn_cfg = NULL;
        _data_reader = NULL;
        _data_proccer = NULL;
        _data_repos = NULL;
        _nn = NULL;
        _store_model_file = _store_md_model_file = NULL;
        _model_predict_queue = NULL;
        _disc_update_queue = NULL;
        _tb_writer = NULL;
    }
    //config
    NNConfig* _nn_cfg;

    // indicator
    std::vector<std::string> _cost_layer_name;
    std::vector<std::string> _out_layer_name;
    std::vector<StatIndicator*> _stat_indicator;
    // data
    BaseDataReader* _data_reader;
    BaseProcesser* _data_proccer;
    BaseRepository* _data_repos;

    // nnet
    NeuralNetwork* _nn;

    // model-storage
    char* _store_model_file;
    char* _store_md_model_file;
    char _last_model_name[512];

    std::vector<IOPackage*> _feat_pack;
    std::vector<IOPackage*> _label_pack;

    MessageQueue<std::string*>* _model_predict_queue;
    MessageQueue<std::string*>* _disc_update_queue;
    TensorBoardWriter* _tb_writer;
};

}

}
#endif
