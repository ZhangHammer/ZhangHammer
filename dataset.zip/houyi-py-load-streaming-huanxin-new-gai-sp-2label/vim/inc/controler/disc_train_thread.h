/**
 * disc_train_thread.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-16
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_CONTROLER_DISC_TRAIN_THREAD_H
#define HOUYI_CONTROLER_DISC_TRAIN_THREAD_H

#include "disc_nn_cfg.h"
#include "multi_discriminator.h"
#include "sub_discriminator.h"
#include "multi_neural_network.h"
#include "sub_neural_network.h"
#include "decoder.h"

namespace houyi {
namespace train {

class MultiDiscriminator;
class SubDiscriminator;
class Decoder;

class DiscTrainThread {
private:
    pthread_t _thread_id;
    int       _device_id;
    DiscNNConfig* _nn_cfg;
    MultiNeuralNetwork* _local_multi_nn;

    SubDiscriminator**  _sub_disc;
    MultiDiscriminator* _local_disc;

    int* _exit_flag;
    bool _is_wait;
    bool _thread_exit;

    std::string _model_file;
    /* period for predict model */
    int _predict_period;
    /* bin call before predict */
    std::string _call_before_predict;
    /* bin call after predict */
    std::string _call_after_predict;

    std::string _bn_path_prefix;

public:

    DiscTrainThread(
        DiscNNConfig* cfg, MultiNeuralNetwork* muti_nn,
        SubDiscriminator* sub_disc[], MultiDiscriminator* disc);

    ~DiscTrainThread() {
        _nn_cfg         = NULL;
        _local_multi_nn = NULL;
        _sub_disc  = NULL;
        _local_disc  = NULL;
    }

    pthread_t* thread_id() {
        return &_thread_id;
    }
    int device_id() {
        return _device_id;
    }

    void set_exit_flag(int* flag) {
        _exit_flag = flag;
    }

    bool is_thread_exit() {
        return _thread_exit;
    }

    static void* run_thread(void* self);
    void run();
    bool is_wait() {
        return _is_wait;
    }
    void resume_from_major();
    void zero_layer_mdw();
};

}
}

#endif
