/**
 * select_decoder.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-12-6
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_CONTROLER_SELECT_DECODER_H
#define HOUYI_CONTROLER_SELECT_DECODER_H
#include "multi_trainer.h"
#include "sub_neural_network.h"
#include "argument.h"
#include "base_data_reader.h"
#include "decoder.h"

namespace houyi {
namespace train {

bool pos_neg_cmp(const std::tuple<DType, int>& a,
                 const std::tuple<DType, int>& b);

class SelectDecoder : public Decoder {
protected:
    /* 召回率 */
    DType _recall;
    /* 按照比例选择样本 */
    DType _select_ratio;
    /* 正负样本所占的比例 */
    DType _pos_neg_ratio;
    /* 根据loss的大小挑选 */
    DType _score_threshold;

    /* 重新生成的feature */
    Tensor<DType> _new_feat;
    /* 重新生成的label */
    Tensor<DType> _new_label;

public:
    SelectDecoder(DecoderConfig& cfg);
    virtual ~SelectDecoder() {}

    virtual void run();

    inline DType get_recall() {
        return _recall;
    }

    inline DType get_select_ratio() {
        return _select_ratio;
    }

    inline DType get_pos_neg_ratio() {
        return _pos_neg_ratio;
    }

    inline DType get_score_threshold() {
        return _score_threshold;
    }

    void get_idx_pos_neg_ratio(size_t cur_score_num, Tensor<DType>& score,
                               Tensor<DType>& label, Tensor<int>& idx_vec, size_t& idx_num);
    void get_idx_score_threshold(size_t cur_score_num, Tensor<DType>& score,
                                 Tensor<DType>& label, Tensor<int>& idx_vec, size_t& idx_num);

protected:
    void init() {
        _recall = -1.0f;
        _select_ratio = -1.0f;
        _pos_neg_ratio = -1.0f;
        _score_threshold = -1.0f;
    }
    void set_device() {
        _new_label.set_device(CPU);
        _new_feat.set_device(CPU);
    }
};

}
}

#endif
