#ifndef HOUYI_CONTROLER_IMAGE_PREDICTOR_H
#define HOUYI_CONTROLER_IMAGE_PREDICTOR_H

#include "predictor.h"

namespace houyi {
namespace train {

class ImagePredictor : public Predictor {

public:
    ImagePredictor() : Predictor() { }

    ImagePredictor(PredictNnConfig* nn_cfg) : Predictor(nn_cfg) { }

    virtual void run();

    virtual void store_score(Tensor<DType>& score, std::string& dir, std::string& model_name,
                             int batch_count, BaseBatchSample* bat);
};

}   // namespace train
}   // namespace houyi

#endif
