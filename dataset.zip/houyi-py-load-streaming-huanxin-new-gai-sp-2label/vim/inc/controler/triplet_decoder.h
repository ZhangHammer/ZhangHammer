/**
 * triplet_decoder.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_CONTROLER_TRIPLET_DECODER_H
#define HOUYI_CONTROLER_TRIPLET_DECODER_H
#include "multi_trainer.h"
#include "sub_neural_network.h"
#include "argument.h"
#include "base_data_reader.h"
#include "decoder.h"

namespace houyi {
namespace train {

class TripletDecoder : public Decoder {
protected:
    Tensor<DType> _trans_score;

    /* 重新生成的feature */
    Tensor<DType> _new_feat;
    /* 重新生成的label */
    Tensor<DType> _new_label;
    /* 计算样本之的距离 */
    Tensor<DType> _an_loss;
    /* triplet_loss_layer输出的loss */
    Tensor<DType> _loss;

    DType _alpha;
    TripletSelectType _triplet_select_type;
public:
    TripletDecoder(DecoderConfig& cfg);
    virtual ~TripletDecoder() {}

    virtual void run();

    inline void set_alpha(DType alpha) {
        _alpha = alpha;
    }
    inline DType get_alpha() {
        return _alpha;
    }
    inline TripletSelectType get_tripet_select_type() {
        return _triplet_select_type;
    }

    inline void set_tripet_select_type(TripletSelectType type) {
        _triplet_select_type = type;
    }

    void select_n_idx(TripletSelectType select_type, size_t sample_num, Tensor<DType>& score,
                      Tensor<DType>& label, Tensor<int>& select_idx, size_t& n_idx_num);
    void select_random_hard(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                            Tensor<int>& select_idx, size_t& n_idx_num);
    void select_semi_hard(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                          Tensor<int>& select_idx, size_t& n_idx_num);
    void row_max_diff_label(size_t sample_num, Tensor<DType>& loss, Tensor<DType>& label,
                            Tensor<int>& max_id);

protected:
    void init() {
        _alpha = 0.0f;
        _triplet_select_type = UNKNOWN_TRIP_SEL_TYPE;
    }
    void set_device() {
        _trans_score.set_device(CPU);
        _new_label.set_device(CPU);
        _new_feat.set_device(CPU);
        _an_loss.set_device(CPU);
        _loss.set_device(CPU);
    }
};

}
}

#endif
