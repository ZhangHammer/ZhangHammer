/**
 * multi_trainer.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_MULTI_TRAINER_H
#define HOUYI_TRAIN_PLATFORM_MULTI_TRAINER_H

#include "nccl_wrapper.h"
#include "trainer.h"
#include "major_train_thread.h"

#include "ps/kvworker.h"

namespace houyi {
namespace train {

class SubTrainer;
class AsyncTrainThread;

typedef std::map<std::string, int> WeightsKey;

class MultiTrainer : public Trainer {
private:
    static const int    _max_thread_num = 16;
    SubTrainer*         _sub_trainers[_max_thread_num];
    AsyncTrainThread*   _multi_train_thread;

    MultiNeuralNetwork* _multi_nn;

    std::vector<WeightsMap>  _w_buf_vec;
    std::vector<WeightsMap>  _dw_accum_vec;
    int                _total_w_size;

    size_t _device_indicator_counter;

    // map weight-name to key
    std::vector<hpps::Key> _kv_key;
    std::vector<hpps::Key> _kv_color;
    std::vector<hpps::Len> _kv_len;
    std::vector<Tensor<DType>> _kv_dw;
    std::vector<Tensor<DType>> _kv_w;
    hpps::KVWorker* _kv;
    size_t _server_model_counter;

public:
    MultiTrainer(NNConfig* nn_cfg);
    ~MultiTrainer();
    inline BaseDataReader* data_reader() {
        return _data_reader;
    }
    inline NNConfig* nn_config() {
        return _nn_cfg;
    }

    inline NeuralNetwork* ref_nn() {
        return _nn;
    }
    inline MultiNeuralNetwork* multi_nn() {
        return _multi_nn;
    }

    void  init_global_buffer();
    void  start_multi_train();
    size_t serialize_wvec(std::vector<WeightsMap>& wvec);
    size_t deserialize_wvec(std::vector<WeightsMap>& wvec);
    inline int get_total_w_size() {
        return _total_w_size;
    }

    void sync_global_weight(SubTrainer* thread_pool[],
                            int num, MultiNeuralNetwork* multi_nn);

    inline MultiNeuralNetwork* get_multi_nn() {
        return _multi_nn;
    }

    inline void reset_weight() {
        _multi_nn->reset_weight(_w_buf_vec);
    }

    int fill_weight_array(weight_t* array);

    size_t serialize(SPEECH_NN_W_TYPE type);
    size_t deserialize(SPEECH_NN_W_TYPE type);
    void update_weight_array(SPEECH_NN_W_TYPE t, weight_t* array);

    virtual void check_epoch(int cur_epoch);
    virtual void check_log(int device, int cur_epoch, std::vector<BaseUpdater*>& update_vec,
                           std::vector<WeightsMap>& w_vec);

    bool is_thread_exit();
    void update_global_weight();
    void store_global_weight();
    void stop_kvstore() {
        if (_kv) {
            delete _kv;
            _kv = NULL;
        }
    }

    void sync_kvstore() {
        CHECK2(_kv);
        if (_kv->major_worker()) {
            _kv->reset(_kv_key, _kv_w);
            INTER_LOG("Synchronize weights with server");
        }
        _kv->barrier();
    }

    inline hpps::KVWorker* get_kv() {
        return _kv;
    }

    void adjust_lr(size_t iter_cnt);
    void adjust_batch_size(size_t iter_cnt);
    void store_quantization_model(const char* prefix_name, int cur_epoch);
};
}
}
#endif
