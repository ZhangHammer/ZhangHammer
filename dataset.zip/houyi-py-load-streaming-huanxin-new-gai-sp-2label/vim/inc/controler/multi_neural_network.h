/**
 * multi_neural_network.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_TRAIN_PLATFORM_MULTI_NEURAL_NETWORK_H
#define HOUYI_TRAIN_PLATFORM_MULTI_NEURAL_NETWORK_H
#include "sub_neural_network.h"
#include "low_bit_quant.h"
#include "low_bit_quant_device.h"

namespace houyi {
namespace train {
class DwMessage;

class MultiNeuralNetwork {
protected:
    typedef std::vector<DwMessage*> DWMSGVec;
    MessageQueue<DwMessage*>* _dw_mq;
    NeuralNetwork* _major_nn;
    int _dw_counter;
    int _up_number;
    int _layer_num;
    std::vector<WeightsMap> _mdw_vec;
    std::vector<WeightsMap> _w_vec;
    std::vector<WeightsMap> _w_quant_vec;
    std::vector<DWMSGVec>  _msg_group;
    std::vector<BaseUpdater*> _updater_vec;

    int  _async_period_num;
    TrainType _train_type;
    int  _global_sync_period;
    bool* _finish_flags;
    int  _train_thread_num;
    int _fixed_period;
    int _fixed_batch_count;

    bool _dirty; // if the model is incorrect, there dirty is set,
    // and the Gradientes from sub-nn should be ignored

    GlobalUpdaterCfg _global_updater_cfg;

    bool _enable_statis;
    std::vector<bool> _layer_quantize;
    std::vector<bool> _weight_quant_transpose;
    std::vector<size_t> _weight_quant_bits;
    LowBitQuantDevice _lbq;
    
    std::vector<bool> _weight_fixed_transpose;
    Tensor<DType> _weight_fixed_buffer;

public:
    void init() {
        _dw_mq = NULL;
        _major_nn = NULL;
        _dw_counter = 0;
        _up_number = 0;
        _layer_num = 0;
        _mdw_vec.clear();
        _w_vec.clear();
        _msg_group.clear();

        _async_period_num = 0;
        _train_type = TRAIN_UNKNOWN;
        _finish_flags = NULL;
        _train_thread_num = 0;

        _dirty = false;
        _enable_statis = false;

        _fixed_period = 0;
        _fixed_batch_count = 0;
    }

    MultiNeuralNetwork() {
        init();
    }
    MultiNeuralNetwork(int layer_size, int threadNum, int async_period_num,
                       int global_sync_period, TrainType train_type,
                       GlobalUpdaterCfg& global_updater_cfg);
    ~MultiNeuralNetwork();

    void set_fixed_period(int fixed_period) {
        _fixed_period = fixed_period;
    }

    void set_layer_quantize(std::vector<bool> in) {
        _layer_quantize = in;
    }

    void set_weight_quant_transpose(std::vector<bool> in) {
        _weight_quant_transpose = in;
    }

    void set_weight_fixed_transpose(std::vector<bool> in) {
        _weight_fixed_transpose = in;
    }

    void set_weight_quant_bits(std::vector<size_t> in, size_t global) {
        _weight_quant_bits = in;
        if (global > 0) {
            for (size_t i = 0; i < _weight_quant_bits.size(); i++) {
                if (_layer_quantize[i] && _weight_quant_bits[i] == 0) {
                    _weight_quant_bits[i] = global;
                }
            }
        }
        _lbq.init(*std::max_element(_weight_quant_bits.begin(), _weight_quant_bits.end()));
    }


    void set_major_nn(NeuralNetwork* nn) {
        _major_nn = nn;
        std::vector<Layer*>& layers = _major_nn->layers();

        for (size_t i = 0; i < layers.size(); i++) {
            if (_train_type == ASYNC_TRAIN) {
                BaseUpdater* updater = layers[i]->updater();
                std::string type = (updater->get_cfg().type() == "unknown") ?
                                   updater->get_global_cfg().get_gd_type() 
                                   : updater->get_cfg().type();

                if (type == "sgd") {
                    UpdaterConfig cfg("sgd");
                    _updater_vec.push_back(new SgdUpdater(cfg, _global_updater_cfg));
                    _updater_vec[i]->adjust(1.0f, 0.0f); // learn_rate, momentum
                } else if (type == "adam") {
                    _updater_vec.push_back(layers[i]->updater()->clone());
                } else {
                    CHECK(false, "updater type support");
                }
            } else {                        // other
                _updater_vec.push_back(layers[i]->updater()->clone());
            }
        }
    }

    inline NeuralNetwork* major_nn() {
        return _major_nn;
    }

    inline int layer_num() {
        return _layer_num;
    }

    inline void set_dirty() {
        _dirty = true;
    }
    inline bool is_dirty() {
        return _dirty;
    }
    inline void set_clean() {
        _dirty = false;
    }
    inline int up_number() {
        return _up_number;
    }

    inline void mark_finish(int last_idx) {
        _finish_flags[last_idx] = true;
    }
    inline std::vector<BaseUpdater*>& updater_vec() {
        return _updater_vec;
    }

    inline bool all_finish() {
        for (int i = 0; i < _train_thread_num; i++) {
            if (!_finish_flags[i]) {
                return false;
            }
        }

        return true;
    }

    inline void clear_msg_group() {
        for (size_t i = 0; i < _msg_group.size(); i++) {
            _msg_group[i].clear();
        }
    }

    inline int poolling(int last_idx) {
        int cur_idx = (last_idx + 1) % _train_thread_num;

        int head_idx = cur_idx;

        do {
            if (_finish_flags[cur_idx] == false) {
                return cur_idx;
            } else {
                cur_idx = (cur_idx + 1) % _train_thread_num;
            }
        } while (head_idx != cur_idx);

        //return -1;
        return last_idx;
    }

    inline void clear_finish_flag() {
        for (int i = 0; i < _train_thread_num; i++) {
            _finish_flags[i] = false;
        }
    }

    inline void set_up_number(int threadNum) {
        _up_number = threadNum;

        if (_finish_flags == NULL) {
            _finish_flags = (bool*) malloc(sizeof(bool) * _train_thread_num);

            for (int i = 0; i < _train_thread_num; i++) {
                _finish_flags[i] = false;
            }
        }

        // _train_thread_num = _up_number;
    }
    inline WeightsMap& w_vec(int idx) {
        return _w_vec[idx];
    }

    inline std::vector<WeightsMap>& w_vec() {
        return _w_vec;
    }

    inline WeightsMap& mdw_vec(int idx) {
        return _mdw_vec[idx];
    }

    inline MessageQueue<DwMessage*>* dw_mesg_queue(int idx) {
        return &_dw_mq[idx];
    }

    inline MessageQueue<DwMessage*>* dw_mesg_queue() {
        return dw_mesg_queue(0);
    }
    inline int get_async_period_num() {
        return _async_period_num;
    }
    void        init_weight(NeuralNetwork* nn,
                            NNConfig* nn_cfg, const char* md_model_file);

    void        update_all_msg();
    DwMessage* collect_msg(DwMessage* msg);
    DwMessage* update_from_msg(DwMessage* msg, bool do_update);
    void        if_do_update(int l, bool notice);
    void        do_update(int layer_id);

    void        reset(int threadNum);
    void        reset_weight(std::vector<WeightsMap>& src);
    void        reset_momentum(std::vector<WeightsMap>& src);
    void        register_dw_buf(std::vector<WeightsMap>& dw_buf);
    void        copy_weight(std::vector<WeightsMap>& src);
    void        copy_momentum(std::vector<WeightsMap>& src);

    void adjust_lr(size_t iter_cnt);

    void store_quantization_weight(const char* prefix_name, int cur_epoch, size_t counter);
};
}
}
#endif
