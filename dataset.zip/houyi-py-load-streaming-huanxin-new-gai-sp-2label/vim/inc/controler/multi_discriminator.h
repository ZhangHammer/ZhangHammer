/**
 * multi_discriminator.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-14
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_CONTROLER_MULTI_DISCRIMINATOR_H
#define HOUYI_CONTROLER_MULTI_DISCRIMINATOR_H

#include "trainer.h"
#include "disc_train_thread.h"
#include "sub_discriminator.h"
#include "decoder.h"

namespace houyi {
namespace train {

class DiscTrainThread;

class MultiDiscriminator : public Trainer {
private:
    static const int    _max_thread_num = 16;
    SubDiscriminator* _sub_disc[_max_thread_num];
    DiscTrainThread*   _multi_train_thread;
    MultiNeuralNetwork* _multi_nn;

    Decoder* _decoder;
    DecoderConfig _decoder_cfg;

    MessageQueue<std::string*>* _model_predict_queue;
    int _model_update_period;
public:
    MultiDiscriminator(DiscNNConfig* nn_cfg);
    ~MultiDiscriminator();
    inline BaseDataReader* data_reader() {
        return _data_reader;
    }
    inline void set_decode_data_reader(BaseDataReader* data_reader) {
        _decoder->set_data_reader(data_reader);
    }
    inline DiscNNConfig* nn_config() {
        return dynamic_cast<DiscNNConfig*>(_nn_cfg);
    }

    inline NeuralNetwork* ref_nn() {
        return _nn;
    }
    inline MultiNeuralNetwork* multi_nn() {
        return _multi_nn;
    }
    inline MessageQueue<std::string*>* get_model_predict_queue() {
        return _model_predict_queue;
    }
    inline int get_model_update_period() {
        return _model_update_period;
    }

    void  start_disc();

    inline void  stop_multi_train() {
        //pthread_join(*(_multi_train_thread->thread_id()), NULL);
        // TODO:
    }

    inline MultiNeuralNetwork* get_multi_nn() {
        return _multi_nn;
    }

};

}
}

#endif
