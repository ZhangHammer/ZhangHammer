/**
 * decoder.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-29
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_CONTROLER_DECODER_H
#define HOUYI_CONTROLER_DECODER_H
#include "multi_trainer.h"
#include "sub_neural_network.h"
#include "argument.h"
#include "base_data_reader.h"

namespace houyi {
namespace train {

class Decoder;

class DecodeData {
public:
    IOPackage _feat;
    IOPackage _label;
    Tensor<DType> _score;
};

Decoder* creat_decoder(DecoderConfig& cfg);

class Decoder {
protected:
    DecoderType _type;
    size_t _decoder_period;
    size_t _epoch;
    size_t _score_thread_num;

    Thread* _work_thread;

    MessageQueue<DecodeData*>* _decode_data_queue;
    BaseDataReader* _data_reader;

    Tensor<DType> _score;
    Tensor<DType> _feat;
    Tensor<DType> _label;

public:
    Decoder(DecoderConfig& cfg);
    virtual ~Decoder();

    virtual void reset();
    void start();
    static void* run_thread(void* self);
    virtual void run();

    MessageQueue<DecodeData*>* get_decode_data_queue() {
        return _decode_data_queue;
    }
    inline void set_data_reader(BaseDataReader* data_reader) {
        _data_reader = data_reader;
    }
    inline DecoderType get_type() {
        return _type;
    }
    inline void set_type(DecoderType type) {
        _type = type;
    }
    inline size_t get_epoch() {
        return _epoch;
    }
    inline void set_epoch(size_t epoch) {
        _epoch = epoch;
    }
    inline size_t get_score_thread_num() {
        return _score_thread_num;
    }
    inline void set_score_thread_num(size_t score_thread_num) {
        _score_thread_num = score_thread_num;
    }
    inline size_t get_decoder_period() {
        return _decoder_period;
    }
    inline void set_decoder_period(size_t decoder_period) {
        _decoder_period = decoder_period;
    }

protected:
    void init() {
        _type = UNKNOWN_DECODER;
        _decode_data_queue = NULL;
        _work_thread = NULL;
        _decoder_period = 1000;
        _epoch = 1;
        _data_reader = NULL;
    }
    void set_device() {
        _score.set_device(CPU);
        _feat.set_device(CPU);
        _label.set_device(CPU);
    }
};

}
}

#endif
