/**
 * neural_network.h
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-26
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_CONTROLER_NEURAL_NETWORK_H
#define HOUYI_CONTROLER_NEURAL_NETWORK_H

#include <gflags/gflags.h>

#include "nn_config.h"
#include "layer.h"
#include "loss_layer.h"
#include "wind/wind.h"

DECLARE_bool(enable_new_layer);

namespace houyi {
namespace train {
class NeuralNetwork {
protected:
    void _init() {
        _start_up_id = -1;
        _end_up_id   = -1;
        _up_num      = 0;
        _cnt_flag = 0;
        _lstm_skip_num = 0;
        _batch_size = 1;
        _batch_clear_prob = 0;
        _batch_clear_num = 0;
    }
public:
    NeuralNetwork() {
        _init();
    }
    NeuralNetwork(NeuralNetwork& nn);
    NeuralNetwork(NNConfig& configs, bool need_update);
    virtual ~NeuralNetwork();
    Layer* create_layer(LayerConfig& cfg, std::vector<std::string>& cost_layer_name,
                        std::vector<LossLayer*>& cost_layer);

    void register_argument();
    void common_set(Tensor<DType>* prior);
    void check_update_limit();
    void zero_grad();
    void zero_buf(SPEECH_NN_W_TYPE t);
    void set_drop_flag(bool drop_flag);

    void forward();
    void backward();

    bool update();
    void read_prior(const char* prior_name);
    void store_model(const char* file_name, SPEECH_NN_W_TYPE t);
    void read_model_no_bn(const char* file_name, SPEECH_NN_W_TYPE t,
                          int start_layer, int end_layer);
    void read_model(const char* file_name, SPEECH_NN_W_TYPE t,
                    int start_layer, int end_layer);
    void read_model(const char* file_name, SPEECH_NN_W_TYPE t,
                    int start_layer, int end_layer,
                    std::string bn_file_prefix);
    void read_heter_model(const char* file_name, int startLayer,
                          int endLayer);
    void read_hfnn_model(const char* file_name, SPEECH_NN_W_TYPE t,
                         int start_layer, int end_layer);
    void read_inq_model(const char* file_name, SPEECH_NN_W_TYPE t, 
                int start_layer, int end_layer);
    void read_inq_model(const char* file_name, SPEECH_NN_W_TYPE t, 
                int start_layer, int end_layer, std::string bn_file_prefix);

    void init_weight(const ModelInitConfig& cfg);
    void gauss_init_weight(DType mean, DType stdv);

    void set_train_data(Argument& train_data_args);
    void clear_train_data(Argument& train_data_args);
    void resize_out();

    void  clear_history(int bat_idx);
    void  clear_history();
    void  store_history();
    Loss& cal_cost(std::string& cost_name);

    Tensor<DType>* get_output(std::string& out_layer_name) {
        IOPackage* io = _out_args.get_pack(out_layer_name);
        CHECK2(io);
        return io->get_ten();
    }
    Tensor<int>* get_output_mask(std::string& out_layer_name) {
        IOPackage* io = _out_args.get_pack(out_layer_name);
        CHECK2(io);
        return io->get_mask();
    }

    Tensor<DType>* get_loss(std::string& loss_layer_name) {
        IOPackage* io = _out_args.get_pack(loss_layer_name);
        CHECK2(io);
        return io->get_ten();
    }

    Tensor<DType>* get_prior() {
        return _out_args.get_prior();
    }
    void reset_weight(std::vector<WeightsMap>& src);
    void reset_momentum(std::vector<WeightsMap>& src);
    void dw_from(NeuralNetwork* nn, int layer);
    void clean_delta_w();
    int layer_size() {
        return (int)this->_layers.size();
    }
    std::vector<Layer*>& layers() {
        return _layers;
    }

    inline int start_id() {
        return _start_up_id;
    }

    inline int end_id() {
        return _end_up_id;
    }

    inline int update_layer_num() {
        return _up_num;
    }

    inline std::vector<LossLayer*> get_cost_layer() {
        return _cost_layer;
    }
    inline std::vector<std::string>& get_out_layer_name() {
        return _out_layer_name;
    }

    inline std::vector<Layer*>& get_out_layer() {
        return _out_layer;
    }

    inline std::vector<std::string>& get_cost_layer_name() {
        return _cost_layer_name;
    }

    inline Argument& get_out_args() {
        return _out_args;
    }

    inline Argument& get_diff_args() {
        return _diff_args;
    }

    inline size_t get_cnt_flag() {
        return _cnt_flag;
    }
    inline int get_lstm_skip_num() {
        return _lstm_skip_num;
    }
    inline int get_batch_size() {
        return _batch_size;
    }
    inline int get_batch_clear_prob() {
        return _batch_clear_prob;
    }
    inline int get_batch_clear_num() {
        return _batch_clear_num;
    }
    inline std::vector<int>& get_odd_his_vec() {
        return _odd_his_vec;
    }
    inline std::vector<int>& get_even_his_vec() {
        return _even_his_vec;
    }
    bool is_feature_key(std::string key);
    bool is_label_key(std::string key);
    Layer* get_layer_by_input_key(std::string& key);
    Layer* get_layer_by_out_key(std::string& key);
    Layer* get_layer_by_name(std::string& name);
    //out layer 指的是最后一个输出的层，一般为softmax
    void build_out_layer();
    int is_echo_finish();
    void layer_set(std::vector<Layer*>& layers, int sample_num);
    void free_layer_output() {
        for (size_t i = 0; i < _layers.size(); i++) {
            _layers[i]->free_output();
        }
    }
    void gen_his_clear_vec();
    void set_workspace(Tensor<unsigned char>* workspace);

protected:
    NNConfig *_nn_config;
    std::vector<Layer*> _layers;
    Argument _out_args;
    Argument _diff_args;
    std::vector<std::string> _out_layer_name;
    std::vector<Layer*> _out_layer;

    std::vector<std::string> _cost_layer_name;
    std::vector<LossLayer*> _cost_layer;

    // update map info
    int _start_up_id; // the layer id which the first update
    int _end_up_id;   // the layer id which the last update
    int _up_num;      // the total layer-number which need to be updated

    //for ctc
    size_t _cnt_flag;
    int _lstm_skip_num;
    int _batch_size;
    int _batch_clear_prob;
    int _batch_clear_num;
    std::vector<int> _odd_his_vec;
    std::vector<int> _even_his_vec;

    std::vector<std::string> _feature_key;
    std::vector<std::string> _label_key;

    std::vector<IOPackage*> _input_io_vec;
};

}
}

#endif
