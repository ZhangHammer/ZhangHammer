/**
 * sub_discriminator.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-11-16
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_CONTROLER_SUB_DISCRIMINATOR_H
#define HOUYI_CONTROLER_SUB_DISCRIMINATOR_H

#include "base_data_reader.h"
#include "multi_discriminator.h"
#include "sub_neural_network.h"
#include "decoder.h"

namespace houyi {
namespace train {

class MultiDiscriminator;
class SubDiscriminator : public Trainer {
protected:
    int _id;
    int _device_id;
    Thread* _work_thread;

    MultiDiscriminator* _parent;
    MessageQueue<DecodeData*>* _decode_data_queue;

    Argument _bat_data;
    int* _reset_mark;

    bool _exit_flag;

public:
    pthread_mutex_t _load_mutex;
    pthread_mutex_t _start_score_mutex;
    pthread_mutex_t _w_update_mutex;
    bool _score_finish;
    bool _epoch_finish;
    SubDiscriminator(int id, const MultiDiscriminator* parent,
                     MessageQueue<DecodeData*>* decode_queue);
    ~SubDiscriminator();

    virtual void reset();
    void start();
    static void* run_thread(void* self);
    void run();

    inline NeuralNetwork* nn() {
        return _nn;
    }
    inline MultiDiscriminator* parent() {
        return _parent;
    }
    inline void parent(MultiDiscriminator* p) {
        _parent = p;
    }
    inline int device_id() {
        return _device_id;
    }

    inline int get_threshold(int lyId, DType** low, DType** up) {
        return _nn->layers()[lyId]->get_threshold(low, up);
    }
    inline void set_threshold(int layer_id, DType* low, DType* up, int cnt) {
        _nn->layers()[layer_id]->set_threshold(low, up, cnt);
    }

    inline void set_exit_flag(bool flag) {
        _exit_flag = flag;
    }
};

}
}

#endif
