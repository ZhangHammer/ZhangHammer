#ifndef HOUYI_CONTROLER_IMAGE_VOTER_H
#define HOUYI_CONTROLER_IMAGE_VOTER_H

#include "predictor.h"

namespace houyi {
namespace train {

class ImageVoter : public Predictor {

public:
    ImageVoter() : Predictor() { }

    ImageVoter(PredictNnConfig* nn_cfg) : Predictor(nn_cfg) { }

    virtual void run();
};

}   // namespace train
}   // namespace houyi

#endif
