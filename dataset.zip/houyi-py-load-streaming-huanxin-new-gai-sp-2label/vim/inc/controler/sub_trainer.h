#ifndef HOUYI_TRAIN_PLATFORM_SUB_TRAINER_H
#define HOUYI_TRAIN_PLATFORM_SUB_TRAINER_H

#include "base_data_reader.h"
#include "multi_trainer.h"
#include "sub_neural_network.h"

namespace houyi {
namespace train {
class MultiTrainer;
class SubTrainer : public Trainer {
protected:
    Thread*     _work_thread;

    MultiTrainer* _parent;
    //SubNeuralNetwork *_nn;

    Argument _bat_data;
    int* _reset_mark;

    // for disc-train
    int _queue_id;
    SyncCls* _sync_cls;

    /* for batch size adjust */
    int _batch_size;
    int _base_batch_size;
    int _cur_step;

    /* workspace for all layer, such as conv */
    Tensor<unsigned char>* _worksapce;
#ifdef __ENABLE_NCCL__
    std::shared_ptr<Nccl> _intra_node_comm;
#endif

public:
    pthread_mutex_t _load_mutex;

    SubTrainer(int id, const MultiTrainer* parent, SyncCls* sync_flag);

    ~SubTrainer();

    virtual void reset();
    void start();
    static void* run_thread(void* self);
    void run();

    inline NeuralNetwork* nn() {
        return _nn;
    }
    inline MultiTrainer* parent() {
        return _parent;
    }
    inline void parent(MultiTrainer* p) {
        _parent = p;
    }
    inline int device_id() {
        return _device_id;
    }

    inline int get_threshold(int lyId, DType** low, DType** up) {
        return _nn->layers()[lyId]->get_threshold(low, up);
    }
    inline void set_threshold(int layer_id, DType* low, DType* up, int cnt) {
        _nn->layers()[layer_id]->set_threshold(low, up, cnt);
    }

    inline std::vector<StatIndicator*>& get_indicator() {
        return _stat_indicator;
    }
    inline StatIndicator* get_indicator(std::string& cost_layer_name) {
        for (size_t i = 0; i < _cost_layer_name.size(); i++) {
            if (_cost_layer_name[i] == cost_layer_name) {
                return _stat_indicator[i];
            }
        }

        CHECK2(false);
        return NULL;
    }
    void adjust_lr(size_t iter_cnt);
    void adjust_batch_size(size_t iter_cnt);
    void store_mean_var();
};

}
}
#endif
