#include <stdio.h>

const char* houyi_build_git_version = "3a165d1";
const char* houyi_build_user = "zhengzaoxin";
const char* houyi_build_host = "yq01-sys-hic-p40-box-0014.yq01.baidu.com";

