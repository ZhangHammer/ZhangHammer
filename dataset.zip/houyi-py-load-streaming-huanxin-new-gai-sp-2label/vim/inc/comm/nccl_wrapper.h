/**
 * nccl_wrapper.h
 * Author: wangkai(wangkai35@baidu.com)
 * Created on: 2018-07-19
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_TRAIN_PLATFORM_NCCL_WRAPPER_H
#define HOUYI_TRAIN_PLATFORM_NCCL_WRAPPER_H

#ifdef __ENABLE_NCCL__

#include <pthread.h>
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cfloat>
#include <nccl.h>
#include "util.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

#define NCCLCHECK(cmd) do {                         \
  ncclResult_t r = cmd;                             \
  if (r!= ncclSuccess) {                            \
    printf("Failed, NCCL error %s:%d '%s'\n",             \
        __FILE__, __LINE__, ncclGetErrorString(r));   \
    exit(EXIT_FAILURE);                             \
  }                                                 \
} while (0)

class NcclSingleton {
public:
    NcclSingleton() {
        ncclGetUniqueId(&_uid);
        INTER_LOG("NCCL uid created");
    }

    ncclUniqueId get_uid() const {
        return _uid;
    }
    
    static NcclSingleton* inst();

private:
    ncclUniqueId _uid;
    static std::shared_ptr<NcclSingleton> get_shared_ref();
};

class Nccl {

public:
    Nccl(const NcclSingleton* ptr, int comm_size, int tid) {
        NCCLCHECK(ncclCommInitRank(&_comm, comm_size, ptr->get_uid(), tid));
        NCCLCHECK(ncclCommCount(_comm, &_comm_size));
        CHECK2(_comm_size == comm_size);
        NCCLCHECK(ncclCommCuDevice(_comm, &_comm_devices));
        NCCLCHECK(ncclCommUserRank(_comm, &_comm_rank));
        _stream = wind_get_stream(WIND_STREAM_DEFAULT);
    }

    ~Nccl() {
        ncclCommDestroy(_comm);
    } 

    int comm_size() const {
        return _comm_size;
    }

    int comm_device() {
        return _comm_devices;
    }

    int comm_rank() {
        return _comm_rank;
    }

    void all_reduce_sum(Tensor<DType> &inout);
    
    void all_reduce_sum(Tensor<DType> &out, const Tensor<DType> &in);

    void wait() {
        cudaStreamSynchronize(_stream);
    }

private: 
    ncclComm_t _comm;
    int _comm_size;
    int _comm_devices;
    int _comm_rank;
    cudaStream_t _stream; 
};

}
} //namespace houyi

#endif

#endif
