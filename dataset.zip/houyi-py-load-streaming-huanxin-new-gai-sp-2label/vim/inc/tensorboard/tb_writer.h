#ifndef HOUYI_TENSORBOARD_TB_WRITER_H
#define HOUYI_TENSORBOARD_TB_WRITER_H

#include <gflags/gflags.h>
#include "neural_network.h"

DECLARE_bool(enable_tensorboard);

namespace houyi {
namespace train {

class TensorBoardWriter {
public:
    explicit TensorBoardWriter(const std::string& dir,
                               NeuralNetwork* model = nullptr);

    ~TensorBoardWriter() {
        this->close();
    }

    // 写一个文本, 可以用来记录训练的名称等信息
    // 网页暂不支持
    void write_text(
            const std::string& name,
            const std::string& value,
            uint64_t step = 0);

    // 写一个值, 可以用来记录训练的 loss
    void write_value(
            const std::string& name,
            float value,
            uint64_t step = 0);

    // 写一张图, 可以可视化图像训练
    void write_image(
            const std::string& name,
            const Tensor<DType>& tensor,
            uint64_t step);

    // 写直方图, 可视化权重, 目前tensor 必须分配在 cpu 上
    void write_histogram(
            const std::string& name,
            const Tensor<DType>& tensor,
            uint64_t step);

    bool flush();

    bool close();

private:
    void init();

    void write_model();

    void write_record(const std::string& data);

    void write_version(time_t time);

    TensorBoardWriter(const TensorBoardWriter& other) = delete;
    TensorBoardWriter& operator=(const TensorBoardWriter& other) = delete;

    NeuralNetwork* _model;
    const std::string _dir;
    std::string _file_name;
    FILE* _fp;
    uint64_t _base_step;
};

}   // namespace train
}   // namespace houyi

#endif
