#ifndef HPPS_EASGD_UPDATER_H
#define HPPS_EASGD_UPDATER_H
#include <vector>
#include <unordered_map>

#include "wind/wind.h"
#include "updater/iupdater.h"

namespace hpps {

class EasgdUpdater : public IUpdater {
public:
    EasgdUpdater(std::string prefix, bool thd) {
        _log_prefix = prefix;
        _moving_rate = 0.25f;
        INTER_LOG("%s EASGD updater created", _log_prefix.c_str());

        if (thd) {
            for (size_t i = 0; i < thread_num; i++) {
                _threads.push_back(std::thread(&EasgdUpdater::thread_entry, this));
            }
        }
    }

    virtual ~EasgdUpdater() {
    }

private:
    const size_t split_threshold = 524288 + 1;
    const size_t thread_num = 4;

    void thread_entry() {
        while (true) {
            task_desc task = _rqt.pop();
            if (task.len == 0) {
                break;
            }

            easgd(task.out1, task.out2, task.in1, task.len, _moving_rate);
            
            _ack.push(true);
        }
    }

    // ASSUME 32-byte aligned
    void easgd(float *w, float *w_bar, const float *w_i, size_t len, float alpha)
    {
        __m256 alpha_vec = _mm256_set1_ps(alpha);
        __m256 w_vec, w_bar_vec, diff_vec;
        size_t len8 = len >> 3; 
        for (size_t i = 0; i < len8; i++) {
            w_vec = _mm256_load_ps(w_i);
            w_bar_vec = _mm256_load_ps(w_bar);
    
            diff_vec = _mm256_sub_ps(w_vec, w_bar_vec);
            diff_vec = _mm256_mul_ps(alpha_vec, diff_vec);
            w_vec = _mm256_sub_ps(w_vec, diff_vec);
            w_bar_vec = _mm256_add_ps(w_bar_vec, diff_vec);
    
            _mm256_store_ps(w, w_vec);
            _mm256_store_ps(w_bar, w_bar_vec);
    
            w += 8;
            w_i += 8;
            w_bar += 8;
        }

        for (size_t i = 0; i < len - (len8 << 3); i++) {
            w[i] = w_i[i] - alpha * (w_i[i] - w_bar[i]);
            w_bar[i] = w_bar[i] + alpha * (w_i[i] - w_bar[i]);
        }
    }

    void easgd_threaded(float *w, float *w_bar, const float *w_i, size_t len, float alpha)
    {
        std::lock_guard<std::mutex> lk(_thread_mutex); 
        size_t split_size = len / thread_num;
        float *out1 = w;
        float *out2 = w_bar;
        const float *in1 = w_i;
        
        for (size_t i = 0; i < thread_num - 1; i++) {
            _rqt.push(task_desc(out1, out2, in1, split_size));      
            out1 += split_size;
            out2 += split_size;
            in1 += split_size;
        }
        _rqt.push(task_desc(out1, out2, in1, len - split_size * (thread_num - 1)));
        for (size_t i = 0; i < thread_num; i++) {
            _ack.pop();
        }
    }

protected:
    virtual void init_val_(Key key, Len len) override {
        _buf[key] = Val(wind::Dim(len), wind::CPU_PINNED);
        _buf[key].zero();
        _initialized = true;
    }

    virtual void set_param_(const std::unordered_map<std::string, std::string>& params) override {
        if (params.find("moving_rate") != params.end()) {
            _moving_rate = atof(params.at("moving_rate").c_str());
            CHECK(_moving_rate <= 1.0f, "Probaly not valid moving_rate = %f", _moving_rate);
            INTER_LOG("%s moving_rate = %f", _log_prefix.c_str(), _moving_rate);
        }
    }

    virtual bool update_(Val& val, Val& odata, const Val& idata) override {
        wind::DType *vptr = val.get_ptr();
        wind::DType *optr = odata.get_ptr();
        const wind::DType *iptr = idata.get_ptr();
        size_t len = val.get_element_count();
        bool align32 = ((((size_t)vptr) & 0x1f) == 0) \
                        && (((size_t)optr & 0x1f) == 0) \
                        && (((size_t)iptr & 0x1f) == 0); 

        if ((len >= split_threshold) && align32) {
            easgd_threaded(odata.get_ptr(), val.get_ptr(), idata.get_ptr(), len, _moving_rate);
                   
        } else if (align32) {
            easgd(odata.get_ptr(), val.get_ptr(), idata.get_ptr(), len, _moving_rate);

        } else {
            saxpby(odata, val, idata, _moving_rate, 1.0f - _moving_rate);
            saxpby(val, idata, _moving_rate, 1.0f - _moving_rate);
        }
        return true;
    }

    virtual bool update_(Val& val, Key key) override {
        saxpby(val, _buf[key], _moving_rate, 1.0f - _moving_rate);
        _buf[key].zero();
        _counter[key] = 0;
        return true;
    }

    virtual int collect_(Key key, Val &data) override {
        CHECK2(_buf.find(key) != _buf.end());
        if (_counter[key] == 0) {
            _buf[key].copy_from(data);
            _counter[key]++;
        } else { 
            saxpby(_buf[key], data, 1.0f, 1.0f);
        }
        return 0;
    }

    bool need_delta_weight_() const override {
        return false;
    }

    bool need_weight_() const override {
        return true;
    }

    float _moving_rate;
    std::unordered_map<Key, Val> _buf;
    std::unordered_map<Key, int> _counter;
};

} //namespace hpps

#endif
