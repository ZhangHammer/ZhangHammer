#ifndef HPPS_SGD_UPDATER_H
#define HPPS_SGD_UPDATER_H
#include <vector>
#include <unordered_map>

#include "wind/wind.h"
#include "updater/iupdater.h"

namespace hpps {

class SgdUpdater : public IUpdater {

public:
    SgdUpdater(std::string prefix, bool thd) {
        _log_prefix = prefix;
        INTER_LOG("%s SGD updater created", _log_prefix.c_str());
        if (thd) {
            for (size_t i = 0; i < thread_num; i++) {
                _threads.push_back(std::thread(&SgdUpdater::thread_entry, this));
            }
        }
    }

protected:
    const size_t split_threshold = 524288 + 1;
    const size_t thread_num = 4;

    void thread_entry() {
        while (true) {
            task_desc task = _rqt.pop();
            if (task.len == 0) {
                break;
            }

            cblas_saxpy(task.len, 1.0f, task.in1, 1, task.out1, 1);
            
            _ack.push(true);
        }
    }

    void update_threaded(float *w, const float *w_i, size_t len)
    {
        std::lock_guard<std::mutex> lk(_thread_mutex); 
        size_t split_size = len / thread_num;
        float *out1 = w;
        const float *in1 = w_i;
        
        for (size_t i = 0; i < thread_num - 1; i++) {
            _rqt.push(task_desc(out1, in1, split_size));      
            out1 += split_size;
            in1 += split_size;
        }
        _rqt.push(task_desc(out1, in1, len - split_size * (thread_num - 1)));
        for (size_t i = 0; i < thread_num; i++) {
            _ack.pop();
        }
    }

    virtual void set_param_(const std::unordered_map<std::string, std::string>& params) {
        //blank
    }

    virtual void init_val_(Key key, Len len) override {
        _buf[key] = Val(wind::Dim(len), wind::CPU_PINNED);
        _buf[key].zero();
        _initialized = true;
    }

    virtual bool update_(Val& val, Key key) override {
        val.add(_buf[key], val, 1.0f, 1.0f);
        _buf[key].zero();
        _counter[key] = 0;
        return false;
    }

    virtual bool update_(Val& val, Val& odata, const Val& idata) override {
        size_t len = val.get_element_count();
        if (len >= split_threshold) {
            update_threaded(val.get_ptr(), idata.get_ptr(), len);
        } else {
            val.add(idata, val, 1.0f, 1.0f);
        } 
        return false;
    }

    virtual int collect_(Key key, Val &data) override {
        CHECK2(_buf.find(key) != _buf.end());
        if (_counter[key] == 0) {
            _buf[key].copy_from(data);
            _counter[key]++;
        } else { 
            _buf[key].add(data, _buf[key], 1.0f, 1.0f);
        }
        return 0;
    }

    bool need_delta_weight_() const override {
        return true;
    }

    bool need_weight_() const override {
        return false;
    }

    std::unordered_map<Key, Val> _buf;
    std::unordered_map<Key, int> _counter;
};

} //namespace hpps

#endif
