#ifndef HPPS_AVG_UPDATER_H
#define HPPS_AVG_UPDATER_H
#include <vector>
#include <unordered_map>
#include <map>

#include "wind/wind.h"
#include "updater/iupdater.h"

namespace hpps {

class AvgUpdater : public IUpdater {
public:
    AvgUpdater (std::string prefix, bool thd) {
        _log_prefix = prefix;
    }
   
    ~AvgUpdater() {
    }

protected:
    virtual void set_param_(const std::unordered_map<std::string, std::string>& params) {
        //blank
    }

    virtual void init_val_(Key key, Len len) override {
        _buf[key] = Val(wind::Dim(len), wind::CPU_PINNED);
        _buf[key].zero();
        _initialized = true;
    }

    virtual bool update_(Val& val, Key key) override {
        if (_counter[key] != 1) {
            _buf[key].mul(1.0f / _counter[key]);
        }
        val.copy_from(_buf[key]);
        _counter[key] = 0;
        return false;
    }

    virtual bool update_(Val& val, Val& odata, const Val& idata) override {
        CHECK(false, "%s should not be called in AvgUpdater", __FUNCTION__);
        return false;
    }

    virtual int collect_(Key key, Val &data) override {
        CHECK2(_buf.find(key) != _buf.end());
        if (_counter[key] == 0) {
            _buf[key].copy_from(data);
        } else { 
            _buf[key].add(data, _buf[key], 1.0f, 1.0f);
        }
        _counter[key]++;
        return 0;
    }

    bool need_delta_weight_() const override {
        return false;
    }

    bool need_weight_() const override {
        return true;
    }
    
    std::unordered_map<Key, Val> _buf;
    std::unordered_map<Key, int> _counter;
};

} //namespace hpps

#endif
