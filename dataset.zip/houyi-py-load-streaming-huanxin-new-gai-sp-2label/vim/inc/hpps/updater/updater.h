#ifndef HPPS_UPDATER_H
#define HPPS_UPDATER_H

#include "sgd_updater.h"
#include "avg_updater.h"
#include "easgd_updater.h"

namespace hpps {

class UpdaterFactory {
public:
    static IUpdater* create_updater(std::string prefix, std::string name, bool thd = false) {
        if (name == std::string("sgd")) {
            return new SgdUpdater(prefix, thd);
        } else if (name == std::string("easgd")) {
            return new EasgdUpdater(prefix, thd);
        } else if (name == std::string("avg")) {
            return new AvgUpdater(prefix, thd);
        } else {
            return NULL;
        } 
    }
};

}

#endif
