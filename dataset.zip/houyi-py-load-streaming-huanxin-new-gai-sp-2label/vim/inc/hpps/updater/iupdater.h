#ifndef HPPS_IUPDATER_H_
#define HPPS_IUPDATER_H_
#include <vector>
#include <unordered_map>
#include <string>
#include <functional>
#include "wind/wind.h"
#include "common/util.h"
#include "common/thread_safe_queue.h"
#include "ps/base.h"

extern "C" 
void cblas_saxpby(const int N, const float alpha, const float *X,
    const int incX, const float beta, float *Y, const int incY);
extern "C"
void cblas_scopy(const int __N, const float *__X, const int __incX, float *__Y, const int __incY);
extern "C"
void cblas_saxpy(const int __N, const float __alpha, const float *__X, 
    const int __incX, float *__Y, const int __incY);

namespace hpps {

class IUpdater {
public:
    struct task_desc {
        float *out1;
        float *out2;
        const float *in1;
        size_t len;
        
        task_desc(float *in_out1, float *in_out2, const float *in_in1, size_t in_len) {
            out1 = in_out1;
            out2 = in_out2;
            in1 = in_in1;
            len = in_len;
        }
        
        task_desc(float *in_out1, const float *in_in1, size_t in_len) {
            out1 = in_out1;
            in1 = in_in1;
            len = in_len;
            out2 = NULL;
        }
    };

public:
    IUpdater(void) {
        _initialized = false;
    }
    virtual ~IUpdater(void) {
        for (size_t i = 0; i < _threads.size(); i++) {
            _rqt.push(task_desc(NULL, NULL, 0));
        }
        for (size_t i = 0; i < _threads.size(); i++) {
            if (_threads[i].joinable()) {
                _threads[i].join();
            }
        }
        if (_threads.size()) {
            INTER_LOG("%s updater threads exit", _log_prefix.c_str());
        }
    }

    /*!
     * \brief set parameters from outside
     * \param name name of parameter
     * \param val value of parameter
     */
    virtual void set_param(const std::unordered_map<std::string, std::string>& params) {
        this->set_param_(params);
    }
    
    /*!
     * \brief init the model updater
     * \param rank the rank of the node
     * \param argc number of arguments
     * \param argv arguments
     */
    virtual void init_updater(int rank, int argc, char *argv[]) {}
    /*!
     * \brief initialize the model
     * \param key the key of data we point to
     * \param dptr the data pointer
     * \param size size of the parameter key
     */
    virtual void init_val(Key key, Len len) {
        this->init_val_(key, len);
    }

    /*!
     * update the model
     * \param key the key of data we point to
     * \param dptr the data pointer
     * \param size size of the parameter key
     */
    virtual bool update(Val& val, Val& odata, const Val& idata) {
        return this->update_(val, odata, idata);
    }

    virtual bool update(Val& val, Key key) {
        return this->update_(val, key);
    }
    
    virtual int collect(Key key, Val &data) {
        return this->collect_(key, data);
    }

    virtual bool need_delta_weight() const {
        return this->need_delta_weight_(); 
    }

    virtual bool need_weight() const {
        return this->need_weight_();
    }

    void saxpby(Val& val, const Val& data, float alpha, float beta) {
        // val = alpha * data + beta * val
        CHECK2(val.get_size() == data.get_size()); 
        CHECK(val.get_device() == wind::CPU || val.get_device() == wind::CPU_PINNED, 
            "Tensor.device = %d (~CPU)", val.get_device());
        cblas_saxpby(val.get_element_count(), alpha, data.get_ptr(), 1, beta, val.get_ptr(), 1);
    }

    void saxpby(Val& val, const Val& data, const Val& data2, float alpha, float beta) {
        // val = alpha * data + beta * data2
        CHECK2(val.get_size() == data.get_size()); 
        CHECK2(val.get_size() == data2.get_size()); 
        CHECK(val.get_device() == wind::CPU || val.get_device() == wind::CPU_PINNED, 
            "Tensor.device = %d (~CPU)", val.get_device());
        cblas_scopy(val.get_element_count(), data2.get_ptr(), 1, val.get_ptr(), 1);
        cblas_saxpby(val.get_element_count(), alpha, data.get_ptr(), 1, beta, val.get_ptr(), 1);
    }

protected:
    std::string _log_prefix;

    bool _initialized;

    std::vector<std::thread> _threads;
    ThreadSafeQueue<task_desc> _rqt;
    ThreadSafeQueue<bool> _ack;
    std::mutex _thread_mutex;

    virtual void set_param_(const std::unordered_map<std::string, std::string>& params) = 0;

    /*!
     * \brief initialize the model, user can implement this one
     *   to take advantage of tensor operations
     * \param key the key of data we point to
     * \param data the tensor data corresponding to the data we want to initialize
     */
    virtual void init_val_(Key key, Len len) = 0;

    /*!
     * \brief update the model, user can implement this one
     *    to take advantage of tensor operations
     * \param key the key of data we point to
     * \param data the tensor data corresponding to the data we want to initialize
     */
    virtual bool update_(Val &val, Val &odata, const Val &idata) = 0;
    
    virtual bool update_(Val &val, Key key) = 0;

    virtual int collect_(Key key, Val &data) = 0;

    virtual bool need_delta_weight_() const = 0;

    virtual bool need_weight_() const = 0;
};

} //namespace hpps 

#endif
