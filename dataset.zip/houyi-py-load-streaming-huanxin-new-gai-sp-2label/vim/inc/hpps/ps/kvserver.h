#ifndef HPPS_PS_KVSERVER_H
#define HPPS_PS_KVSERVER_H

#include <algorithm>
#include <utility>
#include <vector>
#include <queue>
#include <unordered_map>
#include <thread>
#include "common/thread_safe_queue.h"
#include "ps/base.h"
#include "common/message.h"
#include "wind/wind.h"
#include "ps/kvbase.h"
#include "ps/kvcoordinator.h"
#include "common/message.pb.h"
#include "updater/updater.h"
#include "common/cmdline.h"

namespace hpps {

enum comm_type {
    INVALID = 0,
    SEND_DATA = 1,
    RECV_DATA,
    SEND_HDR,
    RECV_HDR,
    WIN_EXCLUSIVE_LOCK,
    WIN_UNLOCK
};

struct comm_rqt {
    comm_type type; 
    void * buf;
    int count;
    int peer;
    
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    mpx::win *win;
#endif

    comm_rqt() {
        type = INVALID;
        buf = NULL;
        count = 0;
        peer = 0; 
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
        win = NULL;
#endif
    }

    comm_rqt (comm_type itype, void* ibuf, int icount, int ipeer) :
        type(itype), buf(ibuf), count(icount), peer(ipeer) {
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
        win = NULL;
#endif
    }

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    comm_rqt(comm_type itype, mpx::win* iwin) :
        type(itype), buf(NULL), count(0), peer(0), win(iwin) {
    }
#endif
};

struct comm_ack {
    Rank peer;

    comm_ack(Rank ipeer) : peer(ipeer) {
    }
    comm_ack() {
    }
};

class KVServer : public KVBase {

public:
    KVServer(int argc, char* argv[]); 

    virtual ~KVServer() {
        stop_all_threads();
        clear_env();
        if (_updater) {
            delete _updater;
            _updater = NULL;
        }
    }

    void init_env();
    
    void clear_env();

    // processing request thread entry
    void processing(int);

    // receiving request thread entry
    void receiving();

    void start_processing();
    void start_receiving();
    void start_comming();

    void stop_all_threads();

    void start_all_threads() {
        start_processing();
        start_receiving();
        start_comming();
    }

    // Initialize
    void coordinate();

    // True: if all workers have exited
    bool check_exit();
    
    bool wait_exit();

    void set_updater_param(const std::unordered_map<std::string, std::string>&);

    inline bool valid_update(Key key, int rank);

    inline void update_timestamp(Key key, int rank);

    void comm_processing(); 
    
    virtual void send(const Message &msg, int dest, int qidx);

    virtual Rank recv(Message &msg, int src, int qidx);

    void barrier() {
        KVCoordinator *coord = KVCoordinator::get_obj(); 
        coord->barrier(*this, NULL);
    }

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    void init_wins() override;
    
    inline virtual void exclusive_lock(mpx::win* win, int qidx);
    
    inline virtual void unlock(mpx::win* win, int qidx);
#endif

private:
    void set_updater(std::string updater);
    
    // key-val pairs
    std::unordered_map<Key, Val> _kvs;
    std::unordered_map<Key, std::mutex*> _key_mutex;

    // thread handler
    std::thread _recv_thread;
    std::vector<std::thread> _proc_thread;
    std::thread _comm_thread;

    // buffer message for each worker
    std::vector<ThreadSafeQueue<Message>> _rqt_queue_vec; 

    // buffer input value for each worker 
    std::vector<ThreadSafeQueue<Val>> _val_queue_vec; 

    // store key-val for each worker
    std::vector<std::unordered_map<Key, Val>> _comm_kvs;
   
    // store output value for each worker 
    std::vector<std::unordered_map<Key, Val>> _output_kvs;

    IUpdater *_updater;

    std::condition_variable _worker_quit;
    bool _recv_thread_quit;

    bool _enable_distance_drop;
    size_t _max_distance;
    std::unordered_map<Key, std::vector<size_t>> _key_timestamps;

    parser _parser;

    std::mutex _status_mutex;

    std::vector<ThreadSafeQueue<comm_rqt>> _comm_rqt_vec; 
    std::vector<ThreadSafeQueue<comm_ack>> _comm_ack_vec; 
    std::vector<char*> _comm_buffer_vec;
    bool _comm_thread_quit;
};

} //namespace hpps

#endif
