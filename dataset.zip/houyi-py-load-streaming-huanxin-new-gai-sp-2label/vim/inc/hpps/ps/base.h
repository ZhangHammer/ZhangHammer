/**
 *  Copyright (c) 2015 by Contributors
 */
#ifndef HPPS_BASE_H
#define HPPS_BASE_H

#include <limits>
#include "wind/wind.h"
#include "common/util.h"
#include "common/math_funcs.h"

namespace hpps {

using Key = uint64_t;

using Rank = int;

using Len = uint64_t;

using Dim = wind::Dim;

using Val = wind::Tensor<wind::DType>;

/*! \brief The maximal allowed key value */
static const Key kMaxKey = std::numeric_limits<Key>::max();

}  // namespace hpps

#endif  // HPPS_BASE_H
