#ifndef HPPS_KV_BASE_H
#define HPPS_KV_BASE_H

#include <algorithm>
#include <utility>
#include <vector>
#include <unordered_map>
#include <queue>
#include "ps/base.h"
#include "wind/wind.h"
#include "mpx/env.hpp"
#include "mpx/comm.hpp"
#include "mpx/win.hpp"
#include "common/message.h"

namespace hpps {

static const size_t max_message_byte_size = 1024;

class KVBase {
public:
    KVBase(Role role) {
        _role = role;
        _env = new mpx::env();
        _comm = new mpx::comm();
        _node = {.role = _role, .id = _comm->rank()};
        _message_buffer = (char*)_mm_malloc(max_message_byte_size, 16);
#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
        _key2wins = new std::unordered_map<Key, WinPtrPair>();
#endif
        INTER_LOG("Create %s", role_desc().c_str());
    }

    virtual ~KVBase() {
        std::string name = role_desc();

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
        if (_key2wins) {
            delete _key2wins;
            _key2wins = NULL;
        }
#endif
        if (_env) {
            delete _env;
            _env = NULL;
        }
        if (_comm) {
            delete _comm;
            _comm = NULL;
        }

        if (_message_buffer) {
            _mm_free(_message_buffer);
            _message_buffer = NULL;
        }
        
        INTER_LOG("%s exited", name.c_str());
    }

    inline Rank rank() const {
        return _comm->rank();
    }

    inline int comm_size() const {
        return _comm->size();
    }

    inline Node node() const {
        return _node;
    }
    
    virtual void send(const Message &msg, int dest) {
        MessageHeader* hdr = (MessageHeader*)_message_buffer;
        hdr->rank = rank();
        hdr->byte_size = msg.pack(_message_buffer + sizeof(MessageHeader), 
            max_message_byte_size - sizeof(MessageHeader));
        _comm->send<char>(_message_buffer, sizeof(MessageHeader)+hdr->byte_size, dest, HeaderTag);
    }

    mpx::future<void> isend(const Message &msg, int dest) {
        MessageHeader* hdr = (MessageHeader*)_message_buffer;
        hdr->rank = rank();
        hdr->byte_size = msg.pack(_message_buffer + sizeof(MessageHeader), 
            max_message_byte_size - sizeof(MessageHeader));
        mpx::future<void> ret = _comm->isend<char>(_message_buffer, 
            sizeof(MessageHeader)+hdr->byte_size, dest, HeaderTag);
        return ret;
    }

    virtual Rank recv(Message &msg, int src) {
        _comm->recv_into<char>(_message_buffer, max_message_byte_size, src, HeaderTag); 
        MessageHeader* hdr = (MessageHeader*)_message_buffer; 
        msg.unpack(_message_buffer+sizeof(MessageHeader), hdr->byte_size);
        return hdr->rank;
    }

    template <typename T>
    void send(const T* msg, size_t size, int dest, int tag = 0) {
        _comm->send(msg, size, dest, tag); 
    }

    template <typename T>
    mpx::future<void> isend(const T* msg, size_t size, int dest, int tag = 0) {
        mpx::future<void> ret = _comm->isend(msg, size, dest, tag); 
        return ret;
    }
    
    template <typename T>
    void recv_into(T* msg, size_t size, int src, int tag = 0) {
        _comm->recv_into(msg, size, src, tag); 
    }

    template <typename T>
    mpx::future<void> irecv_into(T* msg, size_t size, int src, int tag = 0) {
        mpx::future<void> ret = _comm->irecv_into(msg, size, src, tag); 
        return ret;
    }

    bool test(mpx::future<void>& f) {
        return f.valid();
    }

    void wait(mpx::future<void>& f) {
        f.get();
    }

    void wait(std::vector<mpx::future<void>> &fs) {
        for (size_t i=0; i<fs.size(); i++) {
            wait(fs[i]);
        }
        fs.clear();
    }

    Role role() const {
        return _role;
    }

    std::string role_desc() const {
        char name[64];
        switch(_role) {
            case SERVER_NODE:
                sprintf(name, "Server%d", _comm->rank()); 
                break;
            case WORKER_NODE:
                sprintf(name, "Worker%d", _comm->rank()); 
                break;
            default:
                CHECK(false, "Unknown node type: %d", _role);
        }
        return std::string(name);
    }

    int iprobe(int source, int tag) const {
        return _comm->iprobe(source, tag);
    }

    virtual void barrier() = 0;

    std::unordered_map<std::string, std::string>& options() {
        return _options;
    } 

    void set_options(std::vector<Option>& options) {
        for (size_t i = 0; i < options.size(); i++) {
            _options.insert(std::make_pair<std::string, std::string>(
                std::string(options[i].name.c_str()), 
                std::string(options[i].val.c_str())));
            INTER_LOG("%s set option %s = %s", role_desc().c_str(), options[i].name.c_str(),
                options[i].val.c_str());
        }
    }

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    inline void insert_key(Key key) {
        _key2wins->insert(std::make_pair(key, std::make_pair(nullptr, nullptr)));
    }   

    virtual void init_wins() = 0;
#endif
private:
    mpx::env *_env;
    mpx::comm *_comm;
    Role _role;
    Node _node;
    char* _message_buffer;

protected:
    std::unordered_map<std::string, std::string> _options;

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
protected:
    inline const mpx::comm& get_comm() const {
        return *_comm;
    }   
    int _num_workers;
    
    typedef std::pair<std::unique_ptr<mpx::win>, std::unique_ptr<mpx::win>> WinPtrPair;
    std::unordered_map<Key, WinPtrPair>* _key2wins;
#endif


};

} //namespace hpps

#endif
