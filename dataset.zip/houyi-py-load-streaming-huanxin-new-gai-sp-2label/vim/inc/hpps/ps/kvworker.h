#ifndef HPPS_PS_KVWORKER_H
#define HPPS_PS_KVWORKER_H

#include <algorithm>
#include <utility>
#include <vector>
#include <unordered_map>
#include "ps/base.h"
#include "common/message.h"
#include "common/common.h"
#include "wind/wind.h"
#include "ps/kvbase.h"
#include "ps/kvcoordinator.h"
#include "common/profiler.h"
#include "updater/updater.h"

namespace hpps {

enum COMM {
    COMM_PUSHPULL = 1,
    COMM_GETPUT
};

class KVWorker : public KVBase {

public:
    KVWorker();

    virtual ~KVWorker();
    
    void set_updater(std::string updater);

    bool reset(const std::vector<Key>& keys,
            const std::vector<Val>& vals);
    
    bool push(const std::vector<Key>& keys,
            const std::vector<Val>& vals,
            int op = Push);
    
    bool pull(const std::vector<Key>& keys,
            const std::vector<Val>& vals);
    
    bool push_pull(const std::vector<Key>& keys,
            const std::vector<Val>& in,
            std::vector<Val>& out);

    bool update(const std::vector<Key>& keys,
            const std::vector<Val>& in,
            std::vector<Val>& out); 

    bool check_kvs(const std::vector<Key>& keys, const std::vector<Val>& vals);

    void sort_kvs(std::vector<Key>& keys, std::vector<Val>& vals);

    void sort_kvs(std::vector<Key>& keys, std::vector<Val>& in_vals, std::vector<Val>& out_vals);

    void coordinate(std::vector<Key>& key, std::vector<Len>& len); 
    
    void coordinate(std::vector<Key>& key, std::vector<Len>& len, std::vector<size_t> &color); 

    void barrier();

    bool sync_global_status();

    void notify_and_exit();

    std::set<Rank> unique_servers(const std::vector<Key>& keys);

    bool major_worker() const; 

    void set_option(const char* name, const char* var);

    bool need_delta_weight() const {
        return _updater->need_delta_weight();
    }
    
    bool need_weight() const {
        return _updater->need_weight();
    }

#if MPI_VERSION >= 3 && OMPI_MAJOR_VERSION >= 3
    void init_wins() override;
    
    bool get_put(const std::vector<Key>& keys,
                 const std::vector<Val>& in, 
                 std::vector<Val>& out);
#endif

private:
    std::unordered_map<Key, Rank> _key2svr;
    std::unordered_map<int, Callback> _callbacks;
    IUpdater *_updater;
    Profiler *_prof;
    size_t _prof_counter;
    COMM _comm_method;
};

} //namespace hpps

#endif
