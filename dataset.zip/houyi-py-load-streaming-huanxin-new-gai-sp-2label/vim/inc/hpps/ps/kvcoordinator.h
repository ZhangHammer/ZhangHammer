#ifndef HPPS_PS_KVCOORDINATOR_H
#define HPPS_PS_KVCOORDINATOR_H

#include <algorithm>
#include <utility>
#include <vector>
#include <set>
#include <queue>
#include <unordered_map>
#include <thread>
#include "ps/base.h"
#include "common/message.h"
#include "wind/wind.h"

namespace hpps {

class KVCoordinator {
public:
    KVCoordinator() {
    }        

    virtual ~KVCoordinator() {
    }

    static KVCoordinator * get_obj() {
        static KVCoordinator _obj;
        return &_obj;
    }

    void coordinate(KVBase& kv, std::vector<Key>& key, std::vector<Len>& len, 
        std::vector<Key>& color);

    bool barrier(KVBase& kv, Message *msg, Rank rank = 0);

    // called by worker
    bool sync_global_status(KVBase& kv);
    // called by server
    bool sync_global_status(KVBase& kv, Rank rank, int qidx);

    void split_keys();
    
    void split_colors();
    
    inline Rank get_svr(Key key) const {
        if (_key2svr.find(key) != _key2svr.end()) {
            return _key2svr.find(key)->second;
        } else {
            return std::numeric_limits<Rank>::max();
        }
    }

    inline Len get_len(Key key) const {
        if (_key2len.find(key) != _key2len.end()) {
            return _key2len.find(key)->second;
        } else {
            return std::numeric_limits<Len>::max();
        }
    }

    inline size_t worker_num() const {
        return _workers.size();
    }

    inline size_t server_num() const {
        return _servers.size();
    }

    inline std::unordered_map<Key, Rank>& get_key2svr() {
        return _key2svr;
    }

    inline std::unordered_map<Key, Len>& get_key2len() {
        return _key2len;
    }

    inline std::set<Rank> worker_id() const {
        return _workers;
    }

    void worker_exited(KVBase& kv, Rank rank);

    inline void bcast_all_servers(KVBase& kv, Message &msg) {
        for (auto dest : _servers) {
            kv.send(msg, dest);
        }
    }

    inline void recv_all_servers(KVBase& kv) {
        Message msg;
        for (auto src : _servers) {
            kv.recv(msg, src);
            CHECK(msg.type == ControlMsg, "%s: unexpected message from Rank[%d]", 
                kv.role_desc().c_str(), msg.node.id);
        }
    }

private:
    std::unordered_map<Key, Len> _key2len;
    std::unordered_map<Key, Rank> _key2svr;
    std::unordered_map<Key, Key> _key2color;
    std::set<Rank> _servers;
    std::set<Rank> _workers;
    // only for servers
    std::set<Rank> _barrier_workers;
    std::mutex _mutex;
};



} // namespace hpps

#endif
