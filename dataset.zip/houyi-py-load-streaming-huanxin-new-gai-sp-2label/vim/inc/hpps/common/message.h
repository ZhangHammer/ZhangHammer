#ifndef HPPS_MESSAGE_HEADER_H
#define HPPS_MESSAGE_HEADER_H

#include <vector>
#include "common/util.h"
#include "common/message.pb.h"
#include "wind/wind.h"

namespace hpps {

enum MessageTag {
    HeaderTag = 110,
    DataTag = 119
};

enum Role {
    SERVER_NODE = 1949,
    WORKER_NODE = 1950
};

enum MessageType {
    ControlMsg = 2,
    CoordinateMsg = 4,
    DataMsg = 8
};

enum ControlType {
    ControlExit = 16,
    ControlInfo = 32,
    ControlGlobalBarrier = 64,
    ControlGlobalStatus = 128
};

enum UpdateType {
    ASGD = 1,
    EASGD = 2
};

enum PushPullOp {
    Push = 1,
    Pull = 2,
    PushPull = 3,
    Reset = 5,
    PutDone = 6
};

struct MessageHeader {
    static const int kEmpty = std::numeric_limits<int>::max();
    int rank;
    size_t byte_size;
    MessageHeader() : rank(kEmpty), byte_size(0) {}
    void clear() {
        rank = kEmpty;
        byte_size = 0;
    }
};

struct Node {
    static const int kEmpty = std::numeric_limits<int>::max();
    // the node role
    Role role;
    // rank id
    Rank id;
    Node() : role(static_cast<Role>(kEmpty)), id(kEmpty) {} 
    Node(Role role1, Rank id1) : role(role1), id(id1) {}
    void clear() {
        role = static_cast<Role>(kEmpty);
        id = kEmpty;
    }

    bool operator==(const Node &node) const {
        return (role == node.role) && (id == node.id);
    }
};

struct Option {
    std::string name;
    std::string val;
    Option(std::string name, std::string val) : 
        name(name), val(val) {}
};

// system control info
struct Control {
    static const int kEmpty = std::numeric_limits<int>::max();
    // the node role
    int cmd;
    std::vector<Node> node;
    std::vector<Option> option;
    bool empty() const {return cmd == kEmpty;}
    Control() : cmd(kEmpty) {}
    void clear() {
        cmd = kEmpty;
        node.clear();
        option.clear();
    }

    void unpack(const PBControl &pb) {
        clear();
        cmd = pb.cmd();
        for (int i=0; i<pb.node_size(); i++) {
            auto& node1 = pb.node(i);
            Node node2 = {static_cast<Role>(node1.role()), static_cast<Rank>(node1.id())};
            node.push_back(node2);
        }
        for (int i = 0; i < pb.option_size(); i++) {
            auto& opt1 = pb.option(i);
            option.push_back(Option(opt1.name(), opt1.val())); 
        }  
    }

    void pack(PBControl *pb) const {
        pb->set_cmd(cmd);
        for (size_t i=0; i<node.size(); i++) {
            auto pbnode = pb->add_node();
            pbnode->set_role(node[i].role);
            pbnode->set_id(node[i].id);
        }
        for (size_t i=0; i<option.size(); i++) {
            auto pboption = pb->add_option();
            pboption->set_name(option[i].name);
            pboption->set_val(option[i].val);
        }
    }
    
};

struct Data {
    static const int kEmpty = std::numeric_limits<int>::max();
    std::vector<Key> key;
    std::vector<Len> len;
    // whether or not a push/pull/push-pull message
    int op;

    bool empty() const {return (key.size() == 0);}
    Data() {}
    void clear() {
        key.clear();
        len.clear();
        op = kEmpty;
    }

    void unpack(const PBData &pb) {
        clear();
        for (int i=0; i<pb.key_size(); i++) {
            key.push_back(pb.key(i));
        }
        for (int i=0; i<pb.len_size(); i++) {
            len.push_back(pb.len(i));
        }
        op = pb.op();
    }

    void pack(PBData *pb) const {
        for (size_t i=0; i<key.size(); i++) {
            pb->add_key(key[i]);
        }
        for (size_t i=0; i<len.size(); i++) {
            pb->add_len(len[i]);
        }
        pb->set_op(op);
    }
};

struct Coordinate {
    static const int kEmpty = std::numeric_limits<int>::max();
    int cmd;
    std::vector<Key> key;
    std::vector<Len> len;
    std::vector<Key> color;
    std::vector<Rank> svr;
    bool empty() const {return cmd == kEmpty;}
    Coordinate() : cmd(kEmpty) {}

    void clear() {
        cmd = kEmpty;
        key.clear();
        len.clear();
        color.clear();
        svr.clear();
    }
     
    void unpack(const PBCoordinate& pb)
    {
        clear();
        cmd = pb.cmd();
        for (int i=0; i<pb.key_size(); i++) {
            key.push_back(pb.key(i));
        }
        for (int i=0; i<pb.len_size(); i++) {
            len.push_back(pb.len(i));
        }
        for (int i=0; i<pb.color_size(); i++) {
            color.push_back(pb.color(i));
        }
        for (int i=0; i<pb.svr_size(); i++) {
            svr.push_back(pb.svr(i));
        }
    }
    
    void pack(PBCoordinate* pb) const
    {
        pb->Clear();
        pb->set_cmd(cmd);
        for (size_t i=0; i<key.size(); i++) {
            pb->add_key(key[i]);
        }
        for (size_t i=0; i<len.size(); i++) {
            pb->add_len(len[i]);
        }
        for (size_t i=0; i<color.size(); i++) {
            pb->add_color(color[i]);
        }
        for (size_t i=0; i<svr.size(); i++) {
            pb->add_svr(svr[i]);
        }
    }
};

struct Message {
    static const int kEmpty = std::numeric_limits<int>::max();
    // message.type
    int type;
    // message.node
    Node node;
    // if set, then it is system control task. otherwise, it is for data
    Control control;
    // if set, then it is system coordinate task
    Coordinate coordinate;
    // if set, then it is data transfer
    Data data;

    Message() : type(kEmpty) {}

    void clear() {
        type = kEmpty;
        node.clear();
        control.clear();
        coordinate.clear();
        data.clear();
    }

    inline void unpack(const char* str, size_t len);
    inline size_t pack(char* str, size_t len) const;
};

void Message::unpack(const char* str, size_t len)
{
    PBMessage pb;
    CHECK(pb.ParseFromArray(str, len), "failed to parse string into protobuf");
    clear();
    type = pb.type(); 
    node.role = static_cast<Role>(pb.node().role());
    node.id = static_cast<Rank>(pb.node().id());
    
    if (pb.has_control()) {
        auto& pbctrl = pb.control();
        control.unpack(pbctrl);
    }

    if (pb.has_coordinate()) {
        auto& pbcoordinate = pb.coordinate();
        coordinate.unpack(pbcoordinate);
    }
    
    if (pb.has_data()) {
        auto& pbdata = pb.data();
        data.unpack(pbdata);
    }
}

size_t Message::pack(char* str, size_t len) const
{
    PBMessage pb;
    pb.set_type(type); 
    
    auto pbnode = pb.mutable_node();
    pbnode->set_role(node.role);
    pbnode->set_id(node.id);
    if (!control.empty()) {
        auto pbctrl = pb.mutable_control();
        control.pack(pbctrl); 
    }
    
    if (!coordinate.empty()) {
        auto pbcoordinate = pb.mutable_coordinate();
        coordinate.pack(pbcoordinate);
    }

    if (!data.empty()) {
        auto pbdata = pb.mutable_data();
        data.pack(pbdata);
    }
    
    CHECK((size_t)pb.ByteSize() <= len, "failed to serialize protbuf, buffer size not enough");
    CHECK(pb.SerializeToArray(str, pb.ByteSize()), "failed to serialize protbuf");
    return pb.ByteSize();
}

} // namespace hpps

#endif
