#ifndef HPPS_COMMON_H
#define HPPS_COMMON_H

#include <vector>
#include "wind/wind.h"

namespace hpps {

using Callback = std::function<void()>;

} //namespace hpps

#endif
