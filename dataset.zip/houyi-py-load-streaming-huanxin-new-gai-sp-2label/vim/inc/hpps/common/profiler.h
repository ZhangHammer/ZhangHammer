#ifndef HPPS_PROFILER_H
#define HPPS_PROFILER_H
#include <chrono>
#include <iomanip>
#include "common/util.h"

namespace hpps {

struct Profiler {
    std::string head_info;

    Profiler(std::string str) {
        head_info = str;
    }
    struct ProfInfo {
        std::chrono::high_resolution_clock::time_point start;
        std::chrono::high_resolution_clock::time_point stop;
        int total_count = 0;
        double total_time = 0.;
        inline void start_time() {
            start = std::chrono::high_resolution_clock::now();
        }
        inline void stop_time() {
            stop = std::chrono::high_resolution_clock::now();
            total_time += std::chrono::duration<double, std::micro>(stop-start).count();
            total_count += 1;
        }
    };
    std::unordered_map<std::string, std::shared_ptr<ProfInfo>> prof_map;
    inline void prof_begin(std::string sec) {
        auto it = prof_map.find(sec);
        if (it == prof_map.end()) {
            std::shared_ptr<ProfInfo> p(new ProfInfo());
            it = prof_map.insert(it, std::make_pair(sec, p));
        }
        it->second->start_time();
    }
    inline void prof_end(std::string sec) {
        auto it = prof_map.find(sec);
        if (it == prof_map.end()) {
            std::shared_ptr<ProfInfo> p(new ProfInfo());
            it = prof_map.insert(it, std::make_pair(sec, p));
        }
        it->second->stop_time();
    }
    inline void print_prof_info() {
        std::stringstream str;
        if (0 == prof_map.size()) {
            return;
        }
        INTER_LOG("++++++++ %s Prof Info ++++++++ <<< ", head_info.c_str());
        double total_time = 0.0;
        std::vector< std::pair<std::string, std::shared_ptr<ProfInfo>> >
            prof_vector(prof_map.begin(), prof_map.end());
        std::sort(prof_vector.begin(), prof_vector.end(),
            [](const std::pair<std::string, std::shared_ptr<ProfInfo>>& x,
               const std::pair<std::string, std::shared_ptr<ProfInfo>>& y){
                return x.second->total_time > y.second->total_time;
            });
        for (const auto& pair : prof_vector) {
            if (pair.first == "total") {
                total_time = pair.second->total_time;
                break;
            }
        }
        for (const auto& pair : prof_vector) {
            str.clear();
            str << std::fixed << std::setw(15) << pair.first
                      << std::setw(10) << pair.second->total_count
                      << std::setw(10) << std::setprecision(2)
                      << pair.second->total_time / total_time * 100 << "%"
                      << std::setw(10) << std::setprecision(3)
                      << pair.second->total_time / 1000000.0 << " s"
                      << std::setw(12) << std::setprecision(3)
                      << (pair.second->total_count == 0 ? 0 :
                          (pair.second->total_time / pair.second->total_count))
                      << " us";
            INTER_LOG("%s", str.str().c_str());
        }
        INTER_LOG("Total Time %f s", total_time / 1000000.0);
        INTER_LOG("++++++++ %s Prof Info ++++++++ >>>", head_info.c_str());
    }
    inline void clear_prof_info() {
        prof_map.clear();
    }
};

#define USE_PROF
#ifdef USE_PROF
#define PROF_BEGIN(ptr)               (ptr)->prof_begin(__func__)
#define PROF_END(ptr)                 (ptr)->prof_end(__func__)
#define PROF_SEC_BEGIN(ptr, section)  (ptr)->prof_begin(section)
#define PROF_SEC_END(ptr, section)    (ptr)->prof_end(section)
#define PROF_INFO(ptr)                (ptr)->print_prof_info()
#define PROF_CLEAR(ptr)               (ptr)->clear_prof_info()
#else
#define PROF_BEGIN()
#define PROF_END()
#define PROF_SEC_BEGIN(section)
#define PROF_SEC_END(section)
#define PROF_INFO()
#define PROF_CLEAR()
#endif
}

#endif
