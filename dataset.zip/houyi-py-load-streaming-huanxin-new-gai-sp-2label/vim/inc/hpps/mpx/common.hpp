#ifndef MPX_COMMON_HPP
#define MPX_COMMON_HPP

#include <mpi.h>
#include <limits>

namespace mpx {

// define a max limit (either as MAX_INT or as compilation defined variable)
#ifdef MPX_MAX_INT
// set to smaller value for testing
constexpr size_t max_int = MPX_MAX_INT;
#else
/// maximum message size for MPI
constexpr size_t max_int = std::numeric_limits<int>::max();
#endif

// check type of MPI_Aint
static_assert(sizeof(size_t) == sizeof(MPI_Aint), "MPI_Aint must be the same size as size_t");

// assertion failure
inline void assert_fail(const char * cond, const char* file, int line, const char* func) {
    int rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    printf("\n[Rank %d] %s:%d: %s: Assertion `%s` failed. Aborting.\n", rank, file, line, func, cond);
    fflush(stdout);
    MPI_Abort(MPI_COMM_WORLD, -1);
}

} // namespace mpx


// assert macro
#ifdef NDEBUG
#define MPX_ASSERT(cond) ((void)0) /* TODO should we really deactivate all asserts in a -DNDEBUG build? */
#elif defined(MPX_NDEBUG)
#define MPX_ASSERT(cond) ((void)0)
#else
#define MPX_ASSERT(cond) {if (!(cond)) { mpx::assert_fail("" #cond "",__FILE__, __LINE__, __func__); }}
#endif

#endif // MPX_COMMON_HPP
