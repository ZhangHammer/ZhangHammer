#ifndef MPX_BCAST_HPP
#define MPX_BCAST_HPP

#include <mpi.h>
#include <vector>
#include <string>

// mpx includes
#include "common.hpp"
#include "datatypes.hpp"
#include "comm_fwd.hpp"
#include "reduction.hpp"

namespace mpx {

/// Generic bcast
template <typename T>
void bcast(T* data, size_t count, int root, const mpx::comm& comm) {
    mpx::datatype dt = mpx::get_datatype<T>();
    if (count >= mpx::max_int) {
        mpx::datatype bigdt = dt.contiguous(count);
        MPI_Bcast(data, 1, bigdt.type(), root, comm);
    } else {
        MPI_Bcast(data, count, dt.type(), root, comm);
    }
}

/// Broadcast single value
template <typename T>
void bcast(T& value, int root, const mpx::comm& comm) {
    mpx::datatype dt = mpx::get_datatype<T>();
    MPI_Bcast(&value, 1, dt.type(), root, comm);
}

// container bcast implementation
namespace impl {
template <typename Container>
struct container_bcast {
static void do_bcast(Container& c, int root, const mpx::comm& comm) {
    // first bcast the size, so that receiving can allocate the string
    size_t size = c.size();
    mpx::bcast(size, root, comm);
    if (comm.rank() != root)
        c.resize(size);
    mpx::bcast(&c[0], size, root, comm);
}
};

} // namespace impl

// broadcast a vector
template <typename T, typename Alloc = std::allocator<T>>
void bcast(std::vector<T, Alloc>& vec, int root, const mpx::comm& comm) {
    impl::container_bcast<std::vector<T, Alloc>>::do_bcast(vec, root, comm);
}

// broadcast a string
template <typename CharT = char, typename Traits = std::char_traits<CharT>,
          typename Alloc = std::allocator<CharT>>
void bcast(std::basic_string<CharT, Traits, Alloc>& str, int root, const mpx::comm& comm) {
    impl::container_bcast<std::basic_string<CharT, Traits, Alloc>>::do_bcast(str, root, comm);
}

} // namespace mpx

#endif // MPX_BCAST_HPP
