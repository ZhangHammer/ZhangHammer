#ifndef MPX_ENV_HPP
#define MPX_ENV_HPP

#include <mpi.h>
#include <exception>
#include <stdexcept>
#include <string>
#include "common/util.h"

namespace mpx {

static inline std::string thread_level_string(int provided) {
    switch (provided) {
        case MPI_THREAD_SINGLE:
            return "MPI_THREAD_SINGLE";
            break;

        case MPI_THREAD_FUNNELED:
            return "MPI_THREAD_FUNNELED";
            break;

        case MPI_THREAD_SERIALIZED:
            return "MPI_THREAD_SERIALIZED";
            break;

        case MPI_THREAD_MULTIPLE:
            return "MPI_THREAD_MULTIPLE";
            break;

        default:
            return "INVALID LEVEL";
    }
}

inline void mpx_errorhandler(MPI_Comm* comm, int* error_code, ...) {
    char buf[MPI_MAX_ERROR_STRING];
    int strlen;
    int error_class;

    MPI_Error_class(*error_code, &error_class);
    MPI_Error_string(error_class, buf, &strlen);
    std::string classstr(buf);
    MPI_Error_string(*error_code, buf, &strlen);
    std::string errorstr(buf);
    std::terminate();
    throw std::runtime_error("[MPI Error] class: " + classstr + "\n[MPI Error] " + errorstr);
}

class env {
public:

    env() {
        if (!env::initialized()) {
            int provided = 0;
            MPI_Init_thread(NULL, NULL, MPI_THREAD_SINGLE, &provided);
            INTER_LOG("MPI initialized with %s", thread_level_string(provided).c_str());
        }
    }

    env(int& argc, char**& argv) {
        if (!env::initialized()) {
            int provided = 0;
            MPI_Init_thread(&argc, &argv, MPI_THREAD_SINGLE, &provided);
            INTER_LOG("MPI initialized with %s", thread_level_string(provided).c_str());
        }
    }

    virtual ~env() {
        if (env::initialized() && !env::finalized()) {
            int rank = 0;
            MPI_Comm_rank(MPI_COMM_WORLD, &rank);
            MPI_Finalize();
        }
    }

    static inline bool initialized() {
        int init;
        MPI_Initialized(&init);
        return init != 0;
    }

    static inline bool finalized() {
        int fin;
        MPI_Finalized(&fin);
        return fin != 0;
    }

    static void set_exception_on_error() {
        MPI_Errhandler errhandler;
        MPI_Comm_create_errhandler(&mpx_errorhandler, &errhandler);
        MPI_Comm_set_errhandler(MPI_COMM_WORLD, errhandler);
    }
};


} // namespace mpx

#endif // MPX_ENV_HPP
