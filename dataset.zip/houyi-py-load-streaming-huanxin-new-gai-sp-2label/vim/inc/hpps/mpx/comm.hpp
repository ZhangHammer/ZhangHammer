#ifndef MPX_COMM_HPP
#define MPX_COMM_HPP

// first include the forward declarations
#include "comm_fwd.hpp"

// definitions of dependend functions
#include "comm_def.hpp"

#endif // MPX_COMM_HPP
