#ifndef MPX_WIN_HPP
#define MPX_WIN_HPP

#if MPI_VERSION >= 3

#include "comm.hpp"
namespace mpx {

class win {
public:
    /// Constructor : bind the win object to a pre-allocated buffer
    win(char* base, size_t size, size_t disp_unit, const MPI_Comm& c): 
        mpx_comm(c), locked_rank(-1), rma_buffer(base) {
        MPI_Win_create(base, size, disp_unit, MPI_INFO_NULL, MPI_Comm(mpx_comm), &mpi_win);
    }

    /// Constructor : create win object and a rma buffer at the same time
    win(size_t size, size_t disp_unit, const MPI_Comm& c):
        mpx_comm(c), locked_rank(-1), rma_buffer(nullptr) {
        MPI_Win_allocate(size, disp_unit, MPI_INFO_NULL, MPI_Comm(mpx_comm), 
                         &rma_buffer, &mpi_win); 
    }

    /// Destructor
    ~win() {
        MPI_Win_free(&mpi_win);
    }

    /// win fence
    void fence() const {
        MPI_Win_fence(0, mpi_win);
    }

    /// test lockable
    bool test_lock() {
        return (-1 == locked_rank); 
    }

    /// win lock
    void exclusive_lock(int rank) {
        MPX_ASSERT(-1 == locked_rank);
        MPX_ASSERT(0 <= rank && mpx_comm.size() > rank);
        MPI_Win_lock(MPI_LOCK_EXCLUSIVE, rank, 0, mpi_win);
        locked_rank = rank;
    }

    /// win lock
    void shared_lock(int rank) {
        MPX_ASSERT(-1 == locked_rank);
        MPX_ASSERT(0 <= rank && mpx_comm.size() > rank);
        MPI_Win_lock(MPI_LOCK_SHARED, rank, 0, mpi_win);
        locked_rank = rank;
    }

    /// win unlock
    void unlock() {
        MPX_ASSERT(-1 != locked_rank);
        MPI_Win_unlock(locked_rank, mpi_win);
        locked_rank = -1;
    }

    /// Implicit conversion to MPI_Win
    operator MPI_Win() const {
        return mpi_win;
    }

    inline char* get_rma_buffer() const {
        return rma_buffer;
    }
    
    /************
     *  MPI Put *
     ************/

    /// Put a block of memory of a specified base datatype
    template <typename T>
    inline void put(const T* msg, size_t size, int dest, size_t disp) const {
        MPX_ASSERT(0 <= dest && dest < mpx_comm.size());
        MPX_ASSERT(msg != nullptr);
        if (size < mpx::max_int) {
            mpx::datatype dt = mpx::get_datatype<T>();
            MPI_Put(msg, size, dt.type(), dest, disp, size, dt.type(), mpi_win);
        } else {
            mpx::datatype dt = mpx::get_datatype<T>().contiguous(size);
            MPI_Put(msg, 1, dt.type(), dest, disp, 1, dt.type(), mpi_win);
        }
    }

    /************
     *  MPI Get *
     ************/

    /// Get a block of memory of a specified base datatype
    template <typename T>
    inline void get(T* buffer, size_t size, int src, size_t disp) const {
        MPX_ASSERT(0 <= src && src < mpx_comm.size());
        MPX_ASSERT(buffer != nullptr);
        if (size < mpx::max_int) {
            mpx::datatype dt = mpx::get_datatype<T>();
            MPI_Get(buffer, size, dt.type(), src, disp, size, dt.type(), mpi_win);
        } else {
            mpx::datatype dt = mpx::get_datatype<T>().contiguous(size);
            MPI_Get(buffer, 1, dt.type(), src, disp, 1, dt.type(), mpi_win);
        }
    }
    
private:
    comm mpx_comm;
    MPI_Win mpi_win;
    int locked_rank;
    char* rma_buffer;
};

}

#endif

#endif

