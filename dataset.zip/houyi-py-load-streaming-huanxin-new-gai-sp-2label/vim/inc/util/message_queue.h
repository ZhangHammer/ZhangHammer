/**
 * MessageQueue.h

 */
#ifndef IM_TRAIN_PLATFORM_MESSAGE_QUEUE_H
#define IM_TRAIN_PLATFORM_MESSAGE_QUEUE_H
#include <pthread.h>
#include <queue>
#include <stdio.h>

namespace houyi {
namespace train {

template < class T, int QueueSize = -1 >
class MessageQueue {
private:
    std::queue<T> _msg_queue;
    pthread_mutex_t _mutex_1;
    //pthread_mutex_t mutex_2;
    pthread_cond_t _cond_1;
    pthread_cond_t _cond_2;
    int _ex_queue_size;
    int _ex_queue_low;

public:
    MessageQueue(int max = -1) {
        pthread_mutex_init(&this->_mutex_1, NULL);
        //pthread_mutex_init(&this->mutex_2, NULL);
        pthread_cond_init(&this->_cond_1, NULL);
        pthread_cond_init(&this->_cond_2, NULL);
        _ex_queue_size = QueueSize;
        _ex_queue_low = -1;

        if (max > 0) {
            _ex_queue_size = max;
        }
    }

    ~MessageQueue() {
        pthread_mutex_destroy(&this->_mutex_1);
        //pthread_mutex_destroy(&this->mutex_2);
        pthread_cond_destroy(&this->_cond_1);
        pthread_cond_destroy(&this->_cond_2);
    }

    void set_max_length(int max, int min = -1) {
        _ex_queue_size = max;
        _ex_queue_low = min;
    }

    void push(T msg) {
        pthread_mutex_lock(&this->_mutex_1);

        // if queue is too full
        while (_ex_queue_size > 0
                && int(this->_msg_queue.size()) >= _ex_queue_size) {
            pthread_cond_wait(&this->_cond_2, &this->_mutex_1);
        }

        // enqueue
        this->_msg_queue.push(msg);
        pthread_mutex_unlock(&this->_mutex_1);
        pthread_cond_signal(&this->_cond_1);
    };

    T pop() {
        pthread_mutex_lock(&this->_mutex_1);

        while (this->_msg_queue.empty()) {
            // mu_queue should be locked before calling pthread_cond_wait
            // mu_queue will be locked by the callee after pthread_cond_wait return
            pthread_cond_wait(&this->_cond_1, &this->_mutex_1);
        }

        T m = this->_msg_queue.front();
        this->_msg_queue.pop();
        pthread_mutex_unlock(&this->_mutex_1);

        if ((_ex_queue_size > 0 && _ex_queue_low < 0)
                || (_ex_queue_low >= 0 && int(this->_msg_queue.size()) <= _ex_queue_low)) {
            pthread_cond_signal(&this->_cond_2);
        }

        return m;
    }

    size_t size() {
        return this->_msg_queue.size();
    }

    void clean() {
        //pthread_mutex_lock(&this->_mutex_1);
        size_t sz = size();

        for (size_t i = 0; i < sz; i++) {
            T e = pop();

            if (e) {
                delete e;
                e = NULL;
            }
        }

        //pthread_mutex_unlock(&this->_mutex_1);
    }
};
}
}
#endif
