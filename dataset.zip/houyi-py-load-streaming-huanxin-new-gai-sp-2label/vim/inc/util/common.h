#ifndef HOUYI_TRAIN_PLATFORM_INC_COMMON_H
#define HOUYI_TRAIN_PLATFORM_INC_COMMON_H

enum {
    FALSE = 0,
    TRUE,
};

typedef struct weight {
    uint size;
    char* dw;
    char* w;
    size_t layer;
    size_t weight;
    size_t server;
    char key[64];
} weight_t;

typedef enum update_cmd {
    UPDATE_CMD_INVALID = 0,
    UPDATE_CMD_ADD_DW,
    UPDATE_CMD_AVRG_W,
    UPDATE_CMD_MAX
} update_cmd_t;

enum {
    MODE_INVALID = 0,
    MODE_ASGD,
    MODE_AVRG,
    MODE_MAX
};

typedef enum prep_type {
    SYNC_DOWNLOAD_RQT = 1,
    HADOOP_DOWNLOAD_RQT,
    SYNC_DOWNLOAD_ACK,
} prep_type_t;

const int MAX_FILE_NAME = 128;
typedef struct prep_cmd {
    prep_type_t type;
    int idx;
    char src[MAX_FILE_NAME];
    char dst[MAX_FILE_NAME];
} prep_cmd_t;

#define SGN(t, sgn)                     \
    do {                                \
        if (t > 0) sgn = 1;             \
        else if (t == 0) sgn = 0;       \
        else sgn = -1;                  \
    } while (0)

#endif

#define DISABLE_COPY_AND_ASSIGN(className) private: \
        className(const className&); \
            className& operator=(const className&);
