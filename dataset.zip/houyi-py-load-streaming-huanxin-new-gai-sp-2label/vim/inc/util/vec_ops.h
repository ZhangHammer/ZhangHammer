//by zhxfl 2017.12.29
#ifndef HOUYI_TRAIN_PLATFORM_VEC_OPS_H
#define HOUYI_TRAIN_PLATFORM_VEC_OPS_H
#include <iostream>
#include <xmmintrin.h>
#include <stdio.h>
#include <smmintrin.h>
namespace houyi {
namespace train {

void vec_char2float(float* dst, const unsigned char* src, int size);
void vec_short2float(float *dst, const short* src, float value, int size);
// src = (src - mean) * var
void vec_mean_variance_norm(float* src, float* mean, float* var, int size);
// dst /= value
void vec_norm(float *dst, int size, float value);
// dst += src
void vec_add(float* desc, float* src, int size);

}// train
}// houyi

#endif
