#ifndef HOUYI_UTIL_PROF_H
#define HOUYI_UTIL_PROF_H
#include <iostream>
#include <iomanip>
#include <unordered_map>
#include <chrono>
#include <vector>
#include <algorithm>
#include <memory>
#include <string>
#include <pthread.h>
#include <mutex> 
#include <unordered_map>
#include <atomic>
#include "wind/wind.h"
using std::shared_ptr;
extern thread_local int thread_id;
extern std::atomic<int> thread_count;

namespace wind {
struct Profiling {
    struct ProfInfo {
        std::chrono::high_resolution_clock::time_point start;
        std::chrono::high_resolution_clock::time_point stop;
        int total_count = 0;
        double total_time = 0.;
        inline void Start() {
            start = std::chrono::high_resolution_clock::now();
        }
        inline void Stop() {
            stop = std::chrono::high_resolution_clock::now();
            total_time += std::chrono::duration<double, std::micro>(stop-start).count();
            total_count += 1;
        }
        int idx = 0;
    };
    std::unordered_map<int, std::unordered_map<std::string, shared_ptr<ProfInfo>> > prof_map;
    static std::shared_ptr<Profiling> _get_shared_ref();
    static Profiling* get();
    inline void wind_prof_begin(std::string sec) {
        wind_stream_synchronize(WIND_STREAM_DEFAULT);
        if (thread_id == -1) {
            thread_id = thread_count.fetch_add(1);
            std::lock_guard<std::mutex> lck(_mtx);
            auto it = prof_map[thread_id];
        }
        sec = sec + std::string("_") + std::to_string(thread_id);
        auto it = prof_map[thread_id].find(sec);
        if (it == prof_map[thread_id].end()) {
            shared_ptr<ProfInfo> p(new ProfInfo());
            it = prof_map[thread_id].insert(it, std::make_pair(sec, p));
        }
        it->second->Start();
    }
    inline void wind_prof_end(std::string sec) {
        sec = sec + std::string("_") + std::to_string(thread_id);
        auto it = prof_map[thread_id].find(sec);
        if (it == prof_map[thread_id].end()) {
            shared_ptr<ProfInfo> p(new ProfInfo());
            it = prof_map[thread_id].insert(it, std::make_pair(sec, p));
        }
        it->second->Stop();
        wind_stream_synchronize(WIND_STREAM_DEFAULT);
    }
    inline void wind_print_prof_info() {
        std::lock_guard<std::mutex> lck(_mtx);
        if (0 == prof_map[thread_id].size()) {
            return;
        }
        double total_time = 0.0;
        std::vector< std::pair<std::string, shared_ptr<ProfInfo>> >
            prof_vector(prof_map[thread_id].begin(), prof_map[thread_id].end());
        std::sort(prof_vector.begin(), prof_vector.end(),
            [](const std::pair<std::string, shared_ptr<ProfInfo>>& x,
               const std::pair<std::string, shared_ptr<ProfInfo>>& y){
                return x.second->total_time > y.second->total_time;
            });
        for (const auto& pair : prof_vector) {
            if (pair.first.find("total") != std::string::npos) {
                total_time += pair.second->total_time;
                break;
            }
        }
        std::cerr << "++++++++ wind Prof Info thread_id " << pthread_self() << "+++++++++" << std::endl;
        for (const auto& pair : prof_vector) {
            std::cerr << std::fixed << std::setw(25) << pair.first
                      << std::setw(10) << pair.second->total_count
                      << std::setw(10) << std::setprecision(2)
                      << pair.second->total_time / total_time * 100 << "%"
                      << std::setw(10) << std::setprecision(3)
                      << pair.second->total_time / 1000000.0 << " s"
                      << std::setw(12) << std::setprecision(3)
                      << (pair.second->total_count == 0 ? 0 :
                          (pair.second->total_time / pair.second->total_count))
                      << " us" << std::endl;
        }
        std::cerr << "Total Time " << total_time / 1000000.0 << " s" << std::endl;
        std::cerr << "-------- wind Prof Info --------" << std::endl;
    }
    inline void wind_clear_prof_info() {
        prof_map[thread_id].clear();
    }
private:
    std::mutex _mtx;
};
inline std::shared_ptr<Profiling> Profiling::_get_shared_ref() {
    static std::shared_ptr<Profiling> sptr(new Profiling());
    return sptr;
}
inline Profiling* Profiling::get() {
    static Profiling *inst = _get_shared_ref().get();
    return inst;
}
#define PROF_BEGIN()               wind::Profiling::get()->wind_prof_begin(__func__)
#define PROF_END()                 wind::Profiling::get()->wind_prof_end(__func__)
#define PROF_SEC_BEGIN(section)    wind::Profiling::get()->wind_prof_begin(section)
#define PROF_SEC_END(section)      wind::Profiling::get()->wind_prof_end(section)
#define PROF_INFO()                wind::Profiling::get()->wind_print_prof_info()
#define PROF_CLEAR()               wind::Profiling::get()->wind_clear_prof_info()
}   // namespace wind
#endif
