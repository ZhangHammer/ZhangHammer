// by zhxfl 2018.07.30
#ifndef HOUYI_TRAIN_PLATFORM_BARRIER_H
#define HOUYI_TRAIN_PLATFORM_BARRIER_H
#include <thread>
#include <mutex>
#include <condition_variable>
namespace houyi {
namespace train {

class Barrier {
public:
    explicit Barrier(std::size_t count) : 
      _threshold(count), 
      _count(count), 
      _generation(0) {
    }

    void start() {
        _is_working = true; 
        _generation = 0;
        _count = _threshold;
    }

    void stop() {
        _is_working = false;
        this->notify_all();
    }

    void wait() {
        std::unique_lock<std::mutex> lck{_mutex};
        auto lgen = _generation;
        if (!--_count) {
            _generation++;
            _generation %= 100;
            _count = _threshold;
            _cond.notify_all();
        } else {
            _cond.wait(lck, [this, lgen] {return lgen != _generation || (!_is_working);});
        }
    }

    void notify_all() {
        _cond.notify_all();
    }

private:
    std::mutex _mutex;
    std::condition_variable _cond;
    std::size_t _threshold;
    std::size_t _count;
    std::size_t _generation;
    bool _is_working = false;
};

} // namespace houyi
} // namespace train
#endif 
