/**
 * parse_string.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-12-23
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_UTIL_PARSE_STRING_H
#define HOUYI_UTIL_PARSE_STRING_H

#include <string>
#include <vector>
#include <fstream>
#include "util.h"

namespace houyi {
namespace train {

//using namespace std;

template<class T>
void string_to_enum(std::string str, std::vector<std::string>& string_types, T* type) {
    const char* p = str.c_str();
    int find = 0;
    int j = 0;

    for (; j < string_types.size(); ++j) {
        if (str == string_types[j]) {
            find = 1;
            break;
        }
    }

    CHECK(find != 0, "%s not support", p);
    *type = (T)j;
}

template<class T>
void string_to_enum(std::string str, char const** string_types, T* type) {
    const char* p = str.c_str();
    int find = 0;
    int j = 0;

    if (str.length() == 0) {
        return;
    }

    for (j = 0; string_types[j] != NULL; ++j) {
        if (strcmp(p, string_types[j]) == 0) {
            find = 1;
            break;
        }
    }

    CHECK(find != 0, "%s not support", p);
    *type = (T)j;
}

void stream_to_string(std::ifstream& input,
                      const std::string& end_str, std::string& rslt_str);

void remove_white_space_comment(std::string& str);
void remove_white_space_comment(char* str);
bool parse_from_string(const std::string& name,
                       std::string* string, int* param);
bool parse_from_string(const std::string& name,
                       std::string* string, size_t* param);
bool parse_from_string(const std::string& name,
                       std::string* string, bool* param);
bool parse_from_string(const std::string& name,
                       std::string* string, float* param);
bool parse_from_string(const std::string& name,
                       std::string* string, std::string* param);
bool parse_from_string(const std::string& name,
                       std::string* string, std::vector<int>* param);
bool parse_from_string(const std::string& name,
                       std::string* string, std::vector<float>* param);
bool parse_from_string(const std::string& name,
                       std::string* string, std::vector<std::string>* param);
bool parse_tuple_from_string(const std::string& name, std::string* str,
                             std::string* param);

bool split_string(std::vector<std::string>& out, const std::string& s, char seperator);

size_t count_file_lines(std::string path);
}
}

#endif
