// by zhxfl 2017.11.29
#ifndef HOUYI_TRAIN_PLATFORM_IO_PACKAGE_H
#define HOUYI_TRAIN_PLATFORM_IO_PACKAGE_H
#include <vector>
#include <iostream>
#include <sys/time.h>
#include <map>
#include "util.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class IOPackage {
    DISABLE_COPY_AND_ASSIGN(IOPackage);
public:
    //由于is_owner
    //move constructor
    IOPackage& operator=(IOPackage&& other) {
        clear();
        _ten_is_own = other._ten_is_own;
        _mask_is_own = other._mask_is_own;
        _ten = other._ten;
        _mask = other._mask;
        other._ten_is_own = true;
        other._mask_is_own = true;
        other._ten = NULL;
        other._mask = NULL;
        return *this;
    } 
    IOPackage(IOPackage&& pack) {
        init();
        *this = std::move(pack);
    }
public:
    IOPackage() {
        init();
    }

    IOPackage(Tensor<DType>* ten) {
        init();
        _mask = new Tensor<int>(Dim(ten->get_size(0)), ten->get_device());
        _mask->set_element(1);
        _ten = ten;
    }

    //不建议使用
    void set_own(bool own) {
        _ten_is_own = own;
        _mask_is_own = own;
    }

    IOPackage(const Dim& size, const Device& device) {
        init();
        resize(size, device);
    }

    IOPackage(const Device& device) {
        init();
        resize(Dim(1, 1), device);
    }

    ~IOPackage() {
        clear();

        if (_mask != NULL) {
            delete _mask;
        }

        init();
    }
    inline bool is_init() {
        if (_ten!= NULL) {
            return true;
        }
        else {
            return false;
        }
    }

    inline size_t get_height() const {
        return _ten->get_height();
    }
    inline size_t get_width() const {
        return _ten->get_width();
    }
    inline size_t get_channel() const {
        return _ten->get_c();
    }
    inline size_t get_num() const {
        return _ten->get_n();
    }
    /*
     * 返回tensor的最高维
     */
    inline size_t get_batch_size() const {
        return _ten->get_size(0);
    }

    inline void share(Tensor<DType>* ten, Tensor<int>* mask) {
        if (_ten_is_own && _ten != NULL) {
            delete _ten;
        }
        _ten = ten;
        _ten_is_own = false;

        if (_mask_is_own && _mask != NULL) {
            delete _mask;
        }
        _mask = mask;
        _mask_is_own = false;
    }

    inline void share_ten(Tensor<DType>* dtype_ten) {
        if (_ten_is_own && _ten != NULL) {
            delete _ten;
        }
        _ten = dtype_ten;
        _ten_is_own = false;
    }

    inline void share_mask(Tensor<int>* mask) {
        if (_mask_is_own && _mask != NULL) {
            delete _mask;
        }
        _mask = mask;
        _mask_is_own = false;
    }

    inline Tensor<DType>* get_ten() const {
        return _ten;
    }

    inline Tensor<int>* get_mask() const {
        return _mask;
    }

    inline void set_mask(int i) const {
        _mask->set_element(i);
    }

    const Dim& get_size() const {
        return _ten->get_size();
    }
    const int get_size(int idx) const {
        return _ten->get_size(idx);
    }

    const Device& get_device() const {
        return _ten->get_device();
    }

    void resize(const Dim& size, const Device& device);
    void resize(const Dim& ten_size, Tensor<int>* mask, const Device& device);
    void zero();
    void copy_to(Tensor<DType>* ten) const;
    void copy_from(const Tensor<DType>* ten);
    void copy_from(const IOPackage& src);

    int get_dim() {
        return _ten->get_dim();
    }
private:
    void init() {
        _ten_is_own = true;
        _mask_is_own = true;
        _ten = NULL;
        _mask = NULL;
    }

    inline void clear() {
        if (_ten_is_own) {
            if (_ten) {
                delete _ten;
            }
        }
        if (_mask_is_own) {
            if (_mask) {
                delete _mask;
            }
        }
        _ten = NULL;
        _mask = NULL;
    }

private:
    bool _ten_is_own;
    bool _mask_is_own;
    Tensor<DType>* _ten;
    //那些数据是有效的, 0：无效，1：有效
    Tensor<int>* _mask;
};

typedef std::map<std::string, IOPackage*> PacksMap;
}
} //namespace houyi
#endif
