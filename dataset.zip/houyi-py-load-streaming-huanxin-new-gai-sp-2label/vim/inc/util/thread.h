/**
 * thread.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-03-10
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef IM_TRAIN_PLATFORM_THREAD_H
#define IM_TRAIN_PLATFORM_THREAD_H
#include <pthread.h>
#include <semaphore.h>
#include <new>
namespace houyi {
namespace train {
class ThreadContext {
public:
    ThreadContext(void* param, bool* alive_mark) {
        sem_init(&_create_finish_sem, 0, 0);
        _param_data = param;
        _alive = alive_mark;
    }
    ThreadContext(bool* alive_mark) {
        new(this) ThreadContext(NULL, alive_mark);
    }
    ~ThreadContext() {
        sem_destroy(&_create_finish_sem);
        _param_data = NULL;
        _alive = NULL;
    }
    inline void set_param(void* p) {
        _param_data  = p;
    }
    inline void* get_param() {
        return _param_data;
    }

    inline void wait_create() {
        sem_wait(&_create_finish_sem);
    }
    inline bool* get_alive() {
        return _alive;
    }
    sem_t _create_finish_sem;
protected:
    bool* _alive;
    void* _param_data;
};

class Thread {
public:
    Thread() {
        _is_alive = false;
        _ctx = NULL;
    }
    ~Thread() {
        if (_ctx) {
            delete _ctx;
            _ctx = NULL;
        }
    }
    void start(void * (*func)(void*), void* data) {
        if (_ctx == NULL) {
            _ctx = new ThreadContext(&_is_alive);
        }

        _ctx->set_param(data);
        pthread_create(&_thread_id, NULL, func, (void*)_ctx);
        _ctx->wait_create();
    }

    void join() {
        _is_alive = false;
        pthread_join(_thread_id, NULL);
    }

    bool is_alive() {
        return _is_alive;
    }
protected:
    ThreadContext* _ctx;
    pthread_t _thread_id;
    bool      _is_alive;
};
}
}
#endif
