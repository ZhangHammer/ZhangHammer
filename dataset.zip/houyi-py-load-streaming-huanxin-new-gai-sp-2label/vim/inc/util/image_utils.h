#ifndef HOUYI_UTIL_IMAGE_UTILS_H
#define HOUYI_UTIL_IMAGE_UTILS_H
#ifdef __WITH_OPENCV__
#include <opencv2/opencv.hpp>
#endif
#include "base_batch_sample.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
void tensor_to_mat(Tensor<DType>& src, cv::Mat& sink);
void mat_to_tensor(cv::Mat& src, Tensor<DType>& sink);
void save_batch_sample(BaseBatchSample& bat);
void resize_tensor(Tensor<DType>& src, Tensor<DType>& sink);
#endif

/*
 *均匀分布
 */
void random_tensor(Tensor<DType>& ten, float seed, float alpha);
/*
 *  *高精度打印
 *  */
void write_tensor(Tensor<DType>& ten, char* path, int count = 5000);

void write_tensor(Tensor<int>& ten, char* path, int count = 5000);

}
}

#endif
