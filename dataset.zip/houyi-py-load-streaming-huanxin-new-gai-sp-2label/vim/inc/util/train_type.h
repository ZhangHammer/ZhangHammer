/*
 *Filename: train_type.h
 *Description:
 *
 *Version: 1.0
 *Created: 2017年05月16日 14时53分06秒
 *Author: lifeng(lifeng20@baidu.com)
 *
 *Copyright: Copyright (c) baidu, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_LAYERS_TRAIN_TYPE_H
#define HOUYI_LAYERS_TRAIN_TYPE_H

namespace houyi {
namespace train {

enum TrainType {
    SYNC_TRAIN,
    ASYNC_TRAIN,
    TRAIN_UNKNOWN
};

extern const char* trainTypeName[];
}
}

#endif
