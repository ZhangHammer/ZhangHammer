#ifndef HOUYI_TRAIN_PLATFORM_UTIL_H
#define HOUYI_TRAIN_PLATFORM_UTIL_H
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <unistd.h>
#include <sys/types.h>
#include <inttypes.h>
#include <sys/time.h>
#include <sys/syscall.h>
#include <time.h>
#include "glog/logging.h"
//#include "wind_base.h"
#include "common.h"

#ifdef __HFNN_DYNAMIC__
const int open_glog  = 0;
#else
const int open_glog = 1;
#endif

namespace houyi {
namespace train {

#ifdef __TRAIN_OUTPUT_RESULT__
extern int g_batch_cnt;
extern int g_thread_batch_cnt[];
#endif

#define ALIGNED(n, s) ( ((n + s-1) / s) * s )

#define CHECK(condition, format , arg...)  \
    do { \
        char format_str[512];  \
        sprintf(format_str, format, ##arg); \
        if (open_glog) { \
            BAIDU_SPEECH_CHECK(condition) << format_str << "\n"; \
        } else { \
            _CHECK(condition, format_str); \
        } \
    } while (0)

#define _CHECK(condition, format)  \
    if (!(condition)) {  \
        pid_t tid = syscall(SYS_gettid);\
        char f_name[32] = {0}; \
        sprintf(f_name, "%u_ERROR_LOG", tid);\
        FILE* f = fopen( f_name, "a+" );\
        if (f == NULL ) {\
            exit(-1);\
        } else {\
            time_t timep;\
            struct tm * timeinfo;\
            time (&timep);\
            timeinfo = localtime ( &timep); \
            fprintf(f, "ERROR-TIME:%s - FILE:%s LINE:%d FUNC:%s] == %s", \
                    asctime(timeinfo), __FILE__, __LINE__, __func__, format);\
            fclose(f); \
            exit(-1); \
        }\
    }

#define CHECK2(condition)  \
    do { \
        if (open_glog) { \
            BAIDU_SPEECH_CHECK(condition); \
        } else { \
            _CHECK2(condition); \
        } \
    } while (0)

#define _CHECK2(condition)                    \
    if (!(condition)) {                                \
        pid_t tid = syscall(SYS_gettid);\
        char f_name[32] = {0}; \
        sprintf(f_name, "%u_ERROR_LOG", tid);\
        FILE* f = fopen( f_name, "a+" );\
        if (f == NULL) {\
            exit(-1);\
        } else {\
            time_t timep;\
            struct tm * timeinfo;\
            time (&timep);\
            timeinfo = localtime ( &timep); \
            fprintf(f, "ERROR-TIME:%s - FILE:%s LINE:%d FUNC:%s]", \
                asctime(timeinfo), __FILE__, __LINE__, __func__);\
            fclose(f); \
            exit(-1); \
        }\
    }

#define INTER_CHECK(condition, format , arg...)  \
    do { \
        char format_str[512];  \
        sprintf(format_str, format, ##arg); \
        if (open_glog) { \
            BAIDU_SPEECH_CHECK(condition) << format_str << "\n"; \
        } else { \
            _INTER_CHECK(condition, format_str); \
        } \
    } while (0)

#define _INTER_CHECK(condition, format)                    \
    if (!(condition)) {                                \
        pid_t tid = syscall(SYS_gettid);\
        char f_name[32] = {0}; \
        sprintf(f_name, "%u_ERROR_LOG", tid);\
        FILE* f = fopen( f_name, "a+" );\
        if (f == NULL) {\
            exit(-1);\
        } else {\
            time_t timep;\
            struct tm * timeinfo;\
            time (&timep);\
            timeinfo = localtime ( &timep); \
            fprintf(f, "INTERNAL ERROR-TIME:%s - FILE:%s LINE:%d FUNC:%s] == %s\n", \
                asctime(timeinfo), __FILE__, __LINE__, __func__, format);\
            fclose(f); \
        }\
    }

#define INTER_LOG(format , arg...)  \
    do { \
        char format_str[1024];  \
        snprintf(format_str, sizeof(format_str), format, ##arg); \
        if (open_glog) { \
             BAIDU_SPEECH_LOG(INFO) << format_str << "\n"; \
        } else { \
            _INTER_LOG(format_str); \
        } \
    } while (0)

#define _INTER_LOG(format)                    \
    do {                                \
        pid_t tid = syscall(SYS_gettid);\
        char f_name[32] = {0}; \
        sprintf(f_name, "%u_INFO_LOG", tid);\
        FILE* f = fopen( f_name, "a+" );\
        if (f == NULL) {\
            exit(-1);\
        } else {\
            time_t timep;\
            struct tm * timeinfo;\
            time (&timep);\
            timeinfo = localtime (&timep); \
            fprintf(f, "INTERNAL INFO-TIME:%s - FILE:%s LINE:%d FUNC:%s] == %s\n",\
                    asctime(timeinfo), __FILE__, __LINE__, __func__, format);\
            fclose(f); \
        }\
    } while (0)

}
}
#endif
