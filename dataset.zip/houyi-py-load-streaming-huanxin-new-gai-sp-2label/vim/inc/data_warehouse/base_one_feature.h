/**
* base_one_data.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-011
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_ONE_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_BASE_ONE_FEATURE_H
#include <utility>
#include <vector>
#include <sstream>
#include "util.h"
#include "data_tool.h"
#include "wind/wind.h"
#include "base_stream.h"

namespace houyi {
namespace train {

class BaseOneFeature {
public:
    BaseOneFeature(DataType type): _data(Tensor<DType> {cpu_device()}) {
        _data_type = type;
    }

    virtual ~BaseOneFeature() {
    }
//基类方法
public:
    Tensor<DType>&get_feature() {
        return _data;
    }
    DataType get_feature_type() {
        return _data_type;
    }
    void set_feature_type(DataType type) {
        _data_type = type;
    }
    std::string get_feature_desc() {
        return _feature_desc;
    }
//纯虚方法
public:
    //virtual int read_data(std::ifstream &in_stream, size_t st_position_in_byte = 0, size_t size_in_type = 0) = 0;
    virtual int read_data(BaseStream&in_stream, size_t st_position_in_byte = 0, size_t size_in_type = 0) = 0;
    virtual void set_feature(Tensor<DType>& data) = 0;
protected:
    DataType _data_type;
    FeatureDescT _feature_desc;
    Tensor<DType> _data;
    DISABLE_COPY_AND_ASSIGN(BaseOneFeature);
};

}
}

#endif
