/**
 * image_one_label.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-11
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_ONE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_ONE_LABEL_H
#include <utility>
#include <vector>
#include <fstream>
#include "base_one_label.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class ImageOneLabel : public BaseOneLabel {
private:
    //禁用
    ImageOneLabel() = delete;
    ImageOneLabel& operator=(const ImageOneLabel&) = delete;
public:
    //深拷贝函数
    ImageOneLabel(ImageOneLabel& label): BaseOneLabel(label.get_label_type(), label.get_label_dim()){
        _label.resize(label.get_label_tensor().get_size());
        _label.copy_from(label.get_label_tensor());
    }

    ImageOneLabel(LabelType type, size_t label_dim):
        BaseOneLabel(type, label_dim) {
        _label.resize(Dim(1, label_dim), false);
    }

    virtual ~ImageOneLabel() {
    }

    virtual int read_label(BaseStream&in_stream, size_t st_position_in_byte, size_t size_in_byte);
};


}
}

#endif
