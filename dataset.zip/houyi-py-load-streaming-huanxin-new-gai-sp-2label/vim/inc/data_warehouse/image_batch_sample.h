/**
 * image_batch_sample.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_SAMPLE_H
#include <utility>
#include <vector>
#include "image_batch_label.h"
#include "image_batch_feature.h"
#include "base_batch_sample.h"
#include "base_batch_feature.h"
#include "wind/wind.h"
#include <string>
#include <map>
#include "image_batch_desc.h"

namespace houyi {
namespace train {
class ImageBatchSample: public BaseBatchSample {
    DISABLE_COPY_AND_ASSIGN(ImageBatchSample);
public:
    using ParamFeatureT = std::map<std::string, std::tuple<DataType, ChannelT, HeightT, WidthT> >;
    using ParamLabelT = std::map<std::string, std::tuple<LabelType, LabelDimT> >;
public:
    ImageBatchSample(size_t batch_size,
                     ParamFeatureT features,
                     ParamLabelT labels);

    virtual ~ImageBatchSample();

    /*
     * 引入对象管理之后，本对象可能复用
     * 复用的时候可能Tensor大小发生变化
     */
    virtual void resize(size_t batch_size, 
            ParamFeatureT features,
            ParamLabelT labels);

    Tensor<DType> get_label_tensor_by_index(std::string key, size_t src_batch_index) {
        CHECK2(_labels.find(key) != _labels.end());
        ImageBatchLabel* image_label = dynamic_cast<ImageBatchLabel*>(_labels[key]);
        return image_label->get_label(src_batch_index);
    }
};


}
}

#endif
