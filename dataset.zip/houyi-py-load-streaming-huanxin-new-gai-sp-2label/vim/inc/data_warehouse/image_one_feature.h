/**
 * image_one_data.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-011
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_ONE_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_ONE_FEATURE_H
#include <utility>
#include <vector>
#include <memory>
#include "wind/wind.h"
#include "data_tool.h"
#include "base_one_feature.h"
#include <string>
#include <iostream>
#include <fstream>

namespace houyi {
namespace train {

class ImageOneFeature: public BaseOneFeature {
public:
    //禁用
    ImageOneFeature() = delete;
    ImageOneFeature& operator=(const ImageOneFeature&) = delete;
public:
    virtual ~ImageOneFeature() {
    }

    virtual void set_feature(Tensor<DType> &data) {
        _data.resize(data.get_size());
        _data.copy_from(data);
        this->set_width(_data.get_w());
        this->set_height(_data.get_h());
        this->set_channel(_data.get_c());
    }

    ImageOneFeature(ImageOneFeature& feature): BaseOneFeature(feature.get_feature_type()) {
        _channel = feature.get_channel();
        _height = feature.get_height();
        _width = feature.get_width();

        _data.resize(Dim(_channel, _height, _width), false);
        _data.copy_from(feature.get_feature());
    }

    ImageOneFeature(FeatureDescT feature_desc, DataType type, size_t channel, size_t height, size_t width) : BaseOneFeature(type) {
        init();
        _height = height;
        _width = width;
        _channel = channel;
        _feature_desc = feature_desc;

        switch (this->get_feature_type()) {
        case RGB24_TYPE:
        case BBGGRR_UC_TYPE:
        case BBGGRR_FLOAT_TYPE:
        case JPEG_TYPE:
            CHECK2(_channel == 3);
            break;
        case GRAY_FLOAT_TYPE:
            CHECK2(_channel == 1);
            break;
        case SEQ_CHAR_TYPE:
            break;
        default:
            CHECK(false ,"image type not support");
        }

        _data.resize(Dim(_channel, _height, _width), false);
    }

    void decode_image(std::string&buffer, size_t size_in_byte);
    void decode_jpeg(std::string&buffer, size_t size_in_byte);

    virtual int read_data(std::ifstream &in_stream, size_t st_position_in_byte = 0, size_t size_in_type = 0);
    int read_data(BaseStream&in_stream, size_t st_position_in_byte = 0, size_t size_in_type = 0);

    size_t get_height() {
        return _height;
    }

    size_t get_width() {
        return _width;
    }

    size_t get_channel() {
        return _channel;
    }

    virtual void set_height(size_t height) {
        _height = height;
    }

    virtual void set_width(size_t width) {
        _width = width;
    }

    virtual void set_channel(size_t channel) {
        _channel = channel;
    }

private:
    void init() {
        _height = 0;
        _width = 0;
        _channel = 0;
    }

private:
    size_t _height;
    size_t _width;
    size_t _channel;
};

}
}

#endif
