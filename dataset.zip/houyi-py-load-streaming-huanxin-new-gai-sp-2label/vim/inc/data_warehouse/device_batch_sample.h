//by zhxfl 2017.11.27
#ifndef HOUYI_DATA_WAREHOUSE_DEVICE_BATCH_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_DEVICE_BATCH_SAMPLE_H

#include <utility>
#include <vector>
#include <string>
#include <unordered_map>
#include <queue>
#include "base_batch_sample.h"
#include "wind/wind.h"
#include "util.h"
#include "data_tool.h"
#include "io_package.h"

namespace houyi {
namespace train {

/*
 * 构造bat之后，将数据拷贝到gpu设备上
 */

class DeviceBatchSample {
    DISABLE_COPY_AND_ASSIGN(DeviceBatchSample);
public:
    DeviceBatchSample(){};
    ~DeviceBatchSample() {
        for (auto& it : _io_package) {
            delete it.second;
        }
        _io_package.clear();
        while (!_back_io_pack.empty()) {
            delete _back_io_pack.front();
            _back_io_pack.pop();
        }
    }
    void copy_from(BaseBatchSample* sample);
    void reset() {
        for (auto& it :_io_package) {
            _back_io_pack.push(it.second);
        }
        _io_package.clear();
    }

    inline std::vector<IOPackage*> get_io_package(std::vector<std::string> keys) {
        std::vector<IOPackage*> ret;
        for (size_t i = 0; i < keys.size(); i++) {
            ret.push_back(&get_io_package(keys[i]));
        }
        return ret;
    }

    inline IOPackage& get_io_package(std::string key) {
        if (_io_package.find(key) == _io_package.end()) {
            if (!_back_io_pack.empty()) {
                _io_package[key] = _back_io_pack.front();
                _back_io_pack.pop();
            }
            else {
                _io_package[key] = new IOPackage();
            }
        }
        return *_io_package[key];
    }

private:
    std::unordered_map<std::string, IOPackage*> _io_package;
    std::queue<IOPackage*> _back_io_pack;
};

}//namespace train
}//namespace houyi
#endif
