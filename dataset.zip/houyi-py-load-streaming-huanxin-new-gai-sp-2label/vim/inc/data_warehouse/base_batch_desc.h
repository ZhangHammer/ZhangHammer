//by zzxfl 2017.02.09
#ifndef HOUYI_DATA_WAREHOUSE_BASE_BATCH_DESC_H
#define HOUYI_DATA_WAREHOUSE_BASE_BATCH_DESC_H
#include <utility>
#include <vector>
#include <string>
#include <map>
#include "data_tool.h"

namespace houyi {
namespace train {

class BaseBatchDesc {
public:
    virtual ~BaseBatchDesc() {}
    virtual void clear() = 0;
public:
    std::vector<std::string>& get_default_file_name() {
        for (std::map<FeatureDescKeyT,
                std::vector<std::string>>::iterator iter = _file_name.begin();
                iter != _file_name.end();
                iter++) {
            return iter->second;
        }
        CHECK2(false);
        std::vector<std::string>*tmp;
        return *tmp;
    }

    std::vector<std::string>&get_file_name(std::string desc_key) {
        if (_file_name.find(desc_key) == _file_name.end()) {
            _file_name[desc_key] = std::vector<std::string>();
        }
        return _file_name[desc_key];
    }
//图像接口
public:
    virtual std::vector<int>& get_default_origin_width() {
        CHECK2(false);
        std::vector<int>*tmp;
        return *tmp;
    }

    virtual std::vector<int>& get_default_origin_height() {
        CHECK2(false);
        std::vector<int>*tmp;
        return *tmp;
    }

    virtual std::vector<float>& get_default_scale() {
        CHECK2(false);
        std::vector<float>*tmp;
        return *tmp;
    }

    virtual std::vector<int>& get_origin_width(FeatureDescKeyT key) {
        CHECK2(false);
        std::vector<int>*tmp;
        return *tmp;
    }

    virtual std::vector<int>& get_origin_height(FeatureDescKeyT key) {
        CHECK2(false);
        std::vector<int>*tmp;
        return *tmp;
    }

    virtual std::vector<float>& get_scale(FeatureDescKeyT key) {
        CHECK2(false);
        std::vector<float>*tmp;
        return *tmp;
    }

protected:
    std::map<FeatureDescKeyT, std::vector<std::string> > _file_name;//原始图片的文件名（含路径）
};

}//houyi
}//train

#endif
