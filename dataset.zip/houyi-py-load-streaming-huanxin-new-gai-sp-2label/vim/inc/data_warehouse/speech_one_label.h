//by zzxfl 2016.09.18
/*
 * 一个sentence对应的label
 * 每个句子由多个帧构成_frame_num
 * 每个frame可能对应多个标签,标签数目由_label_dim表示
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_ONE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_ONE_LABEL_H
#include <utility>
#include <vector>
#include "base_one_label.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
class SpeechOneLabel :public BaseOneLabel {
    DISABLE_COPY_AND_ASSIGN(SpeechOneLabel);
public:
    SpeechOneLabel(LabelType type, size_t frame_num, size_t label_dim):
        BaseOneLabel(type, label_dim), _frame_num(frame_num) {
        _label.resize(Dim(_frame_num, _label_dim), false);
    }
    
    void resize(LabelType type, size_t frame_num, size_t label_dim) {
        _type = type;
        _label_dim = label_dim;
        _frame_num = frame_num;
        _label.resize(Dim(_frame_num, _label_dim), false);
    } 

    void resize(size_t new_frame_num) {
        _label.resize(Dim(new_frame_num, get_label_dim()), false);
        _frame_num = new_frame_num;
    }

    virtual int read_label(BaseStream& in_stream, size_t st_position_in_byte, size_t size_in_byte);

    virtual ~SpeechOneLabel() {
    }

    virtual size_t get_frame_num() {
        return _frame_num;
    }

    virtual void set_frame_num(size_t frame_num) {
        _frame_num = frame_num;
    }
protected:
    size_t _frame_num;//帧数
};
}//houyi
}//train

#endif
