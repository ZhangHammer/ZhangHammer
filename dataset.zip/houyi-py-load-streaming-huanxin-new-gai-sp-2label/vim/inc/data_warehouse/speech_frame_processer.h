/**
 * speech_frame_processer.h
 *
 * Author: Chen Xu (chenxu13@baidu.com)
 * Created on: 2018-04-18
 *
 * Copyright (c) Baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_FRAME_PROCESSER_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_FRAME_PROCESSER_H

#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>
#include "base_processer.h"

namespace houyi {
namespace train {

class SpeechFrameRepository;
class SpeechFrameProcesser : public BaseProcesser {
friend class SpeechFrameRepository;
public:
    typedef std::pair<int, int> FrameIndex;
    typedef std::pair<std::vector<BaseOneSample*>, std::vector<FrameIndex>> FramePool;

    SpeechFrameProcesser(BaseDataReader *reader, BaseProcConfig &cfg): BaseProcesser(reader, cfg), _device_num(cfg.get_device_num()) { 
        CHECK2(_cfg->is_async());
        _init();
    }

    void clear() override {
        std::lock_guard<std::mutex> lk(_mtx);
        
        if (_is_cleared) {
            return;
        }

        if (_thread.joinable()) {
            _thread.join();
        }
        
        _is_cleared = true;
    }

    virtual void start_async_load() override {
        std::lock_guard<std::mutex> lk(_mtx);
        
        if (_is_started) {
            return;
        }

        _thread = std::move(std::thread(&SpeechFrameProcesser::inter_async_load, this));
        _is_started = true;
    }
    
    virtual void reset() override {
        std::lock_guard<std::mutex> lk(_mtx);
        
        if (_is_started) {
            return;
        }

        if (_thread.joinable()) {
            _thread.join();
        }
        
        _init();
    
        _thread = std::move(std::thread(&SpeechFrameProcesser::inter_async_load, this));
        _is_started = true;
    }

    int get_randomized_frames_from_proc(int max_num_frames, int* start_pos, int* end_pos);

private:
    void inter_async_load();
    void generate_frame_index();
    void _init() {
        _ready_pool_update_done = false;
        _num_frames_in_pool = 0;
        _cur_load_pos = 0;
        _request_counter = 0;

        _is_started = false;
        _is_cleared = false;
    }

private:
    std::thread _thread;
    std::mutex _mtx;
    std::condition_variable _cv_processing_done;
    std::condition_variable _cv_samples_consumed;
    bool _ready_pool_update_done;
    int _device_num;

    FramePool _processing_pool;
    FramePool _ready_pool;
    int _num_frames_in_pool;
    int _cur_load_pos;
    int _request_counter;

    bool _is_started;
    bool _is_cleared;
};

} // namespace train
} // namespace houyi


#endif
