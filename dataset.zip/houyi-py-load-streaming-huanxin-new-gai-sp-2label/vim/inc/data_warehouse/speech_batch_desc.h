//by zzxfl 2017.02.09
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_DESC_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_DESC_H
#include <utility>
#include <vector>
#include <string>
#include <map>
#include "data_tool.h"
#include "base_batch_desc.h"

namespace houyi {
namespace train {

class SpeechBatchDesc : public BaseBatchDesc {
public:
    SpeechBatchDesc() {
    }
    virtual ~SpeechBatchDesc() {
    }
    virtual void clear() {
        _file_name.clear();
    }
};

}//houyi
}//train

#endif
