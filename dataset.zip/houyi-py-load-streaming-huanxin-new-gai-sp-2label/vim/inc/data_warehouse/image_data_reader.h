/**
 * image_data_reader.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-1
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_DATA_READER_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_DATA_READER_H

#include <iostream>
#include <vector>
#include <queue>
#include <pthread.h>
#include <utility>
#include <map>
#include "util.h"
#include "image_reader_config.h"
#include "base_data_reader.h"
#include "message_queue.h"
#include "image_extract_data.h"
#include <mutex>
#include <thread>

namespace houyi {
namespace train {
/*
* 数据读取并且装换成sample由BaseExtractData负责
* 本对象负责获得sample list之后需要进行个处理：
* 1) 模式1：数据少的时候，所有数据都缓存到内存中 is_read_all_sample
* 2) 模式2：正常流水化base_extract_data
* 3) 模式3：区分度训练 push_batch_to_reader
*/


class ImageDataReader : public BaseDataReader {
    DISABLE_COPY_AND_ASSIGN(ImageDataReader);
    ImageDataReader() = delete;
public:
    ImageDataReader(BaseReaderConfig &cfg);
    ~ImageDataReader();

    void read_all_sample();
    void reset();
    size_t get_samples_from_reader(std::vector<BaseOneSample*>& samples, int sample_num);

    // 区分度训练接口，回放样本
    // Tensor的第一维表示样本个数
    // 接口不负责清理feature label的内容
    // 只支持单标签单特征
    virtual void push_batch_to_reader(Tensor<DType>*feature, Tensor<DType>*label);
private:
    void sample_random(std::vector<BaseOneSample *> &sample_vector);
    void random_data_file_list();

    MessageQueue<BaseOneSample*> _sample_queue;
    std::vector<BaseOneSample *> _sample_vector; //临时存放，排序使用
    std::vector<BaseOneSample *> _all_sample;// 将所有样本加载到内存中

    bool _read_from_disk = true; // 1表示从磁盘读取
    ImageReaderConfig* _image_cfg;
    int _finish_thread = 0; // 区分度多卡时，如果一个epoch结束，上层会传过来一个空bat，由于多卡在读取，该标志位标志epoch已经结束，给每个卡的processer放回一个空sample
    bool _is_read_all_sample; // 是否读取所有样本
    int _all_sample_idx = 0; // 所有样本的样本ID
    bool _sample_random = true;
    std::mutex _read_mutex;
    //异步读取磁盘数据
    std::vector<BaseExtractData*> _extract_data_runtime;
};

}
}

#endif
