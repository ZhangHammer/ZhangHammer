/**
 * image_repository.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-06
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_REPOSITORY_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_REPOSITORY_H
#include <utility>
#include "base_repository.h"
#include "image_one_sample.h"
#include "image_batch_sample.h"

namespace houyi {
namespace train {

class ImageRepository : public BaseRepository {
public:
    ImageRepository(BaseProcesser *proc, BaseReposConfig& cfg, int device_id)
        : BaseRepository(proc, cfg, device_id) {
        init();
    }

    virtual ~ImageRepository () {
        _sample_buf.clear();
    }

    void reset() {
        _sample_buf.clear();
        BaseRepository::reset();
    }

    virtual void init() {
        _sample_buf.clear();
    }
    virtual size_t inter_get_batch(std::vector<BaseBatchSample*> &batches, size_t max_num);
private:
    ImageBatchSample::ParamFeatureT get_features_param(ImageOneSample& sample);
    ImageBatchSample::ParamLabelT get_labels_param(ImageOneSample&  sample);

protected:
    std::vector<BaseOneSample*> _sample_buf;
};

}
}

#endif
