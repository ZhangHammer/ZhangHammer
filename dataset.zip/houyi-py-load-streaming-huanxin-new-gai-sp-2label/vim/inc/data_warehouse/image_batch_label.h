/**
 * image_batch_label.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_LABEL_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_LABEL_H
#include <utility>
#include <vector>
#include "base_batch_label.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
class ImageBatchLabel : public BaseBatchLabel {
    DISABLE_COPY_AND_ASSIGN(ImageBatchLabel);
private:
    ImageBatchLabel() = delete;
public:
    ImageBatchLabel(LabelType type, size_t batch_size, size_t label_dim):
        BaseBatchLabel(type, batch_size, label_dim) {
        _label.resize(Dim(batch_size, label_dim), false);
        _mask.resize(Dim(batch_size), false);
        _mask.set_element(1);
    }

    void resize(LabelType type, size_t batch_size, size_t label_dim) {
        _label_type = type;
        _batch_size = batch_size;
        _label_dim = label_dim;
        _label.resize(Dim(batch_size, label_dim), false);
        _mask.resize(Dim(batch_size), false);
        _mask.set_element(1);
    }

    virtual ~ImageBatchLabel() {
    }
};


}
}

#endif
