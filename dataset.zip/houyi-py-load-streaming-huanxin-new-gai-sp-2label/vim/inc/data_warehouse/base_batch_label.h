/**
 * base_batch_label.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_BATCH_LABEL_H
#define HOUYI_DATA_WAREHOUSE_BASE_BATCH_LABEL_H
#include <utility>
#include <vector>
#include "wind/wind.h"
#include "data_tool.h"
#include "util.h"

namespace houyi {
namespace train {

class BaseBatchLabel {
    DISABLE_COPY_AND_ASSIGN(BaseBatchLabel);
public:
    BaseBatchLabel(LabelType type, size_t batch_size, size_t label_dim) {
#ifndef __BUILD_PY_DATA_LOAD__
        _mask.set_device(cpu_pinned_device());
        _label.set_device(cpu_pinned_device());
#else
        _mask.set_device(cpu_device());
        _label.set_device(cpu_device());
#endif 
        _label_type = type;
        _batch_size = batch_size;
        _label_dim = label_dim;
    }

    virtual ~BaseBatchLabel() {}

    LabelType get_label_type() {
        return _label_type;
    }

    size_t get_batch_size() {
        return _batch_size;
    }

    inline size_t get_label_dim() {
        return _label_dim;
    }

    inline Tensor<int>& get_mask() {
        return _mask;
    }

    inline Tensor<DType>& get_label() {
        return _label;
    }

    inline Tensor<int> get_mask(int idx) {
        return _mask.get_block(Dim(idx), Dim((idx + 1)));
    }

    Tensor<DType> get_label(size_t index) {
        Dim start(index, 0);
        Dim stop(index + 1, _label_dim);
        return _label.get_block(start, stop);
    }

    void set_label(Tensor<DType> &one_label, size_t index) {
        Dim start(index, 0);
        Dim stop(index + 1, _label_dim);
        _label.get_block(start, stop).copy_from(one_label);
    }

protected:
    LabelType _label_type;
    size_t _batch_size;
    size_t _label_dim;
    Tensor<int> _mask;
    Tensor<DType> _label;
};

}
}

#endif
