/**
 * base_one_label.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-11
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
//modify by zzxfl 2016.11.10
#ifndef HOUYI_DATA_WAREHOUSE_BASE_ONE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_BASE_ONE_LABEL_H
#include <utility>
#include <vector>
#include <sstream>
#include "data_tool.h"
#include "wind/wind.h"
#include "util.h"
#include "base_stream.h"

namespace houyi {
namespace train {

class BaseOneLabel {
private:
    BaseOneLabel() = delete;
public:
    BaseOneLabel(LabelType type, size_t label_dim) {
        _type = type;
        _label_dim = label_dim;
        _label.set_device(cpu_device());
    }

    virtual ~BaseOneLabel() {}

    LabelType get_label_type() {
        return _type;
    }

    size_t get_label_dim() {
        return _label_dim;
    }

    void set_label_dim(size_t label_dim) {
        _label_dim = label_dim;
    }

    Tensor<DType> get_label(int idx) {
        return _label.get_block(Dim(idx, 0), Dim(idx + 1, _label_dim));
    }
    
    inline Tensor<DType>& get_label() {
        return _label;
    }

    inline Tensor<DType>& get_label_tensor() {
        return _label;
    }

public:
    //virtual int read_label(std::ifstream &in_stream,
    //                       size_t st_position_in_byte, size_t size_in_byte) = 0;
    virtual int read_label(BaseStream&in_stream, size_t st_position_in_byte, size_t size_in_byte) = 0;

protected:
    LabelType _type;
    size_t _label_dim;
    Tensor<DType> _label;
    DISABLE_COPY_AND_ASSIGN(BaseOneLabel);
};

}
}

#endif
