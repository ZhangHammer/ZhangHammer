//by zhxfl 2017.12.23
#ifndef HOUYI_DATA_WAREHOUSE_WAKE_UP_EXTRACT_DATA_H
#define HOUYI_DATA_WAREHOUSE_WAKE_UP_EXTRACT_DATA_H

#include <queue>
#include <thread>
#include <mutex>
#include <string>
#include <vector>
#include <unordered_map>
#include "object_factory.h"
#include "base_extract_data.h"
#include "speech_one_sentence.h"
/*
 * 唤醒数据加载
 * 格式与默认的多特征多label格式有差异
 * 0) 任何一个数据文件都可能已经损坏?? 做安全检查：对train.lst做检查，过滤掉脏数据
 * 1) random shuffle
 */
namespace houyi {
namespace train {

struct DescInfo {
    std::string name;
    int speak_id;
    int feat_frame_beg;
    int label_frame_beg;
    int frame_len;
};
class WakeUpExtractData : public BaseExtractData {
private:
    DISABLE_COPY_AND_ASSIGN(WakeUpExtractData);
public:
    WakeUpExtractData(
        std::vector<std::pair<std::string, std::vector<std::string>>>& feature_list, 
        std::vector<std::pair<std::string, std::vector<std::string>>>& label_list,
        int file_cnt,
        int thread_num,
        int sample_random,
        std::string all_pair_path,
        std::string key_work_label_map,
        DType expand_radio,
        int wake_up_trans_type
    ) : BaseExtractData(feature_list, label_list, file_cnt, thread_num, sample_random),
    _all_pair_path(all_pair_path),
    _key_word_label_map(key_work_label_map),
    _expand_radio(expand_radio), 
    _wake_up_trans_type(wake_up_trans_type) {
        get_data_file_list();
        random_data_file_list();
        INTER_LOG("expand radio %f", _expand_radio);
        read_all_pair_vec();
        read_key_word_label_map();

        _feature_block_buff.resize(thread_num, NULL);
        _feature_mid_block_buff.resize(thread_num, NULL);

        _label_block_buff.resize(thread_num, NULL);
        _label_mid_block_buff.resize(thread_num, NULL);

        _max_cache_frame.resize(thread_num, 0);
        _max_cache_label_size.resize(thread_num, 0);

        _period_mean_tensor.resize(thread_num, Tensor<DType>{cpu_device()});
        
        if (_cache_desc_flag) {
            std::mutex mutex;

#pragma omp parallel for num_threads(24), schedule(dynamic)
            for (int i = 0; i < (int)_all_pair_vec.size(); i++) {
                if (_all_pair_vec[i].first == std::string("INVALID")) {
                    continue;
                }
                std::unordered_map<std::string, std::vector<DescInfo>> mm;
                cache_desc_file(i, mm);

                std::lock_guard<std::mutex> guard(mutex);
                _desc_cache.insert(mm.begin(), mm.end());
                INTER_LOG("read pair desc %d", i);
            }
        }
        memset(_trans_flag, 0, sizeof(_trans_flag));
        _trans_flag[30] = _trans_flag[31] = _trans_flag[32] = _trans_flag[99] = _trans_flag[100] = _trans_flag[101] = 1;
        _trans_flag[198] = _trans_flag[199] = _trans_flag[200] = 1;
        //支持256个文件 
        if (_cache_label_flag) {
            cache_label();
        }
    }
    virtual ~WakeUpExtractData() {
        for (auto ptr : _feature_block_buff) {
            if (ptr) {
                _mm_free(ptr);
            }
        }

        for (auto ptr : _feature_mid_block_buff) {
            if (ptr) {
                _mm_free(ptr);
            }
        }

        for (auto ptr : _label_block_buff) {
            if (ptr) {
                _mm_free(ptr);
            }
        }

        for (auto ptr : _label_mid_block_buff) {
            if (ptr) {
                _mm_free(ptr);
            }
        }
    }
private:
    //reading_samples已经读取好了，将对应数据转移到ready_sample
    virtual void move_sample() {
        sample_random(_reading_samples);
        for (auto sample : _reading_samples) {
            _ready_samples.push(sample);
        }
        _reading_samples.clear();
    }
    
    //从磁盘读取样本 
    virtual void read_sample(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer, int thread_id);

    inline void expand(std::vector<BaseOneSample*>& from, SpeechOneSentence* sample);

    void sample_random(std::vector<BaseOneSample*> & sample_vec);
    int trans(DType* align, DType* feat,
        int wrdid, int frame_num, int frame_dim,
        Tensor<DType>& predictor, 
        Tensor<DType>& label, 
        Tensor<DType>& period_mean_tensor);
    virtual void get_data_file_list();
    
private:
    void read_desc_file(std::string& feat_path, int desc_id, std::vector<DescInfo>& desc_info_vec);
    void cache_desc_file(int desc_id,
        std::unordered_map<std::string, std::vector<DescInfo>>& desc_cache);
    void read_key_word_label_map();
    void read_all_pair_vec();
    int get_feature_head(std::ifstream& feature_stream,
        DataType& data_type, int& tot_frame, int& frame_dim);
    SpeechOneSentence* trans1(
            DType* align, DType* feat, int wrdid, int frame_num,
            int frame_dim, DescInfo& desc_info,
            std::string& feature_key, std::string& label_key);
private:

    //缓冲描述文件
    std::unordered_map<std::string, std::vector<DescInfo> > _desc_cache;
    std::string _all_pair_path = "all_pair";
    std::vector<std::pair<std::string, std::string> > _all_pair_vec;

    //label 映射
    //唤醒的label是用speak_id标志的，-1,1分别是正负样本
    std::map<int, int> _id_map;
    std::string _key_word_label_map = "kwd-label-map";

    float _expand_radio = 1.0f;

private:
    //磁盘读取的临时空间
    std::vector<DType*> _feature_block_buff;
    std::vector<short*> _feature_mid_block_buff;

    std::vector<DType*> _label_block_buff;
    std::vector<unsigned char*> _label_mid_block_buff;

    std::vector<int> _max_cache_frame;
    std::vector<int> _max_cache_label_size;
    std::vector<Tensor<DType> > _period_mean_tensor;

    bool _trans_flag[1000];
    int _frame_dim = 6720;
    bool _cache_desc_flag = false;
private:
    void cache_label();
    std::vector<Tensor<unsigned char> > _cache_label;
    bool _cache_label_flag = false;
    int _wake_up_trans_type = 0;
};
} // houyi
} // train

#endif 
