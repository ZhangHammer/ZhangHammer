/**
 * image_data_config.h
 *
 * Author: lifeng(madongepng@baidu.com)
 * Created on: 2016-07-04
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_READER_CONFIG_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_READER_CONFIG_H
#include <string>
#include <vector>
#include "parse_string.h"
#include "base_reader_config.h"

namespace houyi {
namespace train {

class ImageReaderConfig : public BaseReaderConfig {
public:
    ImageReaderConfig() : BaseReaderConfig() {
        init();
    }

    void parse_params(std::string &config_line);

    inline bool get_disk_cache() {
        return _disk_cache;
    }

    bool get_read_from_disk() {
        return _read_from_disk;
    }

    bool get_is_read_all_sample() {
        return _is_read_all_sample;
    }
    int get_split_image_sub_size() {
        return _split_image_sub_size;
    }
    int get_split_image_perturb() {
        return _split_image_perturb;
    }

    int get_is_control_label() {
        return _is_control_label;
    }

protected:
    void init() {
        _read_from_disk = 1;
        _is_read_all_sample = false;
        _split_image_perturb = -1;
        _split_image_sub_size = -1;
        _is_control_label = false;
        _disk_cache = false;
    }
private:
    bool _read_from_disk; //默认为1，表示从磁盘读取;0表示为区分度训练从内存中获取样本继续训练
    bool _is_read_all_sample; //是否将所有数据一次性加载到内存中
    bool _is_control_label; //唤醒训练控制正负样本的比例为1:1
    int _split_image_sub_size;//图像切分字句功能
    int _split_image_perturb;
    bool _disk_cache;//预取然后在解析，默认不打开
};

}
}

#endif
