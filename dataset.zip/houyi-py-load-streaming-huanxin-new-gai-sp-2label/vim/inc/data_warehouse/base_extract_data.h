//by zhxfl 2017.12.20
#ifndef HOUYI_DATA_WAREHOUSE_BASE_EXTRACT_DATA_H
#define HOUYI_DATA_WAREHOUSE_BASE_EXTRACT_DATA_H
#include <vector>
#include <thread>
#include <mutex>
#include <string>
#include <map>
#include <tuple>
#include <queue>
#include <thread>
#include "message_queue.h"

#include "util.h"
#include "base_one_sample.h"

namespace houyi {
namespace train {

/*
 * 负责异步从磁盘中读取数据，双buffer
 * 打乱列表
 */
class BaseExtractData {
    DISABLE_COPY_AND_ASSIGN(BaseExtractData);
public:
    BaseExtractData(
        std::vector<std::pair<std::string, std::vector<std::string>>> & feature_list,
        std::vector<std::pair<std::string, std::vector<std::string>>> & label_list,
        int file_cnt, 
        int thread_num,
        bool sample_random) : 
        _feature_list(feature_list),
        _label_list(label_list),
        _file_cnt(file_cnt),
        _thread_num(thread_num),
        _sample_random(sample_random) {
        if (_sample_random == false) {
            _thread_num = 1;
        }
#ifdef __CLOSE_RANDOM__
        _thread_num = 1;
        _file_cnt = 1;
#endif
        get_data_file_list();
        _message_vector_sample.set_max_length(_file_cnt * 2);
    }
    virtual~BaseExtractData() {
        for (int i = 0; i < (int)_threads.size(); i++) {
            if (_threads[i].joinable()) {
                _threads[i].join();
            }
        }
    }
    void reset() {
        _stop = false;
        _next_file_load_idx = 0;
        random_data_file_list();
        CHECK2(_consumer.size() == 0);
        for (int i = 0; i < (int)_threads.size(); i++) {
            if (_threads[i].joinable()) {
                _threads[i].join();
            }
        }
        _threads.clear();
    }
    
    /*中英文混合训练，列表不等长*/
    void stop() {
        _stop = true;
        // 消费完所有缓冲数据
        while (_next_file_load_idx < (int)_train_data_file_vec.size()) {
            std::vector<BaseOneSample*> buffer = _message_vector_sample.pop();
            _next_file_load_idx += 1;
            for (auto& s : buffer) {
                delete s;
            }
        }
    }
    virtual void extract_data(std::vector<BaseOneSample*>& samples, int sent_num);
    virtual void extract_all_data(std::vector<BaseOneSample*>& samples) {
        CHECK(false, "Not implemented");
    }

    void random_data_file_list();
    inline size_t get_data_file_num() {
        return _train_data_file_vec.size();
    }
    inline void set_data_file_num(int file_cnt) {
        if (file_cnt <= 0) {
            file_cnt = 1;
        }
        else {
            _file_cnt = file_cnt;
        }
    }
    void inter_extract_data(int thread_id);
protected:
    //从磁盘读取样本 
    virtual void read_sample(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer, int thread_id) = 0;
    virtual void move_sample() = 0;
    void start_thread();
    
    void balance_multi_sample_set();

protected:
    std::mutex _mutex;
    //max frame in one sentence, for split sentence
    //加载训练数据的文件列表
    /*
     * bref
     * map -> key : (feature name) or (label name)
     * tuple -> 1) bool:is feature or label
     *          2) std::string:feature data file or label data file
     *          3) std::string:feature desc file or label desc file
    ¦*/
    std::vector<std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > > _train_data_file_vec;
    MessageQueue<int> _consumer;
    MessageQueue<std::vector<BaseOneSample*>> _message_vector_sample;
    std::vector<std::thread> _threads;
    std::vector<size_t> _num_block_per_set;

    // 多线程读取磁盘，默认值为4
    std::vector<std::pair<std::string, std::vector<std::string>>> _feature_list;
    std::vector<std::pair<std::string, std::vector<std::string>>> _label_list;

    //双buffer,ready表示准备好的数据，reading表示正在读取的数据
    std::queue<BaseOneSample*> _ready_samples;
    std::vector<BaseOneSample*> _reading_samples;

    int _file_cnt = 1;
    int _thread_num = 4;
    int _next_file_load_idx = 0;
    bool _sample_random = true;
    // 让所有线程退出，清理所有缓冲
    bool _stop = false;
private:
    virtual void get_data_file_list();
};

} // namespace houyi
} // namespace train
#endif 
