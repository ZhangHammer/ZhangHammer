//by zzxfl 2016.08.30
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_DATA_READER_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_DATA_READER_H
#include <utility>
#include <vector>
#include <queue>
#include "wind/wind.h"
#include "data_tool.h"
#include "speech_one_sentence.h"
#include "speech_batch_label.h"
#include "base_data_reader.h"
#include "speech_reader_config.h"
#include "speech_one_label.h"
#include "base_extract_data.h"
#include "barrier.h"
#include <thread>
#include <mutex>

namespace houyi {
namespace train {
/*
 * 数据读取并且装换成sample由BaseExtractData负责
 * 本对象负责获得sample list之后需要进行个处理：
 * 1) 中英文混合训练逻辑控制
*/

class SpeechDataReader : public BaseDataReader {
    DISABLE_COPY_AND_ASSIGN(SpeechDataReader);
public:
    SpeechDataReader(BaseReaderConfig&cfg);

    virtual ~SpeechDataReader();
    virtual size_t get_samples_from_reader(std::vector<BaseOneSample*>& samples, int max_num);
    void reset();
    virtual void push_batch_to_reader(Tensor<DType>* feature, Tensor<DType>* label) {
        INTER_CHECK(false, "no implemented interface");
    };

    virtual size_t get_all_samples_from_reader(std::vector<BaseOneSample*>& samples) override;

private:
    void move_sample_to_queue(std::vector<BaseOneSample *> &sample_vector, std::queue<BaseOneSample*> &sample_queue);
    void random_data_file_list();
private:
    SpeechReaderConfig* _speech_cfg;
    bool _sample_random = true;
    // 支持多种类的数据输入，对应多loss网络
    // 目前支持中英文混合训练
    bool _multi_species_data = false;
    //中英文混合训练时，数据的比例
    std::vector<float> _file_cnt_ratio;
    //多种不同的数据异步读取
    std::vector<BaseExtractData*> _extract_data_runtime;
    SpeechExtractType _extract_type = EXTRACT_SPEECH;
    std::mutex _read_mutex;
    std::shared_ptr<Barrier> _barrier;
    // 数据加载负载均衡
    bool _balance = false;
};

}//houyi
}//train

#endif
