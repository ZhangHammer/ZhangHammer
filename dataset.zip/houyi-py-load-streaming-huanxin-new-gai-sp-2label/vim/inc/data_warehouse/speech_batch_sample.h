//by zzxfl 2016.09.05
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_SAMPLE_H
#include <utility>
#include <vector>
#include "speech_batch_label.h"
#include "base_batch_sample.h"
#include "wind/wind.h"
#include "speech_batch_desc.h"
#include "speech_batch_feature.h"
#include <map>
#include <atomic>
#include "image_utils.h"
namespace houyi {
namespace train {

class SpeechBatchSample: public BaseBatchSample {
    DISABLE_COPY_AND_ASSIGN(SpeechBatchSample);
public:
    using ParamFeatureT = std::map<FeatureKeyT, std::tuple<DataType, FrameNumT, FrameDimT> >;
    using ParamLabelT = std::map<LabelKeyT, std::tuple<LabelType, FrameNumT, LabelDimT> >;
public:
    virtual ~ SpeechBatchSample();

    SpeechBatchSample(int batch_size,
                      ParamFeatureT features,
                      ParamLabelT labels);

    void resize(int batch_size,
            ParamFeatureT features,
            ParamLabelT labels);

    void show(int id) {
        char str_id[10];
        sprintf(str_id, "%d_feature", id);
        write_tensor(get_feature_tensor(_feature_keys[0]), str_id), 
        sprintf(str_id, "%d_label", id);
        write_tensor(get_label_tensor(_label_keys[0]), str_id);
    }

    void clear_frame(int pos);
    void clear();
    int get_frame_num(std::string key) {
        //label
        if (_labels.find(key) != _labels.end()) {
            SpeechBatchLabel* label = dynamic_cast<SpeechBatchLabel*>(_labels[key]);
            return label->get_frame_num();
        }
        //feature
        if (_features.find(key) != _features.end()) {
            SpeechBatchFeature* feature = dynamic_cast<SpeechBatchFeature*>(_features[key]);
            return feature->get_frame_num();
        }
        CHECK2(false);
        return 0;
    }

    void set_frame_num(std::string key, int frame_num) {
        //label
        if (_labels.find(key) != _labels.end()) {
            SpeechBatchLabel* label = dynamic_cast<SpeechBatchLabel*>(_labels[key]);
            label->set_frame_num(frame_num);
            return;
        }

        //feature
        if (_features.find(key) != _features.end()) {
            SpeechBatchFeature* feature = dynamic_cast<SpeechBatchFeature*>(_features[key]);
            feature->set_frame_num(frame_num);
            return;
        }
        CHECK2(false);
    }

    int get_frame_dim(std::string key) {
        if (_features.find(key) != _features.end()) {
            SpeechBatchFeature* feature = dynamic_cast<SpeechBatchFeature*>(_features[key]);
            return feature->get_frame_dim();
        }
        CHECK2(false);
        return 0;
    }
};//SpeechBatchSample
}//houyi
}//train


#endif
