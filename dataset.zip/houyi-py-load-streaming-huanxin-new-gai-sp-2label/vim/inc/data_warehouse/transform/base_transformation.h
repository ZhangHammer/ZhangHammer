//by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_BASE_TRANSFORMATION_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_BASE_TRANSFORMATION_H

#include "image_utils.h"

#include "wind/wind.h"
#include <vector>
#include <thread>
#include <mutex>
#include <set>
namespace houyi {
namespace train {

class BaseOneSample;

class BaseTransformation {
public:
    virtual int perform_trans(BaseOneSample &data_pack) = 0;
    virtual void read_data(std::string &config_line) = 0;

    static BaseTransformation* new_trans_of_type(const std::string &type);
    static BaseTransformation* read(std::string &config_line);
    /*
     *bref
     * 如果_keys 为空，对所有feature或者label都进行处理
     * 如果不为空，则对相应的feature或者label进行处理
     *
     */
    inline bool has_key(std::string key) {
        if (_keys.size() == 0) {
            return true;
        }
        if (_keys.find(key) != _keys.end()) {
            return true;
        }
        return false;
    }

    void read_keys(std::string&);

    virtual ~BaseTransformation() {}
protected:
    std::set<std::string>_keys;//记录为label key, feature key
};
}
}
#endif
