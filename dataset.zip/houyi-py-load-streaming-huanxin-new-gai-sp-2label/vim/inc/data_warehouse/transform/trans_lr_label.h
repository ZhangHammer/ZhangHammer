//by zzxfl 2018.05.10
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_LR_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_LR_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransLrLabel : public BaseTransformation {
public:
    TransLrLabel() : BaseTransformation() {
        _label.set_device(cpu_device());
    }
    ~TransLrLabel() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _class_num = -1;
    Tensor<DType> _label;
    std::vector<std::vector<int>> _mask;
};
}
}

#endif
