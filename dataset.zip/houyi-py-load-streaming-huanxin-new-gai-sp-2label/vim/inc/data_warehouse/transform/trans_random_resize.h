// by zzxfl 2017.01.07
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_RANDOM_RESIZE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_RANDOM_RESIZE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
class TransRandomResize: public BaseTransformation {
public:
    TransRandomResize() : BaseTransformation() {
    }

    ~TransRandomResize() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _resize_width;
    int _resize_height;
};
#endif
}
}

#endif
