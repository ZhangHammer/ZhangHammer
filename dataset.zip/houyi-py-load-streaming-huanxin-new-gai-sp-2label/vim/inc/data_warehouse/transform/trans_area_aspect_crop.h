// by zzxfl 2017.01.06
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_AREA_ASPECT_CROP_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_AREA_ASPECT_CROP_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

/*
说明：按照面积比例和长宽比例裁剪
<Transform>
¦   type = areaAspectCrop
¦   areaRatio = 0.8: 1.0
¦   aspectRatio = 0.75 : 1.33
</Transform>
 */
namespace houyi {
namespace train {

class TransAreaAspectCrop: public BaseTransformation {
public:
    TransAreaAspectCrop() : BaseTransformation() {
    }

    ~TransAreaAspectCrop() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    std::vector<float> _aspect_ratio;//[3/4,4/3]
    std::vector<float> _area_ratio; //[0.08, 1.0]
    Tensor<DType> _tmp{cpu_device()};
};
}
}

#endif
