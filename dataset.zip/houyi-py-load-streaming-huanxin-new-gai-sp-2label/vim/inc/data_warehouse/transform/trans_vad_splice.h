//by zzxfl 2018.05.10
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_SPLICE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_SPLICE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransVadSplice : public BaseTransformation {
public:
    TransVadSplice() : BaseTransformation(),
        _left_context(5),
        _right_context(5) {
            _mat.set_device(cpu_device());
            _label.set_device(cpu_device());
        }
    ~TransVadSplice() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);

private:
    int _left_context;
    int _right_context;
    bool _use_head = false;
    Tensor<DType>_mat;
    Tensor<DType>_label;
};
} // houyi
} // train

#endif
