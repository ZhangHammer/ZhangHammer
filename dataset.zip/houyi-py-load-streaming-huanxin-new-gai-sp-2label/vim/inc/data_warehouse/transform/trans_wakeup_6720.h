// by zhxfl 2017.12.24
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_WAKEUP_6720_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_WAKEUP_6720_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
#include <map>
namespace houyi {
namespace train {

class TransWakeup6720: public BaseTransformation {
public:
    TransWakeup6720();
    ~TransWakeup6720() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    void read_key_word_label_map();
private:
    int _frame_dim = 6720;
    Tensor<DType> _period_mean_tensor{cpu_device()};
    bool _flag[102];
    Tensor<DType> _predict{cpu_device()};
    //label 映射
    //唤醒的label是用speak_id标志的，-1,1分别是正负样本
    std::map<int, int> _id_map;
    std::string _key_word_label_map = "kwd-label-map";
    
};
}
}

#endif
