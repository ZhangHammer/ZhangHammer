//by zzxfl 2017.03.20
//bref 针对faster rcnn的翻转，labels是多个物体的坐标，翻转时坐标也需要进行翻转
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_FASTER_RCNN_FLIP_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_FASTER_RCNN_FLIP_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransFasterRcnnFlip: public BaseTransformation {
public:
    TransFasterRcnnFlip() : BaseTransformation() {
    }

    ~TransFasterRcnnFlip() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
};

}
}

#endif
