//by zzxfl 2017.03.11
#ifndef HOUYI_DATA_WAREHOUSE_BASE_BATCH_TRANSFORMATION_H
#define HOUYI_DATA_WAREHOUSE_BASE_BATCH_TRANSFORMATION_H

#ifdef __WITH_OPENCV__
#include "opencv2/opencv.hpp"
#endif 

#include "wind/wind.h"
#include "base_batch_sample.h"
#include <vector>
#include <thread>
#include <mutex>
#include <set>
namespace houyi {
namespace train {

class BaseBatchTransformation {
public:
    virtual int perform_trans(BaseBatchSample& data_pack) = 0;
    virtual void read_data(std::string &config_line) = 0;

    static BaseBatchTransformation* new_trans_of_type(const std::string &type);
    static BaseBatchTransformation* read(std::string &config_line);
    /*
     *bref
     * 如果_keys 为空，对所有feature或者label都进行处理
     * 如果不为空，则对相应的feature或者label进行处理
     *
     */
    inline bool has_key(std::string key) {
        if (_keys.size() == 0) {
            return true;
        }
        if (_keys.find(key) != _keys.end()) {
            return true;
        }
        return false;
    }

    void read_keys(std::string&);

    virtual ~BaseBatchTransformation() {}
protected:
    std::set<std::string>_keys;//记录为label key, feature key
};
}
}

#endif
