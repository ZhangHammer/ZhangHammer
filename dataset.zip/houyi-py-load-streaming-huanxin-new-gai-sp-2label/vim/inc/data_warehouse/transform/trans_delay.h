//by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_DELAY_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_DELAY_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransDelay : public BaseTransformation {
public:
    TransDelay() : BaseTransformation(),
        _time(5) {
        _label_tmp.set_device(cpu_device());
    }
    ~TransDelay() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _time;
    Tensor<DType>_label_tmp;
};
}
}

#endif
