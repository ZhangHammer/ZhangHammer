// by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_CHANGE_BACKGROUND_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_CHANGE_BACKGROUND_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
#include "image_utils.h"
namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
/*
 * 支持机械臂更换背景的数据增强
 */
class TransChangeBackground: public BaseTransformation {
public :
    TransChangeBackground(): BaseTransformation() {
        _width = 640;
        _height = 480;
    }
    ~TransChangeBackground() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    void image_with_wave(cv::Mat& input, cv::Mat& output);
    bool change_background(cv::Mat& src, std::vector<cv::Mat>& bgimg, cv::Mat& sink);
    void load_bg();

private:
    std::string _claw_path;
    std::string _bg_path;
    std::vector<cv::Mat>_bg_img;
    cv::Mat _claw;
    int _width, _height;
};
#endif 

}
}

#endif
