//by zzxfl 2017.05.18
/*bref
 * <Transform>
 *      type = TransBatchRandomSampling
 *      Step = 3:4
 *      Start = 0
 * </Transform>
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_RANDOM_SAMPLING_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_RANDOM_SAMPLING_H
#include "base_batch_transformation.h"
#include "wind/wind.h"
#include "base_batch_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransBatchRandomSampling: public BaseBatchTransformation {
public:
    TransBatchRandomSampling() : BaseBatchTransformation() { }
    ~TransBatchRandomSampling() { }
    virtual int perform_trans(BaseBatchSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _start;
    std::vector<int> _step;
    Tensor<DType>_mat {cpu_device()};
    Tensor<int>_mask {cpu_device()};
    Tensor<DType>_label{cpu_device()};
};
}
}

#endif
