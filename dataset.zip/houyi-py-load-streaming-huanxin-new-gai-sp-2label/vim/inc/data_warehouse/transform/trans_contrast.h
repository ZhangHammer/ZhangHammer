//by zzxfl 2017.05.10
//according to https://github.com/zzxfl/fb.resnet.torch/blob/master/datasets/transforms.lua
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_CONTRAST_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_CONTRAST_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref 明暗对比度
 * 配置表说明：
 * <Transform>
 *      type = contrast
 *      contrast = 0.4
 * </Transform>
 */

class TransContrast : public BaseTransformation {
public:
    TransContrast() : BaseTransformation(), _gray(Dim(1, 1, 1),
                cpu_device()) {
    }

    ~TransContrast() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
    void gray_scale(Tensor<DType>& img);
    void blend(Tensor<DType>& img1, Tensor<DType>& img2, float alpha);
private:
    Tensor<DType>_gray;
    float _constrast;
};
}
}

#endif
