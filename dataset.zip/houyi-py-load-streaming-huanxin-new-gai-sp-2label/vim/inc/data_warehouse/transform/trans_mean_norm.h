//by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MEAN_NORM_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MEAN_NORM_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransMeanNorm : public BaseTransformation {
public:
    TransMeanNorm() : BaseTransformation() {
        _height = 0;
        _width = 0;
        _channel = 0;
        _mean = NULL;
    }

    ~TransMeanNorm() {
        if (_mean) {
            delete _mean;
        }
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<float>* _mean;

    size_t _height;
    size_t _width;
    size_t _channel;
};
}
}

#endif
