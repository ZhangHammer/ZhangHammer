// by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_ADD_DELTAS_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_ADD_DELTAS_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*
# KeepAdditional=true的时候，逻辑和老平台保持一致
# 前后补上去的五帧留着给transSplice用
<Transform>
    type = AddDeltas
    DeltaOrder = 2
    DeltaWindow = 2
    KeepAdditional = false
</Transform>

TODO:二阶差分没有补帧,对应的位置都是0
*/

class TransAddDeltas : public BaseTransformation {
public:
    TransAddDeltas() : BaseTransformation(),
        _order(2),  _window(2) { }
    ~TransAddDeltas() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);

private:
    //DeltaFeaturesOptions opts_;
    int _order;
    int _window; // e.g. 2; controls window size (window size is 2*window + 1)
    // the behavior at the edges is to replicate the first or last frame.
    // this is not configurable.
    bool _keep_additional = false;
    Tensor<DType>_mat {cpu_device()};
};
}
}

#endif
