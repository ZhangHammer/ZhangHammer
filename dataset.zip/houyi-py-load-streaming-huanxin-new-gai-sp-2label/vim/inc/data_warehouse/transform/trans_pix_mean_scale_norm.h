//by longfei 2017.05.22
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PIX_MEAN_SCALE_NORM_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PIX_MEAN_SCALE_NORM_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref 三通道各有一个均值 或者 灰度通道只有一个均值;Scale为一个浮点数
 * 配置表说明：
 * <Transform>
 *      type = pixMeanScaleNorm
 *      Stats = 102.9801:115.9465:122.7717 // Stats = 128
 *      Scale = 0.0078125
 * </Transfrom>
 */

class TransPixMeanScaleNorm : public BaseTransformation {
public:
    TransPixMeanScaleNorm() : BaseTransformation() {
        _mean.set_device(CPU);
    }

    ~TransPixMeanScaleNorm() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _mean;
    DType _scale;
};
}
}

#endif
