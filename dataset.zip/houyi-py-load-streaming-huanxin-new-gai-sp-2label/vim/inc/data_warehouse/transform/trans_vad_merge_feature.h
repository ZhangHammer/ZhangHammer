// by zhxfl 2018.05.17
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MERGE_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MERGE_FEATURE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
#include <map>
namespace houyi {
namespace train {
//
//将两个特征合并成一个特征
//
class TransVadMergeFeature: public BaseTransformation {
public:
    TransVadMergeFeature();
    ~TransVadMergeFeature() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    //最后的特征名
    std::string _feature_name;
    Tensor<DType> _feature;
};

} // train
} // houyi

#endif
