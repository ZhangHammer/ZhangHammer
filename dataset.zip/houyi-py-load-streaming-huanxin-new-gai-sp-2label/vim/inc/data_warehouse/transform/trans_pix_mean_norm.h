//by zzxfl 2017.03.02
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PIX_MEAN_NORM_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PIX_MEAN_NORM_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref rbg三个通道各有一个均值
 * 配置表说明：
 * <Transform>
 *      type = pixMeanNorm
 *      Stats = 102.9801:115.9465:122.7717
 * </Transfrom>
 */

class TransPixMeanNorm : public BaseTransformation {
public:
    TransPixMeanNorm() : BaseTransformation(), _mean(Dim(3, 1), cpu_device()) {
    }

    ~TransPixMeanNorm() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType>_mean;
};
}
}

#endif
