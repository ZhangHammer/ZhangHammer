// by longfei 2017.5.22
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BBOX_AFFINE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BBOX_AFFINE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__
class TransBboxAffine: public BaseTransformation {
public:
    TransBboxAffine() : BaseTransformation() {
    }

    ~TransBboxAffine() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    std::vector<float> _angle_range;
    float _margin_ratio;
    int _new_size;
    std::string _bbox_key;
};
#endif
}
}

#endif
