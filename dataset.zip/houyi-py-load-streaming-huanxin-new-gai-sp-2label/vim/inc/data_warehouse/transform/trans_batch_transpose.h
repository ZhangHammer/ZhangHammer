//by zzxfl 2017.04.10
/*bref
 * <Transform>
 *      type = TransBatchTranspose
 *      Reshape = -1: 11 : 3 : 80
 *      Transpose = 0: 2 : 1 : 3
 * </Transform>
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_TRANSPOSE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_TRANSPOSE_H
#include "base_batch_transformation.h"
#include "wind/wind.h"
#include "base_batch_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransBatchTranspose: public BaseBatchTransformation {
public:
    TransBatchTranspose() : BaseBatchTransformation() { }
    ~TransBatchTranspose() { }
    virtual int perform_trans(BaseBatchSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    std::vector<int>_reshape;
    std::vector<int>_transpose;
    Tensor<DType>_tmp{cpu_device()};
};
}
}

#endif
