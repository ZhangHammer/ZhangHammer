// by zzxfl 2018.05.29
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MEAN_VARIANCE_NORM_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MEAN_VARIANCE_NORM_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransVadMeanVarianceNorm : public BaseTransformation {
public:
    TransVadMeanVarianceNorm() : BaseTransformation() { }
    ~TransVadMeanVarianceNorm() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _mean{cpu_device()};
    Tensor<DType> _std_inv_var{cpu_device()};
    std::string _feature_name;
};
}
}

#endif
