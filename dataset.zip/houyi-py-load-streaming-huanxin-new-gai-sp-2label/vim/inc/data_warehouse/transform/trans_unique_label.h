/**
 * trans_unique_label.h
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-07-02
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransUniqueLabel : public BaseTransformation {
public:
    TransUniqueLabel() : BaseTransformation() {
        _label_data.set_device(cpu_device());

    }
    ~TransUniqueLabel() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    int _blank_id;
    // std::string _new_label_name;
};

}
}

#endif
