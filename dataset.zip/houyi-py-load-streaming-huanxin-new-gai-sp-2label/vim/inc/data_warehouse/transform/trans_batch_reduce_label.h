
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_REDUCE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_REDUCE_LABEL_H
#include "base_batch_transformation.h"
#include "wind/wind.h"
#include "base_batch_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransBatchReduceLabel: public BaseBatchTransformation {
public:
    TransBatchReduceLabel() : BaseBatchTransformation() { }
    ~TransBatchReduceLabel() { }
    virtual int perform_trans(BaseBatchSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    std::vector<int>_reshape;
    std::vector<int>_transpose;
    Tensor<DType>_tmp_label{cpu_device()};
    Tensor<int>_tmp_mask{cpu_device()};
};
}
}

#endif
