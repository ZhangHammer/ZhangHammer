//by zzxfl 2017.03.11
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_RESHAPE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BATCH_RESHAPE_H
#include "base_batch_transformation.h"
#include "wind/wind.h"
#include "base_batch_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransBatchReshape : public BaseBatchTransformation {
public:
    TransBatchReshape() : BaseBatchTransformation() { }
    ~TransBatchReshape() { }
    virtual int perform_trans(BaseBatchSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    std::vector<int>_dim;
};
}
}

#endif
