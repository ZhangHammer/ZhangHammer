// by zhxfl 2018.05.17
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MEAN_MUTE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_VAD_MEAN_MUTE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
#include <map>
namespace houyi {
namespace train {
//
// 唤醒vad使用
// 0是头静音，1是中间静音，2是尾静音，3是语音
//
class TransVadMeanMute: public BaseTransformation {
public:
    TransVadMeanMute();
    ~TransVadMeanMute() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _mute_mean;
    std::string _feature_name;
    float _ratio = 1.0;
    int _label_id = 0;
};

} // train
} // houyi

#endif
