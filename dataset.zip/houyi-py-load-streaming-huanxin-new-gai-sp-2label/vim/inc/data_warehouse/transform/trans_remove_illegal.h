// by zzxfl 2018.06.07
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_REMOVE_ILLEGAL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_REMOVE_ILLEGAL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransRemoveIllegal : public BaseTransformation {
public:
    TransRemoveIllegal() : BaseTransformation() {
        _label.set_device(cpu_device());
        _feature.set_device(cpu_device());
    }
    ~TransRemoveIllegal() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _label_idx = -1;
    Tensor<DType> _label;
    Tensor<DType> _feature;
};
}
}

#endif
