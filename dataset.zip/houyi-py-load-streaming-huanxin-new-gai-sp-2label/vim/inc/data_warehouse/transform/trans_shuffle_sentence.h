// by zzxfl 2017.04.11
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SHUFFLE_SENTENCE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SHUFFLE_SENTENCE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransShuffleSentence : public BaseTransformation {
public:
    TransShuffleSentence() : BaseTransformation() {
        _swap_feature.set_device(cpu_device());
        _swap_label.set_device(cpu_device());
    }
    ~TransShuffleSentence() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _swap_feature; 
    Tensor<DType> _swap_label;
    int _edge_id = -1; 
};
}
}

#endif
