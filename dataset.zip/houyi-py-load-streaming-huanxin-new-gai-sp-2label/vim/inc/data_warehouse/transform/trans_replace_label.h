// by zzxfl 2018.01.03
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_REPLACE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_REPLACE_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransReplaceLabel : public BaseTransformation {
public:
    TransReplaceLabel() : BaseTransformation() {
    }
    ~TransReplaceLabel() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _from_label;
    int _to_label;
    std::vector<int> _replace_label;
};
}
}

#endif
