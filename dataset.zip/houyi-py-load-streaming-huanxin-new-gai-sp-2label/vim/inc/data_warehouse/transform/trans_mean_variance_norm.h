// by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MEAN_VARIANCE_NORM_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MEAN_VARIANCE_NORM_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransMeanVarianceNorm : public BaseTransformation {
public:
    TransMeanVarianceNorm() : BaseTransformation() { }
    ~TransMeanVarianceNorm() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _mean{cpu_device()};
    Tensor<DType> _std_inv_var{cpu_device()};
};
}
}

#endif
