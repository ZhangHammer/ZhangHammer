//by longfei 2017.06.08
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_IMAGE_CHANNEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_IMAGE_CHANNEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref 图像通道转换
 * 配置表说明：
 * <Transform>
 *      type = imagechannel
 *      channel = 1 // 3
 * </Transform>
 */

class TransImageChannel : public BaseTransformation {
public:
    TransImageChannel() : BaseTransformation() {
    }

    ~TransImageChannel() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    size_t _channel;
};
}
}

#endif
