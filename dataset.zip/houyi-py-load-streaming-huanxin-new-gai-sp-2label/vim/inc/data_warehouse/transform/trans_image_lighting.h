#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_IMAGE_LIGHTING_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_IMAGE_LIGHTING_H

#include "base_transformation.h"
#include "base_one_sample.h"

#include <string>
#include <vector>

#include <wind/wind.h>

namespace houyi {
namespace train {
#ifdef __WITH_OPENCV__

class TransImageLighting : public BaseTransformation {
public:

    TransImageLighting() : BaseTransformation() {}

    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);

private:
    int _number_of_env;
    int _number_of_offset;
    // [env_map_num, number_of_offset, cell_number, 3]
    Tensor<DType> _weight;
};
#endif

}   // namespace train
}   // namespace houyi

#endif
