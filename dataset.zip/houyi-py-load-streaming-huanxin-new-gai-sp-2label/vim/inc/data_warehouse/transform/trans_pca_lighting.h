//by zzxfl 2017.05.09
//AlexNet-style PCA-based nois
//according to https://github.com/zzxfl/fb.resnet.torch/blob/master/datasets/transforms.lua
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PCA_LIGHTING_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PCA_LIGHTING_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref rbg三个通道各有一个均值
 * 配置表说明：
 * <Transform>
 *      type = pcaLighting
 *      eigval = 0.2175:0.0188:0.0045
 *      eigvec =-0.5675:0.7192:0.4009:-0.5808:-0.0045:-0.8140:-0.5836:-0.6948:0.4203
 * </Transfrom>
 */

class TransPcaLighting : public BaseTransformation {
public:
    TransPcaLighting() : BaseTransformation(), _eigval(Dim(3, 1), cpu_device()),
        _eigvec(Dim(3, 3), cpu_device()), _distribution(0.0f, 0.1f) {
    }

    ~TransPcaLighting() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType>_eigval;
    Tensor<DType>_eigvec;
    std::default_random_engine _generator;
    std::normal_distribution<double> _distribution;

};
}
}

#endif
