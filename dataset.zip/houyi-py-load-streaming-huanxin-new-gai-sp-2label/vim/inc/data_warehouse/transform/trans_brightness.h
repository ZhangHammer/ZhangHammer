//by zzxfl 2017.05.10
//according to https://github.com/zzxfl/fb.resnet.torch/blob/master/datasets/transforms.lua
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BRIGHTNESS_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_BRIGHTNESS_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

/*bref 调节亮度
 * 配置表说明：
 * <Transform>
 *      type = brightness
 *      brightness = 0.4
 * </Transform>
 */

class TransBrightness : public BaseTransformation {
public:
    TransBrightness() : BaseTransformation() {
    }

    ~TransBrightness() {
    }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    float _brightness;
};
}
}

#endif
