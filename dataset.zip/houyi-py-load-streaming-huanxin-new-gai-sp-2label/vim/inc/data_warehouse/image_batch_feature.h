/**
 * image_batch_feature.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_FEATURE_H
#include <utility>
#include <vector>
#include "data_tool.h"
#include "base_batch_feature.h"

namespace houyi {
namespace train {

class ImageBatchFeature: public BaseBatchFeature {
    DISABLE_COPY_AND_ASSIGN(ImageBatchFeature);
public:
    ImageBatchFeature(DataType type,
                      size_t batch_size,
                      size_t channel,
                      size_t height,
                      size_t width): BaseBatchFeature(type, batch_size) {
        _height = height;
        _width = width;
        _channel = channel;
        _feature.resize(Dim(batch_size, channel, height, width), false);
        _mask.resize(Dim(batch_size), false);
        _mask.set_element(1);
    }
    
    void resize(DataType type,
            size_t batch_size,
            size_t channel,
            size_t height,
            size_t width) {
        BaseBatchFeature::resize(type, batch_size);
        _height = height;
        _width = width;
        _channel = channel;
        _feature.resize(Dim(batch_size, channel, height, width), false);
        _mask.resize(Dim(batch_size), false);
        _mask.set_element(1);
    }

    virtual ~ImageBatchFeature() {
    }

    void set_feature(Tensor<DType>&data, size_t idx) {
        Dim start(idx, 0, 0, 0);
        Dim stop(idx + 1, _channel, _height, _width);
        _feature.get_block(start, stop).copy_from(data);
    }

    Tensor<DType> get_feature(size_t idx) {
        Dim start(idx, 0, 0, 0);
        Dim stop(idx + 1, _channel, _height, _width);
        return _feature.get_block(start, stop);
    }

    size_t get_height() {
        return _height;
    }

    size_t get_width() {
        return _width;
    }

    size_t get_channel() {
        return _channel;
    }
private:
    size_t _height;
    size_t _width;
    size_t _channel;
};

}
}

#endif
