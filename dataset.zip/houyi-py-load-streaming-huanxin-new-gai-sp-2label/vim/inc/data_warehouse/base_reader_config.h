/*
 * base_reader_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-11
 *
 * Copyright (c) lifeng.com, Inc. All Rights Reserved
 *
 */

#ifndef HOUYI_DATA_WAREHOUSE_BASE_READER_CONFIG_H
#define HOUYI_DATA_WAREHOUSE_BASE_READER_CONFIG_H
#include <string>
#include <vector>
#include "parse_string.h"
#include <utility>
#include "data_tool.h"
#include "train_type.h"

namespace houyi {
namespace train {

class BaseReaderConfig {
public:
    BaseReaderConfig() {
        init();
    }
    BaseReaderConfig(DataType type) {
        init();
    }
    virtual ~BaseReaderConfig() {}
    static BaseReaderConfig* read(std::ifstream &input);
    
    /*公共部分的数据加载*/
    void parse_common_params(std::string &param_lines);

    virtual void parse_params(std::string &param_lines) = 0;
    void read_multi_feature_label(std::string&config_line);
    std::vector<std::pair<std::string, std::vector<std::string>> >& get_feat_list() {
        return _feature_list;
    }
    std::vector<std::pair<std::string, std::vector<std::string>> >& get_label_list() {
        return _label_list;
    }

    DataReaderType get_data_reader_type() {
        return _data_reader_type;
    }

    void set_data_reader_type(DataReaderType type) {
        _data_reader_type = type;
    }

    void set_device_num(int num) {
        _device_num = num;
    }

    void set_batch_size(int batch_size) {
        _batch_size = batch_size;
    }

    inline int get_batch_size() {
        return _batch_size;
    }

    void set_train_type(TrainType train_type) {
        _train_type = train_type;
    }
    
    inline TrainType get_train_type() {
        return _train_type;
    }

    int get_device_num() {
        return _device_num;
    }

    int get_multi_thread_read_disk() {
        return _mutil_thread_read_disk;
    }

    inline int get_load_block_num() {
        return _load_block_num;
    }

    //关闭样本随机
    inline bool get_sample_random() {
        return _sample_random;
    }

    inline bool get_balance() {
        return _balance;
    }

protected:
    void init() {
        /**从磁盘读取数据的线程数，默认是1*/
        _mutil_thread_read_disk = 1;
        _load_block_num = 10;
        _sample_random = true;
    }
protected:
    DataReaderType _data_reader_type; // PROC_SPEECH, PROC_IMAGE,
    bool _sample_random; // 控制样本随机，保证预测的顺序是对的
    int _device_num;//代表多少个卡进行训练
    /*
     * 功能：多线程读取磁盘
     * 原理：当数据放在cluster上，多线程有概率同时从本地磁盘和网络IO处获取数据,利用了两个IO设备
     */
    int _mutil_thread_read_disk;
    //每次从磁盘读取的数据块数目
    int _load_block_num;
    
    /*
     * 数据加载负载平衡需要的参数
     */
    // 数据加载的 batch_size
    int _batch_size = 32;
    bool _balance = false;

    TrainType _train_type;

    std::vector< std::pair<std::string, std::vector<std::string>> >_feature_list; // key name : path name
    std::vector< std::pair<std::string, std::vector<std::string>> >_label_list; //key name : path name
};

}
}

#endif
