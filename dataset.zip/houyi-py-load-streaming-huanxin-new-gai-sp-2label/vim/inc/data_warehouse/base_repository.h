/**
 * base_repository.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-05
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_REPOSITORY_H
#define HOUYI_DATA_WAREHOUSE_BASE_REPOSITORY_H
#include "message_queue.h"
#include "base_batch_transformation.h"
#include "thread.h"
#include "base_processer.h"
#include "base_repository_config.h"
#include "base_batch_sample.h"
#include "device_batch_sample.h"

namespace houyi {
namespace train {

class BaseRepository {
    DISABLE_COPY_AND_ASSIGN(BaseRepository);
public:
    BaseRepository() {
        init();
    }
    BaseRepository(BaseProcesser *proc, BaseReposConfig& cfg, int device_id):
        _device_id(device_id) {

        init();
        _data_processer = proc;
        _cfg = &cfg;
        _batch_size = cfg.get_batch_size();
        _new_batch_size = cfg.get_batch_size();

        _is_async = cfg.is_async();
        _laster_batch = false;
        _max_buf_num = cfg.get_max_buf_num();

        trans_read(1);
    }

    virtual void reset() {
        INTER_LOG("base_repository reset from GPU");

        if (_is_async) {
            thread_join();
            INTER_LOG("_batch_queue %d", (int)_batch_queue->size());
            while (_batch_queue->size()) {
                BaseBatchSample* bat = _batch_queue->pop();
                CHECK2(bat == NULL);
            }
            CHECK2(_batch_queue->size() == 0);
            if (_batch_queue && _batch_queue->size()) {
                _batch_queue->clean();
            }
            start_async_load();
        }

        _laster_batch = false;
    }

    void thread_join() {
        if (_async_buf_thread.joinable()) {
            _async_buf_thread.join();
        }
        if (_thread_device_batch.joinable()) {
            _thread_device_batch.join();
        }
    }

    inline void set_device_id(int device_id) {
#ifndef __BUILD_PY_DATA_LOAD__
        _device_id = device_id;
        wind_init(_device_id);
        wind_set_gpu_device(_device_id);
        int unused_device_batch_max_num = 1;
        _device_batch_queue.set_max_length(unused_device_batch_max_num);
        _unused_device_batch.set_max_length(unused_device_batch_max_num);
        // double buffer
        for (int i = 0; i < unused_device_batch_max_num; i++) {
            _unused_device_batch.push(new DeviceBatchSample());
        }
#endif
    }

    virtual ~BaseRepository() {
        if (_async_buf_thread.joinable()) {
            _async_buf_thread.join();
        }
        if (_batch_queue) {
            _batch_queue->clean();
            delete _batch_queue;
            _batch_queue = NULL;
        }
        while (_device_batch_queue.size()) {
            std::pair<BaseBatchSample*, DeviceBatchSample*> pair_batch =  _device_batch_queue.pop();
            delete pair_batch.second;
        }

        while (_unused_device_batch.size()) {
            DeviceBatchSample* sample = _unused_device_batch.pop();
            delete sample;
        }

        if (_thread_device_batch.joinable()) {
            _thread_device_batch.join();
        }
    }
    static BaseRepository* create(BaseProcesser *proc, BaseReposConfig& cfg, int device_id);

    virtual std::pair<BaseBatchSample*, DeviceBatchSample*> get_device_batch_from_repos();

    void perform_trans_stream(BaseBatchSample& batch, int idx);
    void trans_read(int thread_num);

    inline BaseProcesser* get_proccesser() {
        return _data_processer;
    }

    inline MessageQueue<BaseBatchSample* >* get_queue() {
        return _batch_queue;
    }

    void start_async_load();

    size_t get_batch_size() {
        return _batch_size;
    }
    void set_new_batch_size(size_t batch_size) {
        _new_batch_size = batch_size;
    }
    void recycle_device_batch_sample(DeviceBatchSample* device_batch) {
       _unused_device_batch.push(device_batch);
    }

private:
    void async_copy_to_device();

protected:
    virtual size_t inter_get_batch(std::vector<BaseBatchSample* >&batches, size_t max_num) = 0;
    void async_buf_load();

    void init() {
        _data_processer = NULL;
        _batch_queue = NULL;
        _laster_batch = false;

        _batch_size = 0;
        _new_batch_size = 0;
        _label_dim = 1;

        _is_async = true;
        _max_buf_num = 0;
        _laster_batch = false;

        _cfg = NULL;
        _batch_queue = NULL;
        
    }

protected:
    /*标志是否为最后一个batch,其最后一个sample是null*/
    bool _laster_batch;
    size_t _batch_size;
    size_t _new_batch_size;
    size_t _label_dim;
    int _device_id = 0;

    BaseReposConfig *_cfg = NULL;
    BaseProcesser *_data_processer = NULL;
    /*
     *  _async_buf_thread :
     *          负责构造bat
     *  _thread_device_batch : 
     *          负责将bat拷贝到gpu上
     *  _unused_device_batch_DeviceBatchSample:
     *          缓冲区，默认为2个，上层使用完
     *          通过recycle_device_batch_sample回收重用
     *
     */

    std::thread _async_buf_thread;
    MessageQueue<BaseBatchSample*>* _batch_queue = NULL;
    MessageQueue<std::pair<BaseBatchSample*, DeviceBatchSample*> > _device_batch_queue;
    MessageQueue<DeviceBatchSample*> _unused_device_batch;
    std::thread _thread_device_batch;

    bool _is_async;
    size_t _max_buf_num;
private:
    std::vector<std::vector<BaseBatchTransformation*> >_trans_stream;//全局变量，多个线程访问，使用需要加锁
};

}
}

#endif
