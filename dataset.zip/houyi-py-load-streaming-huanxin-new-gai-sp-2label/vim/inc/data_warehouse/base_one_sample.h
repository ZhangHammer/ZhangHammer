/**
 * base_one_sample.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-01
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_ONE_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_BASE_ONE_SAMPLE_H
#include <utility>
#include <vector>
#include <fstream>
#include <iostream>
#include <map>
#include "base_one_label.h"
#include "base_one_feature.h"
#include "data_tool.h"

namespace houyi {
namespace train {

class BaseOneSample {
public:
    BaseOneSample() {}
    BaseOneSample(std::map<std::string, std::string> file_name): _file_name(file_name) {
    }
    virtual ~BaseOneSample() {}
    //调试
    virtual void show() {}
//基类方法
public:
    inline void set_feature(std::string key, BaseOneFeature&data) {
        CHECK2(_features.find(key) != _features.end());
        delete _features[key];
        _features[key] = &data;
    }

    inline void insert_feature(std::string key, BaseOneFeature& data) {
        CHECK2(_features.find(key) == _features.end());
        _features[key] = &data;
        _feature_keys.push_back(key);
        _file_name[key] = key;
    }

    inline void set_feature_tensor(std::string key,  Tensor<DType>& feature) {
        CHECK2(_features.find(key) != _features.end());
        _features[key]->set_feature(feature);
    }
    inline Tensor<DType>&get_feature_tensor(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_feature();
    }
    inline size_t get_feature_size() {
        CHECK2(_feature_keys.size());
        return _features[_feature_keys[0]]->get_feature()._buffer->size();
    }
    inline void set_label(std::string key, BaseOneLabel& label) {
        CHECK2(_labels.find(key) != _labels.end());
        delete _labels[key];
        _labels[key] = &label;
    }
    inline int get_label_dim(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return _labels[key]->get_label_dim();
    }
    inline void set_label_dim(std::string key, int label_dim) {
        CHECK2(_labels.find(key) != _labels.end());
        _labels[key]->set_label_dim(label_dim);
    }

    inline BaseOneLabel& get_label(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return *_labels[key];
    }

    inline DataType get_data_type(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_feature_type();
    }
    
    inline LabelType get_label_type(std::string key) {
        CHECK2(_labels.find(key) !=_labels.end());
        return _labels[key]->get_label_type();
    }
    inline std::vector<std::string>& get_label_keys() {
        return _label_keys;
    }
    inline std::vector<std::string>& get_feature_keys() {
        return _feature_keys;
    }
    BaseOneFeature& get_feature(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return *_features[key];
    }
    DataType get_feature_type(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_feature_type();
    }

    inline Tensor<DType>& get_label_tensor(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return _labels[key]->get_label_tensor();
    }

    inline FeatureDescT get_file_name(std::string key) {
        CHECK2(_file_name.find(key) != _file_name.end());
        return _file_name[key];
    }

    inline std::string get_default_file_name() {
        CHECK2(_file_name.size() >= 1);
        return _file_name.begin()->second;
    }

    inline std::map<std::string, std::string>& get_file_name() {
        return _file_name;
    }

    inline void set_file_name(std::string key, std::string desc) {
        _file_name[key] = desc;
    }

    inline void rename(std::map<std::string, std::string> file_name, 
            std::vector<std::string> feature_key,
            std::vector<std::string> label_key) {
        _file_name = file_name;
        for (size_t i = 0; i < std::min(_feature_keys.size(), feature_key.size()); i++) {
            if (feature_key[i] != _feature_keys[i]) {
                BaseOneFeature* feature = _features[_feature_keys[i]];
                _features[feature_key[i]] = feature;
                _features.erase(_feature_keys[i]);
                _feature_keys[i] = feature_key[i];
            }
        }

        for (size_t i = 0; i < std::min(_label_keys.size(), label_key.size()); i++) {
            if (label_key[i] != _label_keys[i]) {
                BaseOneLabel* label = _labels[_label_keys[i]];
                _labels[label_key[i]] = label;
                _labels.erase(_label_keys[i]);
                _label_keys[i] = label_key[i];
            }
        }
    }
    //纯虚方法
public:
    virtual int read_feature(std::string key, BaseStream& in_stream, 
            size_t st_position_in_byte, size_t size_in_byte) = 0;
    virtual int read_label(std::string key, BaseStream& in_stream, 
            size_t st_position_in_byte, size_t size_in_type) = 0;
public:
    //图像接口
    virtual float get_scale(std::string key) {
        INTER_LOG("virtual get_scale is called");
        CHECK2(false);
        return 0.0;
    }
    virtual float get_default_scale(std::string key) {
        INTER_LOG("virtual get_default_scale is called");
        CHECK2(false);
        return 0.0;
    }
    virtual std::map<std::string, float>& get_scale() {
        INTER_LOG("virtual get_scale is called");
        CHECK2(false);
        std::map<std::string, float>* tmp = NULL;
        return *tmp;
    }
protected:
    std::map<std::string, BaseOneFeature* >_features;
    std::map<std::string, BaseOneLabel* >_labels;
    std::vector<std::string>_label_keys;
    std::vector<std::string>_feature_keys;
    std::map<std::string, std::string>_file_name;
};

}
}

#endif
