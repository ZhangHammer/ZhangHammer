//by zzxfl 2017.06.01
//对流进行封装，解压被zlib,snappy压缩过的数据
//测试结果显示：
//1) 语音数据压缩比：
//   snappy : 0.98
//   zlib   : 0.75
//
//2) 图像数据
//   snappy : 0.917
//   zlib   : 0.759  
#ifndef HOUYI_DATA_WAREHOUSE_BASE_STREAM_H
#define HOUYI_DATA_WAREHOUSE_BASE_STREAM_H
#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include "util.h"
namespace houyi {
namespace train {
//纯虚类
class BaseStream {
public:
    BaseStream() {}
    virtual ~BaseStream() {};
    virtual void seekg(std::streamoff off, std::ios_base::seekdir way) = 0;
    virtual void seekg(std::streampos pos) = 0;
    virtual std::streampos tellg() = 0;
    virtual void read (char* s, std::streamsize n) = 0;
    virtual void close() = 0;
    virtual void getline(char*s, std::streamsize n) = 0;
    virtual std::streamsize gcount() const = 0;
    virtual bool fail() = 0;
    virtual bool is_open() = 0;
};

class IfStream:public BaseStream {
    DISABLE_COPY_AND_ASSIGN(IfStream);
public:
    IfStream(const std::string& path);
    ~IfStream() {
        delete _is;
    }
    virtual void seekg(std::streamoff off, std::ios_base::seekdir way);
    virtual void seekg(std::streampos pos);
    virtual std::streampos tellg();
    virtual void read (char* s, std::streamsize n);
    virtual void close();
    virtual void getline(char*s, std::streamsize n);
    virtual std::streamsize gcount() const;
    virtual bool fail() {
        return _is->fail();
    }
    virtual bool is_open() {
        return _is->is_open();
    }
private:
    std::ifstream* _is;
};

class SnappyStream:public BaseStream {
    DISABLE_COPY_AND_ASSIGN(SnappyStream);
public:
    SnappyStream(std::string& str);
    ~SnappyStream();
    virtual void seekg(std::streamoff off, std::ios_base::seekdir way);
    virtual void seekg(std::streampos pos);
    virtual std::streampos tellg();
    virtual void read (char* s, std::streamsize n);
    virtual void close();
    virtual void getline(char*s, std::streamsize n);
    virtual std::streamsize gcount() const;
    virtual bool fail() {
        return _is.fail();
    }
    virtual bool is_open() {
        return true;
    }
public:
    std::stringstream _is;
    char*_buffer;
};

}
}

#endif
