//by zhxfl 2017.12.20
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_EXTRACT_DATA_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_EXTRACT_DATA_H

#include <queue>
#include <map>
#include "base_extract_data.h"
#include "speech_one_sentence.h"
/*
 * 负责异步从磁盘中读取数据，双buffer
 * 1) 切子句
 * 2) drop sentence
 * 3) replace label
 * 4) random shuffle
 */
namespace houyi {
namespace train {

class SpeechExtractData : public BaseExtractData {
    DISABLE_COPY_AND_ASSIGN(SpeechExtractData);
public:
    SpeechExtractData(
        std::vector<std::pair<std::string, std::vector<std::string>>>& feature_list, 
        std::vector<std::pair<std::string, std::vector<std::string>>>& label_list,
        int file_cnt,
        int thread_num,
        int sample_random,
        int split_sentence_threshold,
        int split_sentence_len,
        bool integrity,
        int drop_sentence_len,
        bool intersection,
        std::vector<int> replace_label,
        int batch_size,
        int device_num,
        bool balance,
        int slack,
        int random_group_size
    ) : BaseExtractData(feature_list, label_list, file_cnt, thread_num, sample_random),
        _split_sentence_threshold(split_sentence_threshold),
        _split_sentence_len(split_sentence_len),
        _integrity(integrity),
        _drop_sentence_len(drop_sentence_len),
        _intersection(intersection),
        _replace_label(replace_label),
        _batch_size(batch_size),
        _device_num(device_num),
        _balance(balance),
        _slack(slack), 
        _random_group_size(random_group_size) {
    }
    virtual ~ SpeechExtractData() {
    }

    virtual void extract_all_data(std::vector<BaseOneSample*>& samples) override;

private:
    //reading_samples已经读取好了，将对应数据转移到ready_sample
    virtual void move_sample() {
        if (_reading_samples.size() == 0) {
            return;
        }
        if (_balance) { 
            CHECK2(_batch_size * _device_num > 0);
            int total_sample_count = _reading_samples.size() % (_batch_size * _device_num);
            int remain_count = (_batch_size * _device_num) - total_sample_count;
            std::vector<BaseOneSample*> vec; 
            for (int i = 0; i < remain_count; ++i) {
                int rand_num = rand() % _reading_samples.size();
                SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(_reading_samples[rand_num]);
                SpeechOneSentence* clone_sent = new SpeechOneSentence(*sent);
                vec.push_back(clone_sent);
            } 
            
            for (auto& s : vec) {
                _reading_samples.push_back(s);
            } 

            sample_random(_reading_samples,
                    _batch_size * _device_num);
            INTER_LOG("random batch_size %d", _batch_size * _device_num);
        } else { 
            if (_random_group_size == -1) {
                _device_num = 1;
                CHECK2(_batch_size * _device_num > 0);
                int total_sample_count = _reading_samples.size() % (_batch_size * _device_num);
                if (total_sample_count) {
                    int remain_count = (_batch_size * _device_num) - total_sample_count;
                    std::vector<BaseOneSample*> vec; 
                    for (int i = 0; i < remain_count; ++i) {
                        int rand_num = rand() % _reading_samples.size();
                        SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(_reading_samples[rand_num]);
                        SpeechOneSentence* clone_sent = new SpeechOneSentence(*sent);
                        vec.push_back(clone_sent);
                    } 

                    for (auto& s : vec) {
                        _reading_samples.push_back(s);
                    } 
                }
                sample_random(_reading_samples,
                        _batch_size * _device_num);
                INTER_LOG("random batch_size %d", _batch_size * _device_num);
            }
            else {
                int total_sample_count = _reading_samples.size() % (_random_group_size);
                if (total_sample_count) {
                    int remain_count = (_random_group_size) - total_sample_count;
                    std::vector<BaseOneSample*> vec; 
                    for (int i = 0; i < remain_count; ++i) {
                        int rand_num = rand() % _reading_samples.size();
                        SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(_reading_samples[rand_num]);
                        SpeechOneSentence* clone_sent = new SpeechOneSentence(*sent);
                        vec.push_back(clone_sent);
                    } 

                    for (auto& s : vec) {
                        _reading_samples.push_back(s);
                    } 
                }
                sample_random(_reading_samples,
                        _random_group_size);
                INTER_LOG("random batch_size %d", _random_group_size);
            }
        }
#ifdef __ENABLE_NCCL__
        CHECK2(_batch_size * _device_num > 0);
        // epoch即将结束，保证总样本数是_batch_size * _device_num的倍数
        if (_next_file_load_idx >= (int)_train_data_file_vec.size()) {
            _total_sample_count += _reading_samples.size();
            _total_sample_count %= (_batch_size * _device_num);
            int remain_count = (_batch_size * _device_num) - _total_sample_count;
            
            for (int i = 0; i < remain_count; ++i) {
                int rand_num = rand() % _reading_samples.size();
                SpeechOneSentence* sent = static_cast<SpeechOneSentence*>(_reading_samples[rand_num]);
                SpeechOneSentence* clone_sent = new SpeechOneSentence(*sent);
                _ready_samples.push(clone_sent);
            } 

            for (size_t i = 0; i < _reading_samples.size(); ++i) {
                _ready_samples.push(_reading_samples[i]); 
            }
            // 清零为下次做准备
            _total_sample_count = 0;
        }
        else {
            for (auto sample : _reading_samples) {
                _ready_samples.push(sample);
            }
            _total_sample_count += _reading_samples.size();
            _total_sample_count = _total_sample_count % (_batch_size * _device_num);
        }
#else
        for (auto sample : _reading_samples) {
            _ready_samples.push(sample);
        }
#endif
        _reading_samples.clear();
    }
    
    //从磁盘读取样本 
    virtual void read_sample(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer,
        int thread_id);
    
    // 校验每个数据描述文件中数据的长度,要求一致
    void read_sample_normal(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer,
        int thread_id);

    // 求每个描述文件中数据的交集（根据样例名字），构造交集sample
    void read_sample_intersection(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer,
        int thread_id);

    int get_intersection_name(
            std::map<std::string, std::vector<std::tuple<std::string, int, int, int, int, int>>>& desc_map);

    bool get_feature_desc_head(BaseStream& file_stream, FeatureDescHead &head);
    bool get_label_desc_head(BaseStream& file_stream, LabelDescHead &label);
    void sample_random(std::vector<BaseOneSample*> & sample_vec, int batch_size);
    void close_stream(std::map<std::string, std::tuple<bool, BaseStream*, BaseStream*> >& one_block_stream);
private:
    //切子句控制变量
    int _split_sentence_threshold = 512; // 句子超过这个长度就切子句，默认为512
    int _split_sentence_len = 256; // 切子句的基础长度
    bool _integrity = true; // 切子句时保持词完整性
    //drop sentence 
    int _drop_sentence_len = -1; // 丢掉长句
    bool _intersection = true; // 根据所有样例的交集构造sample

    //替换 label
    std::vector<int> _replace_label;

    // batch_size and device_num 负载均衡需要
    int _batch_size = 32;
    int _device_num = 1;
    bool _balance = false;
    int _slack = 0;
    int _random_group_size = -1;

    // 统计总的句子个数 
    int _total_sample_count = 0;
};
} // houyi
} // train

#endif 
