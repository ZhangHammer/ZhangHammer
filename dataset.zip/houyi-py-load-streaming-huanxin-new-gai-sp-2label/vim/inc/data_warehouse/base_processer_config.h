/**
 * base_processer_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-12
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_PROCESSER_CONFIG_H
#define HOUYI_DATA_WAREHOUSE_BASE_PROCESSER_CONFIG_H
#include <string>
#include <vector>
#include "parse_string.h"
#include "data_tool.h"

namespace houyi {
namespace train {

class BaseProcConfig {
public:
    BaseProcConfig() {
        _max_buf_num = 1000; // default
        _is_async = false;
        _thread_pool_num = 4; //default
        _trans_lines.clear();
    }

    virtual ~BaseProcConfig() {
        _trans_lines.clear();
    }

    BaseProcConfig& operator=(BaseProcConfig& cfgIn) {
        _is_async = cfgIn.is_async();
        _trans_lines.clear();
        for (size_t i = 0; i < cfgIn.get_trans_lines().size(); i++) {
            _trans_lines.push_back(cfgIn.get_trans_lines()[i]);
        }
        return *(this);
    }

    void parse_params(std::string &config_line);
    static BaseProcConfig* read(std::ifstream &input);

    inline std::vector<std::string> get_trans_lines() {
        return _trans_lines;
    }

    inline size_t get_max_buf_num() {
        return _max_buf_num;
    }
    inline void set_max_buf_num(size_t max_buf) {
        _max_buf_num = max_buf;
    }

    inline bool is_async() {
        return _is_async;
    }
    inline void set_async() {
        _is_async = true;
    }

    inline void set_device_num(int num) {
        _device_num = num;
    }

    inline int get_thread_pool_num() {
        return _thread_pool_num;
    }

    inline std::string get_type() const {
        return _type;
    }   

    inline int get_device_num() const {
        return _device_num;    
    } 

//语音接口
public:
    virtual int get_delta() {
        CHECK2(false);
        return 0;
    }
    virtual int get_splice() {
        CHECK2(false);
        return 0;
    }
    virtual int get_frame_dim() {
        CHECK2(false);
        return 0;
    }

    inline int get_batch_size() {
        return _batch_size;
    }

    inline void set_batch_size(int batch_size) {
        _batch_size = batch_size;
    }

protected:
    std::vector<std::string> _trans_lines;
    size_t _max_buf_num;
    bool   _is_async;
    int _thread_pool_num;
    int _batch_size;
    std::string _type;
    // int _num_devices = 0;
    int _device_num = 1;
};

}
}

#endif
