/**
 * image_one_sample.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-01
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 * modify by zzxfl 2016.11.03
 */
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_ONE_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_ONE_SAMPLE_H
#include <utility>
#include <vector>
#include <map>
#include <string>
#include <base_stream.h>
#include "base_one_sample.h"
#include "image_one_label.h"
#include "image_one_feature.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class ImageOneSample: public BaseOneSample {
public:
    using ParamFeatureT = std::map<FeatureKeyT, std::tuple<FeatureDescT, DataType, ChannelT, HeightT, WidthT> >;
    using ParamLabelT = std::map<LabelKeyT, std::tuple<LabelType, LabelDimT> >;
public:
    //禁用
    ImageOneSample() = delete;
    ImageOneSample& operator=(const ImageOneSample&) = delete;
    //深拷贝函数
    ImageOneSample(ImageOneSample& sample) {
        _feature_keys = sample.get_feature_keys();
        _label_keys = sample.get_label_keys();
        for (auto key : _feature_keys) {
            ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(&(sample.get_feature(key)));
            ImageOneFeature* feature1 = new ImageOneFeature(*feature);
            _features[key] = feature1;
        }
        for (auto key : _label_keys) {
            ImageOneLabel* label = dynamic_cast<ImageOneLabel*>(&(sample.get_label(key)));
            ImageOneLabel* label1 = new ImageOneLabel(*label);
            _labels[key] = label1;
        }
        //deep copy
        _file_name = sample.get_file_name();
        _scale = sample.get_scale();
    }

    ImageOneSample(
        ParamFeatureT features,
        ParamLabelT labels);

    virtual ~ImageOneSample();

    virtual int read_feature(std::string key, BaseStream&in_stream, size_t st_position_in_byte, size_t size_in_byte);
    virtual int read_label(std::string key, BaseStream&in_stream, size_t st_position_in_byte, size_t size_in_type);

    size_t get_height(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        return feature->get_height();
    }

    size_t get_width(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        return feature->get_width();
    }

    size_t get_channel(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        return feature->get_channel();
    }

    void set_height(std::string key, size_t height) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        feature->set_height(height);
    }

    void set_width(std::string key, size_t width) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        feature->set_width(width);
    }

    void set_channel(std::string key, size_t channel) {
        CHECK2(_features.find(key) != _features.end());
        ImageOneFeature* feature = dynamic_cast<ImageOneFeature*>(_features[key]);
        feature->set_channel(channel);
    }

    virtual float get_scale(std::string key) {
        return _scale[key];
    }

    virtual float get_default_scale(std::string key) {
        return _scale.begin()->second;
    }

    virtual std::map<std::string, float>& get_scale() {
        return _scale;
    }
public:
    int split_image(std::vector<ImageOneSample*>&sent, int perturb, int sub_size);
private:
    std::map<std::string, float>_scale; // 特征缩放比例,为faster_rcnn设计
};

}
}

#endif
