/**
 * base_batch_sample.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_BATCH_SAMPLE_H
#define HOUYI_DATA_WAREHOUSE_BASE_BATCH_SAMPLE_H
#include <utility>
#include <vector>
#include "base_batch_label.h"
#include "base_batch_feature.h"
#include "wind/wind.h"
#include "data_tool.h"
#include "base_batch_desc.h"
#include <map>
#include <vector>
#include <string>
#include "unordered_map"
#include "io_package.h"

namespace houyi {
namespace train {

class BaseBatchSample {
    DISABLE_COPY_AND_ASSIGN(BaseBatchSample);
public:
    BaseBatchSample(size_t batch_size) {
        _batch_size = batch_size;
        //默认句子的帧数为1,图像为1
        _batch_desc = NULL;
        _file_name.resize(batch_size);
        _is_speech = true;
    }

    void resize(size_t batch_size) {
        _batch_size = batch_size;
        _batch_desc->clear();
        _file_name.resize(batch_size);
        _is_speech = true;
    }

    virtual ~BaseBatchSample() {
    }

    void set_feature_tensor(std::string key, Tensor<DType>&data) {
        CHECK2(_features.find(key) != _features.end());
        _features[key]->set_feature(data);
    }

    inline size_t get_feature_size() {
        CHECK2(_feature_keys.size());
        return get_feature_tensor(_feature_keys[0])._buffer->size();
    }
//基类方法
public:
    //将一个data存入指定位置
    void set_feature_tensor(std::string key, Tensor<DType>&data, size_t dst_batch_index) {
        CHECK2(_features.find(key) != _features.end());
        _features[key]->set_feature(data, dst_batch_index);
    }

    BaseBatchFeature &get_feature(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return *_features[key];
    }

    Tensor<DType>& get_feature_tensor(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_feature();
    }

    Tensor<DType> get_feature_tensor(std::string key, size_t src_batch_index) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_feature(src_batch_index);
    }

    BaseBatchLabel &get_label(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return *_labels[key];
    }

    std::map<std::string, BaseBatchFeature*>& get_features() {
        return _features;
    }
    std::map<std::string, BaseBatchLabel*>& get_labels() {
        return _labels;
    }

    inline std::vector<std::string>& get_feature_keys() {
        return _feature_keys;
    }

    inline std::vector<std::string>& get_label_keys() {
        return _label_keys;
    }

    LabelType get_label_type(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return _labels[key]->get_label_type();
    }

    Tensor<int>& get_label_mask(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return _labels[key]->get_mask();
    }

    Tensor<int>& get_default_mask() {
        return get_label_mask(_label_keys[0]);
    }

    Tensor<int>& get_feature_mask(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        return _features[key]->get_mask();
    }

    size_t get_batch_size() {
        return _batch_size;
    }

    void set_batch_size(size_t batch_size) {
        _batch_size = batch_size;
    }

    BaseBatchDesc* get_batch_desc() {
        return _batch_desc;
    }

    std::vector<std::string>& get_file_name(std::string key) {
        return _batch_desc->get_file_name(key);
    }

    std::vector<std::string>& get_default_file_name() {
        return _batch_desc->get_default_file_name();
    }

    std::vector<int>& get_default_origin_width() {
        return _batch_desc->get_default_origin_width();
    }

    std::vector<int>& get_default_origin_height() {
        return _batch_desc->get_default_origin_height();
    }

    std::vector<float>& get_default_scale() {
        return _batch_desc->get_default_scale();
    }

    Tensor<DType> get_default_feature_tensor() {
        return get_feature_tensor(_feature_keys[0]);
    }

    Tensor<DType> get_default_label_tensor() {
        return get_label_tensor(_label_keys[0]);
    }

    Tensor<DType>& get_label_tensor(std::string key) {
        CHECK2(_labels.find(key) != _labels.end());
        return _labels[key]->get_label();
    }

    int get_label_dim(std::string key) {
        if (_labels.find(key) != _labels.end()) {
            return _labels[key]->get_label_dim();
        }
        CHECK2(false);
        return 0;
    }

    void rename_feature(std::string key) {
        if (_features.find(key) != _features.end()) {
            return;
        }
        CHECK2(_feature_keys.size() == 1);
        
        BaseBatchFeature* feature = _features[_feature_keys[0]];
        _features.clear();
        _features[key] = feature;
        _feature_keys[0] = key;
    }

    void rename_label(std::string key) {
        if (_labels.find(key) != _labels.end()) {
            return;
        }
        CHECK2(_label_keys.size() == 1);

        BaseBatchLabel* label = _labels[_label_keys[0]];
        _labels.clear();
        _labels[key] = label;
        _label_keys[0] = key;
    }

public:
    void show() {
        Tensor<DType>& label = get_label_tensor(get_label_keys()[0]);
        label.write("label");

        Tensor<DType>& feature = get_feature_tensor(get_feature_keys()[0]);
        feature.write("feature");
    }
    bool is_speech() {
        return _is_speech;
    }
    void set_is_speech(bool flag) {
        _is_speech = flag;
    }
protected:
    size_t _batch_size;
    std::vector<std::string>_feature_keys;
    std::vector<std::string>_label_keys;
    BaseBatchDesc* _batch_desc;
    std::map<FeatureKeyT, BaseBatchFeature*>_features;
    std::map<LabelKeyT, BaseBatchLabel*>_labels;
    std::vector<std::string>_file_name;
    bool _is_speech;
};

}
}

#endif
