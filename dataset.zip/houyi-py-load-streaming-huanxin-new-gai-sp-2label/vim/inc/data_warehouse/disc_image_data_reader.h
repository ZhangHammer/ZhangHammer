// by zzxfl 2016.11.25
// 支持区分度训练的数据加载模块
// 只支持图像
#ifndef HOUYI_DATA_WAREHOUSE_DISC_IMAGE_DATA_READER_H
#define HOUYI_DATA_WAREHOUSE_DISC_IMAGE_DATA_READER_H

#include <iostream>
#include <vector>
#include <queue>
#include <pthread.h>
#include <utility>
#include <map>
#include "util.h"
#include "image_reader_config.h"
#include "base_data_reader.h"
#include "message_queue.h"
#include <mutex>
#include <condition_variable>

namespace houyi {
namespace train {

class DiscImageDataReader : public BaseDataReader {
public:
    //不安全构造函数，禁止使用
    DiscImageDataReader() = delete;
    DiscImageDataReader(const DiscImageDataReader&) = delete;
    DiscImageDataReader& operator=(const DiscImageDataReader&) = delete;

    //唯一构造函数入口
    DiscImageDataReader(BaseReaderConfig &cfg) : BaseDataReader(cfg) {
        init();
        ImageReaderConfig *image_cfg = dynamic_cast<ImageReaderConfig *>(&cfg);
        /*多标签多label*/
        get_data_file_list(image_cfg->get_feat_list(),
                           image_cfg->get_label_list());

        _max_block_load = image_cfg->get_load_block_num();
        _read_from_disk = image_cfg->get_read_from_disk();
        if (_read_from_disk == false) {
            _sample_queue.set_max_length(1000);
        }
        //如果是facenet区分度训练，把随机关闭
        if (_read_from_disk == 0) {
            _sample_random = 0;
        }
        _image_reader_cfg = image_cfg;
    }

    ~DiscImageDataReader() {
    }

    void reset();
    size_t get_samples_from_reader(std::vector<BaseOneSample*>& samples, int sample_num);

    // 区分度训练接口，回放样本
    // Tensor的第一维表示样本个数
    // 接口不负责清理feature label的内容
    // 只支持单标签单特征
    virtual void push_batch_to_reader(Tensor<DType>*feature, Tensor<DType>*label);
protected:
    //将所有文件列表中的sample读取出来
    size_t read_samples_from_disk();
    //从一个文件里面读取所有sample
    size_t read_samples_from_disk(const char *feat_file, const char *desc_file,
                                  const char *label_file);
    size_t read_samples_from_disk(std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block);


    int get_feature_desc_head(BaseStream& file_stream, FeatureDescHead &head);
    int get_label_desc_head(BaseStream &file_stream, LabelDescHead &label);
    //多标签多feature
    void get_data_file_list(
        std::vector<std::pair<std::string, std::vector<std::string>> >&,
        std::vector<std::pair<std::string, std::vector<std::string>> >&);
    void sample_random(std::vector<BaseOneSample *> &sample_vector);
    void move_sample_to_queue();
    void random_data_file_list();

protected:
    void init() {
        _train_data_file_vec.clear();
        _max_block_load = 0;
        _next_file_load_idx = 0;
        _done_image_num = 0;
        _finish_thread = 0;
    }

private:
    MessageQueue<BaseOneSample*> _sample_queue;
    std::vector<BaseOneSample *> _sample_vector; //临时存放，排序使用
    std::vector<BaseOneSample *> _sample_remain; //上次剩余的单数的

    // 要加载的训练数据的文件列表
    // map -> key(feature or label name) , tuple
    // tuple -> <is feature or label, feat or label data, feat_desc or label_desc>
    std::vector<std::map<std::string, std::tuple<bool, size_t, std::string, std::string> > >_train_data_file_vec;
    size_t _max_block_load;                 //_sample_queue中缓存的最大文件数, 每个文件是一个block
    int _next_file_load_idx;                //从硬盘中加载的文件位置
    size_t _done_image_num;                 //reader已经提供的图像数
    bool _sample_random;                    //shuffle the samples
    bool _read_from_disk; // 1表示从磁盘读取
    ImageReaderConfig* _image_reader_cfg;
    int _finish_thread; // 区分度多卡时，如果一个epoch结束，上层会传过来一个空bat，由于多卡在读取，该标志位标志epoch已经结束，给每个卡的processer放回一个空sample
    std::mutex _read_mutex;
    std::condition_variable _condition;//阻塞
};

}
}

#endif
