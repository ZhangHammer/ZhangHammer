//by zzxfl 2016.09.23
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_ONE_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_ONE_FEATURE_H
#include <utility>
#include "wind/wind.h"
#include <vector>
#include "base_one_feature.h"

namespace houyi {
namespace train {
class SpeechOneFeature:public BaseOneFeature {
    DISABLE_COPY_AND_ASSIGN(SpeechOneFeature);
public:
    SpeechOneFeature(DataType type, int frame_num, int frame_dim, int speeker_id):
        BaseOneFeature(type),
        _frame_num(frame_num),
        _frame_dim(frame_dim),
        _speaker_id(speeker_id) {
//由于数据打包的时候已经处理了5帧头尾扩展，配置表只能填5,
//        CHECK2(_head_filled == 5);
//        CHECK2(_tail_filled == 5);
        _data.set_device(cpu_device());
        _data.resize(Dim(frame_num, frame_dim), false);
    }

    void resize(DataType type, int frame_num, int frame_dim, int speeker_id) {
        _data_type = type;
        _frame_num = frame_num;
        _frame_dim = frame_dim;
        _speaker_id = speeker_id;
        _data.resize(Dim(frame_num, frame_dim), false);
    }

    inline int get_frame_num() {
        return _frame_num;
    }

    inline void set_frame_num(int frame_num) {
        _frame_num = frame_num;
    }

    inline int get_frame_dim() {
        return _frame_dim;
    }

    inline void set_frame_dim(int frame_dim) {
        _frame_dim = frame_dim;
    }

    inline int get_head_filled() {
        return _head_filled;
    }

    inline int get_tail_filled() {
        return _tail_filled;
    }

    inline int get_speaker_id() {
        return _speaker_id;
    }

    virtual void set_feature(Tensor<DType>&data) {
        _data.resize(data.get_size(), false);
        _data.copy_from(data);
        _frame_num = _data.get_size(0);
    }

    virtual int read_data(BaseStream& in_stream,
                          size_t st_position_in_byte = 0, size_t size_in_type = 0);

    virtual ~SpeechOneFeature() {
    }
private:
    int _frame_num;
    int _frame_dim;
    int _head_filled;
    int _tail_filled;
    int _speaker_id;
};

}
}

#endif
