//by zzxfl 2017.02.13
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_DESC_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_BATCH_DESC_H
#include <utility>
#include <vector>
#include <string>
#include <map>
#include "data_tool.h"
#include "base_batch_desc.h"

namespace houyi {
namespace train {

class ImageBatchDesc : public BaseBatchDesc {
public:
    ImageBatchDesc() {
    }
    virtual ~ImageBatchDesc() {}
    std::vector<int>& get_origin_width(FeatureDescKeyT key) {
        if (_origin_width.find(key) == _origin_width.end()) {
            _origin_width[key] = std::vector<int>();
        }
        return _origin_width[key];
    }

    std::vector<int>& get_origin_height(FeatureDescKeyT key) {
        if (_origin_height.find(key) == _origin_height.end()) {
            _origin_height[key] = std::vector<int>();
        }
        return _origin_height[key];
    }

    std::vector<float>& get_scale(FeatureDescKeyT key) {
        return _scale[key];
    }

    std::vector<float>& get_default_scale() {
        CHECK2(_scale.size());
        return _scale.begin()->second;
    }

    std::vector<int>& get_default_origin_width() {
        CHECK2(_origin_width.size());
        return _origin_width.begin()->second;
    }

    std::vector<int>& get_default_origin_height() {
        CHECK2(_origin_height.size());
        return _origin_height.begin()->second;
    }

    virtual void clear() {
        _origin_width.clear();
        _origin_height.clear();
        _file_name.clear();
        _scale.clear();
    }
private:
    std::map<FeatureDescKeyT, std::vector<int> >_origin_width;//原始图片的长度
    std::map<FeatureDescKeyT, std::vector<int> >_origin_height;//原始图片的宽度
    std::map<FeatureDescKeyT, std::vector<float> > _scale; //特征放大缩小的比例
};

}//houyi
}//train

#endif
