/**
 * base_batchdata.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-13
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_BATCH_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_BASE_BATCH_FEATURE_H
#include <utility>
#include <vector>
#include "data_tool.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class BaseBatchFeature {
    DISABLE_COPY_AND_ASSIGN(BaseBatchFeature);
public:
    BaseBatchFeature(DataType type, size_t batch_size) {
#ifndef __BUILD_PY_DATA_LOAD__
        _feature.set_device(cpu_pinned_device());
        _mask.set_device(cpu_pinned_device());
#else
        _feature.set_device(cpu_device());
        _mask.set_device(cpu_device());
#endif
        _feature_type = type;
        _batch_size = batch_size;
    }

    void resize(DataType type, size_t batch_size) {
        _feature_type = type;
        _batch_size = batch_size;
    }

    virtual ~BaseBatchFeature() {
    }

    size_t get_batch_size() {
        return _batch_size;
    }

    void set_batch_size(size_t batch_size) {
        _batch_size = batch_size;
    }

    DataType get_feature_type() {
        return _feature_type;
    }

    void set_feature_type(DataType type) {
        _feature_type = type;
    }

    void set_feature(Tensor<DType>&data) {
        _feature.resize(data.get_size());
        _feature.copy_from(data);
    }

    Tensor<DType>& get_feature() {
        return _feature;
    }

    Tensor<int>& get_mask() {
        return _mask;
    }

public:
    virtual void set_feature(Tensor<DType>&data, size_t index) = 0;
    virtual Tensor<DType> get_feature(size_t index) = 0;
protected:
    DataType _feature_type;
    size_t _batch_size;
    std::vector<FeatureDescT>_feature_desc;
    Tensor<DType>_feature;
    Tensor<int> _mask;
};

}
}

#endif
