//by zhxfl 2017.10.27

#ifndef HOUYI_DATA_WAREHOUSE_OBJECT_FACTORY_H
#define HOUYI_DATA_WAREHOUSE_OBJECT_FACTORY_H

#include <iostream>
#include <string>
#include <queue>
#include <mutex>
#include "speech_batch_sample.h"
#include "speech_one_sentence.h"
namespace houyi {
namespace train {
/*
 * 经过测试，语音数据加载主要开销集中在bat对象的初始化上面
 * 单卡拼bat逻辑中，初始化SpeechBatchSample占用整块逻辑的79%
 * 注意：create_object和delete_object内存安全性
 */

template<typename OBJECT>
class ObjectFactory {
public:
    ObjectFactory() {
    }
    
    /*
     * 返回一个可用的对象
     * 1）如果队列不为空，获取小根堆第一个对象返回
     * 2）如果队列为空，创建一个新的对象返回
     */
    OBJECT* create_object();
    /*
     *上层没有用的对象析构
     *1）队列不满，放入队列中备用
     *2）放入队列，队列超过最大值，再把小跟堆的顶部样本拿出来析构(优先析构小的)
     */
    void delete_object(OBJECT* object);
    //单例
    static ObjectFactory* instance() {
        static ObjectFactory factory;
        return &factory; 
    }

    static bool cmp(std::pair<size_t, OBJECT*>a, std::pair<size_t, OBJECT*>b) {
        return a.first > b.first;
    }
    inline void set_max_len(int max_len) {
        _max_len = max_len;
    }
private:

    bool can_push() {
        return (size_t) _max_len > _queue.size();
    }

    struct Node{
        Node(size_t in_size, OBJECT* in_obj) {
            size = in_size;
            obj = in_obj;
        }

        friend bool operator<(Node a, Node b){
            //小值优先
            return a.size > b.size;
        }
        size_t size;
        OBJECT* obj;
    };
private:
    std::priority_queue<Node> _queue;
    int _max_len = 32;
    std::mutex _mutex;
};
}
}
#endif 
