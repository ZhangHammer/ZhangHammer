/**
 * base_processer.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-07-05
 *
 * Copyright (c) lifeng.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_PROCESSER_H
#define HOUYI_DATA_WAREHOUSE_BASE_PROCESSER_H
#include <thread>
#include <map>
#include <mutex>

#include "base_processer_config.h"
#include "message_queue.h"
#include "thread.h"
#include "base_transformation.h"
#include "base_one_sample.h"
#include "base_data_reader.h"

namespace houyi {
namespace train {

class BaseTransformation;
class BaseProcesser {
public:
    BaseProcesser(BaseDataReader *reader, BaseProcConfig &cfg) {
        init();

        _data_reader = reader;
        _sample_queue = NULL;
        _async_pro_thread = NULL;
        _cfg = &cfg;

        _max_sample_num = cfg.get_max_buf_num();

        //thread_pool init
        INTER_LOG("thread_pool_num %d", cfg.get_thread_pool_num());
        //if (cfg.get_thread_pool_num() > 0 &&
        //        (size_t)cfg.get_thread_pool_num() <= std::thread::hardware_concurrency()) {
        trans_read(cfg.get_thread_pool_num());
        //}
        //else {
        //    trans_read(4);
        //}
    }

    virtual ~BaseProcesser() {}
    
    virtual void clear() {
        if (_async_pro_thread) {
            _async_pro_thread->join();
            delete _async_pro_thread;
            _async_pro_thread = NULL;
        }
        if (_sample_queue) {
            delete _sample_queue;
            _sample_queue = NULL;
        }
    }
    static BaseProcesser* create(BaseDataReader* reader, BaseProcConfig &cfg);

    static void * async_pro_load(void *data);
    virtual void start_async_load();

    virtual void reset() {
        if (_async_pro_thread) {
            _async_pro_thread->join();
        }

        if (_cfg->is_async()) {
            if (_sample_queue) {
                _sample_queue->clean();
            }
            start_async_load();
        }
    }

    inline BaseDataReader* get_reader() {
        return _data_reader;
    }

    virtual size_t get_samples_from_proc(
        std::vector<BaseOneSample*>&samples, size_t max_num);

    virtual size_t get_samples_from_proc(std::vector<BaseOneSample*>&samples) {
        return get_samples_from_proc(samples, 1);
    }

    inline MessageQueue<BaseOneSample*>* get_queue() {
        return _sample_queue;
    }

    inline size_t get_max_sample_num() {
        return _max_sample_num;
    }

    bool get_sample_random() {
        return _sample_random;
    }
protected:
    virtual bool perform_trans_stream(BaseOneSample& sample, int idx);
    void trans_read(int);

    size_t get_samples_from_reader(
        std::vector<BaseOneSample*>&samples, size_t max_num);
    void init() {
        _data_reader = NULL;
        _sample_queue = NULL;
        _async_pro_thread = NULL;
        _max_sample_num = 0;
        _laster_batch = false;
        _data_reader = NULL;
        _async_pro_thread = NULL;
        _sample_queue = NULL;
    }
public:
    BaseProcConfig* get_cfg() {
        return _cfg;
    }
protected:
    bool _laster_batch;
    bool _sample_random;

    BaseProcConfig *_cfg;
    BaseDataReader *_data_reader;

    Thread *_async_pro_thread;
    MessageQueue<BaseOneSample*> *_sample_queue;/*thread safe*/

    size_t _max_sample_num;
    std::vector<std::vector<BaseTransformation*> >_trans_stream;//全局变量，多个线程访问，使用需要加锁
};

}
}

#endif
