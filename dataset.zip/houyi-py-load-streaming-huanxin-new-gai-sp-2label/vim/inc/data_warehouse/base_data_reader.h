/**
 * base_data_reader.h
 *
 * Author: lifeng (lifeng20@baidu.com)
 * Created on: 2016-03-09
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_DATA_READER_H
#define HOUYI_DATA_WAREHOUSE_BASE_DATA_READER_H
#include "base_one_sample.h"
#include "base_reader_config.h"
namespace houyi {
namespace train {
// TODO 公共参数在这里解析
class BaseDataReader {
public:
    BaseDataReader() {
        init();
    }
    BaseDataReader(BaseReaderConfig &cfg) {
        init();
        _device_num = cfg.get_device_num();
        _train_type = cfg.get_train_type();
    }
    virtual ~BaseDataReader() {}
    static BaseDataReader* create(BaseReaderConfig &cfg);

    virtual size_t get_samples_from_reader(std::vector<BaseOneSample*>& samples, int max_num) = 0;
    virtual size_t get_samples_from_reader(std::vector<BaseOneSample*>& samples) {
        return get_samples_from_reader(samples, 1);
    }
    virtual void reset() = 0;

    void set_device_num(int num) {
        _device_num = num;
    }

    virtual void push_batch_to_reader(Tensor<DType>* feature, Tensor<DType>* label) = 0;

    virtual size_t get_all_samples_from_reader(std::vector<BaseOneSample*>& samples) {
        CHECK(false, "Not implemented");
    }

protected:
    void init() {
        _device_num = 1;
    }
protected:
    int _device_num = 1;
    int _train_type;
};

}
}

#endif
