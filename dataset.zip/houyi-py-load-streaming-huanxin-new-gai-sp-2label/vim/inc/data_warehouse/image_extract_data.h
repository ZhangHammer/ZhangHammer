//by zhxfl 2017.12.21
#ifndef HOUYI_DATA_WAREHOUSE_IMAGE_EXTRACT_DATA_H
#define HOUYI_DATA_WAREHOUSE_IMAGE_EXTRACT_DATA_H

#include <queue>
#include "base_extract_data.h"
#include "image_one_sample.h"
/*
 * 异步从磁盘读取数据，双buffer
 * 1) shuffle 
 */
namespace houyi {
namespace train {

class ImageExtractData : public BaseExtractData {
    DISABLE_COPY_AND_ASSIGN(ImageExtractData);
public:
    ImageExtractData(
        std::vector<std::pair<std::string, std::vector<std::string>>>& feature_list,
        std::vector<std::pair<std::string, std::vector<std::string>>>& label_list,
        int file_cnt,
        int thread_num, 
        int sample_random,
        int split_image_sub_size,
        int split_image_perturb
        ) :
        BaseExtractData(feature_list,
            label_list, file_cnt,
            thread_num, sample_random),
        _split_image_sub_size(split_image_sub_size),
        _split_image_perturb(split_image_perturb) {
    }

private:
    //reading_samples已经读取好了，将对应数据转移到ready_sample
    virtual void move_sample() {
#ifndef __CLOSE_RANDOM__
        if (_sample_random) {
            std::random_shuffle(_reading_samples.begin(), _reading_samples.end());
        }
#endif
        for (auto sample : _reading_samples) {
            _ready_samples.push(sample);
        }
        _reading_samples.clear();
    }
    
    //从磁盘读取数据
    virtual void read_sample(
        std::map<std::string, std::tuple<bool, size_t, std::string, std::string> >& one_block,
        std::vector<BaseOneSample*>& sample_buffer, int);

    int get_feature_desc_head(BaseStream& file_stream, FeatureDescHead &head);
    int get_label_desc_head(BaseStream& file_stream, LabelDescHead &label);
private:
    // 
    int _split_image_sub_size = -1;
    int _split_image_perturb = -1;
};

} // houyi
} // train
#endif 
