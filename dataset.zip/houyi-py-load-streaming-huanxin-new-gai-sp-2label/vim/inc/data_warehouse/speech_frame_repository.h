//by zzxfl 2016.08.30
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_FRAME_REPOSITORY_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_FRAME_REPOSITORY_H
#include "base_repository.h"
#include "base_repository_config.h"
#include "base_batch_sample.h"
#include "speech_sent_repository.h"
#include "speech_one_sentence.h"
#include <vector>
#include <string>
#include <tuple>
namespace houyi {
namespace train {

class SpeechFrameRepository : public BaseRepository {
public:
    SpeechFrameRepository(
        BaseProcesser *proc, BaseReposConfig& cfg, int device_id)
        : BaseRepository(proc, cfg, device_id) {
    }

    virtual size_t inter_get_batch(
        std::vector<BaseBatchSample*> &batches, size_t max_num);
    virtual void reset();
private:
    SpeechBatchSample::ParamFeatureT get_features_param(SpeechOneSentence& sample);
    SpeechBatchSample::ParamLabelT get_labels_param(SpeechOneSentence& sample);
};
}//houyi
}//train

#endif
