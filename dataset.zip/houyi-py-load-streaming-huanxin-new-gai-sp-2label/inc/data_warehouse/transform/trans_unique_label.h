/**
 * trans_unique_label.h
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-07-02
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransUniqueLabel : public BaseTransformation {
public:
    TransUniqueLabel() : BaseTransformation() {
        _label_data.set_device(cpu_device());
        _start_idx = -1;
        _end_idx   = -1;
        _blank_idx = -1;
        _sil_idx   = -1;
        _insert_sil = false;
    }
    ~TransUniqueLabel() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    std::string _add_label_name_start;
    std::string _add_label_name_end;
    std::string _add_label_name_cont;
    std::string _add_disc_label_start;
    std::string _add_disc_label_end;
    int _start_idx;
    int _end_idx;
    int _blank_idx;
    int _sil_idx;
    int _append_end = 0;
    bool _insert_sil;
};

}
}

#endif
