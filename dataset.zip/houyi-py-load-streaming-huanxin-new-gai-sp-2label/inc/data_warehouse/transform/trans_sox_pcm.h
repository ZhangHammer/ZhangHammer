#pragma once

#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransSoxPcm : public BaseTransformation {
public:
    TransSoxPcm() : BaseTransformation() {
        _keep_ratio = -1.f;
        _sox_effect_type = "speed";
        _sox_effect_val = {1.0, 1.0};
        _sample_rate = 16000;
        _channels = 1;
    }
    ~TransSoxPcm() { }

    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    float _keep_ratio;
    std::string _sox_effect_type;
    std::vector<float> _sox_effect_val;

    int _channels;
    int _sample_rate;

    transform_util::PRNG _prng;
};

}
}

