// trans_multi_way_pcm.h
// Author: Wu Dan (wudan14@baidu.com)
// Created on: 2019-11-28
// Copyright (c) baidu.com, Inc. All Rights Reserved

#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MULTI_WAY_PCM
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_MULTI_WAY_PCM

#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransMultiWayPCM : public BaseTransformation {
public:
    TransMultiWayPCM() : BaseTransformation() {
        _audio_data.set_device(cpu_device());
        _in_channel_num = -1;
        _out_channel_num = 2;
    }
    ~TransMultiWayPCM() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _audio_data;
    std::string _out_audio_key;
    int _in_channel_num;
    int _out_channel_num;
};


} // namespace train
} // namespace houyi


#endif
