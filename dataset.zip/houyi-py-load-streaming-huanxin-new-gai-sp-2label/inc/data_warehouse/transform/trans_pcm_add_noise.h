/**
 * trans_pcm_add_noise.h
 * Author: Chen Xu (chenxu13u@baidu.com)
 * Created on: 2021-02-18
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PCM_ADD_NOISE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_PCM_ADD_NOISE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransPcmAddNoise : public BaseTransformation {
public:
    TransPcmAddNoise() : BaseTransformation() {
        _ratio = -1.f;
        _max_snr = -1000;
        _min_snr = -1000;
        _noise_data.set_device(cpu_device());
        _square.set_device(cpu_device());
    }
    ~TransPcmAddNoise() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    void load_noise(int sample_num);

    std::string _noise_lst;
    std::vector<std::string> _noise_info;
    Tensor<DType> _noise_data;
    Tensor<DType> _square;

    DType _ratio;
    DType _max_snr;
    DType _min_snr;
    transform_util::PRNG _prng;
};

}
}

#endif
