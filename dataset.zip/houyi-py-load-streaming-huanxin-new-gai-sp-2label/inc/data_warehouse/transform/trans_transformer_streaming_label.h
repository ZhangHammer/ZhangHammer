/**
 * trans_transformer_streaming_label.h
 * Author: Chen Xu (chenxu13@baidu.com)
 * Created on: 2019-11-28
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_STREAMING_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_STREAMING_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransTransformerStreamingLabel : public BaseTransformation {
public:
    TransTransformerStreamingLabel() : BaseTransformation() {
        _offset = 4;
        _cos_id = 1;
        _sos_id = 2;
        _eos_id = 3;
        _keep_sil = true;
        _chunk_size = 8;
        _look_ahead = 0;
        _max_unique_label = 100;
        _step = 3;
        _select_ratio = 1.01f;
        _max_selections = -1;
        
        _label_data.set_device(cpu_device());

    }
    ~TransTransformerStreamingLabel() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    int _blank_id;
    int _offset;
    int _cos_id;
    int _sos_id;
    int _eos_id;
    bool _keep_sil;

    int _chunk_size;
    int _look_ahead;
    int _max_unique_label;
    int _step;
    float _select_ratio;
    int _max_selections;

    transform_util::PRNG _prng;
};

}
}

#endif
