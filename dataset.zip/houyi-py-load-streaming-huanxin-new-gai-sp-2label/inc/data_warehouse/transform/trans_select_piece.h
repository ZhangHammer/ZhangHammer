// by zzxfl 2017.04.11
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SELECT_PIECE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SELECT_PIECE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransSelectPiece : public BaseTransformation {
public:
    TransSelectPiece() : BaseTransformation() {
        _piece_feature.set_device(cpu_device());
        _piece_label.set_device(cpu_device());
    }
    ~TransSelectPiece() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _piece_feature; 
    Tensor<DType> _piece_label;
    int _edge_id = -1; 
    int _piece_ratio = 8;
    bool _random_start = true;
    int _sil_ratio = -1;
    int _min_len = 3;
};
}
}

#endif
