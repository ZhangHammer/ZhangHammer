/**
 * trans_unique_label3.h
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-07-02
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL3_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_UNIQUE_LABEL3_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransUniqueLabel3 : public BaseTransformation {
public:
    TransUniqueLabel3() : BaseTransformation() {
        _ignore_id = -1;
        _offset = 4;
        _eos_id = 3;
        _label_data.set_device(cpu_device());
        _is_predict = false;
        _placeholder_ratio = -1.f;

    }
    ~TransUniqueLabel3() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    int _ignore_id;
    int _offset;
    int _sos_id;
    int _flag_id;
    int _eos_id;
    bool _is_predict;
    float _placeholder_ratio;

    transform_util::PRNG _prng;
    // std::string _new_label_name;
};

}
}

#endif
