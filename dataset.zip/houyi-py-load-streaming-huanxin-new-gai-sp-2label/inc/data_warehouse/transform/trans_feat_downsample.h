// by zzxfl 2017.05.18
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_FEAT_DOWNSAMPLE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_FEAT_DOWNSAMPLE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>
namespace houyi {
namespace train {

class TransFeatDownsample : public BaseTransformation {
public:
    TransFeatDownsample() : BaseTransformation(),
        _step(6), _start(0), _random(true) {}
    ~TransFeatDownsample() { }

    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _step;
    int _start;
    bool _random;
    Tensor<DType>_mat {cpu_device()};
};

}
}

#endif
