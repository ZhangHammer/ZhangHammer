//by chenxu 2019.04.02
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_RESIZE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_RESIZE_LABEL_H

#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"

namespace houyi {
namespace train {

class TransResizeLabel : public BaseTransformation {
public:
    TransResizeLabel() : BaseTransformation() {
        _channels = 1;
        _window = 400;
        _stride = 160;
        _align = -1;
        _label.set_device(cpu_device());
    }

    ~TransResizeLabel() {}

    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    int _channels;
    int _window;
    int _stride;
    int _align;

    int _blank_id = 1787;
    
    Tensor<DType> _label;
};

}
}

#endif
