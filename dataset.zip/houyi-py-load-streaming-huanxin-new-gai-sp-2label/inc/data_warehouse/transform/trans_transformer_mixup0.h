#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_MIXUP0_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_MIXUP0_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransTransformerMixup0 : public BaseTransformation {
public:
    TransTransformerMixup0() : BaseTransformation() {
            _feat_mat.set_device(cpu_device());
            _input_label_mat.set_device(cpu_device());
            _output_label_mat.set_device(cpu_device());

            _tmp0.set_device(cpu_device());
            _tmp1.set_device(cpu_device());
            _counter = 0;

            _second_sos = 1;  
            _second_eos = 3;
        }   
    ~TransTransformerMixup0() {} 
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);

private:
    float _no_mixup_ratio;
    int _second_sos;
    int _second_eos;
    Tensor<DType> _feat_mat;
    Tensor<DType> _input_label_mat;
    Tensor<DType> _output_label_mat;

    Tensor<DType> _tmp0;
    Tensor<DType> _tmp1;

    transform_util::PRNG _prng;
    int _counter;
};
}
}

#endif

