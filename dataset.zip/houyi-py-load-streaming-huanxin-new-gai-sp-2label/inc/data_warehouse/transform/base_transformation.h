//by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_BASE_TRANSFORMATION_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_BASE_TRANSFORMATION_H

#include "image_utils.h"

#include "wind/wind.h"
#include <vector>
#include <thread>
#include <mutex>
#include <set>
namespace houyi {
namespace train {

namespace transform_util {
/**
 *  * A simple pseudo-random number generator
 *   * Copy from Zhang Ce
 *    */
class PRNG {
public:
    typedef std::mt19937_64 Engine;

public:
    PRNG() {
        std::random_device r;
        Reset(r());
    }   

    PRNG(uint64_t seed) {
        Reset(seed);
    }   

    void Reset(uint64_t seed) {
        Engine r(seed);
        std::seed_seq uniform_seed{r(), r(), r(), r(), r(), r(), r(), r()};
        std::seed_seq normal_seed{r(), r(), r(), r(), r(), r(), r(), r()};
        uniform_eng_.seed(uniform_seed);
        normal_eng_.seed(normal_seed);
    }   

    template<class T>
    T UniformInt(T a = 0, T b = std::numeric_limits<T>::max()) {
        std::uniform_int_distribution<T> uniform(a, b); 
        return uniform(uniform_eng_);
    }   

    template<class T>
    T Uniform(T a = 0., T b = 1.) {
        std::uniform_real_distribution<T> uniform(a, b); 
        return uniform(uniform_eng_);
    }   

    template<class T>
    T Normal(T a = 0., T b = 1.) {
        std::normal_distribution<T> normal(a, b); 
        return normal(normal_eng_);
    }   

    Engine &UniformEngine() { return uniform_eng_; }
    Engine &NormalEngine() { return normal_eng_; }

private:
    Engine uniform_eng_;
    Engine normal_eng_;
};
}

class BaseOneSample;

class BaseTransformation {
public:
    virtual int perform_trans(BaseOneSample &data_pack) = 0;
    virtual void read_data(std::string &config_line) = 0;

    static BaseTransformation* new_trans_of_type(const std::string &type);
    static BaseTransformation* read(std::string &config_line);
    /*
     *bref
     * 如果_keys 为空，对所有feature或者label都进行处理
     * 如果不为空，则对相应的feature或者label进行处理
     *
     */
    inline bool has_key(std::string key) {
        if (_keys.size() == 0) {
            return true;
        }
        if (_keys.find(key) != _keys.end()) {
            return true;
        }
        return false;
    }

    void read_keys(std::string&);

    virtual ~BaseTransformation() {}
protected:
    std::set<std::string>_keys;//记录为label key, feature key
};
}
}
#endif
