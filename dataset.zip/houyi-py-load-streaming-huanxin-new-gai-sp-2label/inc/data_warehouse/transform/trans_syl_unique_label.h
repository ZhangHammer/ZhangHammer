/**
 * trans_syl_unique_label.h
 * Author: fuxuanyu(fuxuanyu@baidu.com)
 * Created on: 2018-07-02
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SYL_UNIQUE_LABEL_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_SYL_UNIQUE_LABEL_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransSylUniqueLabel : public BaseTransformation {
public:
    TransSylUniqueLabel() : BaseTransformation() {
        _keep_blank = true;
        _keep_sil = true;
        _label_data.set_device(cpu_device());
    }
    ~TransSylUniqueLabel() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    int _blank_id;
    bool _keep_blank;
    bool _keep_sil;

    transform_util::PRNG _prng;
};

}
}

#endif
