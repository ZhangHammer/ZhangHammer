//by zzxfl 2016.10.28
#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_NAIVE_SPLICE_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_NAIVE_SPLICE_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransNaiveSplice : public BaseTransformation {
public:
    TransNaiveSplice() : BaseTransformation(),
        _left_context(5),
        _right_context(5) {
            _mat.set_device(cpu_device());
        }
    ~TransNaiveSplice() { }
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);

private:
    int _left_context;
    int _right_context;
    Tensor<DType>_mat;
};
}
}

#endif
