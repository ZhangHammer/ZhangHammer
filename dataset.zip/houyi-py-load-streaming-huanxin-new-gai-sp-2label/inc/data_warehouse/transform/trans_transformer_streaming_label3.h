/**
 * trans_transformer_streaming_label3.h
 * Author: Chen Xu (chenxu13@baidu.com)
 * Created on: 2019-12-19
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 */

#ifndef HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_STREAMING_LABEL3_H
#define HOUYI_DATA_WAREHOUSE_TRANSFORM_TRANS_TRANSFORMER_STREAMING_LABEL3_H
#include "base_transformation.h"
#include "wind/wind.h"
#include "base_one_sample.h"
#include <vector>

namespace houyi {
namespace train {

class TransTransformerStreamingLabel3 : public BaseTransformation {
public:
    TransTransformerStreamingLabel3() : BaseTransformation() {
        _offset = 4;
        _cos_id = 1;
        _sos_id = 2;
        _eos_id = 3;
        _keep_sil = true;
        _chunk_size = 8;
        _look_ahead = 0;
        _max_unique_label = 100;
        _step = 3;
        _rewind = 3;

        _label_data.set_device(cpu_device());

    }
    ~TransTransformerStreamingLabel3() {}
    virtual int perform_trans(BaseOneSample& data_pack);
    virtual void read_data(std::string& config_line);
private:
    Tensor<DType> _label_data;
    int _blank_id;
    int _offset;
    int _cos_id;
    int _sos_id;
    int _eos_id;
    bool _keep_sil;

    int _chunk_size;
    int _look_ahead;
    int _max_unique_label;
    int _step;
    int _rewind;
};

}
}

#endif
