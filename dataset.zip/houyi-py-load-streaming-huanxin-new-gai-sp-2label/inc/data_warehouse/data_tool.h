/**
 * data_tool.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-07-011
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_DATA_TOOL_H
#define HOUYI_DATA_WAREHOUSE_DATA_TOOL_H
#include <string>
#include <vector>
#include <cstring>
#include <string>
#include <stdio.h>
#include <stdlib.h>

namespace houyi {
namespace train {

typedef enum {
    INT_LABEL_TYPE,
    FLOAT_LABEL_TYPE,
    CHAR_LABEL_TYPE,
    UNKNOWN_LABEL_TYPE = 0x7FFFFFFF
} LabelType;

extern  const char*label_type_name[];

//数据的格式
typedef enum {
    // 0
    FBANK_TYPE,
    // 1
    PCM_TYPE,
    // 2 图像以原始数据的形式按照RGB存储,每通道8bit,存储顺序:BGR,BGR....
    RGB24_TYPE,
    // 3 图像的数据为float类型，各个通道单独存放在tensor中,B存放到tensor[0][][],G存放到tensor[1][][], R存放到tensor[2][][];
    BBGGRR_FLOAT_TYPE,
    // 4 jpg格式，需要进行解码
    JPEG_TYPE,
    // 5 图像的数据为UC(unsigned char)类型，各个通道单独存放在tensor中，B存放到tensor[0][][],G存放到tensor[1][][], R存放到tensor[2][][];
    BBGGRR_UC_TYPE,
    // 6
    GRAY_FLOAT_TYPE,
    // 7 视频序列输入,格式为frame*height*width
    SEQ_CHAR_TYPE,
    // 8 与FBANK_TYPE类似，特征是SHORT形式存储的, FBANK_TYPE特征是FLOAT形式存储的
    FBANK_SHORT_TYPE,
    // 9 兼容老格式swap32，32位
    FBANK_SWAP32_TYPE,
    // 10 
    UNKNOWN_DATA_TYPE = 0X7FFFFFFF
} DataType;

//enum DataReadType {READ_FBANK, READ_PCM, READ_IMAGE, READ_UNKNOWN};
//添加新的类型时，在后面添加!!!!!!!!!!!!!!
extern const char *data_type_name[];

//block feature的头信息
typedef struct  {
    DataType data_type;
    int data_num;
    int dim;
    std::string to_feature_string() {
        std::string ret;
        char str[1024];
        snprintf(str, 1024, "%d %d %d\n", data_type, data_num, dim);
        ret = std::string(str);
        return ret;
    }
} FeatureDescHead;

//block label 的头信息
typedef struct  {
    LabelType label_type;
    int data_num;
    int dim;

    std::string to_label_string() {
        std::string ret;
        char str[1024];
        snprintf(str, 1024, "%d %d %d\n", label_type, data_num, dim);
        ret = std::string(str);
        return ret;
    }

} LabelDescHead;

//for reader
typedef enum {
    READER_SPEECH,
    READER_IMAGE,
    READER_DISC_IMAGE,
    READER_UNKNOWN,
} DataReaderType;

// 支持多种存储格式
// EXTRACT_SPEECH : READER_SPEECH的默认格式
// EXTRACT_WAKE_UP: READER_SPEECH支持唤醒的磁盘存储格式 
typedef enum {
    EXTRACT_SPEECH,
    EXTRACT_WAKE_UP
} SpeechExtractType;

extern const char* speech_extract_type[];
extern const char *data_reader_type_name[];

//for repository
enum DataReposType {
    REPOS_SPEECH_SENT,
    REPOS_SPEECH_FRAME,
    REPOS_SPEECH_PCM,
    REPOS_IMAGE,
    REPOS_SPEECH_SENT_3D,
    REPOS_BALANCE_SPEECH_SENT,
    REPOS_UNKNOWN
};

extern const char* repos_type_name[];

void swap32(char* c);
void swap16(char* c);

}
}

//增加参数可读性
using WidthT = size_t;
using HeightT = size_t;
using ChannelT = size_t;
using FeatureDescT = std::string;
using FeatureDescKeyT = std::string;
using FeatureKeyT = std::string;
using LabelKeyT = std::string;
using LabelDimT = size_t;
using FrameDimT = size_t;
using FrameNumT = size_t;
using SpeakerIdT = size_t;

#endif
