//by zzxfl 2016.08.30
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_SENT_REPOSITORY_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_SENT_REPOSITORY_H
#include "base_repository.h"
#include "base_repository_config.h"
#include "base_batch_sample.h"
#include "speech_batch_sample.h"
#include "speech_one_sentence.h"
#include <map>
#include <string>
#include <vector>

namespace houyi {
namespace train {
class SpeechSentRepository : public BaseRepository {
public:
    SpeechSentRepository(BaseProcesser *proc, BaseReposConfig& cfg, int device_id)
        : BaseRepository(proc, cfg, device_id) {
        _sample_random = proc->get_sample_random();
        _is_direct = cfg.get_is_direct();
    }

    virtual void reset() {
        _laster_batch = false;
        BaseRepository::reset();
    }

    virtual size_t inter_get_batch(std::vector<BaseBatchSample*> &batches, size_t max_num);

    std::map<std::string, int> get_max_frame_len(std::vector<BaseOneSample*>& samples);
    SpeechBatchSample::ParamFeatureT get_features_param(SpeechOneSentence& sample, 
            std::map<std::string, int>& max_frame_num);
    SpeechBatchSample::ParamLabelT get_labels_param(SpeechOneSentence& sample, 
            std::map<std::string, int>& max_frame_num);

protected:
    bool _sample_random = true;
    bool _is_direct = false;
};
}//houyi
}//train

#endif
