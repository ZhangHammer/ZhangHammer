//by zzxfl 2016.08.30
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_LABEL_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_LABEL_H
#include <utility>
#include <vector>
#include "base_batch_label.h"
#include "wind/wind.h"

namespace houyi {
namespace train {
class SpeechBatchLabel :public BaseBatchLabel {
    DISABLE_COPY_AND_ASSIGN(SpeechBatchLabel);
public:
    SpeechBatchLabel(LabelType type, size_t batch_size,
                     size_t frame_num, size_t label_dim):
        BaseBatchLabel(type, batch_size, label_dim) {
        _frame_num = frame_num;
        _label.resize(Dim(batch_size * frame_num, label_dim));
        _mask.resize(Dim(batch_size));
        _mask.set_element(0);
    }

    void resize(LabelType type, size_t batch_size,
            size_t frame_num, size_t label_dim) {
        _label_type = type;
        _batch_size = batch_size;
        _label_dim = label_dim;
        _frame_num = frame_num;
        _label.resize(Dim(batch_size * frame_num, label_dim));
        _mask.resize(Dim(batch_size));
        _label.set_element(0);
    }

    virtual ~SpeechBatchLabel() {
    }

    void insert(int pos, Tensor<DType>&label_val, Tensor<int>& mask_val) {
        _label.copy_row(label_val, 0, pos);
        _mask.get_block(Dim(pos), Dim(pos + 1)).copy_from(mask_val);
    }

    inline int get_frame_num() {
        return _frame_num;
    }

    inline void set_frame_num(int frame_num) {
        _frame_num = frame_num;
    }
protected:
    int _frame_num;
};

}//houyi
}//train

#endif
