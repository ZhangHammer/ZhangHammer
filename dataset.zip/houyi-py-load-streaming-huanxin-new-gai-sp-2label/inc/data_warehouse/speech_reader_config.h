//by zzxfl 2016.08.30
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_READER_CONFIG_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_READER_CONFIG_H
#include "base_reader_config.h"
#include "wind/wind.h"

namespace houyi {
namespace train {

class SpeechReaderConfig : public BaseReaderConfig {
public:
    SpeechReaderConfig() : BaseReaderConfig() {
    }

    void parse_params(std::string &config_line);

    bool get_integrity() {
        return _integrity;
    }

    inline int get_split_sentence_threshold() {
        return _split_sentence_threshold;
    }
    inline int get_split_sentence_len() {
        return _split_sentence_len;
    }
    inline int get_drop_sentence_len() {
        return _drop_sentence_len;
    }
    inline int get_min_sentence_len() {
        return _min_sentence_len;
    }
    inline std::vector<int>& get_replace_labels() {
        return _replace_labels;
    }
    inline bool get_multi_species_data() {
        return _multi_species_data;
    }
    inline SpeechExtractType get_speech_extract_type() {
        return _extract_type;
    }
    inline DType get_expand_radio() {
        return _expand_radio;
    }
    inline std::string get_all_pair_path() {
        return _all_pair_path;
    }
    inline std::string get_key_word_label_map() {
        return _key_word_label_map;
    }
    inline int get_wake_up_trans_type() {
        return _wake_up_trans_type;
    }
    inline bool get_intersection() {
        return _intersection;
    }
    inline int get_slack() {
        return _slack;
    }
    inline int get_random_group_size() {
        return _random_group_size;
    }
protected:
    int _split_sentence_threshold = 512;// 句子长度超过这个值就进行切子句
    int _split_sentence_len = 250; //子句的最小长度
    int _drop_sentence_len = -1; // 
    int _min_sentence_len = -1;
    int _slack = 0; // 语音数据加载开blance开关之后，设置slack进行松弛
    bool _integrity = false; //完整
    bool _multi_species_data = false; // 中英文混合
    bool _intersection = false; // 根据多个描述文件的file_name进行交集处理
    SpeechExtractType _extract_type = EXTRACT_SPEECH; // 默认是多特征多label格式 
    //唤醒变量
    std::string _all_pair_path = "all_pair";
    std::string _key_word_label_map = "kwd-label-map";
    //wake_up_trans_type说明:
    //1、->6720
    //2、->根据对齐结果提取有效特征
    int _wake_up_trans_type = 0;
    DType _expand_radio = 1.0f;
    //
    int _random_group_size = -1;
    std::vector<int> _replace_labels;
};

} // namespace train
} // namespace houyi

#endif
