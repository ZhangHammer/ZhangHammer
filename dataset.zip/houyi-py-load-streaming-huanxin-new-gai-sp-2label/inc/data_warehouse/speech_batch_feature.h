// by zzxfl 2016.11.10
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_FEATURE_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_BATCH_FEATURE_H
#include <utility>
#include <vector>
#include "data_tool.h"
#include "base_batch_feature.h"

namespace houyi {
namespace train {

class SpeechBatchFeature: public BaseBatchFeature {
    DISABLE_COPY_AND_ASSIGN(SpeechBatchFeature);
public:
    SpeechBatchFeature(DataType type, int batch_size, int frame_num, int frame_dim):
        BaseBatchFeature(type, batch_size), _frame_num(frame_num), _frame_dim(frame_dim) {
        _feature.resize(Dim(batch_size * frame_num, frame_dim));
        _mask.resize(Dim(batch_size));
        _mask.set_element(0);
    }

    virtual ~SpeechBatchFeature() {
    }

    void resize(DataType type, int batch_size, int frame_num, int frame_dim) {
        _feature_type = type;
        _batch_size = batch_size;
        _frame_num = frame_num;
        _frame_dim = frame_dim;
        _feature.resize(Dim(batch_size * frame_num, frame_dim));
        _mask.resize(Dim(batch_size * frame_num));
        _mask.set_element(0);
    }

    void set_feature(Tensor<DType>&data, size_t idx) {
        Dim start(idx, 0);
        Dim stop(idx + 1, _frame_dim);
        _feature.get_block(start, stop).copy_from(data);
    }

    Tensor<DType> get_feature(size_t idx) {
        Dim start(idx, 0);
        Dim stop(idx + 1, _frame_dim);
        return _feature.get_block(start, stop);
    }

    int get_frame_dim() {
        return _frame_dim;
    }

    int get_frame_num() {
        return _frame_num;
    }

    void set_frame_num(int frame) {
        _frame_num = frame;
    }
private:
    int _frame_num;
    int _frame_dim;
};

}
}

#endif
