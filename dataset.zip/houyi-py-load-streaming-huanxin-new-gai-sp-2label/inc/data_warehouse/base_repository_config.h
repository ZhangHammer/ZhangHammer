/**
 * base_repository_config.h
 *
 * Author: lifeng(lifeng20@baidu.com)
 * Created on: 2016-03-09
 *
 * Copyright (c) baidu.com, Inc. All Rights Reserved
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_BASE_REPOSITORY_CONFIG_H
#define HOUYI_DATA_WAREHOUSE_BASE_REPOSITORY_CONFIG_H
#include <string>
#include <vector>
#include <map>
#include "wind/wind.h"
#include "parse_string.h"
#include "text_utils.h"
#include "base_processer_config.h"
#include "base_reader_config.h"
#include "train_type.h"

namespace houyi {
namespace train {

class BaseReposConfig {
public:
    BaseReposConfig() {
        init();
    }
    BaseReposConfig(DataReposType type) {
        init();
        _type = type;
    }
    virtual ~BaseReposConfig () {
        if (_reader_cfg) {
            delete _reader_cfg;
            _reader_cfg = NULL;
        }
        if (_proc_cfg) {
            delete _proc_cfg;
            _proc_cfg = NULL;
        }
    }

    inline int get_align_speech_sentence() {
        return _align_speech_sentence;
    }

    virtual void read(const char *cfg_file);

    inline int get_batch_size() {
        return _batch_size;
    }

    inline bool is_async() {
        return _is_async;
    }

    inline size_t get_max_buf_num() {
        return _max_buf_num;
    }

    inline DataReposType get_type() const {
        return _type;
    }

    inline BaseReaderConfig* get_reader_cfg() {
        return _reader_cfg;
    }

    inline BaseProcConfig* get_proc_cfg() {
        return _proc_cfg;
    }

    void init() {
        _type = REPOS_UNKNOWN;
        _batch_size = 0;
        _is_async = true;
        _max_buf_num = 0;

        _reader_cfg = NULL;
        _proc_cfg = NULL;
        _align_speech_sentence = 1;

        _do_splice = false;
        _left_context = 0;
        _right_context = 0;
    }

    void set_device_num(int num) {
        _reader_cfg->set_device_num(num);
        _proc_cfg->set_device_num(num);
    }

    inline std::vector<std::string> get_trans_lines() {
        return _trans_lines;
    }

    //解析输入数据的维度,输出保存在_dims中
    void parse_dims(std::string& config_lines);

    inline Dim get_dim(std::string key) {
        CHECK2(_dims.find(key) != _dims.end());
        return _dims[key];
    }

    inline std::vector<std::string> get_dim_string() {
        std::vector<std::string> keys;
        transform(_dims.begin(), _dims.end(), back_inserter(keys), 
                [](const std::map<std::string, Dim>::value_type& pair){ return pair.first;});
        return keys;
    }
    
    inline void set_train_type(TrainType train_type) {
        _reader_cfg->set_train_type(train_type);
    }

    inline bool get_do_splice() const {
        return _do_splice;
    }   

    inline size_t get_left_context() const {
        return _left_context;
    }   

    inline size_t get_right_context() const {
        return _right_context;
    }
    inline bool get_is_direct() const {
        return _is_direct;
    }
    inline int get_device_num() const {
        return _device_num;
    }
protected:
    DataReposType _type;
    int _batch_size;
    bool _is_async;
    size_t _max_buf_num;
    int _device_num = 0;
    int _align_speech_sentence;
    std::vector<std::string> _trans_lines;

    BaseReaderConfig* _reader_cfg;
    BaseProcConfig*  _proc_cfg;

    //描述输入网络的数据格式为dim=[key:1,2,3][key1:2,4,5]
    std::map<std::string, Dim> _dims;
    
    // Parameters for speech-frame train
    bool _do_splice;
    size_t _left_context;
    size_t _right_context;

    // 选择拼batch的方式
    bool _is_direct = false;

};

}
}

#endif
