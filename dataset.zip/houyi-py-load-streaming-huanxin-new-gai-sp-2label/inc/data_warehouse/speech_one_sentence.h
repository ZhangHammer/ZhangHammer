//by zzxfl 2016.08.30
/*
 * modify by zzxfl 2016.11.03 :
 * 1、支持多标签多特征(仅仅是预留接口，保持兼容性，等多标签多label的打包格式确定之后再细化)
 * 2、由于要兼容老的格式, 如分子句接口还有不少未定义的行为
 *
 */
#ifndef HOUYI_DATA_WAREHOUSE_SPEECH_ONE_SENTENCE_H
#define HOUYI_DATA_WAREHOUSE_SPEECH_ONE_SENTENCE_H
#include "base_one_sample.h"
#include "speech_one_label.h"
#include "speech_batch_label.h"
#include "speech_one_feature.h"
#include "base_one_label.h"
#include "wind/wind.h"
#include "speech_batch_sample.h"
#include <map>
#include <string>
#include <utility>
#include <atomic>

namespace houyi {
namespace train {

class SpeechOneSentence : public BaseOneSample {
public:
    using ParamFeatureT = std::map<FeatureKeyT, std::tuple<DataType, FrameNumT, FrameDimT, SpeakerIdT> >;
    using ParamLabelT = std::map<LabelKeyT, std::tuple<LabelType, FrameNumT, LabelDimT> >;

public:

    SpeechOneSentence() : BaseOneSample() {
    }
    virtual ~SpeechOneSentence();
    SpeechOneSentence(
        ParamFeatureT features,
        ParamLabelT labels,
        std::map<std::string, std::string> file_name
    );
    
    SpeechOneSentence(SpeechOneSentence& sentence);

    void copy_from(SpeechOneSentence& sentence);

    void resize(ParamFeatureT features,
            ParamLabelT labels,
            std::map<std::string, std::string> file_name);

    inline Tensor<DType>& get_split_head() {
        return _split_head;
    }

    inline Tensor<DType>& get_split_tail() {
        return _split_tail;
    }

    int copy_next_frame(SpeechBatchSample& bat,
                        int fill_pos, int fetch_pos = -1);

    int copy_spliced_frame(SpeechBatchSample& bat, int fill_pos, int fetch_pos, int left_context, int right_context);

    void copy_sent(SpeechBatchSample& bat, int batch_size, int batch_id);
    
    // batch * frame_num * frame_dim
    void copy_sent_direct(SpeechBatchSample& bat, int batch_size, int batch_id);

    inline int get_frame_dim(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
        return feature->get_frame_dim();
    }

    inline void set_frame_dim(std::string key, int frame_dim) {
        CHECK2(_features.find(key) != _features.end());
        SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
        feature->set_frame_dim(frame_dim);
    }

    inline int get_frame_num(std::string key) {
        if (_features.find(key) != _features.end()) {
            SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
            return feature->get_frame_num();
        }
        if (_labels.find(key) != _labels.end()) {
            SpeechOneLabel* label = dynamic_cast<SpeechOneLabel*>(_labels[key]);
            return label->get_frame_num();
        }
        CHECK(false, ("get_frame_num fail: " + key).c_str());
        return 0;
    }

    //所有特征和标签的帧数一样
    inline int get_frame_num() {
        CHECK2(_feature_keys.size());
        SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[_feature_keys[0]]);
        return feature->get_frame_num();
    }

    inline void set_frame_num(std::string key, int frame_num) {
        if (_features.find(key) != _features.end()) {
            SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
            feature->set_frame_num(frame_num);
        }
        else if (_labels.find(key) != _labels.end()) {
            SpeechOneLabel* label = dynamic_cast<SpeechOneLabel*>(_labels[key]);
            label->set_frame_num(frame_num);
        }
        else {
            CHECK(false, "set_frame_num fail");
        }
    }

    virtual int read_feature(std::string key, BaseStream& in_stream, size_t st_position_in_byte, size_t size_in_byte);
    virtual int read_label(std::string key, BaseStream& in_stream, size_t st_position_in_byte, size_t size_in_byte);

    inline int get_speaker_id(std::string key) {
        CHECK2(_features.find(key) != _features.end());
        SpeechOneFeature* feature = dynamic_cast<SpeechOneFeature*>(_features[key]);
        return feature->get_speaker_id();
    }

    /*兼容单标签单特征*/
    inline SpeechOneFeature& get_default_feature() {
        CHECK2(_features.size());
        SpeechOneFeature* feature = NULL;
        for (auto feat : _features) {
            feature = dynamic_cast<SpeechOneFeature*>(feat.second);
        }
        return *feature;
    }

    /*兼容单标签单特征*/
    inline SpeechOneLabel& get_default_label() {
        CHECK2(_labels.size());
        SpeechOneLabel* label = NULL;
        for (auto lab: _labels) {
            label = dynamic_cast<SpeechOneLabel*>(lab.second);
        }
        return *label;
    }

    //inline size_t get_label_dim(std::string key) {
    //    SpeechOneLabel* label = dynamic_cast<SpeechOneLabel*>(get_label(key));
    //    return label->get_label_dim();
    //}
    /*
     *
     * bref: 1、将本句子切成多个子句
     *       2、切子句成功，将子句放在sent中,return 句子的个数;
     *       3、不需要切子句;
     *       4、上层需要对本句子进行处理
     *       5、如果特征或者标签的帧数不一致，这种未定义行为无法处理，所以切子句的逻辑只支持单特诊单标签
     * perturb:  随机扰动，默认为50,切子句的长度为sub_seq_size + random() % perturb
     * sub_seq_size:  子句的基本长度，默认为250
     * split_sentence_threshold: 切子句的阈值，句子操作这个长度就进行切子句
     * integrity : 完整性
     *
     *
     */
    int split_sentence(std::vector<BaseOneSample*>&sent, int perturb, int sub_seq_size, int split_sentence_threshold, bool integrity);

    void replace_label(int old_label, int new_label);
private:
    Tensor<DType>_split_head;
    Tensor<DType>_split_tail;
};
}//houyi
}//train

#endif
