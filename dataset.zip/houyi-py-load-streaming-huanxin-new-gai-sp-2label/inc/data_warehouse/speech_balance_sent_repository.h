//by zhxfl 2020.06.11
#pragma once
#include "base_repository.h"
#include "base_repository_config.h"
#include "base_batch_sample.h"
#include "speech_batch_sample.h"
#include "speech_one_sentence.h"
#include <map>
#include <string>
#include <vector>

namespace houyi {
namespace train {
class SpeechBalanceSentRepository : public BaseRepository {
public:
    SpeechBalanceSentRepository(BaseProcesser *proc, BaseReposConfig& cfg, int device_id)
        : BaseRepository(proc, cfg, device_id) {
        _sample_random = proc->get_sample_random();
        _is_direct = cfg.get_is_direct();
        _device_num = cfg.get_device_num();
    }

    virtual void reset() {
        _laster_batch = false;
        BaseRepository::reset();
    }

    virtual size_t inter_get_batch(std::vector<BaseBatchSample*> &batches, size_t max_num);

    std::map<std::string, int> get_max_frame_len(std::vector<BaseOneSample*>& samples);
    SpeechBatchSample::ParamFeatureT get_features_param(SpeechOneSentence& sample, 
            std::map<std::string, int>& max_frame_num);
    SpeechBatchSample::ParamLabelT get_labels_param(SpeechOneSentence& sample, 
            std::map<std::string, int>& max_frame_num);

    float cal_phi(int num_sent, float max_frame) {
        return 1.0f * num_sent * (std::pow(max_frame, 1.05f));
    }

    //float cal_phi(int num_sent, float max_frame, float max_label) {
    //    return 3.79970898e-09 * num_sent * (std::pow(max_frame, 2.0f)) + 1.67208932e-05 * num_sent * max_frame + 2.66662920e-04 * num_sent + 1.23564540e-01 - 1.62752366e-08 * (std::pow(max_frame, 2.0f)) - 3.76390668e-05 * max_frame + 4.00680746e-07 * num_sent * (std::pow(max_label, 2.0f)) + 3.32386484e-05 * num_sent * max_label - 5.01529920e-06 * (std::pow(max_label, 2.0f)) + 1.59476158e-04 * max_label;
    //}


    std::vector<std::vector<BaseOneSample*>> balance_split_sent(std::vector<BaseOneSample*>& samples_vec, int device_num);
    void find_num_sent(float tgt_phi, int start_pos, std::vector<BaseOneSample*>& vec, 
        int& num, float& out_phi);
    void update_phi(float all_phi, std::vector<BaseOneSample*>& vec, 
            std::vector<float>&phis, std::vector<int>&sents_num);

protected:
    bool _sample_random = true;
    bool _is_direct = false;
    int _device_num = 0;
};
}//houyi
}//train
