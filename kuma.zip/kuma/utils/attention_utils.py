"""Common Attention utils"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math

import tensorflow as tf
import tensorflow.keras.layers as layers

def scale_dot_product_attention(q, k, v, bias, dropout_rate):
    """
    compute attention weight with scale_dot_product algrothm 

    Args:
        q: a Tensor with shape [batch, heads, q_len, q_size]
        k: a Tensor with shape [batch, heads, k_len, q_size]
        v: a Tensor with shape [batch, heads, k_len, v_size]
        mask: a Tensor with shape could be cast to [batch, heads, k_len, v_size]
        dropout_rate: float number

    Returns:
        output: weighted results, a Tensor with the same shape as 1
        att_weight: attention weight, a Tensor with the same shape as q 
        
    """

    qk_mul = tf.matmul(q, k, transpose_b=True)  #[batch, heads, q_len, k_len]
    dk = tf.cast(tf.shape(k)[-1], tf.float32)
    qk_mul = qk_mul / tf.math.sqrt(dk)

    if bias is not None:
        qk_mul = qk_mul + bias

    """Do softmax on the last dim, e.g. k_len"""
    attention_weights = tf.nn.softmax(qk_mul, axis=-1)
    attention_weights = tf.nn.dropout(attention_weights, dropout_rate)
    output = tf.matmul(attention_weights, v)

    return output, attention_weights

class MultiHeadAttention(layers.Layer):
    def __init__(self,
            num_units,
            num_heads,
            att_units = None,
            dropout_rate = 0.0,
            name="mha"):
        super(MultiHeadAttention, self).__init__(name=name)
        self.num_heads = num_heads
        self.num_units = num_units
        self.att_units = num_units if att_units is None else att_units
        self.dropout_rate = dropout_rate

        assert(self.att_units % num_heads == 0)

        self.q_w = layers.Dense(self.att_units) ## weight of query
        self.k_w = layers.Dense(self.att_units) ## weight of key
        self.v_w = layers.Dense(self.att_units) ## weight of value

        self.depth = self.att_units // self.num_heads

        self.dense = layers.Dense(self.num_units)

    def split_heads(self, x, batch_size):
        """
        Split last dim into num_heads

        Args:
            x: a Tensor with shape [batch, length, hidden_units]
            batch_size: a Tensor with only one scalar 

        Returns:
            a Tensor with shape [batch, num_heads, length, hidden_units // num_heads]
        """
        x = tf.reshape(x, (batch_size, -1, self.num_heads, self.depth))
        return tf.transpose(x, perm=[0, 2, 1, 3])

    def call(self, q, k, v, bias):
        """
        compute multi-head scale_dot_product attention

        Args:
            same as scale_dot_product 

        Returns: 
            output: concated weight results, a Tensor with shape[batch, length, dim]
        """ 
        
        batch_size = tf.shape(q)[0]

        q = self.q_w(q)  #from dim to num_units, [batch, len, num_units] 
        k = self.k_w(k)  #from dim to num_units, [batch, len, num_units] 
        v = self.k_w(v)  #from dim to num_units, [batch, len, num_units] 

        q_split = self.split_heads(q, batch_size)
        k_split = self.split_heads(k, batch_size)
        v_split = self.split_heads(v, batch_size)

        output, att_w = scale_dot_product_attention(q_split, k_split, v_split, bias, self.dropout_rate)
        output = tf.transpose(output, perm=[0,2,1,3])
        output = tf.reshape(output, (batch_size, -1, self.att_units))
        output = self.dense(output)

        return output, att_w

def attention_bias_lower_triangle(length, time_ahead=-1):
    """
    Create an bias Tensor to add on attention logits. 
    Mask future tokens to prevent peeping later information.

    Args:
        length: a Scalar.

    Returns:
        a Tensor with shape [1, 1, length, length]
    """

    time_ahead = tf.math.minimum(length, time_ahead)
    lower_triangle = tf.linalg.band_part(tf.ones([length, length]), time_ahead, 0)
    ret = -1e30 * (1.0 - lower_triangle)
    return tf.reshape(ret, [1, 1, length, length])

def attention_bias_ignore_padding(padding):
    """
    Create bias Tensor to add on attention logits.
    Mask invalid tokens according to the padding.
    
    Args:
        padding: a Tensor with shape [batch_size, length] 

    Returns:
        a Tensor with shape [batch, 1, 1, length]

    """
    
    ret = tf.cast(padding, dtype=tf.float32) * -1e30
    return tf.expand_dims(tf.expand_dims(ret, 1), 1)

def attention_bias_dual_truncate(length, ahead, delay):
    """                                                       
    Create bias Tensor to add on attention logits.
    Mask tokens in both future and past that count 
    trunc tokens dist from current token position

    Args:
        length: a Tensor with shape [batch]
        trunc: a scalar 

    Returns:
        a Tensor with shape [batch, 1, 1, length]
    """
    ahead = tf.cast(tf.math.minimum(length, ahead), tf.int64)
    delay = tf.cast(tf.math.minimum(length, delay), tf.int64)
    front_bias = tf.linalg.band_part(tf.ones([length, length]), ahead, 0)
    back_bias = tf.linalg.band_part(tf.ones([length, length]), 0, delay)
    dual_bias = tf.math.logical_and(
        tf.cast(1 - front_bias, tf.bool), 
        tf.cast(1 - back_bias, tf.bool))
    dual_bias = tf.cast(dual_bias, tf.float32) * -1e30

    return tf.reshape(dual_bias, [1, 1, length, length])

def add_timing_signal_1d(x, min_time_scale=1.0, max_time_scale=1e5):
    """
    Add a branch of sinusoids of different frequencies to a Tensor. 
    PE(pos, 2i) = sin(pos/pow(max_time_scale, 2i/d_model))
    PE(pos, 2i+1) = cos(pos/pow(max_time_scale, 2i/d_model))

    Args:
        x: a Tensor with shape [batch, length, d_model]
        min_time_scale: a float Scalar
        max_time_scale: a float Scalar

    Returns:
        output: a Tensor with same shape as x
    """

    length = tf.shape(x)[1]
    channels = tf.shape(x)[2]
    position = tf.cast(tf.range(length), dtype=tf.float32)

    num_time_scales = channels // 2
    log_time_scale_increment = tf.math.log(float(max_time_scale) / float(min_time_scale)) / tf.cast(num_time_scales - 1, dtype=tf.float32)
    inv_time_scales = min_time_scale * tf.math.exp(tf.cast(tf.range(num_time_scales), dtype=tf.float32) * -log_time_scale_increment)
    scaled_time = tf.expand_dims(position, 1) * tf.expand_dims(inv_time_scales, 0)
    signal = tf.concat([tf.math.sin(scaled_time), tf.math.cos(scaled_time)], axis=1)
    signal = tf.pad(signal, [[0, 0], [0, channels % 2]])
    signal = tf.reshape(signal, [1, length, channels])
    return x + signal
