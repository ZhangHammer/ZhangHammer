"""Wrapper of tf.keras.layers for layers or activation implementation"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

from typing import List
from typing import Tuple 

class TransposeableDense(layers.Layer):
    """
    Dense layer whose weight is transposeable 
    """
    def __init__(self, 
                num_row, 
                num_col, 
                w_decay = 0.0001, 
                name="TD"):
        """
        Initialization
        """
        super(TransposeableDense, self).__init__(name=name)

        self.kernel = self.add_weight(
            shape=[num_row, num_col],
            initializer='glorot_uniform',
            regularizer=tf.keras.regularizers.L2(l2=w_decay),
            trainable=True, 
            name=name+"/kernel") 

    def call(self, x, transpose_w=False):
        """
        Forward of transposeable dense layer
        
        Args:
            x: a Tensor with shape [B, T, D], 
               D should be equal with num_row if
               transpose_w if False else num_col 
            transpose_w: bool

        Returns:
            out: a Tensor with shape [B, T, D2]
        """
        return tf.linalg.matmul(x, self.kernel, transpose_b=transpose_w)
        
class FeedForwardFLayer(layers.Layer): 
    """
    Point wise feed forward layer
    """
    def __init__(self, num_units, hidden_units, 
                do_layernorm=False, 
                use_bias=True, 
                activation = "relu",
                name="ffn"):
        super(FeedForwardFLayer, self).__init__(name=name)

        if activation == "glu":
            self.dense2 = layers.Dense(hidden_units, 
                    activation="sigmoid", 
                    use_bias=use_bias,
                    name=self.name+"/dense2")
            self.dense1 = layers.Dense(hidden_units, 
                    activation=None, 
                    use_bias=use_bias,
                    name=self.name+"/dense1")
        else:
            self.dense1 = layers.Dense(hidden_units, 
                    activation=activation,
                    use_bias=use_bias,
                    name=self.name+"/dense1")

        if do_layernorm:
            self.layer_norm = layers.LayerNormalization(epsilon=1e-6, name=self.name+"/layernorm0")              

        self.dense3 = layers.Dense(num_units, activation=None, use_bias=use_bias, name=self.name+"/dense3")
        self.activation = activation
        self.do_layernorm = do_layernorm

    def call(self, x):
        """
        Point-wise feed-forward layer forwad
        Args:
            x: a Tensor with shape [batch, length, num_units]
        
        Returns:
            out: a Tensor with shape [batch, length, num_units] 
        """    
        if self.do_layernorm:
            out = self.layer_norm(x)
        else:
            out = x
        
        if self.activation == "glu":
            out = self.dense1(out) * self.dense2(out)
        else:
            out = self.dense1(out)

        return self.dense3(out)

class ComplexConv(layers.Layer):
    """
    Complex convolution layer
    """ 
    def __init__(self, kernel_h, kernel_w, stride_h, stride_w, channel, 
            use_bias=True, stream_mode=False, name="complex_conv", w_decay=0.0001):
        super(ComplexConv, self).__init__(name=name)

        self.w_real = layers.Conv2D(channel, 
                (kernel_h, kernel_w),
                (stride_h, stride_w),
                activation=None,  padding='valid', 
                kernel_regularizer=tf.keras.regularizers.L2(l2=w_decay),
                use_bias=False, name=name+'/w_real')

        self.w_imag = layers.Conv2D(channel, 
                (kernel_h, kernel_w), 
                (stride_h, stride_w), 
                activation=None, padding='valid', 
                kernel_regularizer=tf.keras.regularizers.L2(l2=w_decay),
                use_bias=False, name=name+'/w_imag')

        if use_bias:
            self.bias_real = tf.Variable(initial_value = tf.zeros([channel]),
                trainable=True, name=name+'/bias_real')
            self.bias_imag = tf.Variable(initial_value = tf.zeros([channel]),
                trainable=True, name=name+'/bias_imag')

        self.use_bias = use_bias
        self.kernel_h = kernel_h
        self.stride_h = stride_h
        self.stream_mode = stream_mode

    def call(self, X, L):
        """
        Complex convlution forward 

        Args:
            X: a complex Tensor with shape [batch, length, width, in_channel]
            L: a Tensor with shape [batch]

        Returns:
            out: a complex Tensor with shape [batch, length, width, channel]
            padding: a Tensor with shape [batch, out_length]
        """

        if self.stream_mode:
            X = tf.pad(X, [[0, 0], [2, 0], [1, 1], [0, 0]], "CONSTANT")
        else:
            X = tf.pad(X, [[0, 0], [1, 1], [1, 1], [0, 0]], "CONSTANT")

        Xr = tf.math.real(X)  
        Xi = tf.math.imag(X)

        out_real_r = self.w_real(Xr)
        out_real_i = self.w_imag(Xr)
        out_imag_r = self.w_real(Xi)
        out_imag_i = self.w_imag(Xi)

        out_real = out_real_r - out_real_i
        out_imag = out_imag_r + out_imag_i

        if self.use_bias:
            out_real = tf.nn.bias_add(out_real, self.bias_real)
            out_imag = tf.nn.bias_add(out_imag, self.bias_imag)

        L = (L - self.kernel_h + 2) // self.stride_h + 1
        padding = tf.cast(tf.sequence_mask(L, tf.shape(out_real)[1]), tf.float32)
        mask = tf.expand_dims(tf.expand_dims(padding, axis=-1), axis=-1)

        out_real = out_real * mask 
        out_imag = out_imag * mask 

        return tf.dtypes.complex(out_real, out_imag), padding

class ComplexFull(layers.Layer):
    def __init__(self, out_dim, use_bias, w_decay=0.0001, name='complex_full'):
        super(ComplexFull, self).__init__(name=name)

        self.w_real = layers.Dense(out_dim, use_bias=False, name=name+'/w_real', 
            kernel_regularizer=tf.keras.regularizers.L2(l2=w_decay))
        self.w_imag = layers.Dense(out_dim, use_bias=False, name=name+'/w_real', 
            kernel_regularizer=tf.keras.regularizers.L2(l2=w_decay))

        self.use_bias = use_bias
        if use_bias:
            self.bias_real = tf.Variable(initial_value = tf.zeros([out_dim]),
                trainable=True, name=name+'/bias_real')
            self.bias_imag = tf.Variable(initial_value = tf.zeros([out_dim]),
                trainable=True, name=name+'/bias_imag')

    def call(self, X, padding):
        """
        Complex convlution forward 

        Args:
            X: a complex Tensor with shape [batch, length, width]
            padding: a Tensor with shape [batch, length]
                                                                              
        Returns:
            out: a complex Tensor with shape [batch, length, out_dim]
        """
        Xr = tf.math.real(X)                                      
        Xi = tf.math.imag(X)

        out_real_r = self.w_real(Xr)
        out_real_i = self.w_imag(Xr)
        out_imag_r = self.w_real(Xi)
        out_imag_i = self.w_imag(Xi)

        out_real = out_real_r - out_real_i
        out_imag = out_imag_r + out_imag_i

        if self.use_bias:
            out_real = tf.nn.bias_add(out_real, self.bias_real)
            out_imag = tf.nn.bias_add(out_imag, self.bias_imag)

        mask = tf.expand_dims(tf.expand_dims(padding, axis=-1), axis=-1)
        out_real = out_real * mask
        out_imag = out_imag * mask

        return tf.dtypes.complex(out_real, out_imag)

class ComplexFullV2(layers.Layer):
    def __init__(self, in_dim, out_dim, use_bias, 
            w_decay=0.0001, name='complex_full'):
        super(ComplexFullV2, self).__init__(name=name)

        self.kernel = self.add_weight(
            shape=[in_dim, out_dim, 2],
            initializer='glorot_uniform',
            regularizer=tf.keras.regularizers.L2(l2=w_decay),
            trainable=True, name=name+"/kernel") 

        self.use_bias = use_bias
        if use_bias:
            self.bias = tf.add_weight(
                shape=[out_dim, 2],
                initializer='zeros',
                trainable=True,
                regularizer=tf.keras.regularizers.L2(l2=w_decay),
                name=name+'/bias')

    def call(self, X, padding):
        """
        Complex convlution forward 

        Args:
            X: a complex Tensor with shape [batch, length, width]
            padding: a Tensor with shape [batch, length]
                                                                              
        Returns:
            out: a complex Tensor with shape [batch, length, out_dim]
        """
        cplx_w = tf.dtypes.complex(self.kernel[:,:,0], self.kernel[:,:,1])

        out = tf.linalg.matmul(X, cplx_w)
        if self.use_bias:
            out += tf.dtypes.complex(self.bias[:,:,0], self.bias[:,:,1])

        return out

class FCLP(layers.Layer):
    def __init__(self, config, name='FCLP'):
        super(FCLP, self).__init__(name=name)

        self.cplx_conv = ComplexConv(
                config.complex_conv['kernel_h'],
                config.complex_conv['kernel_w'],
                config.complex_conv['stride_h'],
                config.complex_conv['stride_w'],
                config.complex_conv['channel'],
                config.complex_conv['use_bias'],
                config.complex_conv['stream'],
                name = name+'/cplx_conv')

        self.cplx_fc = ComplexFullV2(
                config.complex_full['in_dim'],
                config.complex_full['out_dim'],
                config.complex_full['use_bias'],
                name = name+'/cplx_fc')

        self.channel = config.channel
        self.fft_size = config.fft_size
        self.fft_step = config.fft_step
        self.fft_bins = config.fft_bins

    def call(self, X, L):
        """
        Complex convlution forward 

        Args:
            X: a complex Tensor with shape [batch, sample]
            L: a Tensor with shape [batch]

        Returns:
            out: a complex Tensor with shape [batch, out_length, channel, out_dim]
            padding: a Tensor with shape [batch, out_length]
        """

        batch_size = tf.shape(X)[0]
        sample_num = tf.shape(X)[1]
        X = tf.reshape(X, [batch_size, self.channel, sample_num // self.channel])
        L = tf.squeeze(L, axis=-1)
        fft_out = tf.signal.stft(X,
            frame_length=self.fft_size,
            frame_step=self.fft_step,
            window_fn=tf.signal.hamming_window) 

        fft_out = tf.reshape(fft_out, [batch_size, self.channel, -1, self.fft_bins])
        fft_out = tf.transpose(fft_out, [0, 2, 3, 1])  # [B, T, W, C]

        L = (L // self.channel - self.fft_size) // self.fft_step + 1
        out, padding = self.cplx_conv(fft_out, L)
        out = tf.transpose(out, [0, 1, 3, 2])  #[batch length, channel, in_dim]
        out = self.cplx_fc(out, padding)
        out = tf.transpose(out, [0, 1, 3, 2])  #[batch length, in_dim, channel]

        out = tf.math.abs(out)
        out = tf.math.log(out + 1e-7)
        out = out * tf.expand_dims(tf.expand_dims(padding, axis=-1), axis=-1)

        return out, padding

class MobileNetConv(layers.Layer):
    """
    Wrapper a MobileNet convolution block with one depth-wise conv, 
    one point-wise conv and layernorm and optional Max pooling
    """
    def __init__(self, channel,
            pooling_size=(2, 2), 
            pooling_stride=(2, 2),
            filter_size=(3, 3),
            pre_pooling=True,
            use_bias=False,
            activation='relu',
            name="mobile_net"):
        super(MobileNetConv, self).__init__(name=name) 

        self.pre_pooling = pre_pooling
        self.pooling_size = pooling_size
        self.pooling_stride = pooling_stride

        self.pooling = layers.MaxPool2D(
            pooling_size, 
            pooling_stride,
            padding='valid', 
            name=name+"/max_pooling"
        )

        self.p_conv = layers.Conv2D(channel, 
            (1, 1), (1, 1), 
            use_bias=use_bias, 
            name=name+'/p_conv'
        ) 
        self.p_conv_ln = layers.LayerNormalization(
            epsilon=1e-6, name=name+"/p_conv_ln"
        )
        self.d_conv = layers.DepthwiseConv2D(
            filter_size, (1, 1), 
            padding='same', 
            use_bias=use_bias, 
            name=name+'/d_conv'
        )
        self.d_conv_ln = layers.LayerNormalization(
            epsilon=1e-6, name=name+"/d_conv_ln"
        )

        self.activation = activation
        self.channel = channel 

    def call(self, X, L):
        """
        MobileNet conv forawrd

        Args:
            X: a Tensor with shape [B, T, W, C]
            L: a Tensor with shape [B]

        Returns:
            output: a Tensor with shape [B, T, W, C]
            L: a Tensor with shape [B]
        """ 

        if self.pre_pooling:
            pad_t = (self.pooling_size[0] - 1) // 2
            pad_f = (self.pooling_size[1] - 1) // 2
            X = tf.pad(X, [[0, 0], [pad_t, pad_t], [pad_f, pad_f], [0, 0]])
            X = self.pooling(X)
            L = (L + pad_t * 2) // self.pooling_stride[0]

        B = tf.shape(X)[0]
        T = tf.shape(X)[1]
        W = X.get_shape()[2]
        C = self.channel 

        X = self.p_conv(X)
        X = tf.reshape(X, [B, T, C*W])
        X = self.p_conv_ln(X)
        X = activations.swish(X) if self.activation=='swish' else activations.relu(X, max_value=6)
        X = tf.reshape(X, [B, T, W, C])
        X = self.d_conv(X)
        X = tf.reshape(X, [B, T, C*W])        
        X = self.d_conv_ln(X)
        X = activations.swish(X) if self.activation=='swish' else activations.relu(X, max_value=6)
        X = tf.reshape(X, [B, T, W, C])

        padding = tf.expand_dims(
            tf.expand_dims(
                tf.sequence_mask(L, T, tf.float32), axis=-1
            ), axis=-1
        )

        X = X * padding

        return X, L

class ViterbiAlign(layers.Layer):
    def __init__(self, head_blank, tail_blank, 
            token_repeat = 12, 
            token_weights = [1.0, 1.0],
            blank_weights = [1.0, 1.0],
            name="vtb_ali"):
        super(ViterbiAlign, self).__init__(name=name)

        self.token_repeat = token_repeat
        self.head_blank = head_blank
        self.tail_blank = tail_blank 
        self.token_weights = tf.convert_to_tensor(token_weights, tf.float32)
        self.blank_weights = tf.convert_to_tensor(blank_weights, tf.float32)

    def construct_graph(self, path):
        """
        Construct decode graph with given path
        
        Args:
            path: a 1-D Tensor

        Returns:
            graph: a Tensor with shape [repeat * n + 2]
            trans_mat: a Tensor with shape [repeat*n+2, 2]
        """
        graph = tf.reshape(path, [-1, 1]) 
        graph = tf.tile(graph, [1, self.token_repeat])
        graph = tf.reshape(graph, [-1])

        trans_mat = tf.tile(self.token_weights, [tf.shape(graph)[0]])

        head_blank = tf.constant([self.head_blank], tf.int32)
        tail_blank = tf.constant([self.tail_blank], tf.int32)

        graph = tf.concat([head_blank, graph, tail_blank], axis=0)
        trans_mat = tf.concat([self.blank_weights, trans_mat, self.blank_weights], axis=0)

        return graph, trans_mat

    def traceback(self, probs, index, L):
        """
        Trace viterbi decode path and maximum prob

        Args:
            probs: a TensorArray of size length and Tensor shape [batch, token]
            index: a TensorArray of size length and Tensor shape [batch, token]
            L: a Tensor with shape [batch, 1]

        Returns:
            slice: a Tensor with shape [batch, 2]
            score: a Tensor with shape [batch]
        """ 
        length = probs.size()

        true_prob = tf.TensorArray(dtype=tf.float32,
            size=length, name="vtb_true_prob")
        true_path = tf.TensorArray(dtype=tf.int32,
            size=length, name="vtb_true_path")

        prob_t = probs.read(length-1)
        index_t = index.read(length-1)

        batch_size = tf.shape(prob_t)[0]
        token_num = tf.shape(prob_t)[1]

        prob_t = prob_t[:,-1]
        index_t = index_t[:,-1]

        batch_indices = tf.reshape(tf.range(batch_size), [batch_size, 1])
        true_prob = true_prob.write(length-1, prob_t) 
        true_path = true_path.write(length-1, index_t)

        for t in tf.range(2, length+1):
            indices = tf.concat([batch_indices, index_t[:,None]], axis=-1)
            index_t = tf.gather_nd(index.read(length-t), indices)
            prob_t = tf.gather_nd(probs.read(length-t), indices)
            true_path = true_path.write(length-t, index_t)
            true_prob = true_prob.write(length-t, prob_t)

        true_path = tf.transpose(true_path.stack())  # [batch, length]
        true_prob = tf.transpose(true_prob.stack())  # [batch, length]

        begin = tf.math.equal(true_path, 0)
        begin = tf.reduce_sum(tf.cast(begin, tf.int32), axis=-1)
        end = tf.math.not_equal(true_path, token_num-1)
        end = tf.reduce_sum(tf.cast(end, tf.int32), axis=-1)

        eff_length = end - begin
        eff_indices = tf.cast(tf.math.greater(eff_length, 1), tf.int32)
        begin = begin * eff_indices 
        end = end * eff_indices + L * (1 - eff_indices)

        indices = tf.concat([batch_indices, end[:,None]-1], axis=-1) 
        end_prob = tf.gather_nd(true_prob, indices)
        indices = tf.concat([batch_indices, begin[:,None]], axis=-1)
        beg_prob = tf.gather_nd(true_prob, indices)

        eff_prob = end_prob - beg_prob  ## sum of effective decode token probs
        eff_prob = eff_prob / tf.cast(eff_length, tf.float32)

        return eff_prob, begin, end

    def call(self, X, path, L):
        """
        Viterib Force alignemnt forward

        Args:
            X: a Tensor with shape [batch, length, dim], probs tensor
            path: a 1-D Tensor alignment path

        Returns:
            probs: a Tensor with shape [batch] 
            index: a Tensor with shape [batch, 2]
        """

        graph, trans_m = self.construct_graph(path)

        batch_size = tf.shape(X)[0]
        length = tf.shape(X)[1]
        dim = tf.shape(X)[2]
        token_num = tf.shape(graph)[0]

        log_X = X
        log_T = trans_m + 1e-7

        ### Use TensorArray to store decode result
        #array_size = tf.reshape(length, [1])
        probs_arr = tf.TensorArray(dtype=tf.float32,
            size=length, name="vtb_probs_arr")

        index_arr = tf.TensorArray(dtype=tf.int32,
            size=length, name="vtb_index_arr")

        prob_t = tf.slice(log_X, [0, 0, self.head_blank], [batch_size, 1, 1]) 
        prob_t = tf.reshape(prob_t, [batch_size, 1])
        prob_t = tf.concat([prob_t, tf.ones([batch_size, token_num - 1], tf.float32) * -1e30], axis=-1)
        probs_arr = probs_arr.write(0, prob_t)
        index_t = tf.concat([tf.zeros([batch_size, 1], tf.int32),
            tf.ones([batch_size, token_num - 1], tf.int32) * -1], axis=-1)
        index_arr = index_arr.write(0, index_t)

        batch_indices = tf.tile(tf.range(batch_size)[:,None], [1, token_num])
        batch_indices = tf.reshape(batch_indices, [-1, 1])
        token_indices = tf.reshape(tf.tile(graph, [batch_size]), [-1, 1])

        for t in tf.range(1, length):
            num = tf.math.minimum(t, token_num)
            eff_indices = tf.cast(tf.math.greater(L, t), tf.int32)[:,None]
            t = tf.reshape(t, [1])
            t_indices = tf.tile(t, [batch_size*token_num])
            indices = tf.concat([batch_indices, t_indices[:,None], token_indices], axis=1)
            gathered = tf.gather_nd(log_X, indices)
            gathered = tf.reshape(gathered, [batch_size, token_num])

            last_probs = tf.pad(prob_t, [[0, 0], [1, 0]], "CONSTANT", -1e30)
            last_probs_shift = tf.slice(last_probs, [0, 0], [batch_size, token_num])
            val = tf.cast(tf.greater(last_probs_shift, prob_t), tf.int32)
            prob_t = tf.math.maximum(prob_t, last_probs_shift) + gathered

            new_index = tf.tile(tf.reshape(tf.range(num), [1, -1]), [batch_size, 1])
            new_index = tf.pad(new_index, [[0, 0], [0, token_num-num]], "CONSTANT", -1)

            last_index = tf.pad(new_index, [[0, 0], [1, 0]], "CONSTANT", -1)
            last_index_shift = tf.slice(last_index, [0, 0], [batch_size, token_num])
            index_t = new_index * (1 - val) + last_index_shift * val

            index_t = index_t * eff_indices + new_index * (1 - eff_indices)

            probs_arr = probs_arr.write(t[0], prob_t)
            index_arr = index_arr.write(t[0], index_t)

        probs, begin, end = self.traceback(probs_arr, index_arr, L)

        return probs, begin, end 

def scatter_values_on_batch_indices(values, batch_indices, output_shape):
    indices_shape = tf.shape(batch_indices)
    # broadcast batch dim to indices_shape
    broadcasted_batch_dims = tf.reshape(
        tf.broadcast_to(
            tf.expand_dims(tf.range(indices_shape[0]), axis=-1), indices_shape
        ),
        [1, -1],
    )
    # transform batch_indices to pair_indices
    pair_indices = tf.transpose(
        tf.concat([broadcasted_batch_dims, tf.reshape(batch_indices, [1, -1])], 0)
    )
    # scatter values to pair indices
    return tf.scatter_nd(pair_indices, tf.reshape(values, [-1]), output_shape)

def sequence_to_segments(X, window, shift):
    """
    Truncate a sequence to segmemts with given window and shift
    
    Args:
        X: a Tensor with shape [B, T, D]
        window: a scalar
        shift: a scalar 

    Returns: 
        segments: a Tensor with shape [B*N, window, D]
    """

    B, T, D = tf.shape(X)[0], tf.shape(X)[1], tf.shape(X)[2]

    """
    Compute number of segments padding 0 at the end
    """
    N = (T - window) // shift + 2
    T_pad = (N - 1) * shift + window
    X = tf.pad(X, [[0, 0], [0, T_pad - T], [0, 0]], mode="CONSTANT")

    segs_arr = tf.TensorArray(dtype=tf.float32, 
        size=B*N, name="segments_arr")

    for b in tf.range(B):
        for n in tf.range(N):
            seg = tf.slice(X, [b, n * shift, 0], [1, window, D])
            segs_arr = segs_arr.write(b*N + n, tf.squeeze(seg, axis=0))

    return segs_arr.stack(), N

def segments_to_sequence(X, shift, N, D):
    """
    Merge segments to sequence with given window and shift
    
    Args:
        X: a Tensor with shape [B*N, window, D]
        shift: a scalar
        N: a scalar
        D: a scalar

    Returns:
        seq: a Tensor with shape [B, T, D]
    """

    B, window = tf.shape(X)[0], tf.shape(X)[1]
    B = B // N

    seqs_arr = tf.TensorArray(dtype=tf.float32, size=B, 
        name="sequence_arr")
    for b in tf.range(B):
        b_seg = tf.slice(X, [b*N, 0, 0], [N-1, shift, D])
        last_seg = tf.slice(X, [b*N+N-1, 0, 0], [1, window, D])
        b_seq = tf.concat(
            [tf.reshape(b_seg, [1, (N-1)*shift, D]),
             tf.reshape(last_seg, [1, window, D])
            ], axis = 1
        )
        seqs_arr = seqs_arr.write(b, b_seq)

    return seqs_arr.stack() 
