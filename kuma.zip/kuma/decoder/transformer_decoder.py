"""Implementation of transformer decoder"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from utils.attention_utils import MultiHeadAttention, attention_bias_lower_triangle, attention_bias_ignore_padding

from utils.layer_utils import FeedForwardFLayer

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class TransformerDecoder(layers.Layer):
    def __init__(self, config, name="transformer"):
        super(TransformerDecoder, self).__init__(name=name)

        self.intra_mha = MultiHeadAttention(config.num_units,
                            config.num_heads, 
                            dropout_rate = config.att_droprate,
                            name=self.name+"/intra_mha")

        self.inter_mha = MultiHeadAttention(config.num_units,               
                            config.num_heads, 
                            dropout_rate = config.att_droprate,
                            name=self.name+"/inter_mha")

        self.pre_ffn = FeedForwardFLayer(config.num_units,
                            config.hidden_units, 
                            use_bias=True,
                            activation=config.ff_activation, 
                            do_layernorm=config.decoder_prenorm,
                            name=self.name+"/pre_ffn")

        self.pos_ffn = FeedForwardFLayer(config.num_units,
                            config.hidden_units,
                            use_bias=True,
                            activation=config.ff_activation, 
                            do_layernorm=config.decoder_prenorm,
                            name=self.name+"/pos_ffn")

        self.res_drop = [layers.Dropout(config.res_droprate, name=self.name+"/drop0"),
                         layers.Dropout(config.res_droprate, name=self.name+"/drop1"),
                         layers.Dropout(config.res_droprate, name=self.name+"/drop2"),
                         layers.Dropout(config.res_droprate, name=self.name+"/drop3")
                        ]

        self.res_ln = [layers.LayerNormalization(epsilon=1e-6, name=self.name+"/ln0"),
                       layers.LayerNormalization(epsilon=1e-6, name=self.name+"/ln1"),
                       layers.LayerNormalization(epsilon=1e-6, name=self.name+"/ln2"),
                       layers.LayerNormalization(epsilon=1e-6, name=self.name+"/ln3")
                      ]

        self.config = config
        self.use_prenorm = config.decoder_prenorm
        self.peep_later = False if config.peep_later is None else config.peep_later

    def residual(self, x, y, idx, scale=1.0, training=True):
        """Residual connection

        Args:
            x: A Tensor.
            y: A Tensor.
            do_layernorm: bool
            scale: A float range from [0, 1).

        Returns:
            A Tensor.
        """
        out = x + self.res_drop[idx](y, training=training) * scale
        if not self.use_prenorm:
            out = self.res_ln[idx](out)

        return out

    def call(self, x, y, training):
        """                                                          
        Vanilla transformer decoder layer forward

        Args:
            x: a Tensor with shape [batch, frames, num_units]
            y: a Tensor with shape [batch, tokens, num_units] 
            training: a bool 

        Returns:
            last_out: a Tensor with shape [batch, length, num_units]
        """

        """
        Self-attention on decoder input embedding
        """
        dec_out = self.residual(y, self.pre_ffn(y), idx=0, scale=0.5, training=training)

        padding = tf.cast(tf.math.equal(tf.reduce_sum(y, axis=-1), 0), tf.float32)
        intra_mha_bias = attention_bias_ignore_padding(padding) if self.peep_later else attention_bias_lower_triangle(tf.shape(y)[1]) 
        intra_mha_out, _ = self.intra_mha(dec_out, dec_out, dec_out, intra_mha_bias)

        dec_out = self.residual(dec_out, intra_mha_out, idx=1, scale=1.0, training=training)

        """
        Cross-attention between deocder input and encoder output
        """

        enc_padding = tf.equal(tf.reduce_sum(tf.math.abs(x), axis=-1), 0)
        inter_mha_bias = attention_bias_ignore_padding(enc_padding)

        inter_mha_out, _ = self.inter_mha(dec_out, x, x, inter_mha_bias)
        dec_out = self.residual(dec_out, inter_mha_out, idx=2, scale=1.0, training=training)

        dec_out = self.residual(dec_out, self.pos_ffn(dec_out), idx=3, scale=0.5, training=training)

        return dec_out
