"""
Implementation of LSTM with residual and layernorm  
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
from tensorflow.keras import layers

class ResidualLstm(layers.Layer):
    """
    Implementation of LSTM with resudial connection and layernorm
    Args:
        config: yaml config tuple
        return_sequence: bool whether return whole sequence output or only the last time step output
        return_state: bool whether return lstm state
    """
    def __init__(self, config,
            return_sequences = True,
            return_state = False,
            name="ResidualLstm"):
        super(ResidualLstm, self).__init__(name=name)

        #self.initializer = tf.keras.initializers.RandomNormal(
        #        mean=0.0, stddev=0.02, seed=None)

        """
        Use default configuration, such as:
        activation = tanh, recurrent_act = sigmoid
        """
        self.lstm = layers.LSTM(
                config.cell_units,
                activation = 'tanh',
                return_sequences = return_sequences,
                return_state = return_state,
                name = self.name + "lstm")

        self.proj = layers.Dense(
                config.num_units,
                activation = 'linear')

        self.drop = layers.Dropout(
                config.droprate,
                name = self.name + "drop")

        self.ln = layers.LayerNormalization(
                epsilon = 1e-3, # same with houyi
                name = self.name + "ln")

        self.return_state = return_state
        self.config = config

    def call(self, X, training, init_state=None):
        """
        Residual LSTM forward

        Args:
            X: a Tensor with shape [B, T, self.num_units]
            mask: a Tensor with shape [B, T, 1]
            training: bool

        Returns:
            out: a Tensor with shape [B, T, self.num_units]
        """ 

        if not self.return_state:
            out = self.proj(self.lstm(X))
            out = X + self.drop(out, training = training)

            return self.ln(out)
        else:
            if init_state is not None:
                out, state_h, state_c = self.lstm(X, initial_state=init_state)
            else:
                out, state_h, state_c = self.lstm(X)

            out = X + self.drop(self.proj(out), training=training)

            return self.ln(out), state_h, state_c 
