"""
Implementation of RNN-T decoder including:
    1. joint network
    2. RNN-T loss 
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from utils.layer_utils import FeedForwardFLayer

import tensorflow as tf
from tensorflow.keras import layers, activations, models

from cpp import rnnt_loss

class RnntDecoder(layers.Layer):
    """
    RNN-T implementation 
    """
    def __init__(self, config, name="RNN-T"):
        super(RnntDecoder, self).__init__(name=name)

    def joint_network(a_enc, a_padding, l_enc, l_padding, joint_type="add"):
        """
        RNN-T joint network, generate RNN-T search graph

        Args:
            a_enc: a Tensor with shape [B, T, D]
            l_enc: a Tensor with shape [B, U, D]
            a_padding: a Tensor with shape [B, T]
            l_padding: a Tensor with shape [B, U]
            joint_type: a string
        
        Returns:
            out: a Tensor with shape [B, T*U, D]
                 which is a memory NOT efficient manner
        """
        T = tf.shape(a_enc)[1]
        U = tf.shape(l_enc)[1] 
        out = tf.tile(a_enc, [1, 1, U, 1]) + tf.tile(l_enc, [1, T, 1, 1])
        out_mask = tf.tile(a_padding, [1, 1, U]) + tf.tile(l_padding, [1, T, 1]) 

        return out * out_mask

    def rnnt_loss_itf(logit, labels, logit_len, label_len, blank = 0):
        """
        RNN-T loss computation 

        Args:
            logit: a Tensor with shape [B, T, U+1, V], 
                   RNN-T joint network output without  
                   softmax or log_softmax activation
            label: a Tensor with shape [B, U] 
            logit_len: a Tensor with shape [B]
            label_len: a Tensor with shape [B]
            blank_id: a scalar
                                                        
        Returns:
            loss: a Tensor with shape [B, 1]
        """ 
        return rnnt_loss(logit, labels, logit_len, label_len, blank)
