"""Implentation of feature extraction"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math
import re
import numpy as np
import py_data_load
import logging
import tensorflow as tf

def fbank_loader(lines):
    import struct
    key_num_data = []
    for line in lines:
        ark, scp, label, label_desc = line.strip().split()
        pcmfile = open(ark, "rb")
        pcmdata= pcmfile.read()
        txtfile = open(label, "rb")
        txtdata = txtfile.read()

        pcm_key_note = {}
        for key_note in open(scp).readlines()[1:]:
            key, _= key_note.strip().split(" ", 1)
            pcm_key_note[key] = key_note 

        for key_note in open(label_desc).readlines()[1:]:
            items = key_note.strip().split()
            if items[0] not in pcm_key_note:
                continue

            # load pcm data
            items = pcm_key_note[items[0]].strip().split()
            beg_in_bytes = int(items[2])
            end_in_bytes = beg_in_bytes + int(items[3])
            samples = int(items[3]) // 4
            pcms = pcmdata[beg_in_bytes:end_in_bytes]
            pdata = struct.unpack("{}f".format(samples), pcms)

            items = key_note.strip().split()
            beg_in_bytes = int(items[2])
            end_in_bytes = beg_in_bytes + int(items[3])
            tokens = int(items[3]) // 4
            txts = txtdata[beg_in_bytes:end_in_bytes]
            tdata = struct.unpack("{}i".format(tokens), txts)
            tdata_uniq = [0]
            for t in tdata[1:]:
                if t != tdata_uniq[-1] and t != 1748 and t != 0:
                    tdata_uniq.append(t)
            tdata_uniq.append(1749)
            #print(tdata_uniq)
            #print(tdata)
            key_num_data.append((items[0], samples, len(tdata_uniq)-1, pdata, tdata_uniq[1:]))

    return key_num_data

class DataReader(object):
    """
    Read data and create batches for training and testing.
    """

    def __init__(self, config, is_training=True):
        self._config = config
        self._py_data_load = self._py_data_load_init(self._config.train.houyi_data_config) if is_training else None 
        self._testdata = self.load_testset() if not is_training else None
        self._dim = self._config.Fbank.bins if self._config.Fbank is not None else 1
        self.keyword = [] 
        if config.viterbi is not None:
            for word, path in config.viterbi.decode_path.items():
                self.keyword.append(path)

    def _py_data_load_init(self, houyi_data_config):
        return py_data_load.PyDataLoad(houyi_data_config)

    def multi_channel_reshape(self, feat, sample_num, batch_size):
        if self._config.input_channel == 1:
            return np.copy(feat) 

        feat_copy = np.zeros([batch_size, feat.shape[1]])
        len_per_chan = feat.shape[1] // self._config.input_channel

        for b in range(batch_size):
            num = int(sample_num[b]) // self._config.input_channel
            for c in range(self._config.input_channel):
                start = len_per_chan * c 
                feat_copy[b,start:start+num] = feat[b,c*num:(c+1)*num]

        return feat_copy

    def keyword_path_search(self, label_batch, batch_size):
        new_label = np.zeros([batch_size, 1], np.float32)
        matched_num = 0
        for b in range(batch_size):
            label_str = ' '.join([str(v) for v in label_batch[b]])
            for key in self.keyword:
                if re.search(key, label_str):
                    new_label[b, 0] = 1.0 
                    break

        return new_label
                    
    def get_training_batch(self):
        num_gpus = self._config.train.num_gpus

        while True:
            batch = self._py_data_load.load_datam(1)
            if batch.is_none():
                break

            feat = batch.feat()[0]
            input_label = batch.input_label()[0]
            output_label = batch.output_label()[0]
            sample_num = batch.mask()[0]
            batch_size = batch.batch_size()[0]

            feat = np.reshape(feat, [batch_size, -1])
            input_label = np.reshape(input_label, [batch_size, -1])
            output_label = np.reshape(output_label, [batch_size, -1])
            sample_num = np.reshape(sample_num, [batch_size, -1])

            feat_copy = self.multi_channel_reshape(feat, sample_num, batch_size)
            input_label_copy = np.copy(input_label)
            output_label_copy = np.copy(output_label)
            sample_num_copy = np.copy(sample_num)

            if self._config.viterbi is not None:
                keyword_match_label = self.keyword_path_search(input_label_copy, batch_size)
                output_label_copy = np.concatenate((keyword_match_label, output_label_copy), axis=-1)

            tot_sample_num = np.sum(sample_num_copy)
            num_per_device = tot_sample_num // num_gpus

            device_id = 0
            begin = np.zeros([num_gpus, 2])
            slice_f = np.zeros([num_gpus, 2])
            slice_l = np.zeros([num_gpus, 2])

            temp_num = 0
            temp_pos = 0
            for i in range(batch_size):
                temp_num += sample_num[i]
                if temp_num >= num_per_device * (device_id + 1):
                    begin[device_id, 0] = temp_pos
                    begin[device_id, 1] = 0
                    slice_f[device_id, 0] = i - temp_pos + 1
                    slice_f[device_id, 1] = np.max(sample_num[temp_pos:i]) * self._dim
                    slice_l[device_id, 0] = i - temp_pos + 1
                    slice_l[device_id, 1] = input_label.shape[1]
                    device_id += 1
                    temp_pos = i + 1

            yield (feat_copy, input_label_copy, output_label_copy, sample_num_copy, begin, slice_f, slice_l)

    def get_training_batches(self):
        num_gpus = self._config.train.num_gpus

        while True:
            batch = self._py_data_load.load_datam(num_gpus)
            if batch.is_none():
                break

            feat = batch.feat()
            input_label = batch.input_label()
            output_label = batch.output_label()
            sample_num = batch.mask()
            batch_size = batch.batch_size()

            if len(feat) != num_gpus or len(input_label) != num_gpus or len(output_label) != num_gpus or len(batch_size) != num_gpus or len(sample_num) != num_gpus:
                continue

            total_batch_size = 0
            feats = []
            input_labels = []
            output_labels = []
            sample_nums = []
            for i in range(num_gpus):
                sub_batch_size = batch_size[i]

                total_batch_size += sub_batch_size
                feat[i] = np.reshape(feat[i], [sub_batch_size, -1, 1])
                input_label[i] = np.reshape(input_label[i], [sub_batch_size, -1])
                output_label[i] = np.reshape(output_label[i], [sub_batch_size, -1])

                feat_copy = self.multi_channel_reshape(feat[i], sample_num[i], sub_batch_size)
                input_label_copy = np.copy(input_label[i])
                output_label_copy = np.copy(output_label[i])
                sample_num_copy = np.copy(sample_num[i])

                feats.append(feat_copy)
                input_labels.append(input_label_copy)
                output_labels.append(output_label_copy)
                sample_nums.append(sample_num_copy)

            yield (feats, input_labels, output_labels, sample_nums, total_batch_size)

    def load_testset(self):
        import multiprocessing as mp

        num_loaders = 5
        testset = self._config.test.testset
        print("Loading testdata from {}".format(testset))
        keys, nums, pcms, txts, toks = [], [], [], [], []

        with open(testset, "r") as testfile:
            lines = testfile.readlines()

        pool = mp.Pool(num_loaders)
        sub_line_num = (len(lines) + num_loaders - 1) // num_loaders
        split_lines = []
        for i in range(num_loaders):
            start_idx = i * sub_line_num
            end_idx = (i + 1) * sub_line_num
            if end_idx >= len(lines):
                end_idx = len(lines)

            split_lines.append(lines[start_idx:end_idx])

        key_num_data_all = pool.map(fbank_loader, split_lines)
        pool.close()

        for key_num_data_group in key_num_data_all:
            for key_num_data in key_num_data_group:
                key, num, tok, data, txt = key_num_data
                keys.append(key)
                nums.append(num)
                pcms.append(data)
                txts.append(txt)
                toks.append(tok)
                    
        total_pcms = len(keys) 
        logging.info("{} test pcms loaded".format(total_pcms))    
        return (keys, nums, pcms, txts, toks)

    def get_testing_batches(self):
        batch_size = self._config.test.batch_size
        keys, nums, pcms, txts, toks = self._testdata
        total_pcms = len(keys)
        batches = (total_pcms + batch_size - 1) // batch_size    

        for n in range(batches):
            start = n * batch_size
            end = (n + 1) * batch_size if (n + 1) * batch_size < total_pcms else total_pcms

            batch_keys = keys[start:end]
            new_pcms = pcms[start:end]
            new_txts = txts[start:end]
            new_nums = nums[start:end]
            new_toks = toks[start:end]

            batch_len = np.array(new_nums, dtype=np.int32)
            batch_len = np.reshape(batch_len // self._dim, [-1, 1])
            new_batchsize = len(new_nums)
            max_samples = max(new_nums)
            len_per_chan = max_samples // self._config.input_channel
            max_txt_tokens = max(new_toks)
            batch_feat = np.zeros([new_batchsize, max_samples], dtype=np.float32)
            batch_txt = np.zeros([new_batchsize, max_txt_tokens], dtype=np.int32)

            for idx in range(new_batchsize):
                num = new_nums[idx] // self._config.input_channel
                for c in range(self._config.input_channel):
                    pcm = new_pcms[idx][c*num:(c+1)*num]
                    np_pcm = np.array(pcm, dtype=np.float32)
                    pcm_start = c * len_per_chan
                    batch_feat[idx, pcm_start:pcm_start+num] = np_pcm
                batch_txt[idx, :new_toks[idx]] = np.array(new_txts[idx], dtype=np.int32)

            yield (batch_keys, batch_feat, batch_len, batch_txt)

    def reset(self):
        self._py_data_load.reset()


def pcm2fbank(x, sample_rate=16000, low_freq=0, high_freq=8000, num_bins=80):
    """
    Compute fbank. Some  

    Args:
        x: a Tensor with shape [batch, length, 1]
    
    Returns:
        log_mel_spectrograms: a Tensor with shape [batch, lenght, num_bins]
    """
    x = tf.squeeze(x, axis=2)
    stfts = tf.signal.stft(x, frame_length=400, frame_step=160, window_fn=tf.signal.hamming_window)

    magnitude = tf.math.abs(stfts) * tf.math.abs(stfts)
    mel_weight = tf.signal.linear_to_mel_weight_matrix(num_bins, tf.shape(magnitude)[-1], sample_rate, low_freq, high_freq) 

    mel_spectrograms = tf.tensordot(magnitude, mel_weight, 1) 
    mel_spectrograms.set_shape(magnitude.shape[:-1].concatenate(mel_weight.shape[-1:]))  
    mel_spectrograms = mel_spectrograms + 1e-7
    mel_spectrograms = tf.math.maximum(mel_spectrograms, 1.0)
    log_mel_spectrograms = tf.math.log(mel_spectrograms)

    return log_mel_spectrograms

def compute_delta(x, window, order, sigma, lctx, rctx):
    """
    Compute delta feature of time-frequency feature, such as fbank
    
    Args:
        x: a Tensor with shape [batch, length, dim]
        window: a scalar
        order: a scalar
        sigma: a scalar
        lctx: a scalar
        rctx: a scalar

    Returns:
        delta: a Tensor with shape [batch, length, (1+window) * dim]
    """ 
    batch_size = tf.shape(x)[0]
    len = tf.shape(x)[1] - lctx - rctx 
    dim = tf.shape(x)[2]

    out_lst = [x]

    for n in range(order):
        fea = out_lst[-1]
        out = tf.zeros(tf.shape(fea))
        for i in range(1, window + 1):
            ten0 = tf.slice(fea, [0, lctx-i, 0], [batch_size, len, dim])
            ten1 = tf.slice(fea, [0, lctx+i, 0], [batch_size, len, dim])
            tmp = (ten1 - ten0) * i
            tmp = tf.pad(tmp, [[0, 0], [lctx, rctx], [0, 0]], "CONSTANT", 0)
            out += tmp
        out = out / sigma
        out_lst.append(out)

    out = tf.concat(out_lst, axis=-1)

    return out

def compute_splice(X, lctx, rctx):
    """
    Splice input feature

    Args:
        X: a Tensor with shape [batch, length, dim]
        lctx: a scalar
        rctx: a scalar

    Returns:
        output: a Tensor with shape [batch, length, dim, left_ctx+right_ctx+1]
    """
    batch_size = tf.shape(X)[0]    
    len = tf.shape(X)[1] - lctx - rctx 
    dim = tf.shape(X)[2]

    X_lst = []
    for i in range(lctx + rctx + 1):
        ten = tf.slice(X, [0, i, 0], [batch_size, len, dim])
        X_lst.append(ten[:, :, None, :])

    out = tf.concat(X_lst, axis=2)
    out = tf.transpose(out, [0, 1, 3, 2])
    return out 

def spectral_augment(X, L, config):
    """
    Spectral augmentation on input feature

    Args:
        X: a Tensor with shape [B, T, D] 
        L: a Tensor with shape [B]
        config: yaml config of spectral augment parameters
        input_dim: a scalar

    Returns:
        X: a Tensor with shape [B, T, D]
    """

    if not config.enable:
        return X

    B, T = tf.shape(X)[0], tf.shape(X)[1]

    input_dim = config.D

    # Frequency masking
    range_f = tf.range(input_dim)[None, :]
    for m in tf.range(config.m_F):
        f = tf.random.uniform([B],
            minval=0,
            maxval=config.F, 
            dtype=tf.int32)
        f0 = tf.random.uniform([B], 
            minval=0.0, 
            maxval=1.0, 
            dtype=tf.float32)
        f0 = tf.cast(
            tf.math.round(
                f0 * (input_dim - tf.cast(f, tf.float32))
            ), tf.int32
        )

        mask_f = tf.logical_and(
            tf.greater_equal(range_f, f0[:, None]),
            tf.less(range_f, (f0 + f)[:, None])
        )

        X = X * (1.0 - tf.cast(mask_f[:, None, :], tf.float32))

    # Time masking
    range_t = tf.range(T)[None, :]
    upper_bound = tf.minimum(
        tf.ones([B], tf.float32) * float(config.T),
        tf.cast(L, tf.float32) * config.p
    )
    for m in tf.range(config.m_T):
        t = tf.random.uniform([B], 
            minval=0.0,
            maxval=1.0,
            dtype=tf.float32)
        t *= upper_bound
        t = tf.cast(tf.math.round(t), tf.int32)

        t0 = tf.random.uniform([B], 
            minval=0.0,
            maxval=1.0,
            dtype=tf.float32)
        t0 *= tf.cast(L - t, tf.float32)
        t0 = tf.cast(tf.math.round(t0), tf.int32)

        mask_t = tf.logical_and(
            tf.greater_equal(range_t, t0[:, None]),
            tf.less(range_t, (t0 + t)[:, None])
        ) 

        X = X * (1.0 - tf.cast(mask_t[:, :, None], tf.float32))

    return X
