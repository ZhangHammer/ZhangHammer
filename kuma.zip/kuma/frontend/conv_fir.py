"""Implentation of feature extraction"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math
import time
import numpy as np
import struct 
#import threading
#import queue
import multiprocessing as mp

import logging
import tensorflow as tf

def ceil2(x):
    if x<=0:
        return x
    for i in range(30, -1, -1):
        mask = 1 << i
        if mask & x:
            maskt = mask -1
            if maskt & x:
                return mask << 1
            else:
                return mask
    return x

def global_load_data(rir_batches, rir_lst, pnt_lst, iso_lst, state, rir_lock, batch_size, channel):
    rir_ark_num = len(rir_lst)
    pnt_ark_num = len(pnt_lst)
    iso_ark_num = len(iso_lst)
    while True:
        if state == 0:
            break;

        start_time = time.time()
        rir_ark_idx = np.random.randint(0, rir_ark_num)  ## chosen one ark file
        rir_data = np.fromfile(rir_lst[rir_ark_idx][0], dtype=np.float32)

        pnt_ark_idx = np.random.randint(0, pnt_ark_num)  ## chosen one ark file
        pnt_data = np.fromfile(pnt_lst[pnt_ark_idx][0], dtype=np.int16)

        iso_ark_idx = np.random.randint(0, iso_ark_num)  ## chosen one ark file
        iso_data = np.fromfile(iso_lst[iso_ark_idx][0], dtype=np.int16)

        print("Reloading RIR ark block {}".format(time.time() - start_time))
        rir_num = len(rir_lst[rir_ark_idx][1])
        pnt_num = len(pnt_lst[pnt_ark_idx][1])
        iso_num = len(pnt_lst[iso_ark_idx][1])
        
        min_num = min([rir_num, pnt_num, iso_num])
        min_num = ((min_num + batch_size - 1) // batch_size) * batch_size

        rir_idx = np.random.randint(0, rir_num, [min_num])
        pnt_idx = np.random.randint(0, pnt_num, [min_num])
        iso_idx = np.random.randint(0, iso_num, [min_num])

        for i in range(0, min_num, batch_size):
            sizes = [rir_lst[rir_ark_idx][2][n] for n in rir_idx[i:i+batch_size]]
            N = max(sizes)  ## maximum rir length
            N = ceil2(N) * 2

            start_time = time.time()
            rir_arr = np.zeros([batch_size, channel, N])
            for b in range(batch_size):
                idx = rir_idx[i + b]
                beg_sample = rir_lst[rir_ark_idx][1][idx] // 4
                len_sample = rir_lst[rir_ark_idx][2][idx] // 4
                rir_f = rir_data[beg_sample:beg_sample+len_sample]

                len_per_chan = len_sample // channel
                for c in range(channel):
                    rir_arr[b, c, :len_per_chan] = rir_f[c*len_per_chan:(c+1)*len_per_chan]

            sizes = [pnt_lst[pnt_ark_idx][2][n] for n in pnt_idx[i:i+batch_size]]
            N = max(sizes)
            pnt_arr = np.zeros([batch_size, N], np.int16)
            for b in range(batch_size):
                idx = pnt_idx[i + b]
                beg_sample = pnt_lst[pnt_ark_idx][1][idx] // 2
                len_sample = pnt_lst[pnt_ark_idx][2][idx] // 2
                pnt_arr[b, :len_sample] = pnt_data[beg_sample:beg_sample+len_sample]

            sizes = [iso_lst[iso_ark_idx][2][n] for n in iso_idx[i:i+batch_size]]
            N = max(sizes)
            iso_arr = np.zeros([batch_size, N], np.int16)
            for b in range(batch_size):
                idx = iso_idx[i + b]
                beg_sample = iso_lst[pnt_ark_idx][1][idx] // 2
                len_sample = iso_lst[pnt_ark_idx][2][idx] // 2
                iso_arr[b, :len_sample] = iso_data[beg_sample:beg_sample+len_sample]

            rir_lock.acquire()
            rir_batches.append((rir_arr, pnt_arr, iso_arr))
            rir_lock.release()

        print("Finish loading batches: {}".format(time.time()-start_time))

class RIRNoiseLoader(object):
    """
    Asnyc load RIR ISO and PNT noise, store in FIFO queue
    """
    def __init__(self, rir_lst, pnt_lst, iso_lst, queue_size, batch_size, channel = 1):
        self.channel = channel
        self.batch_size = batch_size

        self.manager = mp.Manager() 
        self.rir_lock = mp.Lock()

        self.rir_lst = self.manager.list(self.load_lst(rir_lst))
        self.pnt_lst = self.manager.list(self.load_lst(pnt_lst))
        self.iso_lst = self.manager.list(self.load_lst(iso_lst))

        self.rir_data = self.manager.list([])
        self.closed = mp.Value('i', 1)
        self.rir_thread = mp.Process(target=global_load_data, 
            args=(self.rir_data,
                  self.rir_lst,
                  self.pnt_lst,
                  self.iso_lst,
                  self.closed,
                  self.rir_lock,
                  self.batch_size, 
                  self.channel,))

    def load_lst(self, lst):
        ark = {}
        for line in open(lst).readlines():
            items = line.strip().split()
            if items[1] not in ark:
                ark[items[1]] = ([int(items[2])], [int(items[3])])
            else:
                ark[items[1]][0].append(int(items[2]))
                ark[items[1]][1].append(int(items[3]))

        ark_lst = []
        for k, v in ark.items():
            ark_lst.append((k, v[0], v[1]))
        print("Success loaded rir: {}".format(len(ark_lst)))
        return ark_lst

    def fetch_rir_batch(self):
        while len(self.rir_data) == 0:
            print("sleep...{}".format(len(self.rir_data)))
            time.sleep(0.1)

        start_time = time.time()
        (rir_batch, pnt_batch, iso_batch) = self.rir_data
        print("Fetching one batch: {}".format(time.time()-start_time))
        return (rir_batch, pnt_batch, iso_batch)

    def start(self):
        self.rir_thread.start()

    def reset(self):
        self.closed = 0 
        self.rir_thread.join()

class ConvFir(tf.keras.layers.Layer):
    def __init__(self, rir_lst, batch_size, queue_size=2, channel = 1, name=None):
        super().__init__()
        self.channel = channel

    def apply_rir(self, X, R, L, M):
        """
        Apply FIR on X in Frequency domain with overlap-save method

        Args:
            X: a Tensor with shape [batch, length]
            R: a Tensor with shape [batch, channel, N]
            L: a Tensor with shape [batch] 
            M: a scalar

        Retrurns:
            out: a Tensor with shape [batch, channel, length]
        """

        N = ceil2(M) * 2
        T = N - (M - 1)
        K = N / 2 + 1 

        length = tf.shape(X)[1]
        frm_num = (length + T - 1) // T
        pad_len = frm_num * T + M - 1

        tail_pad = pad_len - length - M + 1
        Xp = tf.pad(X, [[0, 0], [M-1, tail_pad]], "CONSTANT")

        XF = tf.signal.stft(Xp, frame_length=N, frame_step=T, fft_length=N)
        XF = tf.reshape(XF, [batch_size, 1, -1, K])

        RF = tf.signal.fft(R)
        RF = tf.reshape(RF, [batch_size, self.channel, 1, K])
        conv_F = XF * RF

        # IFFT back to pcm
        conv_T = tf.signal.ifft(conv_F)
        conv_T = conv_T / (1.0 * N)

        conv_T = tf.slice(conv_T, [0, 0, M-1, 0], [batch_size, self.channel, frm_num, T])
        conv_T = tf.reshape(conv_T, [batch_size, self.channel, frm_num * T])
        conv_T = tf.slice(conv_T, [0, 0, 0], [batch_size, self.channel, frm_num * T - tail_pad])

        return conv_T
