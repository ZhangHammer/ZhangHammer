"""Implementation of conformer encoder"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from utils.attention_utils import MultiHeadAttention, attention_bias_lower_triangle, attention_bias_ignore_padding, attention_bias_dual_truncate

from utils.layer_utils import FeedForwardFLayer

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class ConvModule(layers.Layer):
    def __init__(self, num_units, kernel_size, do_layernorm=False, 
            stream=False, name="conv_module"):
        super(ConvModule, self).__init__(name=name)

        self.do_layernorm = do_layernorm
        self.input_ln = layers.LayerNormalization(
            epsilon=1e-6, name=self.name+"/input_ln")

        self.dense1 = layers.Dense(num_units, 
            activation=None, name=self.name+"/dense1") 

        self.dense2 = layers.Dense(num_units,
            activation='sigmoid', name=self.name+"/dense2")

        self.d_conv = tf.keras.Sequential([
            layers.DepthwiseConv2D(
                [kernel_size, 1], [1, 1], 
                data_format='channels_last',
                activation=None, 
                name=self.name+"/d_conv0"),
            layers.LayerNormalization(
                epsilon=1e-6,
                name=self.name+"/dconv_ln"),
            layers.Activation('swish')
        ], name=self.name + 'd_conv')

        self.dense3 = layers.Dense(num_units, 
                        activation=None, 
                        name=self.name+"/dense3")

        self.stream = stream
        self.kernel_size = kernel_size

    def call(self, x, mask):
        """
        Conformer conv module forward

        Args:
            x: a Tensor with shape [batch, length, num_units]
            mask: a Tensor with shape [batch, length, 1]
        
        Returns:
            out: a Tensor with shape [batch, length, num_units]
        """
        out = self.layernorm(x) if self.do_layernorm else x

        # glu activation: dense(x) * sigmoid(dense(x))
        out = self.dense1(out) * self.dense2(out)
        out = out * mask

        left_pad = self.kernel_size // 2 * 2 if self.stream else self.kernel_size // 2 
        right_pad = 0 if self.stream else self.kernel_size // 2 

        out = tf.expand_dims(out, axis=2) # [batch, length, 1, width] channel last
        out = tf.pad(out, [[0, 0], [left_pad, right_pad], [0, 0], [0, 0]], "CONSTANT")
        out = tf.squeeze(self.d_conv(out), axis=2)
        out = self.dense3(out) * mask

        return out 

class ConformerEncoder(layers.Layer):
    def __init__(self, config, name="conformer", group_index=None):
        super(ConformerEncoder, self).__init__(name=name)

        """
        group_index would not be None if use revise pyramid downsample mode 
        """
        if group_index is not None:
            group = config.encoder_pyramid[group_index]
            self.num_units = group['num_units']
            self.att_units = group['att_units']
            self.num_heads = group['num_heads']
            self.hidden_units = group['hidden_units']
            self.stream = group['stream']
            self.kernel_size = group['kernel_size_t']
            self.trunc = group['trunc']
        else:
            self.num_units = config.num_units
            self.att_units = config.att_units
            self.num_heads = config.num_heads
            self.hidden_units = config.hidden_units
            self.stream = config.stream
            self.kernel_size = config.kernel_size_t
            self.trunc = config.trunc

        self.time_ahead = -1 if config.time_ahead is None else config.time_ahead
        self.mha = MultiHeadAttention(self.num_units,
            self.num_heads, self.att_units,
            config.att_droprate, name=self.name+"/mha0")

        self.pre_ffn = FeedForwardFLayer(self.num_units, 
            self.hidden_units, use_bias=True,
            activation=config.ff_activation, 
            do_layernorm=config.encoder_prenorm,
            name=self.name+"/ffn0")

        self.pos_ffn = FeedForwardFLayer(self.num_units, 
            self.hidden_units, use_bias=True,
            activation=config.ff_activation,
            do_layernorm=config.encoder_prenorm,
            name=self.name+"/ffn1")

        self.use_prenorm = config.encoder_prenorm
        self.res_ln = [  # layernorm in residualconnection
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln0"), 
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln1"), 
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln2"), 
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln3")
        ]

        self.res_drop = [ # dropout in residual connection
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop0"), 
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop1"), 
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop2"), 
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop3")
        ]

        self.conv_module = ConvModule(
            num_units=self.num_units,
            stream=self.stream,
            kernel_size=self.kernel_size, 
            do_layernorm=self.use_prenorm,
            name=self.name+"/conv_module0")

    def residual(self, x, y, index, scale=1.0, training=True):
        """Residual connection

        Args:
            x: A Tensor.
            y: A Tensor.
            do_layernorm: bool
            scale: A float range from [0, 1).

        Returns:
            A Tensor.
        """
        out = x + self.res_drop[index](y, training=training) * scale 
        if not self.use_prenorm:
            out = self.res_ln[index](out)

        return out

    def call(self, x, training, padding):
        """
        Conformer encoder layer forward

        Args:
            x: a Tensor with shape [batch, length, num_units]
            training: a bool 
            padding: a Tensor with shape [batch, length]

        Returns:
            last_out: a Tensor with shape [batch, length, num_units]
        """
        # Feed Forward
        mask = tf.expand_dims(padding, axis=-1)
        x = self.residual(x, self.pre_ffn(x), 0, scale=0.5, training=training)
        x = x * mask 

        # Mask future tokens if using stream
        #bias = attention_bias_lower_triangle(tf.shape(x)[1], self.time_ahead) if self.stream else attention_bias_ignore_padding(1 - tf.squeeze(padding, axis=-1))
        bias = attention_bias_ignore_padding(1-padding)

        if self.trunc > 0:
            dual_bias = attention_bias_dual_truncate(tf.shape(x)[1], self.time_ahead, self.trunc)
            bias += dual_bias 
        elif self.stream:
            dual_bias = attention_bias_lower_triangle(tf.shape(x)[1], self.time_ahead)
            bias += dual_bias 

        attn_out, _ = self.mha(x, x, x, bias)
        attn_out = attn_out * mask 
        attn_out = self.residual(x, attn_out, 1, scale=1.0, training=training)
        attn_out = attn_out * mask 

        conv_out = self.conv_module(attn_out, mask)
        conv_out = self.residual(attn_out, conv_out, 2, scale=1.0, training=training)
        conv_out = conv_out * mask 

        last_out = self.residual(conv_out, self.pos_ffn(conv_out), 3, scale=1.0, training=training)
        last_out = last_out * mask 

        return last_out
