"""Implementation of vanilla transformer encoder"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from utils.attention_utils import MultiHeadAttention, attention_bias_lower_triangle, attention_bias_ignore_padding

from utils.layer_utils import FeedForwardFLayer

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class VallinaTransformer(layers.Layer):
    def __init__(self, config, name="transformer", group_index=None):
        super(VallinaTransformer, self).__init__(name=name)

        """
        group_index would not be None if use revise pyramid downsample mode 
        """
        if group_index is not None:
            group = config.encoder_pyramid[group_index]
            self.num_units = group['num_units']
            self.num_heads = group['num_heads']
            self.hidden_units = group['hidden_units']
            self.stream = group['stream']
        else:
            self.num_units = config.num_units
            self.num_heads = config.num_heads
            self.hidden_units = config.hidden_units
            self.stream = config.stream

        self.mha = MultiHeadAttention(
                self.num_units, 
                self.num_heads, 
                dropout_rate = config.att_droprate, 
                name=self.name+"/mha0")

        self.pre_ffn = FeedForwardFLayer(self.num_units, 
            self.hidden_units, use_bias=True,
            activation=config.ff_activation, 
            do_layernorm=config.encoder_prenorm,
            name=self.name+"/ffn0")

        self.pos_ffn = FeedForwardFLayer(self.num_units, 
            self.hidden_units, use_bias=True,
            activation=config.ff_activation, 
            do_layernorm=config.encoder_prenorm,
            name=self.name+"/ffn1")

        self.use_prenorm = config.encoder_prenorm
        self.res_ln = [  # layernorm in residualconnection
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln0"), 
            layers.LayerNormalization(epsilon=1e-6, name=self.name+"/res_ln1"), 
        ]

        self.res_drop = [ # dropout in residual connection
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop0"), 
            layers.Dropout(config.res_droprate, name=self.name+"/res_drop1"), 
        ]

    def residual(self, x, y, index, scale=1.0, training=True):
        """Residual connection

        Args:
            x: A Tensor.
            y: A Tensor.
            do_layernorm: bool
            scale: A float range from [0, 1).

        Returns:
            A Tensor.
        """
        out = x + self.res_drop[index](y, training=training) * scale 
        if not self.use_prenorm:
            out = self.res_ln[index](out)

        return out

    def call(self, x, training, padding):
        """
        Conformer encoder layer forward

        Args:
            x: a Tensor with shape [batch, length, num_units]
            training: a bool 
            padding: a Tensor with shape [batch, length]

        Returns:
            last_out: a Tensor with shape [batch, length, num_units]
        """
        # Feed Forward
        x = self.residual(x, self.pre_ffn(x), 0, scale=0.5, training=training)

        # Mask future tokens if using stream
        mask = attention_bias_lower_triangle(tf.shape(x)[1]) if self.stream else attention_bias_ignore_padding(1-padding)

        attn_out, _ = self.mha(x, x, x, mask) 
        last_out = self.residual(x, attn_out, 1, scale=1.0, training=training)

        return last_out
