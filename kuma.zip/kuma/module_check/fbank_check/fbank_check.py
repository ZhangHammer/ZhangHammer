"""Train main function"""

import os
import sys

from frontend.feature import pcm2fbank,custom_fbank_delta,compute_splice 

import numpy as np
import struct
import tensorflow as tf

# load test pcm
pcm_file = open(sys.argv[1], "rb")
pcm_data = pcm_file.read()
pcm_lst = struct.unpack("{}h".format(len(pcm_data)//2), pcm_data)
pcm_arr = np.array(pcm_lst)
pcm_ten = tf.reshape(tf.cast(tf.convert_to_tensor(pcm_arr, tf.int16), tf.float32), [1, -1, 1])
fbank = pcm2fbank(pcm_ten)
fbank_delta = custom_fbank_delta(fbank)
fbank_splice = compute_splice(fbank_delta, 5, 5)
fbank_arr = np.array(fbank_splice)

out_io = open(sys.argv[2], "w")
for i in range(fbank_arr.shape[1]):
    for d in range(fbank_arr.shape[2]):
        out_io.write("[ ")
        for c in range(fbank_arr.shape[3]):
            out_io.write("%f " %(fbank_arr[0, i, d, c]))
        out_io.write("]")
    out_io.write("\n")
out_io.close()
