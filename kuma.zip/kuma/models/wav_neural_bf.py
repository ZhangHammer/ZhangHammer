"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice
from frontend.feature import custom_fbank_delta as compute_delta 
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class NeuralBeamform(tf.keras.Model):
    def __init__(self, config):
        super(NeuralBeamform, self).__init__()

        self.config = config

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.transformer_decoder import TransformerDecoder as DecoderLayer

        ### Conv1D layers for pcm encoder
        self.kernel_strides = [(10, 5), (5, 3), (5, 3), (3, 2), (3, 2)]
        self.conv_t_layers = [
            tf.keras.Sequential([
                layers.Conv1D(64, 10, 5, use_bias=False, name='conv1d_0'),
                layers.Activation('swish'),
            ]),
            tf.keras.Sequential([
                layers.Conv1D(128, 5, 3, use_bias=False, name='conv1d_1'),
                layers.Activation('swish'),
            ]),
            tf.keras.Sequential([
                layers.Conv1D(256, 5, 3, use_bias=False, name='conv1d_2'),
                layers.Activation('swish'),
            ]),
            tf.keras.Sequential([
                layers.Conv1D(512, 3, 2, use_bias=False, name='conv1d_3'),
                layers.Activation('swish'),
            ]),
            tf.keras.Sequential([
                layers.Conv1D(512, 3, 2, use_bias=False, name='conv1d_4'),
                layers.Activation('swish'),
            ])
        ]
        self.conv_t_ln = layers.LayerNormalization(epsilon=1e-6, name='conv_t_ln')

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 2), (2, 2), (1, 2)]

        self.conv2d_layers = [
            layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv_t0"),
            layers.Conv2D(32, (3, 3), (1, 2), activation='relu', padding='valid', name="conv_t1"), 
            layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv_t2"), 
            layers.Conv2D(64, (3, 3), (1, 2), activation='relu', padding='valid', name="conv_t3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(EncoderLayer(config.encoder, name="encoder_{}_{}".format(g_idx, i), group_index=g_idx))

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
                 layers.Dense(enc_embed_units, name="enc_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="enc_embed_ln")
                ])
        self.encoder_dropout = layers.Dropout(config.encoder.res_droprate, name="enc_embed_drop")

        self.decoder_layers = [DecoderLayer(config.decoder, name="decoder_{}".format(idx)) 
                for idx in range(config.decoder.num_blocks)]

        self.decoder_embedding = layers.Dense(config.decoder.num_units, use_bias=False, name="dec_embed_dense")
        self.decoder_dropout = layers.Dropout(config.decoder.res_droprate, name="enc_embed_drop")
        self.decoder_layernorm = layers.LayerNormalization(epsilon=1e-6, name="dec_ln")

        self.e2e_output = layers.Dense(self.config.dst_vocab_size, use_bias=False, name="e2e_output")
        self.ce_loss = tf.keras.losses.SparseCategoricalCrossentropy(
                from_logits=True, reduction='none')

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = X
        for ii, conv in enumerate(self.conv_t_layers):
            out = conv(out)
            length = (length - self.kernel_strides[ii][0]) // self.kernel_strides[ii][1] + 1
            conv_mask = tf.cast(
                tf.sequence_mask(length, tf.shape(out)[1]),
                tf.float32
            )
            out = out * tf.expand_dims(conv_mask, axis=-1)

        out = tf.expand_dims(self.conv_t_ln(out), axis=-1)

        for ii, conv in enumerate(self.conv2d_layers):
            if self.config.conv_module.stream:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool
                                                                                                  
        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.encoder_embedding(x)
        enc_input = add_timing_signal_1d(enc_input)
        enc_output = self.encoder_dropout(enc_input, training=training)

        enc_outputs = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
                enc_output = enc_output * enc_mask

            if not training:
                enc_output = tf.stop_gradient(enc_output)
            enc_outputs.append(enc_output)

        return enc_outputs

    def decoder_impl(self, x, y, training):
        """
        Decoder block forward 

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool

        Returns:
            dec_output: [batch, tokens, dim]
        """

        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0) 

        dec_input = self.decoder_embedding(dec_input) 
        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)

        dec_input = add_timing_signal_1d(dec_input)
        mask = tf.expand_dims(padding, axis=-1)
        dec_input = dec_input * mask 
        dec_output = self.decoder_dropout(dec_input)

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(x, dec_output, training)                          
            dec_output *= mask 

        if self.config.decoder.decoder_prenorm:
            dec_output = self.decoder_layernorm(dec_output) 
            dec_output *= mask

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output

    def call(self, X, Y, L, training):
        """                                                                       
        NeuralBeamform model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens] 
            L: a Tensor with shape [batch, 1] 
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size] 
        """
        
        X = tf.reshape(X,
            shape = [tf.shape(X)[0], self.config.input_channel,
                     tf.shape(X)[1]//self.config.input_channel]
        )
        X = tf.transpose(X, [0, 2, 1])

        L = tf.squeeze(L, axis=-1) // self.config.input_channel
        wav_enc, enc_len = self.conv_downsample(X, L)
        wav_enc = tf.reshape(wav_enc,
            shape=[tf.shape(wav_enc)[0], 
                   tf.shape(wav_enc)[1], 
                   self.config.conv_module.out_dim
                  ]
        )

        enc_output = self.encoder_impl(wav_enc, enc_len, training)
        dec_output = self.decoder_impl(enc_output[-1], Y, training)

        e2e_logits = self.e2e_output(dec_output)

        return e2e_logits 

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 
    
        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)

        Y = tf.math.maximum(Y - 4, 0)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = tf.math.reduce_mean(loss / tf.cast(label_len, tf.float32))

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err

    def e2e_loss(self, X, Y):
        """                                                                    
        E2E Cross entropy loss 

        Args:
            X: a Tensor with shape [batch, tokens, dst_vocab_size]
            Y: a Tensor with shape [batch, tokens] 

        Returns:

        """

        """
        slice X and label to same shape, label shape is greater or equal with X
        """
        masks = tf.cast(tf.math.greater(Y, 0), tf.float32)

        batch_size = tf.shape(X)[0]
        len = tf.shape(X)[1]
        dim = tf.shape(X)[2]

        Y = tf.slice(Y, [0, 0], [batch_size, len])
        masks = tf.slice(masks, [0, 0], [batch_size, len])

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)
        probs = tf.nn.softmax(X)
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = self.ce_loss(Y, X)
        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 
