"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice
from frontend.feature import custom_fbank_delta as compute_delta 
from utils.layer_utils import FCLP, MobileNetConv, scatter_values_on_batch_indices
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class NeuralBeamform(tf.keras.Model):
    def __init__(self, config):
        super(NeuralBeamform, self).__init__()

        self.config = config

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.transformer_decoder import TransformerDecoder as DecoderLayer

        self.fclp = FCLP(config.FCLP, name='FCLP')
        self.fclp_ln = layers.LayerNormalization(epsilon=1e-6, name='FCLP_ln')
        #### BUILD MobileNet blocks ###
        self.conv_block00 = tf.keras.Sequential([
            layers.Conv2D(32, (5, 5), (1, 1), use_bias=False, padding='same', name='conv00'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block00_ln"),
        ])

        self.conv_block01 = tf.keras.Sequential([
            layers.DepthwiseConv2D((3, 3), (1, 1), use_bias=False, padding='same', name='dconv0'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block01_ln"),
        ])
            
        self.conv_f_layers = [
            MobileNetConv(32, (1, 2), (1, 2), (3, 3), name='mobile_conv0'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv1'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv2'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv3'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv4')
        ]

        self.conv_block1 = tf.keras.Sequential([
            layers.Conv2D(64, (1, 1), (1, 1), use_bias=False, padding='valid', name='conv1'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block1_ln"),
            layers.Activation('tanh'),                                                                                 
        ])

        self.conv_kernel_size = [(3, 1), (3, 1), (3, 1), (3, 1)]
        self.conv_stride_size = [(1, 1), (1, 1), (1, 1), (1, 1)]

        self.conv_t_layers = [
            layers.Conv2D(32, (3, 1), (1, 1), activation='swish', padding='valid', name="conv_t0"),
            layers.Conv2D(32, (3, 1), (1, 1), activation='swish', padding='valid', name="conv_t1"), 
            layers.Conv2D(64, (3, 1), (1, 1), activation='swish', padding='valid', name="conv_t2"), 
            layers.Conv2D(64, (3, 1), (1, 1), activation='swish', padding='valid', name="conv_t3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(EncoderLayer(config.encoder, name="encoder_{}_{}".format(g_idx, i), group_index=g_idx))

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
                 layers.Dense(enc_embed_units, name="enc_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="enc_embed_ln")
                ])
        self.encoder_dropout = layers.Dropout(config.encoder.res_droprate, name="enc_embed_drop")

        self.decoder_layers = [DecoderLayer(config.decoder, name="decoder_{}".format(idx)) 
                for idx in range(config.decoder.num_blocks)]

        self.decoder_embedding = layers.Dense(config.decoder.num_units, use_bias=False, name="dec_embed_dense")
        self.decoder_dropout = layers.Dropout(config.decoder.res_droprate, name="enc_embed_drop")
        self.decoder_layernorm = layers.LayerNormalization(epsilon=1e-6, name="dec_ln")

        self.mask_w = self.add_weight(
            shape=[1, 1, config.conv_module.out_dim],
            initializer='glorot_uniform',
            trainable=True, name="mask_w")

        self.enc_proj = layers.Dense(enc_embed_units, name='enc_proj')
        self.ctx_proj = layers.Dense(enc_embed_units, name='ctx_proj')

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = self.conv_block00(X)
        out = activations.relu(out, max_value=6)
        out = self.conv_block01(out)
        out = activations.relu(out, max_value=6)
        for conv in self.conv_f_layers:
            out, length = conv(out, length)
        out = self.conv_block1(out)

        for ii, conv in enumerate(self.conv_t_layers):
            if self.config.conv_module.stream:
                out = tf.pad(out, [[0, 0], [2, 0], [0, 0], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [0, 0], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool
                                                                                                  
        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.encoder_embedding(x)
        enc_input = add_timing_signal_1d(enc_input)
        enc_output = self.encoder_dropout(enc_input, training=training)

        enc_outputs = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
                enc_output = enc_output * enc_mask

            if not training:
                enc_output = tf.stop_gradient(enc_output)
            enc_outputs.append(enc_output)

        return enc_outputs

    def decoder_impl(self, x, y, training):
        """
        Decoder block forward 

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool

        Returns:
            dec_output: [batch, tokens, dim]
        """

        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0) 

        dec_input = self.decoder_embedding(dec_input) 
        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)

        dec_input = add_timing_signal_1d(dec_input)
        dec_input = dec_input * tf.expand_dims(padding, axis=-1)
        dec_output = self.decoder_dropout(dec_input)

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(x, dec_output, training)                          

        if self.config.decoder.decoder_prenorm:
            dec_output = self.decoder_layernorm(dec_output) 

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output

    def apply_mask(self, X, L, padding):
        """
        Random mask some frames of contextual encoder input
        Instead of masking them to zero, we subsitute them 
        with a trainable weights

        Args:
            X: a Tensor with shape [batch, T, dim]
            L: a Tensor with shape [batch]
            padding: a Tensor with shape [batch, T, 1]

        Returns:
            X: masked Tensor with shape [batch, T, dim]
            mask: random chosen mask with shape [batch, T]
        """

        batch_size = tf.shape(X)[0]
        T = tf.shape(X)[1]

        P = self.config.contrast_loss['P']
        M = self.config.contrast_loss['M']

        ## at least 1 mask for each sentence
        num_mask = tf.cast(tf.math.ceil(L * P), tf.int32)
        max_num = tf.math.reduce_max(num_mask)
        L = tf.cast(L, tf.int32)
        mask_indices = tf.TensorArray(dtype=tf.int32, size=batch_size)
        for b in tf.range(batch_size):
            rand_f = tf.random.uniform([L[b]-M+1], 0.0, 1.0)
            _, indices = tf.nn.top_k(rand_f, num_mask[b])
            indices = tf.reshape(
                tf.pad(indices[:, None], [[0, max_num-num_mask[b]], [0, 0]], 'CONSTANT', constant_values=-M),
                shape = [-1]
            )
            mask_indices=mask_indices.write(b, indices)

        mask_indices = mask_indices.stack()
        mask_indices = tf.reshape(
            tf.broadcast_to(mask_indices[:,:,None], [batch_size, max_num, M]),
            shape = [batch_size, max_num*M]
        )

        offset = tf.reshape(
            tf.broadcast_to(tf.range(M)[None,None,:], [batch_size, max_num, M]),
            shape = [batch_size, max_num*M]
        )

        mask_indices += offset
        mask_indices = tf.math.maximum(mask_indices, 0)

        # scatter value on batch indices
        mask = scatter_values_on_batch_indices(
            tf.ones_like(mask_indices), mask_indices, (batch_size, T)
            )
        mask = tf.cast(tf.math.equal(mask, 1), tf.float32)
        mask = tf.expand_dims(mask, axis=-1) * padding

        X = X * (1.0 - mask) + self.mask_w * mask

        return X, mask

    def fetch_negative_mask(self, mask):                              
        """
        Fetch positive and negative samples according to mask
                                                                   
        Args:
            mask: a Tensor with shape [B, T, 1]
                                                                   
        Returns:
            neg_mask: a Tensor with shape [B, T, T]
        """
        B = tf.shape(mask)[0]
        T = tf.shape(mask)[1]
        N = self.config.contrast_loss['N']
                                                                   
        neg_mask = tf.linalg.matmul(mask, mask, transpose_b=True)
        bias = 1 - tf.linalg.diag(tf.ones([B, T], tf.float32))
        neg_mask = neg_mask * bias
                                                                   
        rand_m = tf.random.uniform([B, T, T], 0.0, 1.0)
        mask_n = tf.reduce_sum(neg_mask, axis=-1)
        mask_p = tf.expand_dims(
            tf.math.maximum(
                N / (mask_n - 1e-7), 0
            ), axis=-1
        )
                                                                   
        mask_i = tf.cast(tf.math.less(rand_m, mask_p), tf.float32)
        neg_mask = neg_mask * mask_i
                                                                   
        return neg_mask


    def call(self, X, L, training):
        """                                                                       
        NeuralBeamform model forward 

        Args:
            X: a Tensor with shape [batch, T, dim]
            L: a Tensor with shape [batch, 1] 
            training: a bool

        Returns:
            ctx: a Tensor with shape [batch, T, dim] 
            enc: a Tensor with shape [batch, T, dim] 
            mask: a Tensor with shape [batch, T] 
            length: a Tensor with shape [batch]
        """

        bf_out, mask = self.fclp(X, L)
        length = tf.reduce_sum(mask, axis=-1)

        B = tf.shape(bf_out)[0]
        C = self.config.FCLP.complex_conv['channel'] 
        W = self.config.FCLP.complex_full['out_dim']

        bf_out = tf.reshape(bf_out, [B, -1, W * C])
        bf_out = self.fclp_ln(bf_out)
        bf_out = tf.reshape(bf_out, [B, -1, W, C])

        enc_input, enc_length = self.conv_downsample(bf_out, length)
        enc_input = tf.reshape(enc_input,
            shape=[tf.shape(enc_input)[0],
                   tf.shape(enc_input)[1], 
                   self.config.conv_module.out_dim
                  ])

        padding = tf.sequence_mask(enc_length, tf.shape(enc_input)[1], dtype=tf.float32)
        padding = tf.expand_dims(padding, axis=-1)
        enc_input = enc_input * padding 

        enc, mask = self.apply_mask(enc_input, enc_length, padding)
        ctx = self.encoder_impl(enc, enc_length, training)[-1]

        neg_mask = self.fetch_negative_mask(mask)
        ctx = self.ctx_proj(ctx)
        enc = self.enc_proj(enc_input)

        return ctx, enc, enc_length, mask, neg_mask

    def contrast_loss(self, X, Y, L, mask, neg_mask):
        """
        Compute constrastive loss same as work in SimCLR

        Args:
            X: a Tensor with shape [batch, T, units]
            Y: a Tensor with shape [batch, T, units]
            L: a Tensor with shape [batch]
            mask: a Tensor with shape [batch, T, 1]

        Returns:
            loss: a Tensor with shape [1]
        """
        batch_size = tf.shape(X)[0]
        length = tf.shape(X)[1]
                                                                         
        X_norm = tf.math.l2_normalize(X, axis=-1)
        Y_norm = tf.math.l2_normalize(Y, axis=-1)
        
        # dist: [batch, T, T]
        # mask: [batch, T, T]
        dist = tf.linalg.matmul(X_norm, Y_norm, transpose_b=True)
        tf.print(tf.reduce_sum(tf.cast(tf.math.greater(dist, 1), tf.int32)))
        dist = tf.math.exp(dist / self.config.contrast_loss['T'])
                                                                         
        bias = tf.linalg.diag(tf.ones([batch_size, length]))
        mask_mat = tf.linalg.matmul(mask, mask, transpose_b=True)
        pos_mask = mask_mat * bias
                                                                         
        pos_dist = dist * pos_mask 
        neg_dist = dist * neg_mask + pos_dist

        intra_sim = tf.math.reduce_sum(pos_dist, axis=-1)
        inter_sim = tf.math.reduce_sum(neg_dist, axis=-1) + 1e-7
        #tf.print("Inter sim: ", inter_sim / tf.math.reduce_sum(mask, axis=1))
        #tf.print("Intra sim: ", intra_sim / tf.math.reduce_sum(mask, axis=1))
        loss = intra_sim / inter_sim
        loss = -1 * tf.math.log(loss + 1e-7) * tf.squeeze(mask, axis=-1)
        loss = tf.math.reduce_sum(loss) / tf.math.reduce_sum(mask)
                                                                         
        return loss
