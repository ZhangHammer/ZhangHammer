"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice
from frontend.feature import custom_fbank_delta as compute_delta 
from utils.layer_utils import FCLP, ViterbiAlign
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class EmbeddingContrast(tf.keras.Model):
    def __init__(self, config):
        super(EmbeddingContrast, self).__init__()

        self.config = config

        from encoder.conformer_encoder import ConformerEncoder as AcousticEncoder 
        from encoder.transformer_encoder import TransformerEncoder as TextEncoder

        self.fclp_layer = FCLP(config.FCLP, name='FCLP')

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 1), (2, 2), (1, 1)]

        self.conv_layers = [
                layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv0"),
                layers.Conv2D(32, (3, 3), (1, 1), activation='relu', padding='valid', name="conv1"), 
                layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv2"), 
                layers.Conv2D(64, (3, 3), (1, 1), activation='relu', padding='valid', name="conv3")]

        self.acoustic_encoder_layers = [AcousticEncoder(config.acoustic_encoder, name="acoustic_encoder_{}".format(i))
                for i in range(config.acoustic_encoder.block_num)]

        self.text_encoder_layers = [TextEncoder(config.text_encoder, name="text_encoder_{}".format(i))
                for i in range(config.text_encoder.block_num)]

        self.acoustic_embedding = tf.keras.Sequential([
                 layers.Dense(config.acoustic_encoder.num_units, name="acoustic_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="acoustic_embed_ln")
                ])
        self.acoustic_embed_drop = layers.Dropout(config.acoustic_encoder.res_droprate, name="acoustic_embed_drop")

        self.text_embedding = tf.keras.Sequential([
                 layers.Dense(config.text_encoder.num_units, name="text_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="text_embed_ln")
                ])
        self.text_embed_drop = layers.Dropout(config.text_encoder.res_droprate, name="text_embed_drop")

        self.acoustic_output = tf.keras.Sequential([
                 layers.Dense(config.acoustic_encoder.hidden_units, 
                    activation='relu', name="acoustic_out_dense1"),
                 layers.Dense(config.acoustic_encoder.num_units, 
                    name="acoustic_out_dense2"),
                ])

        self.text_output = tf.keras.Sequential([
                 layers.Dense(config.text_encoder.hidden_units, 
                    activation='relu', name="text_out_dense1"),
                 layers.Dense(config.text_encoder.num_units, 
                    name="text_out_dense2"),
                ])

        self.temperature = 1.0 if config.temperature is not None else config.temperature

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = X
        for ii, conv in enumerate(self.conv_layers):
            if self.config.stream_mode:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def acoustic_encoder_impl(self, X, L, training): 
        """
        Acoustic Encoder block forward

        Args:
            X: a Tensor with shape [batch, frames, dim]
            L: length, a Tensor with shape [batch, 1]
            training: a bool
                                                        
        Returns:
            enc_output: a list of Tensor with element shape [batch, frames, units]
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(X)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.acoustic_embedding(X)
        enc_input = add_timing_signal_1d(enc_input)
        enc_output = self.acoustic_embed_drop(enc_input, training=training)

        for enc_layer in self.acoustic_encoder_layers: 
            enc_output = enc_layer(enc_output, training, enc_padding)
            enc_output = enc_output * enc_mask
                                                                                     
        if not training:
            enc_output = tf.stop_gradient(enc_output)

        return enc_output

    def text_encoder_impl(self, Y, training):
        """                                                             
        Acoustic Encoder block forward
                                                         
        Args:
            Y: a Tensor with shape [batch, tokens, dim]
            training: a bool
                                                        
        Returns:
            enc_output: a Tensor with shape [batch]
        """
        padding = tf.cast(tf.math.not_equal(Y, 0), tf.float32)
        mask = tf.expand_dims(padding, axis=-1)

        text_one_hot = tf.one_hot(tf.cast(Y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0)

        text_enc_input = self.text_embedding(text_one_hot) 
        text_enc_input = add_timing_signal_1d(text_enc_input)
        text_enc_output = self.text_embed_drop(text_enc_input)

        for enc_layer in self.text_encoder_layers:
            text_enc_output = enc_layer(text_enc_output, training, padding)
            text_enc_output = text_enc_output * mask

        if not training:
            text_enc_output = tf.stop_gradient(text_enc_output)

        return text_enc_output

    def call(self, X, Y, L, training):
        """                                                                       
        KeywordSpotting model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens]
            L: a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size]
        """

        bf_out, mask = self.fclp_layer(X, L)
        length = tf.cast(tf.reduce_sum(mask, axis=-1), tf.int32)
        acoustic_enc_input, acoustic_enc_length = self.conv_downsample(bf_out, length)
        acoustic_enc_input = tf.reshape(acoustic_enc_input,
            shape=[tf.shape(acoustic_enc_input)[0], 
                   tf.shape(acoustic_enc_input)[1], 
                   self.config.conv_out_dim
                  ])

        acoustic_enc_output = self.acoustic_encoder_impl(
            acoustic_enc_input, acoustic_enc_length, training)
        text_enc_output = self.text_encoder_impl(Y, training)

        acoustic_enc_output = tf.math.reduce_mean(acoustic_enc_output, axis=1)
        text_enc_output = tf.math.reduce_mean(text_enc_output, axis=1)

        acoustic_enc_output = self.acoustic_output(acoustic_enc_output) 
        text_enc_output = self.text_output(text_enc_output) 
        
        return acoustic_enc_output, text_enc_output 

    def constrast_loss(self, X, Y):
        """
        Compute constrastive loss same as work in SimCLR

        Args:
            X: a Tensor with shape [batch, units]
            Y: a Tensor with shape [batch, units]

        Returns:
            loss: a Tensor with shape [1]
        """
        batch_size = tf.shape(X)[0]

        X_norm = tf.math.l2_normalize(X, epsilon=1e-6)
        Y_norm = tf.math.l2_normalize(Y, epsilon=1e-6)

        sim_mat = tf.linalg.matmul(X_norm, Y_norm, transpose_b=True)
        preds = tf.cast(tf.math.argmax(sim_mat, axis=-1), tf.int32)
        acc = tf.cast(tf.math.equal(preds, tf.range(batch_size)), tf.float32)

        sim_mat = tf.math.exp(sim_mat / self.temperature)
        mask = tf.linalg.diag(tf.ones([batch_size]))

        intra_sim = sim_mat * mask
        inter_sim = sim_mat * (1 - mask)

        intra_sim = tf.math.reduce_sum(intra_sim, axis=-1)
        inter_sim = tf.math.reduce_sum(inter_sim, axis=-1)
        loss = -1 * tf.math.log(tf.math.reduce_sum(intra_sim/inter_sim))

        return loss, tf.reduce_mean(acc)

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 
    
        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = tf.math.reduce_mean(loss / tf.cast(label_len, tf.float32))

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err, err

    def e2e_loss(self, X, Y):
        """                                                                    
        E2E Cross entropy loss 

        Args:
            X: a Tensor with shape [batch, tokens, dst_vocab_size]
            Y: a Tensor with shape [batch, tokens]

        Returns:

        """

        """
        slice X and label to same shape, label shape is greater or equal with X
        """
        batch_size = tf.shape(X)[0]
        Y = tf.strided_slice(Y, [0, 0], [batch_size, tf.shape(Y)[1]], [1, 4])
        masks = tf.cast(tf.math.greater(Y, 0), tf.float32)

        len = tf.math.minimum(tf.shape(X)[1], tf.shape(Y)[1])
        dim = tf.shape(X)[2]

        Y = tf.slice(Y, [0, 0], [batch_size, len])
        X = tf.slice(X, [0, 0, 0], [batch_size, len, dim])
        masks = tf.slice(masks, [0, 0], [batch_size, len])

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)
        probs = tf.nn.softmax(X)
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = self.ce_loss(Y, X)
        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 
