"""
Implementation of hybrid autoregressive transducer (HAT) speech recognition
    1. conformer encoder
    2. LSTM predict network
    3. joint network
    4. RNN-T training loss
    5. conformer rescore
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice, compute_delta, spectral_augment
from utils.attention_utils import attention_bias_lower_triangle, MultiHeadAttention, attention_bias_ignore_padding, scale_dot_product_attention 
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

from cpp import rnnt_loss, rnnt_loss_v2

class HAT(tf.keras.Model):
    """
    Initialization
    """
    def __init__(self, config):
        super(HAT, self).__init__()

        self.config = config
        self.mean, self.var = self.load_cmvn(self.config.Fbank.cmvn_path)

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.lstm_decoder import ResidualLstm as DecoderLayer

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 1), (2, 2), (1, 1)]

        self.conv_layers = [
            layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv0"),
            layers.Conv2D(32, (3, 3), (1, 1), activation='relu', padding='valid', name="conv1"), 
            layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv2"), 
            layers.Conv2D(64, (3, 3), (1, 1), activation='relu', padding='valid', name="conv3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(
                    EncoderLayer(config.encoder, 
                        name="encoder_{}_{}".format(g_idx, i), 
                        group_index=g_idx
                    )
                )

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
            layers.Dense(enc_embed_units, 
               name="enc_embed_dense"
            ),
            layers.LayerNormalization(
               epsilon=1e-6, name="enc_embed_ln"
            ),
            layers.Dropout(
                config.encoder.res_droprate,
                name="enc_embed_drop"
            )
        ], name='encoder_embd')

        self.decoder_layers = [
            DecoderLayer(config.decoder, name="decoder_{}".format(idx))
            for idx in range(config.decoder.num_blocks)]

        self.encoder_proj = layers.Dense(
            config.decoder.num_units,
            use_bias=True,
            name="encoder_proj_dense")
                                                  
        self.decoder_proj = layers.Dense(
            config.decoder.num_units,
            use_bias=True,
            name="decoder_proj_dense")

        self.decoder_embedding = layers.Dense(
                config.decoder.num_units, 
                use_bias=False, 
                name="dec_embed_dense")

        self.out_proj = layers.Dense(
                config.dst_vocab_size, 
                use_bias=False,
                name="rnnt_proj")

    def load_cmvn(self, cmvn_path):
        means = []
        vars = []

        with open(cmvn_path, "r") as cmvn_file:
            lines = cmvn_file.readlines()
            for line in lines:
                line = line.strip()
                mean, var = line.split()
                means.append(float(mean))

                var = float(var)
                var = 1.0 / np.sqrt(var)
                var = var if var < 100000.0 else 100000.0
                vars.append(var)
        
        return tf.constant(means, tf.float32), tf.constant(vars, tf.float32)

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = X if self.config.Fbank['splice'] else tf.expand_dims(X, axis=-1)
        for ii, conv in enumerate(self.conv_layers):
            if self.config.stream:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT")
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT")

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_output = self.encoder_embedding(x)
        enc_output *= enc_mask
        #enc_output = self.encoder_dropout(enc_input, training=training)
        group = self.config.encoder.encoder_pyramid[0]
        start = group['start']
        end = group['end']
                                                                                   
        for i in range(start, end):
            enc_output = self.encoder_layers[i](enc_output, training, enc_padding)

        ## stream encoder part
        enc_outputs = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid[1:]):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                enc_output = self.encoder_layers[i](enc_output, training, enc_padding)

            if not training:
                enc_output = tf.stop_gradient(enc_output)
            enc_outputs.append(enc_output)

        return enc_outputs 

    def decoder_impl(self, y, training):
        """
        Decoder block forward 

        Args:
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool
                                                                                      
        Returns:
            dec_output: [batch, tokens, dim]
        """
                                                                                       
        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0) 
                                                                                       
        dec_input = self.decoder_embedding(dec_input) 
        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)
                                                                                       
        # No need position encoding for LSTM decoder
        mask = tf.expand_dims(padding, axis=-1)
        dec_output = dec_input * mask

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(dec_output, training)
            dec_output = dec_output * mask
                                                                                       
        dec_output = self.decoder_proj(dec_output)
        dec_output = dec_output * mask 
        if not training:
            dec_output = tf.stop_gradient(dec_output)
                                                                                       
        return dec_output

    def compute_fbank(self, X, L, training=True):
        """
        compute fbank feature with delta or splice

        Args:
            X: a Tensor with shape [batch, sample_num, 1]
            length: a Tensor with shape [batch, 1]

        Returns:
            mel_banK: a Tensor with shape [batch, frames, dim]
            length: a Tensor with shape [batch, 1]
        """

        length = tf.reshape(L, [-1])

        num_bins = self.config.Fbank.bins
        mel_bank = pcm2fbank(X) if self.config.Fbank.compute else tf.reshape(X, [tf.shape(X)[0], tf.shape(X)[1] // num_bins, num_bins])
        length = (length - 400) // 160 + 1 if self.config.Fbank.compute else length

        B = tf.shape(X)[0]
        window = self.config.Fbank.window
        order = self.config.Fbank.order
        sigma = self.config.Fbank.sigma
        lctx = self.config.Fbank.left_context
        rctx = self.config.Fbank.right_context

        if lctx > 0:
            head_copy = tf.tile(
                tf.reshape(mel_bank[:,0,:], shape = [B, 1, num_bins]),
                multiples = [1, lctx, 1]
            )
            mel_bank = tf.concat([head_copy, mel_bank], axis=1)

        if rctx > 0:
            tail_copy = tf.tile(
                tf.reshape(mel_bank[:,-1,:], shape = [B, 1, num_bins]),
                multiples = [1, rctx, 1]
            )
            mel_bank = tf.concat([mel_bank, tail_copy], axis=1)

        if self.config.Fbank.delta:
            mel_bank = compute_delta(mel_bank, window, order, sigma, lctx, rctx)

        mel_bank = (mel_bank - self.mean) * self.var
        if training and self.config.spec_augment.enable:
            mel_bank = spectral_augment(mel_bank, length, self.config.spec_augment)

        if self.config.Fbank.splice:
            mel_bank = compute_splice(mel_bank, lctx, rctx)

        return mel_bank, length
    
    def memory_efficient_joint_network(self, X_embd, Y_embd, X_length, Y_length):
        """
        RNN-T joint network, generate RNN-T search graph
        in memory efficient manner
        Only add joint type is support for now 
                                                                                  
        Args:
            X_embd: a Tensor with shape [B, T, D]
            Y_embd: a Tensor with shape [B, U, D]
            X_length: a Tensor with shape [B, 1]
            Y_length: a Tensor with shape [B, 1]
            joint_type: a string
                                                                                  
        Returns:
            out: a Tensor with shape [B, T*U, D]
                 which is a memory NOT efficient manner
        """
        B = tf.shape(X_embd)[0]
        D = tf.shape(X_embd)[2]
                                                                                  
        joint = tf.TensorArray(
            dtype = tf.float32, size=B,
            infer_shape=False,
            name=self.name + "rnnt_joint"
        )
                                                                                  
        for b in range(B):
            X_sliced = tf.reshape(
                tf.slice(X_embd, [b, 0, 0], [1, X_length[b], D]),
                shape = [X_length[b], 1, D]
            )
            Y_sliced = tf.reshape(
                tf.slice(Y_embd, [b, 0, 0], [1, Y_length[b]+1, D]),
                shape = [1, Y_length[b]+1, D]
            )
            XY_joint = tf.keras.activations.tanh(
                tf.reshape(X_sliced + Y_sliced,
                    shape = [X_length[b] * (Y_length[b]+1), D]
                )
            )
                                                                                  
            joint = joint.write(b, XY_joint)
                                                                                  
        return joint.concat()

    def call(self, X, L, training):
        """
        Conformer transducer model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens] 
            L: a Tensor with shape [batch] 
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size]
        """

        mel_bank, length = self.compute_fbank(X, L, training)
        mel_bank = tf.stop_gradient(mel_bank)

        mask = tf.sequence_mask(length, tf.shape(mel_bank)[1])

        enc_input, enc_length = self.conv_downsample(mel_bank, length)
        enc_input = tf.reshape(enc_input, 
            shape=[tf.shape(enc_input)[0],
                tf.shape(enc_input)[1],
                self.config.conv_out_dim])

        enc_output = self.encoder_impl(enc_input, enc_length, training)

        return enc_output[-1], enc_length

    def rnnt_loss_v2(self, enc_output, Y, enc_length, training):
        """
        Warp RNN-T loss
        Args:
            enc_output: a Tensor with shape [B, T, D]
            Y: a Tensor with shape [B, U]
            enc_length: a Tensor with shape [B]
                                                                                  
        Returns:
            loss: a Tensor with shape [1]
        """

        enc_output = self.encoder_proj(enc_output)
        enc_length = enc_length - 1

        Z = tf.pad(Y, [[0, 0], [1, 0]], "CONSTANT", constant_values=3616)
        dec_output = self.decoder_impl(Z, training)

        Y_len = tf.math.reduce_sum(
            tf.cast(
                tf.math.not_equal(Y, 0), tf.int32
            ), axis=-1
        )

        logit = self.memory_efficient_joint_network(
                enc_output, dec_output, enc_length, Y_len)

        logit = tf.reshape(logit, [-1, self.config.decoder.num_units])
        logit_proj = self.out_proj(logit)

        loss = rnnt_loss_v2(logit_proj, Y, enc_length, Y_len, 3616, True)

        return tf.reduce_sum(loss) / tf.cast(tf.reduce_sum(Y_len), tf.float32)

    def hat_loss(self, X, Y, L, training):
        """
        Hybrid autoregressive transducer loss following
        https://arxiv.org/pdf/2003.07705.pdf 
       
        Args:
            X: a Tensor with shape [B, T, D] 
            Y: a Tensor with shape [B, U]
            L: a Tensor with shape [B]

        Returns: 
            loss a Tensor with shape [1]
        """
        
        X = self.encoder_proj(X)  
        X_len = L - 1

        Z = tf.pad(Y, [[0, 0], [1, 0]], "CONSTANT", constant_values=3616)
        dec = self.decoder_impl(Z, training)

        Y_len = tf.math.reduce_sum(
            tf.cast(
                tf.math.not_equal(Y, 0), tf.int32
            ), axis=-1
        )

        logit = self.memory_efficient_joint_network(
                X, dec, X_len, Y_len)

        logit = tf.reshape(logit, [-1, self.config.decoder.num_units])
        logit = self.out_proj(logit)

        T = tf.shape(logit)[0]
        blank_logit = tf.reshape(logit[:, 3615], [T, 1]) 
        nonblank_logit = tf.concat(
            [logit[:, 0:3615],
             tf.reshape(logit[:, -1], [T, 1])
            ], axis = 1)

        blank_prob = tf.keras.activations.sigmoid(blank_logit)
        nonblank_prob = tf.keras.activations.softmax(nonblank_logit)
        nonblank_prob = (1 - blank_prob) * nonblank_prob

        prob = tf.concat([blank_prob, nonblank_prob], axis = 1)
        loss = rnnt_loss_v2(prob, Y, X_len, Y_len, 3616, True, from_logits=False)

        return tf.reduce_sum(loss) / tf.cast(tf.reduce_sum(Y_len), tf.float32)

    def memory_efficient_chunkwise_joint(self, X_embd, Y_embd, X_padding, X_len, Y_len):
        """                                                     
        CHUNK_WISE RNN-T joint network with multi-head attention 
        in memory efficient manner
                                                                                         
        Args:
            X_embd: a Tensor with shape [B, T, D]
            Y_embd: a Tensor with shape [B, U, D]
            X_padding: a Tensor with shape [B, T]
            X_len: a Tensor with shape [B, 1]
            Y_len: a Tensor with shape [B, 1]
            joint_type: a string
                                                                                         
        Returns:
            out: a Tensor with shape [T0*U0 + T1*U1 ..., D]
                 in memory efficient manner
            X_len: a Tensor with shape [B]
        """
                                                                                         
        B = tf.shape(X_embd)[0]
        T = tf.shape(X_embd)[1]
        D = self.config.decoder.num_units 
        H = 16
                                                                                         
        joint = tf.TensorArray(
            dtype=tf.float32, size=B,
            infer_shape = False,
            name = self.name + "rnnt_joint"
        )
                                                                                         
        for b in tf.range(B):
            X_sliced = tf.slice(X_embd,
                [b, 0, 0],
                [1, X_len[b], D]
            )
                                                                                         
            X_padding_sliced = tf.slice(X_padding,
                [b, 0], [1, X_len[b]]
            )
                                                                                         
            Y_sliced = tf.slice(Y_embd, 
                [b, 0, 0], [1, Y_len[b] + 1, D])
                                                                                         
            # q shape: [1, head, Y_length[b], q_size]
            q = tf.transpose(
                tf.reshape(Y_sliced, 
                    shape = [Y_len[b] + 1, 1, H, D // H]
                ), perm = [0, 2, 1, 3]
            )
            # q shape after tile: [X_length[b], head, Y_length[b], q_size]
            q = tf.tile(q, multiples = [1, 1, X_len[b], 1])
                                                                                         
            # kv shape: [X_length[b], head, W, q_size]
            kv = tf.transpose(
                tf.reshape(X_sliced, 
                    shape = [1, X_len[b], H, D // H]
                ), perm = [0, 2, 1, 3]
            )
                                                                                         
            X_padding_sliced = tf.tile(
                tf.reshape(
                    X_padding_sliced, 
                    shape=[1, X_len[b]]
                ), multiples = [Y_len[b] + 1, 1]
            )
            # [Y_len[b], 1, 1, X_len[b]]
            bias = attention_bias_ignore_padding(1 - X_padding_sliced)
            dual_bias = attention_bias_lower_triangle(X_len[b], 12)
            bias += dual_bias
            # [Y_len[b], head, X_len[b], q_size]
            out, w = scale_dot_product_attention(q, kv, kv, bias, 0.0)
            out = tf.reshape(
                tf.transpose(out, perm = [2, 0, 1, 3]
                ), shape = [X_len[b], (Y_len[b] + 1), D]
            )
                                                                                         
            ## stride slice to cut down length in T dimension
            out = tf.strided_slice(out,
                begin = [0, 0, 0], 
                end = [X_len[b], Y_len[b] + 1, D],
                strides = [4, 1, 1]
            )
                                                                                         
            out = tf.keras.activations.tanh(
                tf.reshape(out + Y_sliced, shape = [-1, D])
            )

            joint = joint.write(b, out)
                                                                                         
        return joint.concat()

    def ce_loss(self, X, Y, L):
        """
        Compute fix-label loss

        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]
            L: length, a Tensor with shape [batch]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        Y = Y[:,0:-1:4]
        batch_size = tf.shape(X)[0]
        len = tf.minimum(tf.shape(X)[1], tf.shape(Y)[1])

        masks = tf.sequence_mask(L, len, tf.float32)

        X = self.out_proj(X)
        dim = tf.shape(X)[2]

        X = tf.slice(X, [0, 0, 0], [batch_size, len, dim])
        Y = tf.slice(Y, [0, 0], [batch_size, len])

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)  
        probs = tf.nn.softmax(X) 
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = tf.keras.losses.SparseCategoricalCrossentropy(    
            from_logits=True, reduction='none')(Y, X)

        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 
