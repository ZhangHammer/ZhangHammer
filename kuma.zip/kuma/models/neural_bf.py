"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice
from frontend.feature import custom_fbank_delta as compute_delta 
from utils.layer_utils import FCLP, MobileNetConv
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class NeuralBeamform(tf.keras.Model):
    def __init__(self, config):
        super(NeuralBeamform, self).__init__()

        self.config = config

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.transformer_decoder import TransformerDecoder as DecoderLayer

        self.fclp = FCLP(config.FCLP, name='FCLP')
        self.fclp_ln = layers.LayerNormalization(epsilon=1e-6, name='FCLP_ln')
        #### BUILD MobileNet blocks ###
        self.conv_block00 = tf.keras.Sequential([
            layers.Conv2D(32, (5, 5), (1, 1), use_bias=False, padding='same', name='conv00'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block00_ln"),
        ])

        self.conv_block01 = tf.keras.Sequential([
            layers.DepthwiseConv2D((3, 3), (1, 1), use_bias=False, padding='same', name='dconv0'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block01_ln"),
        ])
            
        self.conv_f_layers = [
            MobileNetConv(32, (1, 2), (1, 2), (3, 3), name='mobile_conv0'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv1'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv2'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv3'),
            MobileNetConv(64, (1, 2), (1, 2), (3, 3), name='mobile_conv4')
        ]

        self.conv_block1 = tf.keras.Sequential([
            layers.Conv2D(64, (1, 1), (1, 1), use_bias=False, padding='valid', name='conv1'),
            layers.LayerNormalization(epsilon=1e-6, name="conv_block1_ln"),
            layers.Activation('tanh'),                                                                                 
        ])

        self.conv_kernel_size = [(3, 1), (3, 1), (3, 1), (3, 1)]
        self.conv_stride_size = [(2, 1), (1, 1), (2, 1), (1, 1)]

        self.conv_t_layers = [
            layers.Conv2D(32, (3, 1), (2, 1), activation='relu', padding='valid', name="conv_t0"),
            layers.Conv2D(32, (3, 1), (1, 1), activation='relu', padding='valid', name="conv_t1"), 
            layers.Conv2D(64, (3, 1), (2, 1), activation='relu', padding='valid', name="conv_t2"), 
            layers.Conv2D(64, (3, 1), (1, 1), activation='relu', padding='valid', name="conv_t3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(EncoderLayer(config.encoder, name="encoder_{}_{}".format(g_idx, i), group_index=g_idx))

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
                 layers.Dense(enc_embed_units, name="enc_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="enc_embed_ln")
                ])
        self.encoder_dropout = layers.Dropout(config.encoder.res_droprate, name="enc_embed_drop")

        self.decoder_layers = [DecoderLayer(config.decoder, name="decoder_{}".format(idx)) 
                for idx in range(config.decoder.num_blocks)]

        self.decoder_embedding = layers.Dense(config.decoder.num_units, use_bias=False, name="dec_embed_dense")
        self.decoder_dropout = layers.Dropout(config.decoder.res_droprate, name="enc_embed_drop")
        self.decoder_layernorm = layers.LayerNormalization(epsilon=1e-6, name="dec_ln")

        self.e2e_output = layers.Dense(self.config.dst_vocab_size, use_bias=False, name="e2e_output")
        self.ce_loss = tf.keras.losses.SparseCategoricalCrossentropy(
                from_logits=True, reduction='none')

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = self.conv_block00(X)
        out = activations.relu(out, max_value=6)
        out = self.conv_block01(out)
        out = activations.relu(out, max_value=6)
        for conv in self.conv_f_layers:
            out, length = conv(out, length)
        out = self.conv_block1(out)

        for ii, conv in enumerate(self.conv_t_layers):
            if self.config.conv_module.stream:
                out = tf.pad(out, [[0, 0], [2, 0], [0, 0], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [0, 0], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool
                                                                                                  
        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.encoder_embedding(x)
        enc_input = add_timing_signal_1d(enc_input)
        enc_output = self.encoder_dropout(enc_input, training=training)

        enc_outputs = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
                enc_output = enc_output * enc_mask

            if not training:
                enc_output = tf.stop_gradient(enc_output)
            enc_outputs.append(enc_output)

        return enc_outputs

    def decoder_impl(self, x, y, training):
        """
        Decoder block forward 

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool

        Returns:
            dec_output: [batch, tokens, dim]
        """

        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0) 

        dec_input = self.decoder_embedding(dec_input) 
        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)

        dec_input = add_timing_signal_1d(dec_input)
        mask = tf.expand_dims(padding, axis=-1)
        dec_input = dec_input * mask 
        dec_output = self.decoder_dropout(dec_input)

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(x, dec_output, training)                          
            dec_output *= mask 

        if self.config.decoder.decoder_prenorm:
            dec_output = self.decoder_layernorm(dec_output) 
            dec_output *= mask

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output

    def call(self, X, Y, L, training):
        """                                                                       
        NeuralBeamform model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens] 
            L: a Tensor with shape [batch, 1] 
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size] 
        """

        bf_out, mask = self.fclp(X, L)
        length = tf.reduce_sum(mask, axis=-1)

        B = tf.shape(bf_out)[0]
        C = self.config.FCLP.complex_conv['channel'] 
        W = self.config.FCLP.complex_full['out_dim']

        bf_out = tf.reshape(bf_out, [B, -1, W * C])
        bf_out = self.fclp_ln(bf_out)
        bf_out = tf.reshape(bf_out, [B, -1, W, C])

        enc_input, enc_length = self.conv_downsample(bf_out, length)
        enc_input = tf.reshape(enc_input, 
            shape=[tf.shape(enc_input)[0], 
                   tf.shape(enc_input)[1], 
                   self.config.conv_module.out_dim
                  ])

        enc_output = self.encoder_impl(enc_input, enc_length, training)
        dec_output = self.decoder_impl(enc_output[-1], Y, training)

        e2e_logits = self.e2e_output(dec_output)

        return e2e_logits 

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 
    
        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)

        Y = tf.math.maximum(Y - 4, 0)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = tf.math.reduce_mean(loss / tf.cast(label_len, tf.float32))

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err

    def e2e_loss(self, X, Y):
        """                                                                    
        E2E Cross entropy loss 

        Args:
            X: a Tensor with shape [batch, tokens, dst_vocab_size]
            Y: a Tensor with shape [batch, tokens] 

        Returns:

        """

        """
        slice X and label to same shape, label shape is greater or equal with X
        """
        masks = tf.cast(tf.math.greater(Y, 0), tf.float32)

        batch_size = tf.shape(X)[0]
        len = tf.shape(X)[1]
        dim = tf.shape(X)[2]

        Y = tf.slice(Y, [0, 0], [batch_size, len])
        masks = tf.slice(masks, [0, 0], [batch_size, len])

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)
        probs = tf.nn.softmax(X)
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = self.ce_loss(Y, X)
        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 
