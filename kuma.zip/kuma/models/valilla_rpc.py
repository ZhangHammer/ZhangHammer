"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class ReversePyramidConformer(tf.keras.Model):
    def __init__(self, config):
        super(ReversePyramidConformer, self).__init__()

        self.config = config
        self.mean, self.var = self.load_cmvn(self.config.cmvn_path)

        if self.config.encoder == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.transformer_decoder import TransformerDecoder as DecoderLayer

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 1), (2, 2), (1, 1)]

        self.conv_layers = [
            layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv0"),
            layers.Conv2D(32, (3, 3), (1, 1), activation='relu', padding='valid', name="conv1"), 
            layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv2"), 
            layers.Conv2D(64, (3, 3), (1, 1), activation='relu', padding='valid', name="conv3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(self.config.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(EncoderLayer(config, name="encoder_{}_{}".format(g_idx, i), group_index=g_idx))

        self.decoder_layers = [DecoderLayer(config, name="decoder_{}".format(idx)) 
                for idx in range(self.config.decoder_num_blocks)]

        enc_embed_units = config.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
                 layers.Dense(enc_embed_units, name="enc_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="enc_embed_ln")
                ])
        self.encoder_dense = layers.Dense(config.encoder_pyramid[-1]['num_units'], name="enc_downsample_dense")

        self.decoder_embedding = layers.Dense(self.config.num_units, use_bias=False, name="dec_embed_dense")

        self.encoder_dropout = layers.Dropout(self.config.res_droprate, name="enc_embed_drop")
        self.decoder_dropout = layers.Dropout(self.config.res_droprate, name="dec_embed_drop")
        self.decoder_layernorm = layers.LayerNormalization(epsilon=1e-6, name="dec_ln")
        self.output_layer = layers.Dense(self.config.dst_vocab_size, use_bias=False, name="out_dense")

        self.ce_loss = tf.keras.losses.SparseCategoricalCrossentropy(
                            from_logits=True, reduction='none')

    def load_cmvn(self, cmvn_path):
        means = []
        vars = []
        
        with open(cmvn_path, "r") as cmvn_file:
            lines = cmvn_file.readlines()
            for line in lines:
                line = line.strip()
                mean, var = line.split()
                means.append(float(mean))

                var = float(var)
                var = 1.0 / np.sqrt(var)
                var = var if var < 100000.0 else 100000.0
                vars.append(var)
        
        return tf.constant(means, tf.float32), tf.constant(vars, tf.float32)

    def conv_downsample(self, x, length):
        """
        convlution downsample forward

        Args:
            x: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = tf.expand_dims(x, axis=-1)
        for ii, conv in enumerate(self.conv_layers):
            if self.config.stream_mode:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT")
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT")

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)
        #out = tf.reshape(out, [tf.shape(out)[0], tf.shape(out)[1], tf.shape(out)[2] * tf.shape(out)[3]])

        return out, length 

    def pyramid_donwsample(self, x, length, dim, training):
        """
        Pyramid encoder downsample on T axis

        Args:
            x: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch]
            training: bool

        Returns:
            outputs: a Tensor with shape [batch length // 2, dim]
            length: a Tensor with shape [batch]
        """ 
        tail_pad = tf.shape(x)[1] % 2
        x = tf.pad(x, [[0, 0], [0, tail_pad], [0, 0]], "CONSTANT")

        batch_size = tf.shape(x)[0]
        max_frames = tf.shape(x)[1]

        outputs = x[:, ::2, :]
        #if training: # random chose odd or evn for train
        #    base_indices = tf.range(batch_size * max_frames // 2)
        #    base_indices *= 2

        #    rand_indices = tf.cast(tf.random.uniform([batch_size * max_frames // 2], minval=0, maxval=2), tf.int32)
        #    rand_indices += base_indices

        #    cum_len = tf.range(batch_size) * max_frames + length
        #    max_indices = tf.tile(tf.reshape(cum_len, [batch_size, 1]), multiples=[1, max_frames // 2])
        #    max_indices = tf.reshape(max_indices, [-1])
        #    indices = tf.math.minimum(rand_indices, max_indices - 1)

        #    outputs = tf.gather(tf.reshape(x, [batch_size * max_frames, dim]), indices)
        #    outputs = tf.reshape(outputs, [batch_size, max_frames // 2, dim])
        #else:   # odd frame for test
        #    outputs = x[:, ::2, :]  

        return outputs, (length + 1) // 2

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.encoder_embedding(x)
        enc_input = add_timing_signal_1d(enc_input)
        enc_output = self.encoder_dropout(enc_input, training=training)
    
        for g_idx, group in enumerate(self.config.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
                enc_output = enc_output * enc_mask

            if g_idx == len(self.config.encoder_pyramid) - 1:
                break

            enc_output, L = self.pyramid_donwsample(enc_output, L, group['num_units'], training)
            enc_output = self.encoder_dense(enc_output)
            enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(enc_output)[1]), dtype=tf.float32)
            enc_mask = tf.expand_dims(enc_padding, axis=-1)

        if not training:
            enc_output = tf.stop_gradient(enc_output)

        return enc_output

    def decoder_impl(self, x, y, training):
        """
        Decoder block forward 

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool

        Returns:
            dec_output: [batch, tokens, dim]
        """

        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0) 

        dec_input = self.decoder_embedding(dec_input) 
        if self.config.scale_embedding:
            dec_input = dec_input * (self.config.num_units ** 0.5)

        dec_input = add_timing_signal_1d(dec_input)
        dec_output = self.decoder_dropout(dec_input)

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(x, dec_output, training)                          

        if self.config.decoder_prenorm:
            dec_output = self.decoder_layernorm(dec_output) 

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output

    def call(self, X, Y, Z, L, training):
        """
        RPC model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens] 
            Z: a Tensor with shape [batch, tokens] 
            L: a Tensor with shape [batch] 
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size] 
        """

        x = tf.reshape(X, [tf.shape(X)[0], tf.shape(X)[1], 1])
        length = tf.reshape(L, [-1])

        mel_bank = pcm2fbank(x)
        length = (length - 400) // 160 + 1  #acutal frames

        mask = tf.sequence_mask(length, tf.shape(mel_bank)[1])
        enc_input = (mel_bank - self.mean) * self.var
        enc_input = enc_input * tf.expand_dims(tf.cast(mask, dtype=tf.float32), axis=-1)

        enc_input, enc_length = self.conv_downsample(enc_input, length)
        enc_input = tf.reshape(enc_input, shape=[tf.shape(enc_input)[0], 
                                                 tf.shape(enc_input)[1],
                                                 self.config.conv_out_dim])

        enc_output = self.encoder_impl(enc_input, enc_length, training)
        dec_output = self.decoder_impl(enc_output, Y, training)

        return self.output_layer(dec_output)

    def e2e_loss(self, X, Y):
        """                                                                    
        E2E Cross entropy loss 
                                                                        
        Args:
            X: a Tensor with shape [batch, tokens, dst_vocab_size]
            Y: a Tensor with shape [batch, tokens] 

        Returns:
            
        """
        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)  
        probs = tf.nn.softmax(X) 
        masks = tf.cast(tf.not_equal(Y, 0), tf.float32)
        Y_int32 = tf.cast(Y, tf.int32)
 
        batch_size = tf.shape(X)[0] 
        len = tf.shape(X)[1]
        dim = tf.shape(X)[2]

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = self.ce_loss(Y, X)
        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 

        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]
            
        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = loss / tf.cast(label_len, tf.float32)

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err, err
