"""Implementation of transformer model"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice
from frontend.feature import custom_fbank_delta as compute_delta 
from utils.layer_utils import FCLP, ViterbiAlign
from utils.attention_utils import add_timing_signal_1d
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

class KeywordSpotting(tf.keras.Model):
    def __init__(self, config):
        super(KeywordSpotting, self).__init__()

        self.config = config

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.transformer_decoder import TransformerDecoder as DecoderLayer

        self.fclp_layer = FCLP(config.FCLP, name='FCLP')

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 1), (2, 2), (1, 1)]

        self.conv_layers = [
                layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv0"),
                layers.Conv2D(32, (3, 3), (1, 1), activation='relu', padding='valid', name="conv1"), 
                layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv2"), 
                layers.Conv2D(64, (3, 3), (1, 1), activation='relu', padding='valid', name="conv3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(EncoderLayer(config.encoder, name="encoder_{}_{}".format(g_idx, i), group_index=g_idx))

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
                 layers.Dense(enc_embed_units, name="enc_embed_dense"),
                 layers.LayerNormalization(epsilon=1e-6, name="enc_embed_ln")
                ])
        self.encoder_dropout = layers.Dropout(config.encoder.res_droprate, name="enc_embed_drop")

        self.decoder_layers = [DecoderLayer(config.decoder, name="decoder_{}".format(idx)) 
                for idx in range(config.decoder_num_blocks)]
        self.decoder_embedding = layers.Dense(config.decoder.num_units, use_bias=False, name="dec_embed_dense")
        self.decoder_dropout = layers.Dropout(config.decoder.res_droprate, name="enc_embed_drop")
        self.decoder_layernorm = layers.LayerNormalization(epsilon=1e-6, name="dec_ln")

        self.output1 = layers.Dense(self.config.dst_vocab_size, use_bias=False, name="output1")
        self.output2 = layers.Dense(self.config.dst_vocab_size, use_bias=False, name="output2")
        self.ce_loss = tf.keras.losses.SparseCategoricalCrossentropy(
                from_logits=True, reduction='none', name='ce_loss1')

        self.cfd_output = layers.Dense(self.config.output_dim, use_bias=False, name="cfd_output")

        self.vtb_align = False if config.vtb_align is None else config.vtb_align 
        self.viterbi = ViterbiAlign(
                head_blank=config.viterbi.head_blank, 
                tail_blank=config.viterbi.tail_blank, 
                token_repeat=config.viterbi.token_repeat, 
                name="vib_ali")

        ### parse decode path and score in a dict
        self.decode_path = {} 
        for word, path in config.viterbi.decode_path.items():
            self.decode_path[word] = tf.convert_to_tensor(
                [int(v) for v in path.strip().split()], tf.int32)

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = X
        for ii, conv in enumerate(self.conv_layers):
            if self.config.stream_mode:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT", name="conv_downsample_pad_{}".format(ii))

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, X, L, Z, training): 
        """
        Encoder block forward

        Args:
            X: a Tensor with shape [batch, frames, dim]
            L: length, a Tensor with shape [batch, 1]
            Z: a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            decoder_output
        """
        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(X)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_input = self.encoder_embedding(X)
        enc_input = add_timing_signal_1d(enc_input)
        enc_input_drop = self.encoder_dropout(enc_input, training=training)
        enc_input_drop = tf.stop_gradient(enc_input_drop)

        enc_output_lst = []

        group = self.config.encoder.encoder_pyramid[0]
        start = group['start']
        end = group['end']

        enc_output = enc_input_drop
        for i in range(start, end):
            enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
            enc_output = enc_output * enc_mask
        enc_output_lst.append(enc_output)
        logits = self.output1(enc_output)
        logits = tf.stop_gradient(logits)

        path = None
        if self.vtb_align:
            _, begin, end, path = self.viterbi_align(logits, L)

            #batch_size = tf.shape(enc_output)[0]
            #length = tf.shape(enc_output)[1]
            #new_mask = tf.tile(tf.reshape(tf.range(length), [1, -1]), [batch_size, 1])
            #head_mask = tf.cast(tf.math.greater(new_mask, begin[:,None]), tf.float32)
            #tail_mask = tf.cast(tf.math.less(new_mask, end[:,None]), tf.float32)
            #new_padding = head_mask * tail_mask * enc_padding 
            #enc_padding = enc_padding * Z + new_padding * (1 - Z)
            #tf.print(["New padding check: ", tf.math.reduce_sum(new_padding, axis=-1), tf.math.reduce_sum(enc_padding, axis=-1)])
            #enc_mask = tf.expand_dims(enc_padding, axis=-1)

        group = self.config.encoder.encoder_pyramid[1]
        start = group['start']
        end = group['end']

        enc_output = enc_input_drop
        for i in range(start, end):
            enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
            enc_output = enc_output * enc_mask

        if not training:
            enc_output = tf.stop_gradient(enc_output)

        enc_output_lst.append(enc_output)
        return enc_output_lst[1], path 

    def decoder_impl(self, x, y, training):
        """
        Decoder block forward 

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool

        Returns:
            dec_output: [batch, tokens, dim]
        """

        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0)

        dec_input = self.decoder_embedding(dec_input) 
        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)

        dec_input = add_timing_signal_1d(dec_input)
        dec_input = dec_input * tf.expand_dims(padding, axis=-1)

        dec_output = self.decoder_dropout(dec_input)

        for dec_layer in self.decoder_layers:
            dec_output = dec_layer(x, dec_output, training)                          

        if self.config.decoder_prenorm:
            dec_output = self.decoder_layernorm(dec_output) 

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output


    def viterbi_align(self, X, L):
        """
        Viterbi force alignment on all path

        Args:
            X: a Tensor with shape [batch, length, dim]
            L: a Tensor with shape [batch]
        Retruns:
            last_index: a Tensor with shape [batch, 2]
        """

        mask = tf.sequence_mask(L, tf.shape(X)[1], dtype=tf.float32)
        mask = tf.expand_dims(mask, axis=-1)
        score = tf.nn.softmax(X) * mask

        batch_size = tf.shape(X)[0]
        length = tf.shape(X)[1]

        max_probs = tf.ones(batch_size, tf.float32) * -1e30
        max_begin = tf.zeros(batch_size, tf.int32)
        max_end = tf.zeros(batch_size, tf.int32)
        max_path = tf.zeros([batch_size, self.config.viterbi.max_path_length], tf.int32)
        for word, path in self.decode_path.items():
            new_probs, new_begin, new_end = self.viterbi(score, path, L)
            mask = tf.cast(tf.greater(new_probs, max_probs), tf.int32)
            max_begin = new_begin * mask + max_begin * (1 - mask)
            max_end = new_end * mask + max_end * (1 - mask)
            max_probs = tf.math.maximum(max_probs, new_probs)

            num = self.config.viterbi.max_path_length - tf.shape(path)[0] 
            padded_path = tf.pad(tf.reshape(path, [1, -1]), [[0, 0], [0, num]], 'CONSTANT')
            padded_path = tf.tile(padded_path, [batch_size, 1])
            mask = tf.expand_dims(mask, axis=-1)

            max_path = padded_path * mask + max_path * (1 - mask)

        max_probs = tf.stop_gradient(max_probs)
        max_begin = tf.stop_gradient(max_begin)
        max_end = tf.stop_gradient(max_end)
        max_path = tf.stop_gradient(max_path)

        return max_probs, max_begin, max_end, max_path

    def call(self, X, Y, Z, L, training):
        """                                                                       
        KeywordSpotting model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens]
            Z: a Tensor with shape [batch, 1] 
            L: a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size]
        """

        bf_out, mask = self.fclp_layer(X, L)
        length = tf.cast(tf.reduce_sum(mask, axis=-1), tf.int32)
        enc_input, enc_length = self.conv_downsample(bf_out, length)
        enc_input = tf.reshape(enc_input,
            shape=[tf.shape(enc_input)[0], tf.shape(enc_input)[1], self.config.conv_out_dim])

        batch_size = tf.shape(Y)[0]
        Z = tf.reshape(Z, [batch_size, 1])

        enc_output1, path = self.encoder_impl(enc_input, enc_length, Z, training)
        if self.vtb_align:
            vtb_err = tf.edit_distance(tf.sparse.from_dense(path),
                tf.sparse.from_dense(tf.cast(Y, tf.int32)))
            vtb_err = tf.stop_gradient(vtb_err)

            path = tf.cast(path, tf.float32)

            num1 = tf.shape(Y)[1]
            num2 = tf.shape(path)[1]
            Y = tf.cond(num1 < num2,
                lambda: tf.pad(Y, [[0, 0], [0, num2 - num1]], "CONSTANT") * Z + path * (1 - Z),
                lambda: Y * Z + tf.pad(path, [[0, 0], [0, num1 - num2]], "CONSTANT") * (1 - Z))
            tf.print(["Path check: ", tf.shape(Z), tf.math.reduce_sum(Z)])
        else:
            vtb_err = tf.constant(0.0, tf.float32)

        dec_output = self.decoder_impl(enc_output1, Y, training)
        dec_output = tf.math.reduce_mean(dec_output, axis=1, keepdims=True)

        return self.cfd_output(dec_output), vtb_err
        #return self.output2(enc_output1), tf.math.reduce_mean(vtb_err)

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 
    
        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = tf.math.reduce_mean(loss / tf.cast(label_len, tf.float32))

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err, err

    def e2e_loss(self, X, Y):
        """                                                                    
        E2E Cross entropy loss 

        Args:
            X: a Tensor with shape [batch, tokens, dst_vocab_size]
            Y: a Tensor with shape [batch, tokens]

        Returns:

        """

        """
        slice X and label to same shape, label shape is greater or equal with X
        """
        batch_size = tf.shape(X)[0]
        #Y = tf.strided_slice(Y, [0, 0], [batch_size, tf.shape(Y)[1]], [1, 4])
        masks = tf.cast(tf.math.greater(Y, -1), tf.float32)

        len = tf.math.minimum(tf.shape(X)[1], tf.shape(Y)[1])
        dim = tf.shape(X)[2]

        Y = tf.slice(Y, [0, 0], [batch_size, len])
        X = tf.slice(X, [0, 0, 0], [batch_size, len, dim])
        masks = tf.slice(masks, [0, 0], [batch_size, len])

        tf.print("Label check: ", Y)

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)
        probs = tf.nn.softmax(X)
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = self.ce_loss(Y, X)
        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 

    def constrast_loss(self, X, Y):
        """
        Compute constrastive loss same as work in SimCLR

        Args:
            X: a Tensor with shape [batch, units]
            Y: a Tensor with shape [batch, units]
                                                                              
        Returns:
            loss: a Tensor with shape [1]
        """
        batch_size = tf.shape(X)[0]

        X_norm = tf.math.l2_normalize(X, epsilon=1e-6)
        Y_norm = tf.math.l2_normalize(Y, epsilon=1e-6)

        sim_mat = tf.linalg.matmul(X_norm, Y_norm, transpose_b=True)
        preds = tf.cast(tf.math.argmax(sim_mat, axis=-1), tf.int32)
        acc = tf.cast(tf.math.equal(preds, tf.range(batch_size)), tf.float32)

        sim_mat = tf.math.exp(sim_mat / self.temperature)
        mask = tf.linalg.diag(tf.ones([batch_size]))

        intra_sim = sim_mat * mask
        inter_sim = sim_mat * (1 - mask)

        intra_sim = tf.math.reduce_sum(intra_sim, axis=-1)
        inter_sim = tf.math.reduce_sum(inter_sim, axis=-1)
        loss = -1 * tf.math.log(tf.math.reduce_sum(intra_sim/inter_sim))

        return loss, tf.reduce_mean(acc)
