"""
Implementation of 2pass E2E speech recognition with Reduced & tied Conformer Transducer including:
    1. conformer encoder
    2. reduced & tied predict network
    3. joint network
    4. RNN-T training loss
    5. conformer rescore
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from frontend.feature import pcm2fbank, compute_splice, compute_delta
from utils.layer_utils import sequence_to_segments, segments_to_sequence
from utils.attention_utils import attention_bias_lower_triangle, MultiHeadAttention
import numpy as np

import tensorflow as tf
from tensorflow.keras import layers, activations, models

from cpp import rnnt_loss_v2

class ReducedConformerT(tf.keras.Model):
    """
    Initialization
    """
    def __init__(self, config):
        super(ReducedConformerT, self).__init__()

        self.config = config
        self.mean, self.var = self.load_cmvn(self.config.Fbank.cmvn_path)

        if self.config.encoder.type == "conformer":  
            from encoder.conformer_encoder import ConformerEncoder as EncoderLayer 
        else:
            raise TypeError("{} not defined".format(self.config.encoder))

        from decoder.lstm_decoder import ResidualLstm as DecoderLayer

        self.conv_kernel_size = [(3, 3), (3, 3), (3, 3), (3, 3)]
        self.conv_stride_size = [(2, 2), (1, 1), (2, 2), (1, 1)]

        self.conv_layers = [
            layers.Conv2D(32, (3, 3), (2, 2), activation='relu', padding='valid', name="conv0"),
            layers.Conv2D(32, (3, 3), (1, 1), activation='relu', padding='valid', name="conv1"), 
            layers.Conv2D(64, (3, 3), (2, 2), activation='relu', padding='valid', name="conv2"), 
            layers.Conv2D(64, (3, 3), (1, 1), activation='relu', padding='valid', name="conv3")]

        self.encoder_layers = []
        for g_idx, group in enumerate(self.config.encoder.encoder_pyramid):
            start = group['start']
            end = group['end']

            for i in range(start, end):
                self.encoder_layers.append(
                    EncoderLayer(config.encoder, 
                        name="encoder_{}_{}".format(g_idx, i), 
                        group_index=g_idx
                    )
                )

        enc_embed_units = config.encoder.encoder_pyramid[0]['num_units']
        self.encoder_embedding = tf.keras.Sequential([
            layers.Dense(enc_embed_units, 
               name="enc_embed_dense"
            ),
            layers.LayerNormalization(
               epsilon=1e-6, name="enc_embed_ln"
            ),
            layers.Dropout(
                config.encoder.res_droprate,
                name="enc_embed_drop"
            )
        ])

        self.encoder_dim_proj = tf.keras.Sequential([
            layers.Dense(config.encoder.encoder_pyramid[1]['num_units'], 
               name="enc_embed_dense"
            ),
            layers.LayerNormalization(
               epsilon=1e-6, name="enc_embed_ln"
            ),
            layers.Dropout(
                config.encoder.res_droprate,
                name="enc_embed_drop"
            )
        ])

        #self.encoder_dropout = layers.Dropout(
        #        config.encoder.res_droprate,
        #        name="enc_embed_drop")

        self.mha = MultiHeadAttention(
                config.decoder.num_units,
                config.decoder.num_heads,
                dropout_rate = config.decoder.droprate,
                name = self.name + "mha")

        self.encoder_proj = tf.keras.Sequential([
                layers.Dense(
                    config.decoder.num_units,
                    use_bias=True,
                    name="encoder_proj"),
                layers.LayerNormalization(
                    epsilon=1e-3,
                    name='encoder_proj_ln')])

        self.decoder_proj = tf.keras.Sequential([
                layers.Dense(
                    config.decoder.num_units,
                    use_bias=True,
                    name="decoder_proj"),
                layers.LayerNormalization(
                    epsilon=1e-3,
                    name="decoder_proj_ln")])

        self.decoder_embedding = layers.Dense(
                config.decoder.num_units, 
                use_bias=False, 
                name="dec_embed_dense")

        self.rnnt_proj = layers.Dense(
                config.dst_vocab_size, 
                use_bias=False,
                name="out_proj")


    def load_cmvn(self, cmvn_path):
        means = []
        vars = []

        with open(cmvn_path, "r") as cmvn_file:
            lines = cmvn_file.readlines()
            for line in lines:
                line = line.strip()
                mean, var = line.split()
                means.append(float(mean))

                var = float(var)
                var = 1.0 / np.sqrt(var)
                var = var if var < 100000.0 else 100000.0
                vars.append(var)
        
        return tf.constant(means, tf.float32), tf.constant(vars, tf.float32)

    def conv_downsample(self, X, length):
        """
        convlution downsample forward

        Args:
            X: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape 

        Retruns:
            out: a Tensor with shape [batch, length, dim]
            length: a Tensor with shape [batch, 1]
        """
        out = X if self.config.Fbank['splice'] else tf.expand_dims(X, axis=-1)
        for ii, conv in enumerate(self.conv_layers):
            if self.config.stream:
                out = tf.pad(out, [[0, 0], [2, 0], [1, 1], [0,0]], "CONSTANT")
            else:
                out = tf.pad(out, [[0, 0], [1, 1], [1, 1], [0,0]], "CONSTANT")

            out = conv(out)
            length = (length - self.conv_kernel_size[ii][0] + 2) // self.conv_stride_size[ii][0] + 1
            conv_mask = tf.cast(tf.sequence_mask(length, tf.shape(out)[1]), tf.float32)
            out = out * tf.expand_dims(tf.expand_dims(conv_mask, axis=-1), axis=-1)

        return out, length 

    def encoder_impl(self, x, L, training):
        """
        Encoder block forward

        Args:
            x: a Tensor with shape [batch, frames, dim]
            y: length, a Tensor with shape [batch, 1]
            training: a bool

        Returns:
            decoder_output
        """

        enc_padding = tf.cast(tf.sequence_mask(L, tf.shape(x)[1]), dtype=tf.float32)
        enc_mask = tf.expand_dims(enc_padding, axis=-1)

        enc_output = self.encoder_embedding(x)
        group = self.config.encoder.encoder_pyramid[0]
        start = group['start']
        end = group['end']

        for i in range(start, end):
            enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
            enc_output = enc_output * enc_mask

        enc_output = self.encoder_dim_proj(enc_output)
        enc_output = enc_output * enc_mask
        ori_shape = tf.shape(enc_output)

        enc_segs, N = sequence_to_segments(enc_output, 45, 15)
        mask_segs, N = sequence_to_segments(enc_mask, 45, 15)

        group = self.config.encoder.encoder_pyramid[1]
        start = group['start']
        end = group['end']

        enc_output = tf.reshape(enc_segs, [-1, 45, group['num_units']])
        enc_mask = tf.reshape(mask_segs, [-1, 45, 1])
        enc_padding = tf.squeeze(enc_mask, axis=-1)

        for i in range(start, end):
            enc_output = self.encoder_layers[i](enc_output, training, enc_padding)
            enc_output = enc_output * enc_mask

        enc_recover = segments_to_sequence(enc_output, 15, N, group['num_units'])

        enc_recover = tf.slice(
            tf.squeeze(enc_recover, axis=1),
            [0, 0, 0], ori_shape,
        )

        return [enc_recover]

    def decoder_impl(self, y, training):
        """
        Decoder block forward 

        Args:
            y: a Tensor with shape [batch, tokens, 1] 
            training: a bool
                                                                                      
        Returns:
            dec_output: [batch, tokens, dim]
        """

        padding = tf.cast(tf.math.not_equal(y, 0), tf.float32)
        dec_input = tf.one_hot(tf.cast(y, tf.int32),
                self.config.dst_vocab_size,
                on_value=1, off_value=0,
                dtype=tf.float32) 

        dec_input = self.decoder_embedding(dec_input)

        if self.config.decoder.scale_embedding:
            dec_input = dec_input * (self.config.decoder.num_units ** 0.5)

        bias = attention_bias_lower_triangle(tf.shape(dec_input)[1])
        dec_output, _ = self.mha(dec_input, dec_input, dec_input, bias)  
        dec_output = tf.keras.activations.swish(self.decoder_proj(dec_output))
        dec_output = dec_output * tf.expand_dims(padding, axis=-1) 

        if not training:
            dec_output = tf.stop_gradient(dec_output)

        return dec_output

    def compute_fbank(self, X, L):
        """
        compute fbank feature with delta or splice

        Args:
            X: a Tensor with shape [batch, sample_num, 1]
            length: a Tensor with shape [batch, 1]

        Returns:
            mel_banK: a Tensor with shape [batch, frames, dim]
            length: a Tensor with shape [batch, 1]
        """

        length = tf.reshape(L, [-1])

        num_bins = self.config.Fbank.bins
        mel_bank = pcm2fbank(X) if self.config.Fbank.compute else tf.reshape(X, [tf.shape(X)[0], tf.shape(X)[1] // num_bins, num_bins])
        length = (length - 400) // 160 + 1 if self.config.Fbank.compute else length

        B = tf.shape(X)[0]
        window = self.config.Fbank.window
        order = self.config.Fbank.order
        sigma = self.config.Fbank.sigma
        lctx = self.config.Fbank.left_context
        rctx = self.config.Fbank.right_context

        if lctx > 0:
            head_copy = tf.tile(
                tf.reshape(mel_bank[:,0,:], shape = [B, 1, num_bins]),
                multiples = [1, lctx, 1]
            )
            mel_bank = tf.concat([head_copy, mel_bank], axis=1)

        if rctx > 0:
            tail_copy = tf.tile(
                tf.reshape(mel_bank[:,-1,:], shape = [B, 1, num_bins]),
                multiples = [1, rctx, 1]
            )
            mel_bank = tf.concat([mel_bank, tail_copy], axis=1)

        if self.config.Fbank.delta:
            mel_bank = compute_delta(mel_bank, window, order, sigma, lctx, rctx)

        mel_bank = (mel_bank - self.mean) * self.var

        if self.config.Fbank.splice:
            mel_bank = compute_splice(mel_bank, lctx, rctx)

        return mel_bank, length
    
    def joint_network(self, X_embd, Y_embd, X_padding, Y_padding):
        """
        RNN-T joint network, generate RNN-T search graph
        Only add joint type is support for now

        Args:
            X_embd: a Tensor with shape [B, T, D]
            Y_embd: a Tensor with shape [B, U, D]
            X_padding: a Tensor with shape [B, T]
            Y_padding: a Tensor with shape [B, U]
            joint_type: a string

        Returns:
            out: a Tensor with shape [B, T*U, D]
                 which is a memory NOT efficient manner
        """
        out = tf.expand_dims(X_embd, axis=2) + tf.expand_dims(Y_embd, axis=1)
        out = tf.keras.activations.tanh(out)
        mask = tf.expand_dims(X_padding, axis=2) * tf.expand_dims(Y_padding, axis=1)

        return out, mask

    def memory_efficient_joint_network(self, X_embd, Y_embd, X_length, Y_length):
        """
        RNN-T joint network, generate RNN-T search graph
        in memory efficient manner
        Only add joint type is support for now 

        Args:
            X_embd: a Tensor with shape [B, T, D]
            Y_embd: a Tensor with shape [B, U, D]
            X_length: a Tensor with shape [B, 1]
            Y_length: a Tensor with shape [B, 1]
            joint_type: a string

        Returns:
            out: a Tensor with shape [B, T*U, D]
                 which is a memory NOT efficient manner
        """
        B = tf.shape(X_embd)[0]
        D = tf.shape(X_embd)[2]

        joint = tf.TensorArray(
            dtype = tf.float32, size=B,
            infer_shape=False,
            name=self.name + "rnnt_joint"
        )

        for b in tf.range(B):
            X_sliced = tf.reshape(
                tf.slice(X_embd, [b, 0, 0], [1, X_length[b], D]),
                shape = [X_length[b], 1, D]
            )
            Y_sliced = tf.reshape(
                tf.slice(Y_embd, [b, 0, 0], [1, Y_length[b]+1, D]),
                shape = [1, Y_length[b]+1, D]
            )
            XY_joint = tf.keras.activations.tanh(
                tf.reshape(X_sliced + Y_sliced,
                    shape = [X_length[b] * (Y_length[b]+1), D]
                )
            )

            joint = joint.write(b, XY_joint)

        return joint.concat()

    def memory_efficient_chunkwise_joint(self, X_embd, X_padding, Y_len):
        """                                                     
        CHUNK_WISE RNN-T joint network with multi-head attention 
        in memory efficient manner

        Args:
            X_embd: a Tensor with shape [B, N, W, D]
            Y_embd: a Tensor with shape [B, U, D]
            X_padding: a Tensor with shape [B, N, W]
            Y_len: a Tensor with shape [B, 1]
            joint_type: a string
                                                         
        Returns:
            out: a Tensor with shape [T0*U0 + T1*U1 ..., D]
                 in memory efficient manner
        """

        B = tf.shape(X_embd)[0]
        W = tf.shape(X_embd)[2]
        D = self.config.decoder.num_units 
        H = 16

        joint = tf.TensorArray(
            dtype=tf.float32, size=B,
            infer_shape = False,
            name = self.name + "rnnt_joint"
        )

        X_len = tf.reduce_sum(
            tf.cast(
                tf.greater(
                    tf.reduce_sum(X_padding, axis=-1), 0
                ), tf.int32
            ), axis=-1
        )

        for b in tf.range(B):
            X_sliced = tf.slice(X_embd,
                [b, 0, 0, 0],
                [1, X_length[b], W, D]
            )

            X_padding_sliced = tf.slice(X_padding,
                [b, 0, 0], [1, X_length[b], W]
            )

            Y_sliced = tf.slice(Y_embd, 
                [b, 0, 0], [1, Y_length[b], D])

            # q shape: [1, head, Y_length[b], q_size]
            q = tf.transpose(
                tf.reshape(Y_sliced, 
                    shape = [1, Y_len[b], H, D // H]
                ), perm = [0, 2, 1, 3]
            )
            # q shape after tile: [X_length[b], head, Y_length[b], q_size]
            q = tf.tile(q, multiples = [X_length[b], 1, 1, 1])

            # kv shape: [X_length[b], head, W, q_size]
            kv = tf.transpose(
                tf.reshape(X_sliced, 
                    shape = [X_len[b], W, H, D // H]
                ), perm = [0, 2, 1, 3]
            )

            # [X_length[b], 1, 1, W]
            bias = attention_bias_ignore_padding(1 - tf.squeeze(X_padding_sliced))
            # [X_length[b], head, Y_length[b], q_size]
            out, w = scale_dot_product_attention(q, kv, kv, bias, 0.0)
            out = tf.reshape(
                tf.transpose(out, perm = [0, 2, 1, 3]
                ), shape = [X_len[b] * Y_len[b], D]
            )

            joint = joint.write(b, out)

        return joint.concat() 

    def call(self, X, L, training):
        """
        Conformer transducer model forward 

        Args:
            X: a Tensor with shape [batch, frames, dim]
            Y: a Tensor with shape [batch, tokens] 
            L: a Tensor with shape [batch] 
            training: a bool

        Returns:
            preds: a Tensor with shape [batch, tokens, dst_vocab_size]
        """

        mel_bank, length = self.compute_fbank(X, L)

        mask = tf.sequence_mask(length, tf.shape(mel_bank)[1])

        enc_input, enc_length = self.conv_downsample(mel_bank, length)
        enc_input = tf.reshape(enc_input, shape=[tf.shape(enc_input)[0],
                                                 tf.shape(enc_input)[1],
                                                 self.config.conv_out_dim])

        enc_output = self.encoder_impl(enc_input, enc_length, training)

        return enc_output[-1], enc_length

    def rnnt_loss(self, enc_output, Y, enc_length, training):
        """
        Warp RNN-T loss
        Args:
            enc_output: a Tensor with shape [B, T, D]
            Y: a Tensor with shape [B, U]
            enc_length: a Tensor with shape [B]

        Returns:
            loss: a Tensor with shape [1]
        """

        enc_output = tf.keras.activations.swish(self.encoder_proj(enc_output))
        enc_length = tf.cast(enc_length - 1, tf.int32)

        Z = tf.pad(Y, [[0, 0], [1, 0]], "CONSTANT", constant_values=1748)
        dec_output = self.decoder_impl(Z, training)

        enc_padding = tf.sequence_mask(
                enc_length,
                tf.shape(enc_output)[1],
                dtype=tf.float32)

        dec_padding = tf.cast(tf.math.not_equal(Z, 0), tf.float32)
        Y_length = tf.math.reduce_sum(
            tf.cast(
                tf.math.not_equal(Y, 0), tf.int32
            ), axis=-1
        )

        logit = self.memory_efficient_joint_network(
                enc_output, dec_output, enc_length, Y_length)

        logit = tf.reshape(logit, [-1, self.config.decoder.num_units])
        logit_proj = self.rnnt_proj(logit)

        loss = rnnt_loss_v2(logit_proj, Y, enc_length, Y_length, 1748, True)

        return tf.reduce_sum(loss) / tf.cast(tf.reduce_sum(Y_length), tf.float32)

    def ctc_loss(self, X, Y):
        """
        compute CTC loss 
                                                                                              
        Args:
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]
                                                                                              
        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        X = self.output_proj(X)

        Y = tf.math.maximum(Y, 0)
        logit_padding = tf.math.not_equal(tf.math.reduce_sum(tf.math.abs(X), axis=-1), 0)
        logit_len = tf.math.reduce_sum(tf.cast(logit_padding, tf.int32), axis=-1)
        label_padding = tf.math.not_equal(Y, 0)
        label_len = tf.math.reduce_sum(tf.cast(label_padding, tf.int32), axis=-1)

        X = tf.transpose(X, [1, 0, 2]) # convert to logits_time_major   
        Y = tf.cast(Y, tf.int32)
        sparse_targets = tf.sparse.from_dense(Y)
        loss = tf.compat.v1.nn.ctc_loss(
                labels=sparse_targets, inputs=X, sequence_length=logit_len,
                ignore_longer_outputs_than_inputs=True, time_major=True)

        loss = tf.math.reduce_mean(loss / tf.cast(label_len, tf.float32))

        """
        compute CTC greedy decode error
        """
        decoded, _ = tf.nn.ctc_greedy_decoder(X, logit_len)
        err = tf.edit_distance(tf.cast(decoded[0], tf.int32), sparse_targets, normalize=True)
        err = tf.math.reduce_mean(err)

        return loss, err

    def mhat_greedy_decode(self, X, L, blank, eos_id):
        """                                         
        Transducer greedy decode search with reduced MHA predict network 
                                             
        Args:
            X: a Tensor with shape [B, T, D]
            L: a Tensor with shape [B]
            blank: a scalar

        Returns:
            Y: a Tensor with shape [B, U]
        """

        X = tf.keras.activations.swish(self.encoder_proj(X))
                                                                         
        B = tf.shape(X)[0]
        T = tf.shape(X)[1]
        pL = tf.cast(tf.cast(L, tf.float32) * 0.8, tf.int32)
        L -= 1

        sos = tf.ones([B, 1], tf.int32) * blank
        eos = tf.ones([B, 1], tf.int32) * eos_id 

        Y_all = tf.TensorArray(dtype=tf.int32, size=2*T+1, name="Y_all")
        Y_all = Y_all.write(0, sos)

        def predict_network_inference(Q, Y):
            """
            One step of MHA predict network inference

            Args:
                Q: a Tensor with shape [B, 1]
                Y: a Tensor with shape [B, T]

            Returns:
                out: a Tensor with shape [B, D]
            """
            k_ohot = tf.one_hot(Y,
                self.config.dst_vocab_size,
                on_value=1, off_value=0
            )

            q_ohot = tf.one_hot(Q,
                self.config.dst_vocab_size,
                on_value=1, off_value=0
            )

            k_embd = self.decoder_embedding(k_ohot)
            q_embd = self.decoder_embedding(q_ohot)
            if self.config.decoder.scale_embedding:
                k_embd = k_embd * (self.config.decoder.num_units ** 0.5)
                q_embd = q_embd * (self.config.decoder.num_units ** 0.5)

            N = tf.shape(Y)[1]

            if N == 1:
                bias = tf.zeros([B, 1, 1, 1])
            else:
                Y_eff = tf.slice(Y, [0, 1], [B, N-1])
                bias = tf.math.logical_or(
                    tf.math.equal(Y_eff, blank),
                    tf.math.equal(Y_eff, eos_id)
                )

                # pad zero at first place as eos token is effective
                bias = tf.pad(tf.cast(bias, tf.float32), [[0, 0], [1, 0]], "CONSTANT") * -1e30
                bias = tf.reshape(bias, [B, 1, 1, -1])

            #tf.print("Bias check: ", bias, tf.shape(bias)[-1], N)
            out, _ = self.mha(q_embd, k_embd, k_embd, bias)
            out = tf.keras.activations.swish(self.decoder_proj(out))

            return out 

        ### Initial state: equal with sos embed
        embd = predict_network_inference(sos, sos)

        X_indices = tf.expand_dims(tf.range(B), axis=-1)
        X_indices = tf.concat(
            [X_indices, 
            tf.zeros([B, 1], tf.int32)], 
            axis=-1
        )

        blank_penalty = tf.zeros([1, self.config.dst_vocab_size - 2], tf.float32)
        blank_penalty = tf.tile( 
            tf.concat(
                [blank_penalty, 
                 tf.constant([[-1.0, 0.0]])
                ], axis=-1
            ), multiples = [B, 1]
        )

        steps = tf.zeros([B, 1], tf.int32)
        Y_pred = sos
        for t in tf.range(2 * T - 1):
            X_enc = tf.gather_nd(X, X_indices)
            logit = tf.keras.activations.tanh(
                tf.expand_dims(X_enc, axis=1) + embd
            )

            proj = self.rnnt_proj(logit)
            prob = tf.nn.softmax(proj, axis=-1)

            x_exhausted = tf.math.less(X_indices[:, 1], L)[:, None]
            x_exhausted_f = tf.reshape(
                tf.cast(x_exhausted, tf.float32),
                shape = [B, -1, 1]
            )

            prob += (1 - x_exhausted_f) * tf.expand_dims(blank_penalty, axis=1)
            pred = tf.cast(
                tf.math.argmax(prob, axis=-1), tf.int32
            )

            resist_end = tf.cast(
                tf.logical_and(
                    tf.math.equal(pred, eos), 
                    tf.reshape(
                        tf.math.less(X_indices[:, 1], pL),
                        shape = [B, 1]
                    )
                ), tf.int32
            )

            pred = (1 - resist_end) * pred + resist_end * blank

            reach_end = tf.cast(tf.equal(Y_pred, eos), tf.int32)

            pred = pred * (1 - reach_end) + eos * reach_end
            pred = tf.reshape(pred, [B, 1])
            Y_all = Y_all.write(t+1, pred)

            Y_mat = tf.squeeze(tf.transpose(Y_all.stack(), [1, 0, 2]), axis=-1)
            Y_mat = tf.slice(Y_mat, [0, 0], [B, t+2])

            y_update = tf.math.not_equal(pred, sos)
            x_update = tf.logical_and(
                tf.logical_not(y_update), x_exhausted
            )

            steps += tf.cast(x_exhausted, tf.int32)

            x_update = tf.concat(
                [tf.zeros([B, 1], tf.int32),
                 tf.cast(x_update, tf.int32)
                ], axis=-1
            )
            X_indices += x_update

            y_update = tf.cast(y_update, tf.int32)
            Y_pred = Y_pred * (1 - y_update) + pred * y_update
            embd = predict_network_inference(Y_pred, Y_mat) 

            batch_end = tf.reduce_sum(tf.cast(tf.equal(pred, eos), tf.int32))
            if tf.math.equal(batch_end, B):
                break;

        Y_final = tf.slice(
            tf.transpose(Y_all.stack(), [1, 0, 2]),
            [0, 0, 0], [B, t+2, 1]
        )

        return Y_final, tf.squeeze(steps, axis=-1)

    def ce_loss(self, X, Y, L):
        """
        Compute fix-label loss

        Args:                                                                                         
            X: logits before softmax, a Tensor with shape [batch, length, dim]
            Y: label, a Tensor with shape [batch, length]
            L: length, a Tensor with shape [batch]

        Returns:
            loss: ctc loss, a Tensor
            error: ctc decode error, a Tensor
        """

        Y = Y[:,0:-1:4]
        batch_size = tf.shape(X)[0]
        len = tf.minimum(tf.shape(X)[1], tf.shape(Y)[1])

        #masks = tf.cast(tf.math.greater(Y, 0), tf.float32)
        masks = tf.sequence_mask(L, len, tf.float32)

        X = self.rnnt_proj(X)
        dim = tf.shape(X)[2]

        X = tf.slice(X, [0, 0, 0], [batch_size, len, dim])
        Y = tf.slice(Y, [0, 0], [batch_size, len])

        preds = tf.cast(tf.math.argmax(X, axis=-1), tf.int32)  
        probs = tf.nn.softmax(X) 
        Y_int32 = tf.cast(Y, tf.int32)

        base_indices = tf.range(batch_size * len)
        base_indices *= dim

        indices = tf.reshape(Y_int32, [-1]) + base_indices
        probs_gatherd = tf.gather(tf.reshape(probs, [-1]), indices) 

        probs_gatherd = tf.reshape(probs_gatherd, tf.shape(Y_int32))
        preds_gatherd = tf.equal(preds, Y_int32)
        lk = tf.math.reduce_sum(probs_gatherd * masks) / tf.math.reduce_sum(masks)
        acc = tf.math.reduce_sum(tf.cast(preds_gatherd, tf.float32) * masks) / tf.math.reduce_sum(masks)

        loss = tf.keras.losses.SparseCategoricalCrossentropy(    
            from_logits=True, reduction='none')(Y, X)

        mean_loss = tf.math.reduce_sum(loss * masks) / tf.math.reduce_sum(masks)

        return mean_loss, lk, acc 
