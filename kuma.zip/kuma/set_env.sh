export PATH=/mnt/AM4_disk2/zhangshusheng/env/python-3.8.5_gcc-8.2/bin/:$PATH
export LD_LIBRARY_PATH=/mnt/NFS2/env/cuda/cuda-10.1/lib64/:$LD_LIBRARY_PATH 
export LD_LIBRARY_PATH=/mnt/AM4_disk1/chenxu/run_env/cudnn10.0-7.6.5/lib64/:$LD_LIBRARY_PATH 
