"""Train main function"""

import os
import time
import yaml
import threading 
import logging
from argparse import ArgumentParser

from frontend.feature import DataReader 
from frontend.feature import pcm2fbank 
from models.keyword_spotting import KeywordSpotting as Transformer 

import numpy as np
import tensorflow as tf

class AttrDict(dict):
    """
    Dictionary whose keys can be accessed as attributes.
    """

    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)

    def __getattr__(self, item):
        if item not in self:
            return None
        if type(self[item]) is dict:
            self[item] = AttrDict(self[item])
        return self[item]

def train(config):
    logger = logging.getLogger('')

    """
    Data Reader and a new thread for ansync data enqueue 
    """ 
    data_reader = DataReader(config=config, is_training=True)

    """
    Specify input shape to avoid re-tracing, like placeholder
    """
    train_signature = [
        tf.TensorSpec(shape=(None, None), dtype=tf.float32),
        tf.TensorSpec(shape=(None, None), dtype=tf.float32),
        tf.TensorSpec(shape=(None, None), dtype=tf.float32),
        tf.TensorSpec(shape=(None, 1), dtype=tf.int32),
        tf.TensorSpec(shape=(None, 2), dtype=tf.int32),
        tf.TensorSpec(shape=(None, 2), dtype=tf.int32),
        tf.TensorSpec(shape=(None, 2), dtype=tf.int32),
    ] 
    num_in = len(train_signature)
    logging.info("Number of input: %d" %(num_in))

    num_devices = config.train.num_gpus
    devices = ['/gpu:%d' % i for i in range(num_devices)] if num_devices > 0 else ['/cpu:0']
    gpus = tf.config.list_physical_devices(device_type='GPU')
    for gpu in gpus:
        tf.config.experimental.set_memory_growth(gpu, True) 

    data_queue = tf.queue.FIFOQueue(config.queue_size, [t.dtype for t in train_signature])
    def async_enqueue():
        for epoch in range(1, config.train.num_epochs + 1):
            for batch in data_reader.get_training_batch():
                feat, src_label, tar_label, sample_num, begin, slice_f, slice_l = batch

                X = tf.convert_to_tensor(feat, tf.float32)
                Y = tf.convert_to_tensor(src_label, tf.float32)
                Z = tf.convert_to_tensor(tar_label, tf.float32)
                L = tf.convert_to_tensor(sample_num, tf.int32)
                B = tf.convert_to_tensor(begin, tf.int32)
                S_f = tf.convert_to_tensor(slice_f, tf.int32)
                S_l = tf.convert_to_tensor(slice_l, tf.int32)

                while data_queue.size() >= config.queue_size:
                    time.sleep(0.1)

                data_queue.enqueue([X, Y, Z, L, B, S_f, S_l])

            logging.info("Finish one epoch")
            if epoch != config.train.num_epochs:
                data_reader.reset()

        data_queue.close()

    async_threads = []
    for n in range(config.async_thread):
        t = threading.Thread(target=async_enqueue)
        t.start()
        async_threads.append(t)

    """
    Create a model instance
    """
    class CustomSchedule(tf.keras.optimizers.schedules.LearningRateSchedule):
        def __init__(self, d_model, warmup_steps=4000, scale=1.0):
            super(CustomSchedule, self).__init__()

            self.d_model = tf.cast(d_model, tf.float32)
            self.warmup_steps = warmup_steps
            self.scale = scale
            self.lr = 0.0

        def get_config(self):
            return {'custom_schedule' : self.lr}

        def __call__(self, step):
            arg1 = tf.math.rsqrt(step)
            arg2 = step * (self.warmup_steps ** -1.5)

            self.lr = self.scale * tf.math.rsqrt(self.d_model) * tf.math.minimum(arg1, arg2)
            self.lr = self.scale
            return self.lr
    
    strategy = tf.distribute.MirroredStrategy(devices=devices)
    with strategy.scope():
        step = 0
        mdl_instance = Transformer(config)

        learning_rate = CustomSchedule(config.encoder.encoder_pyramid[0]['num_units'], config.train.warmup_steps, config.train.learning_rate)

        """
        Optimizer
        """
        optimizer = tf.keras.optimizers.Adam(
                learning_rate, 
                beta_1=0.9,
                beta_2=0.98, 
                epsilon=1e-9)

        """
        Restore model from checkpoint
        """
        ckpt = tf.train.Checkpoint(optimizer=optimizer, model=mdl_instance, step=tf.Variable(step))
        manager = tf.train.CheckpointManager(ckpt, config.model_dir, max_to_keep=10, checkpoint_name="model_step")

        if manager.latest_checkpoint: 
            print("Restored from {}".format(manager.latest_checkpoint))
            ckpt.restore(manager.latest_checkpoint)
        else:
            print("Initializing from scratch.")

        def device_train_step(per_replica_val):
            X = per_replica_val[0]
            Y = per_replica_val[1]
            Z = per_replica_val[2]
            L = per_replica_val[3]

            with tf.GradientTape() as tape:
                pred1, pred2 = mdl_instance(X, Y, L, training=True)
                loss1, lk1, acc1 = mdl_instance.e2e_loss(pred1, Z)
                loss2, lk2, acc2 = mdl_instance.e2e_loss(pred2, Z)
                loss = loss1 + loss2

            gradients = tape.gradient(loss, mdl_instance.trainable_variables)

            """
            clip gradients by global norm
            """
            if config.train.grads_clip > 0:
                gradients, grad_norm = tf.clip_by_global_norm(gradients,
                    clip_norm=config.train.grads_clip)
            optimizer.apply_gradients(zip(gradients, mdl_instance.trainable_variables))

            return loss, lk1, acc1, lk2, acc2 

        @tf.function(input_signature=train_signature)
        def distributed_train_step(X, Y, Z, L, B, S_f, S_l):
            X_lst, Y_lst, Z_lst, L_lst = [], [], [], []
            for n in range(config.train.num_gpus):
                begin = tf.reshape(tf.slice(B, [n, 0], [1, 2]), [-1])
                s_f = tf.reshape(tf.slice(S_f, [n, 0], [1, 2]), [-1])
                s_l = tf.reshape(tf.slice(S_l, [n, 0], [1, 2]), [-1])
                X_lst.append(tf.slice(X, begin, s_f))
                Y_lst.append(tf.slice(Y, begin, s_l))
                Z_lst.append(tf.slice(Z, begin, s_l))
                L_lst.append(tf.slice(L, begin, [s_l[0], 1]))

            def dist_value_fn(ctx):
                id = ctx.replica_id_in_sync_group
                val = (tf.convert_to_tensor(X_lst[id], tf.float32),
                      tf.convert_to_tensor(Y_lst[id], tf.float32),
                      tf.convert_to_tensor(Z_lst[id], tf.float32),
                      tf.convert_to_tensor(L_lst[id], tf.int32))

                return val

            dist_vals = (strategy.experimental_distribute_values_from_function(dist_value_fn))

            loss, lk1, acc1, lk2, acc2 = strategy.run(device_train_step, args=(dist_vals,))
            loss = strategy.reduce(tf.distribute.ReduceOp.MEAN, loss, axis=None)
            lk1 = strategy.reduce(tf.distribute.ReduceOp.MEAN, lk1, axis=None)
            acc1 = strategy.reduce(tf.distribute.ReduceOp.MEAN, acc1, axis=None)
            lk2 = strategy.reduce(tf.distribute.ReduceOp.MEAN, lk2, axis=None)
            acc2 = strategy.reduce(tf.distribute.ReduceOp.MEAN, acc2, axis=None)
            lr = optimizer.get_config()['learning_rate']['config']['custom_schedule']
            return loss, lk1, acc1, lk2, acc2, lr

        mean_loss = tf.keras.metrics.Mean(name="mean_loss")
        mean_lk = tf.keras.metrics.Mean(name="mean_lk")
        mean_acc = tf.keras.metrics.Mean(name="mean_acc")
        mean_lk2 = tf.keras.metrics.Mean(name="mean_lk2")
        mean_acc2 = tf.keras.metrics.Mean(name="mean_acc2")
        mean_lr = tf.keras.metrics.Mean(name="mean_lr")

        while not data_queue.is_closed():
            if data_queue.size() > 0:
                start_time = time.time()
                [X, Y, Z, L, B, S_f, S_l] = data_queue.dequeue()

                loss, lk1, acc1, lk2, acc2, lr = distributed_train_step(X, Y, Z, L, B, S_f, S_l)
                mean_loss(loss)
                mean_acc(acc1) 
                mean_lk(lk1)
                mean_lk2(lk2)
                mean_acc2(acc2)
                mean_lr(lr)
                ckpt.step.assign_add(1)
                step = ckpt.step.read_value()
                logging.info('step: {0}\tloss: {1:.4f}\tlk: {2:.4f}\tacc: {3:.4f}\tlk: {4:.4f}\tacc: {5:.4f}\ttime: {6:.4f}\tlr: {7:.6f}\tbatch_size: {8}'.format(
                    step, mean_loss.result(), mean_lk.result(), mean_acc.result(), mean_lk2.result(), mean_acc2.result(), time.time()-start_time, mean_lr.result(), config.train.batch_size))

                mean_loss.reset_states()
                mean_acc.reset_states()
                mean_lk.reset_states()
                mean_acc2.reset_states()
                mean_lk2.reset_states()
                mean_lr.reset_states()

                """
                save checkpoint
                """
                if config.train.save_freq > 0 and step % config.train.save_freq == 0:
                    print("Saving model at step: {}".format(step))
                    manager.save(checkpoint_number=step)
    for t in async_threads:
        t.join()

def config_logging(log_file):
    logging.basicConfig(filename=log_file, level=logging.INFO,
                        format='%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s',
                        datefmt='%a, %d %b %Y %H:%M:%S', filemode='w')
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(filename)s[line:%(lineno)d] %(levelname)s %(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)

if __name__ == "__main__":
    # Parser
    parser = ArgumentParser()
    parser.add_argument('-c', '--config', dest='config')
    args = parser.parse_args()
    config = AttrDict(yaml.load(open(args.config)))

    # Logger
    if not os.path.exists(config.model_dir):
        os.makedirs(config.model_dir)
    config_logging(config.model_dir + '/train.log')

    import shutil
    shutil.copy(args.config, config.model_dir)

    # Train
    train(config)
