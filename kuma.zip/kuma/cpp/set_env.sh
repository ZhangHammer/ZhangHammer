export PATH=/mnt/AM4_disk2/zhangshusheng/env/python-3.8.5_gcc-8.2/bin/:$PATH
export PATH=/mnt/AM4_disk2/zhangshusheng/env/cuda-10.1/bin/:$PATH
export PATH=/opt/compiler/gcc-4.8.2/bin/:$PATH
export PATH=/mnt/AM4_disk2/zhangshusheng/env/cmake-3.18.0/cmake/data/bin/:$PATH
export LD_LIBRARY_PATH=/mnt/AM4_disk1/chenxu/run_env/cudnn10.0-7.6.5/lib64/:$LD_LIBRARY_PATH 
export LD_LIBRARY_PATH=/mnt/AM4_disk2/zhangshusheng/env/python-3.8.5_gcc-8.2/lib/:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/mnt/AM4_disk2/zhangshusheng/env/cuda-10.1/lib64/:$LD_LIBRARY_PATH
