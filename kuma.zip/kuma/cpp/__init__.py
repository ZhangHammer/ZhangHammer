import tensorflow as tf
from tensorflow.python.framework import ops

import os

lib_file = os.getcwd() + "/cpp/libkuma.so"
cpp_warp = tf.load_op_library(lib_file) 

def rnnt_loss(logit, 
        label, 
        logit_len, 
        label_len, 
        blank_id, 
        norm=True, 
        fast_emit=0.0):
    """
    Compute RNN-T loss between logit(without actavition) and 
    row label(without padding </s> or blank at beginint)

    Args:
        logit: a Tensor with shape [B, T, U+1, V], 
               RNN-T joint network output without  
               softmax or log_softmax activation
        label: a Tensor with shape [B, U] 
        logit_len: a Tensor with shape [B]
        label_len: a Tensor with shape [B]
        blank_id: a scalar

    Returns:
        loss: a Tensor with shape [B, 1]
    """

    loss, _ = cpp_warp.rnnt_loss(
                logit = logit,
                label = label,
                logit_length = logit_len,
                label_length = label_len,
                blank_idx = blank_id,
                loss_batch_norm=norm,
                fast_emit = fast_emit)
    return loss

@ops.RegisterGradient("RnntLoss")
def _RnntLossGrad(op, grad_loss, _):
    """
    Register RNN-T grads
    """
    grad = op.outputs[1]

    return [grad, None, None, None]

def rnnt_loss_v2(logit, 
        label, 
        logit_len, 
        label_len, 
        blank_id, 
        norm=True,
        fast_emit=0.0,
        from_logits=True):
    """
    Compute RNN-T loss between logit(without actavition) and 
    row label(without padding </s> or blank at beginint)
    in a memory efficient manner

    Args:
        logit: a Tensor with shape [L, V], 
               RNN-T joint network output without  
               softmax or log_softmax activation
        label: a Tensor with shape [B, U] 
        logit_len: a Tensor with shape [B]
        label_len: a Tensor with shape [B]
        blank_id: a scalar

    Returns:
        loss: a Tensor with shape [B, 1]
    """

    loss, _ = cpp_warp.rnnt_loss_v2(
                logit = logit,
                label = label,
                logit_length = logit_len,
                label_length = label_len,
                blank_idx = blank_id,
                loss_batch_norm=norm,
                fast_emit = fast_emit,
                from_logits = from_logits)
    return loss

@ops.RegisterGradient("RnntLossV2")
def _RnntLossV2Grad(op, grad_loss, _):
    """
    Register RNN-T grads
    """
    grad = op.outputs[1]

    return [grad, None, None, None]
