/**
* @file:     rnnt_ops.cc
* @author:   zhangshusheng@baidu.com
* @created:  2021-12-11 18:48
* @modified: 2021-12-11 18:48
* @brief: 
*
**/

#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "rnnt.h"
#include "cuda.h"
#include "cuda_runtime_api.h"
#include "unary_ops.h"

using namespace tensorflow;

using GPUDevice = Eigen::GpuDevice;
using CPUDevice = Eigen::ThreadPoolDevice;

REGISTER_OP("RnntLoss")
    .Attr("blank_idx: int = 0")
    .Attr("loss_batch_norm: bool = false")
    .Attr("fast_emit: float = 0.0")
    .Attr("dtype: {float}")
    .Input("logit: dtype")
    .Input("label: dtype")
    .Input("logit_length: int32")
    .Input("label_length: int32")
    .Output("loss: dtype")
    .Output("grad: dtype")
    .Doc("Compute RNN transducer loss and decode\n");

template <typename T>
class RnntLossOp : public OpKernel {
public:
    explicit RnntLossOp(OpKernelConstruction* ctx) : OpKernel(ctx) {
        OP_REQUIRES_OK(ctx, ctx->GetAttr("blank_idx", &_blank_idx));
        OP_REQUIRES_OK(ctx, ctx->GetAttr("loss_batch_norm", &_loss_batch_norm));
        OP_REQUIRES_OK(ctx, ctx->GetAttr("fast_emit", &_fast_emit));
    }  

    void Compute(OpKernelContext* ctx) override {
        const Tensor* logit;
        const Tensor* label;
        const Tensor* logit_length;
        const Tensor* label_length;

        OP_REQUIRES_OK(ctx, ctx->input("logit", &logit));
        OP_REQUIRES_OK(ctx, ctx->input("label", &label));
        OP_REQUIRES_OK(ctx, ctx->input("logit_length", &logit_length));
        OP_REQUIRES_OK(ctx, ctx->input("label_length", &label_length));

        const auto& logit_shape = logit->shape();
        const auto batch_size = logit_shape.dim_size(0);
        const auto max_T = logit_shape.dim_size(1);
        const auto max_U = logit_shape.dim_size(2);
        const auto vocab_size = logit_shape.dim_size(3); 

        OP_REQUIRES(ctx, batch_size == logit_length->dim_size(0),
            errors::InvalidArgument("len(logit_length) != batch_size",
                    "len(logit_length):  ", logit_length->dim_size(0),
                    "batch_size: ", batch_size));
        auto logit_length_v = logit_length->vec<int32_t>();
           
        OP_REQUIRES(ctx, batch_size == label_length->dim_size(0),
            errors::InvalidArgument("len(label_length) != batch_size",
                    "len(label_length):  ", label_length->dim_size(0),
                    "batch_size: ", batch_size));
        auto label_length_v = label_length->vec<int32_t>();

        Tensor* loss = NULL;
        Tensor* grad = NULL;
        OP_REQUIRES_OK(ctx, ctx->allocate_output("loss", logit_length->shape(), &loss));
        OP_REQUIRES_OK(ctx, ctx->allocate_output("grad", logit->shape(), &grad));
        cudaMemset(loss->flat<T>().data(), 0, loss->NumElements()*sizeof(T));
        cudaMemset(grad->flat<T>().data(), 0, grad->NumElements()*sizeof(T));

        /// Allocate temp space for alpha and beta
        Tensor alpha, beta, log_prob;
        auto workspace_size = TensorShape{batch_size * max_T * max_U};
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, workspace_size, &alpha));
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, workspace_size, &beta));
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, logit->shape(), &log_prob));

        compute_log_softmax<T>(
            ctx->eigen_device<GPUDevice>(),
            log_prob.flat<T>().data(),
            logit->flat<T>().data(),
            logit_length_v.data(),
            label_length_v.data(),
            batch_size,
            vocab_size,
            max_T,
            max_U);
 
        compute_rnnt_alpha<T>(
            ctx->eigen_device<GPUDevice>(),
            alpha.flat<T>().data(),
            loss->flat<T>().data(),
            log_prob.flat<T>().data(),
            label->flat<T>().data(),
            logit_length_v.data(),
            label_length_v.data(),
            batch_size,
            vocab_size,
            max_T,
            max_U, 
            _blank_idx);

        compute_rnnt_beta<T>(
            ctx->eigen_device<GPUDevice>(),
            beta.flat<T>().data(),
            log_prob.flat<T>().data(),
            label->flat<T>().data(),
            logit_length_v.data(),
            label_length_v.data(),
            batch_size, 
            vocab_size,
            max_T, 
            max_U,
            _blank_idx);

        if (fabs(_fast_emit - T(0.0)) < 1e-4) {
            compute_rnnt_grad<T>(
                ctx->eigen_device<GPUDevice>(),
                grad->flat<T>().data(),
                log_prob.flat<T>().data(),
                label->flat<T>().data(),
                alpha.flat<T>().data(),
                beta.flat<T>().data(),
                logit_length_v.data(),
                label_length_v.data(),
                batch_size,
                max_T,
                max_U,
                vocab_size,
                _blank_idx,
                _loss_batch_norm);
    
        } else {
            fast_emit_regularization<T>(
                ctx->eigen_device<GPUDevice>(),
                grad->flat<T>().data(),
                log_prob.flat<T>().data(),
                label->flat<T>().data(),
                alpha.flat<T>().data(),
                beta.flat<T>().data(),
                logit_length_v.data(),
                label_length_v.data(),
                batch_size,
                max_T,
                max_U,
                vocab_size,
                _blank_idx,
                _loss_batch_norm,
                _fast_emit);
        }
        //cudaMemcpy(grad->flat<T>().data(), log_prob.flat<T>().data(), grad->NumElements() * sizeof(T), cudaMemcpyDeviceToHost);
        //cudaMemcpy(alpha_o->flat<T>().data(), alpha.flat<T>().data(), alpha_o->NumElements() * sizeof(T), cudaMemcpyDeviceToHost);
        //cudaMemcpy(beta_o->flat<T>().data(), beta.flat<T>().data(), beta_o->NumElements() * sizeof(T), cudaMemcpyDeviceToHost);
    }

private:
    int _blank_idx;
    bool _loss_batch_norm;
    T _fast_emit; 
};

REGISTER_KERNEL_BUILDER(Name("RnntLoss").Device(DEVICE_GPU).TypeConstraint<float>("dtype"), RnntLossOp<float>);

REGISTER_OP("RnntLossV2")
    .Attr("blank_idx: int = 0")
    .Attr("loss_batch_norm: bool = false")
    .Attr("fast_emit: float = 0.0")
    .Attr("from_logits: bool = true")
    .Attr("dtype: {float}")
    .Input("logit: dtype")
    .Input("label: dtype")
    .Input("logit_length: int32")
    .Input("label_length: int32")
    .Output("loss: dtype")
    .Output("grad: dtype")
    .Doc("Compute RNN transducer loss in memory efficient manner\n");

template <typename T>
class RnntLossV2Op : public OpKernel {
public:
    explicit RnntLossV2Op(OpKernelConstruction* ctx) : OpKernel(ctx) {
        OP_REQUIRES_OK(ctx, ctx->GetAttr("blank_idx", &_blank_idx));
        OP_REQUIRES_OK(ctx, ctx->GetAttr("loss_batch_norm", &_loss_batch_norm));
        OP_REQUIRES_OK(ctx, ctx->GetAttr("fast_emit", &_fast_emit));
        OP_REQUIRES_OK(ctx, ctx->GetAttr("from_logits", &_from_logits));
    }

    void Compute(OpKernelContext* ctx) override {
        const Tensor* logit;
        const Tensor* label;
        const Tensor* logit_length;
        const Tensor* label_length;

        OP_REQUIRES_OK(ctx, ctx->input("logit", &logit));
        OP_REQUIRES_OK(ctx, ctx->input("label", &label));
        OP_REQUIRES_OK(ctx, ctx->input("logit_length", &logit_length));
        OP_REQUIRES_OK(ctx, ctx->input("label_length", &label_length));

        const auto& logit_shape = logit->shape();
        const auto& label_shape = label->shape();
        const auto batch_size = label_shape.dim_size(0);
        const auto graph_size = logit_shape.dim_size(0);
        const auto vocab_size = logit_shape.dim_size(1);

        OP_REQUIRES(ctx, batch_size == logit_length->dim_size(0),
            errors::InvalidArgument("len(logit_length) != batch_size",
                    "len(logit_length):  ", logit_length->dim_size(0),
                    "batch_size: ", batch_size));
        auto logit_length_v = logit_length->vec<int32_t>();

        OP_REQUIRES(ctx, batch_size == label_length->dim_size(0),
            errors::InvalidArgument("len(label_length) != batch_size",
                    "len(label_length):  ", label_length->dim_size(0),
                    "batch_size: ", batch_size));
        auto label_length_v = label_length->vec<int32_t>();

        Tensor* loss = NULL;
        Tensor* grad = NULL;
        OP_REQUIRES_OK(ctx, ctx->allocate_output("loss", logit_length->shape(), &loss));
        OP_REQUIRES_OK(ctx, ctx->allocate_output("grad", logit->shape(), &grad));
        cudaMemset(loss->flat<T>().data(), 0, loss->NumElements()*sizeof(T));
        cudaMemset(grad->flat<T>().data(), 0, grad->NumElements()*sizeof(T));

        /// Allocate temp space for alpha and beta
        Tensor alpha, beta, log_prob;
        auto workspace_size = TensorShape{graph_size};
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, workspace_size, &alpha));
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, workspace_size, &beta));
        OP_REQUIRES_OK(ctx, ctx->allocate_temp(DT_FLOAT, logit->shape(), &log_prob));
        cudaMemset(alpha.flat<T>().data(), 0, alpha.NumElements()*sizeof(T));
        cudaMemset(beta.flat<T>().data(), 0, beta.NumElements()*sizeof(T));
        cudaMemset(log_prob.flat<T>().data(), 0, log_prob.NumElements()*sizeof(T));

        if (_from_logits) {
            efficient_compute_log_softmax<T>(
                ctx->eigen_device<GPUDevice>(),
                log_prob.flat<T>().data(),
                logit->flat<T>().data(),
                logit_length_v.data(),
                label_length_v.data(),
                batch_size,
                vocab_size,
                graph_size);
        } else {
            log_op<T>(ctx->eigen_device<GPUDevice>(),
                log_prob.flat<T>().data(), 
                logit->flat<T>().data(),
                logit->NumElements());
        }

        efficient_compute_rnnt_alpha<T>(
            ctx->eigen_device<GPUDevice>(),
            alpha.flat<T>().data(),
            loss->flat<T>().data(),
            log_prob.flat<T>().data(),
            label->flat<T>().data(),
            logit_length_v.data(),
            label_length_v.data(),
            batch_size,
            vocab_size,
            label_shape.dim_size(1),
            _blank_idx);

        efficient_compute_rnnt_beta<T>(
            ctx->eigen_device<GPUDevice>(),
            beta.flat<T>().data(),
            log_prob.flat<T>().data(),
            label->flat<T>().data(),
            logit_length_v.data(),
            label_length_v.data(),
            batch_size, 
            vocab_size,
            label_shape.dim_size(1),
            _blank_idx);

        if (_from_logits) {
            efficient_compute_rnnt_grad<T>(
                ctx->eigen_device<GPUDevice>(),
                grad->flat<T>().data(),
                log_prob.flat<T>().data(),
                label->flat<T>().data(),
                alpha.flat<T>().data(),
                beta.flat<T>().data(),
                logit_length_v.data(),
                label_length_v.data(),
                batch_size,
                vocab_size,
                graph_size,
                label_shape.dim_size(1),
                _blank_idx,
                _loss_batch_norm);
        } else {
            efficient_compute_rnnt_grad_v2<T>(
                ctx->eigen_device<GPUDevice>(),
                grad->flat<T>().data(),
                log_prob.flat<T>().data(),
                label->flat<T>().data(),
                alpha.flat<T>().data(),
                beta.flat<T>().data(),
                logit_length_v.data(),
                label_length_v.data(),
                batch_size,
                vocab_size,
                graph_size,
                label_shape.dim_size(1),
                _blank_idx,
                _loss_batch_norm);
        }
    }

private:
    int _blank_idx;
    bool _loss_batch_norm;
    bool _from_logits;
    T _fast_emit; 
};

REGISTER_KERNEL_BUILDER(Name("RnntLossV2").Device(DEVICE_GPU).TypeConstraint<float>("dtype"), RnntLossV2Op<float>);
