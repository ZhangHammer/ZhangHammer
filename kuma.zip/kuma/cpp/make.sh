CUDA_PATH=/mnt/AM4_disk2/zhangshusheng/env/cuda-10.1/
TF_INC=$(python -c 'import tensorflow as tf; print(tf.sysconfig.get_include())')
TF_LIB=$(python -c 'import tensorflow as tf; print(tf.sysconfig.get_lib())')
TF_CFLAGS=( $(python -c 'import tensorflow as tf; print(" ".join(tf.sysconfig.get_compile_flags()))') )
TF_LFLAGS=( $(python -c 'import tensorflow as tf; print(" ".join(tf.sysconfig.get_link_flags()))') )
echo $TF_INC
echo $TF_LIB
if [ "$1" == "P40" ];then
echo "Making on P40 machine"
arch_version=sm_61
elif [ "$1" == "V100" ];then 
echo "Making on V100 machine"
arch_version=sm_70
fi

nvcc -std=c++11 -c -o src/cus/rnnt.cu.o src/cus/rnnt.cu -I $TF_INC -I ${CUDA_PATH}/include -I./inc/cus -I./inc/utils -D GOOGLE_CUDA=1 -x cu -Xcompiler -fPIC --expt-relaxed-constexpr -arch=$arch_version -g
nvcc -std=c++11 -c -o src/cus/unary_ops.cu.o src/cus/unary_ops.cu -I $TF_INC -I ${CUDA_PATH}/include -I./inc/cus -I./inc/utils -D GOOGLE_CUDA=1 -x cu -Xcompiler -fPIC --expt-relaxed-constexpr -arch=$arch_version -g
g++ -std=c++11 -shared -o libkuma.so src/ops/rnnt_ops.cc src/cus/rnnt.cu.o src/cus/unary_ops.cu.o -I./inc/cus -I./inc/utils -I ${CUDA_PATH}/include -D GOOGLE_CUDA=1 -fPIC ${TF_CFLAGS[@]} ${TF_LFLAGS[@]} -lcudart -L ${CUDA_PATH}/lib64 -O2 -g
