/**
* @file:     functor.h
* @author:   zhangshusheng@baidu.com
* @created:  2022-04-01 11:43
* @modified: 2022-04-01 11:43
* @brief: 
*
**/

#ifndef KUMA_CPP_UTILS_FUNCTOR_H
#define KUMA_CPP_UTILS_FUNCTOR_H

template <typename T>
struct Log {
    T eps;

    Log(): eps(1e-6) {}

    __host__ __device__
    T operator()(const T v) {
        return log(v + eps);
    }
};

#endif /// KUMA_CPP_UTILS_FUNCTOR_H
