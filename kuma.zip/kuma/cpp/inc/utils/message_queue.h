/**
 * MessageQueue.h
   copy from houyi
 */

#ifndef KUMA_CPP_UTILS_MESSAGE_QUEUE_H
#define KUMA_CPP_UTILS_MESSAGE_QUEUE_H

#include <pthread.h>
#include <deque>
#include <stdio.h>
#include <util.h>

namespace kuma {

template < class T, int QueueSize = -1 >
class MessageQueue {
private:
    std::deque<T> _msg_queue;
    pthread_mutex_t _mutex_1;
    pthread_cond_t _cond_1;
    pthread_cond_t _cond_2;
    int _ex_queue_size;
    int _ex_queue_low;

public:
    MessageQueue(int max = -1) {
        pthread_mutex_init(&this->_mutex_1, NULL);
        pthread_cond_init(&this->_cond_1, NULL);
        pthread_cond_init(&this->_cond_2, NULL);
        _ex_queue_size = QueueSize;
        _ex_queue_low = -1;

        if (max > 0) {
            _ex_queue_size = max;
        }
    }

    ~MessageQueue() {
        pthread_mutex_destroy(&this->_mutex_1);
        pthread_cond_destroy(&this->_cond_1);
        pthread_cond_destroy(&this->_cond_2);
    }

    std::deque<T>& msg_queue() {
        return _msg_queue;
    }

    void lock() {
        pthread_mutex_lock(&this->_mutex_1);
    }

    void unlock() {
        pthread_mutex_unlock(&this->_mutex_1);
    }

    void set_max_length(int max, int min = -1) {
        _ex_queue_size = max;
        _ex_queue_low = min;
    }

    void push(T msg) {
        pthread_mutex_lock(&this->_mutex_1);

        struct timespec now{};
        struct timespec timeout{};
        // if queue is too full
        while (_ex_queue_size > 0
                && int(this->_msg_queue.size()) >= _ex_queue_size) {
            if (houyi::train::g_exception_ptr){
                pthread_mutex_unlock(&this->_mutex_1);
                return;
            }
            clock_gettime(CLOCK_REALTIME, &now);
            timeout.tv_sec = now.tv_sec + 5;
//            pthread_cond_wait(&this->_cond_2, &this->_mutex_1);
            pthread_cond_timedwait(&this->_cond_2, &this->_mutex_1, &timeout);
        }

        // enqueue
        this->_msg_queue.push_back(msg);
        pthread_mutex_unlock(&this->_mutex_1);
        pthread_cond_signal(&this->_cond_1);
    };

    T pop() {
        pthread_mutex_lock(&this->_mutex_1);

        struct timespec now{};
        struct timespec timeout{};
        while (this->_msg_queue.empty()) {
            // mu_queue should be locked before calling pthread_cond_wait
            // mu_queue will be locked by the callee after pthread_cond_wait return
            if (houyi::train::g_exception_ptr){
                pthread_mutex_unlock(&this->_mutex_1);
                std::rethrow_exception(g_exception_ptr);
            }
            clock_gettime(CLOCK_REALTIME, &now);
            timeout.tv_sec = now.tv_sec + 5;
//            pthread_cond_wait(&this->_cond_1, &this->_mutex_1);
            pthread_cond_timedwait(&this->_cond_1, &this->_mutex_1, &timeout);
        }

        T m = this->_msg_queue.front();
        this->_msg_queue.pop_front();
        pthread_mutex_unlock(&this->_mutex_1);

        if ((_ex_queue_size > 0 && _ex_queue_low < 0)
                || (_ex_queue_low >= 0 && int(this->_msg_queue.size()) <= _ex_queue_low)) {
            pthread_cond_signal(&this->_cond_2);
        }

        return m;
    }

    T front() {
        pthread_mutex_lock(&this->_mutex_1);

        struct timespec now{};
        struct timespec timeout{};
        while (this->_msg_queue.empty()) {
            // mu_queue should be locked before calling pthread_cond_wait
            // mu_queue will be locked by the callee after pthread_cond_wait return
            if (houyi::train::g_exception_ptr){
                pthread_mutex_unlock(&this->_mutex_1);
                std::rethrow_exception(g_exception_ptr);
            }
            clock_gettime(CLOCK_REALTIME, &now);
            timeout.tv_sec = now.tv_sec + 5;
//            pthread_cond_wait(&this->_cond_1, &this->_mutex_1);
            pthread_cond_timedwait(&this->_cond_1, &this->_mutex_1, &timeout);
        }

        T m = this->_msg_queue.front();
        pthread_mutex_unlock(&this->_mutex_1);
        return m;
    }

    bool try_pop(T& in) {
        pthread_mutex_lock(&this->_mutex_1);
    
        if (this->_msg_queue.empty()) {
            pthread_mutex_unlock(&this->_mutex_1);
            return false;
        } 

        while (this->_msg_queue.empty()) {
            // mu_queue should be locked before calling pthread_cond_wait
            // mu_queue will be locked by the callee after pthread_cond_wait return
            pthread_cond_wait(&this->_cond_1, &this->_mutex_1);
        }

        T m = this->_msg_queue.front();
        this->_msg_queue.pop_front();
        pthread_mutex_unlock(&this->_mutex_1);

        if ((_ex_queue_size > 0 && _ex_queue_low < 0)
                || (_ex_queue_low >= 0 && int(this->_msg_queue.size()) <= _ex_queue_low)) {
            pthread_cond_signal(&this->_cond_2);
        }
        in = m;
        return true;
    }

    size_t size() {
        return this->_msg_queue.size();
    }

    void clean() {
        //pthread_mutex_lock(&this->_mutex_1);
        size_t sz = size();

        for (size_t i = 0; i < sz; i++) {
            T e = pop();

            if (e) {
                delete e;
                e = NULL;
            }
        }

        //pthread_mutex_unlock(&this->_mutex_1);
    }
};

}i /// namespace kuma

#endif
