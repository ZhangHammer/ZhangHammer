/**
* @file:     unary_ops.h
* @author:   zhangshusheng@baidu.com
* @created:  2022-04-01 11:38
* @modified: 2022-04-01 11:38
* @brief: 
*
**/

#ifndef KUMA_CPP_CUS_UNARY_H
#define KUMA_CPP_CUS_UNARY_H

#include "unsupported/Eigen/CXX11/Tensor"

using GPUDevice = Eigen::GpuDevice;

template <typename T>
void log_op(const GPUDevice& device, 
    T* out, const T* in,
    unsigned long size);

#endif /// KUMA_CPP_CUS_UNARY_H
