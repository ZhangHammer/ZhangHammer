/**
* @file:     rnnt.h
* @author:   zhangshusheng@baidu.com
* @created:  2021-12-13 14:58
* @modified: 2021-12-13 14:58
* @brief: 
*
**/

#ifndef KUMA_CPP_CUS_RNNT_H
#define KUMA_CPP_CUS_RNNT_H

#include "unsupported/Eigen/CXX11/Tensor"

using GPUDevice = Eigen::GpuDevice;

template <typename T>
void compute_rnnt_alpha(const GPUDevice& device, 
            T* alpha, T* cost,
            const T* log_prob,
            const T* label,
            const int* TL, 
            const int* UL,
            int B, int V,
            int max_T, 
            int max_U,
            int blank_id); 

template <typename T>
void compute_rnnt_beta(const GPUDevice& device, 
            T* beta, 
            const T* log_prob,
            const T* label,
            const int* TL, 
            const int* UL,
            int B, int V,
            int max_T, 
            int max_U,
            int blank_id); 

template <typename T>
void compute_rnnt_grad(const GPUDevice& device,
            T* grad,
            const T* log_prob,
            const T* label,
            const T* alpha,
            const T* beta,
            const int* TL,
            const int* UL,
            int B, 
            int max_T, 
            int max_U,
            int V, 
            int blank_id,
            bool loss_batch_norm); 

template <typename T>
void fast_emit_regularization(const GPUDevice& device,
            T* grad,
            const T* log_prob,
            const T* label,
            const T* alpha,
            const T* beta,
            const int* TL,
            const int* UL,
            int B, 
            int max_T, 
            int max_U,
            int V, 
            int blank_id,
            bool loss_batch_norm,
            T lambda); 

template <typename T>
void compute_log_softmax(const GPUDevice& device,
            T* out, const T* in,
            const int* TL,
            const int* UL, 
            int B, int V,
            int max_T,
            int max_U); 

template <typename T>
void efficient_compute_rnnt_alpha(const GPUDevice& device, 
            T* alpha, T* cost,
            const T* log_prob,
            const T* label,
            const int* TL,
            const int* UL,
            int B, int V,
            int U_size,
            int blank_id); 

template <typename T>
void efficient_compute_rnnt_beta(const GPUDevice& device, 
            T* beta,
            const T* log_prob,
            const T* label,
            const int* TL, 
            const int* UL,
            int B, int V,
            int U_size,
            int blank_id); 

template <typename T>
void efficient_compute_rnnt_grad(const GPUDevice& device,
            T* grad,
            const T* log_prob,
            const T* label,
            const T* alpha,
            const T* beta,
            const int* TL,
            const int* UL,
            int B, 
            int V, 
            int graph_size,
            int blank_id,
            int U_size,
            bool loss_batch_norm); 

template <typename T>
void efficient_compute_rnnt_grad_v2(
            const GPUDevice& device,
            T* grad,
            const T* log_prob,
            const T* label,
            const T* alpha,
            const T* beta,
            const int* TL,
            const int* UL,
            int B, 
            int V, 
            int graph_size,
            int blank_id,
            int U_size,
            bool loss_batch_norm); 

template <typename T>
void efficient_compute_log_softmax(const GPUDevice& device,
            T* out, 
            const T* in,
            const int* TL,
            const int* UL, 
            int B, int V,
            int graph_size); 

#endif /// KUMA_CPP_CUS_RNNT_H 
